# XTREME TITAN OFFICIAL AutoPay — AndroidForge v1.1.0

এটি শুধু ওয়েবসাইট অ্যাডমিনের Android ফোনের জন্য Admin SMS Bridge।

## AndroidForge Build
1. এই ZIP-টি AndroidForge-এ upload করুন।
2. Android / Gradle project auto-detection নির্বাচন করুন।
3. Build সম্পন্ন হলে APK install করুন।

## Website API আগে upload করুন
`XTREME_TITAN_OFFICIAL_Website_MATCHED_AutoPay_API_v1.2.0.zip` থেকে সম্পূর্ণ website deploy করুন, অথবা আপনার live website-এর `config.php`-এর একই root-এ `website-mobile-api` folder upload/replace করুন।

## Login
- Username / email / phone: Website Admin account-এর সংরক্ষিত identifier দিন।
- Password: Website Admin password দিন।
- API URL: `https://xtremetitanofficial.gamer.free/website-mobile-api`
- Setup screen-এ ভুল করে `.gamer.fr` দিলে অ্যাপ সেটিকে documented `.gamer.free` ঠিকানায় সংশোধন করবে।

Android অ্যাপ login-এ URL-encoded form body পাঠায়; matching Website API `login.php` JSON এবং form-urlencoded—দুই format-ই গ্রহণ করে। Login শুধুমাত্র website-এর `admins` table অথবা `users` table-এ admin role থাকা account-কে অনুমতি দেয়।

## সীমাবদ্ধতা
- এটি AndroidForge source project; prebuilt APK নয়। AndroidForge-এ build করতে হবে।
- SMS access Android permission ও device/OS policy-র ওপর নির্ভরশীল।
- SMS notification স্বয়ংক্রিয়ভাবে customer wallet-এ টাকা যোগ করে না; SMS শুধু admin review-এর জন্য সংরক্ষিত হয়।
- প্রথমে test/staging copy-তে পরীক্ষা করুন।
