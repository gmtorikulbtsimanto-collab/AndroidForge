package com.xtremetitan.official.autopay;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import android.net.Uri;
import org.json.JSONObject;
import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

public class MainActivity extends Activity {
 private static final int BG=0xff050b08,PANEL=0xff101a12,LINE=0xff31552a,GREEN=0xff8cff28,WHITE=0xfff3ffe9,MUTED=0xffa6b99b,REQ=501;
 private String api="https://xtremetitanofficial.gamer.free/website-mobile-api",token="";
 private EditText identifier,password,apiInput; private TextView status,summary; private Button loginButton,smsButton; private boolean busy=false;
 private SharedPreferences prefs;
 @Override public void onCreate(Bundle b){super.onCreate(b);getWindow().setStatusBarColor(BG);getWindow().setNavigationBarColor(BG);prefs=getSharedPreferences("xt_autopay",MODE_PRIVATE);token=prefs.getString("token","");api=prefs.getString("api",api);showLogin();}
 private int dp(float v){return (int)(v*getResources().getDisplayMetrics().density+.5f);}
 private GradientDrawable bg(int c,int s,int r){GradientDrawable d=new GradientDrawable();d.setColor(c);d.setCornerRadius(dp(r));if(s!=0)d.setStroke(dp(1),s);return d;}
 private TextView txt(String s,int z,int c,boolean b){TextView t=new TextView(this);t.setText(s);t.setTextSize(z);t.setTextColor(c);if(b)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);return t;}
 private LinearLayout col(){LinearLayout l=new LinearLayout(this);l.setOrientation(1);return l;}
 private void pad(View v,int n){v.setPadding(dp(n),dp(n),dp(n),dp(n));}
 private EditText field(String h,boolean secret){EditText e=new EditText(this);e.setSingleLine(true);e.setHint(h);e.setTextColor(WHITE);e.setHintTextColor(MUTED);e.setPadding(dp(13),dp(10),dp(13),dp(10));e.setBackground(bg(0xff09110b,LINE,12));if(secret)e.setInputType(129);return e;}
 private Button btn(String s){Button b=new Button(this);b.setText(s);b.setTextColor(0xff102006);b.setTypeface(null,Typeface.BOLD);b.setAllCaps(false);b.setBackground(bg(GREEN,0,13));return b;}
 private void label(LinearLayout p,String s){TextView t=txt(s,10,MUTED,true);LinearLayout.LayoutParams x=new LinearLayout.LayoutParams(-1,-2);x.topMargin=dp(13);x.bottomMargin=dp(6);p.addView(t,x);}
 private void card(LinearLayout p,View v){v.setBackground(bg(PANEL,LINE,18));pad(v,16);LinearLayout.LayoutParams x=new LinearLayout.LayoutParams(-1,-2);x.bottomMargin=dp(14);p.addView(v,x);}
 private void shell(LinearLayout root){ScrollView sc=new ScrollView(this);sc.setBackgroundColor(BG);sc.setFillViewport(true);sc.addView(root);setContentView(sc);}
 private void header(LinearLayout root){ImageView logo=new ImageView(this);logo.setImageResource(com.xtremetitan.official.autopay.R.drawable.autopay_logo);logo.setScaleType(ImageView.ScaleType.FIT_CENTER);LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(dp(116),dp(116));lp.gravity=Gravity.CENTER_HORIZONTAL;lp.bottomMargin=dp(12);root.addView(logo,lp);TextView t=txt("XTREME TITAN OFFICIAL",11,GREEN,true);root.addView(t);TextView h=txt("AutoPay",31,WHITE,true);LinearLayout.LayoutParams x=new LinearLayout.LayoutParams(-1,-2);x.topMargin=dp(4);root.addView(h,x);TextView sub=txt("ADMIN-ONLY PAYMENT SMS BRIDGE",11,MUTED,true);root.addView(sub);}
 private void showLogin(){
  LinearLayout root=col();root.setPadding(dp(20),dp(24),dp(20),dp(30));shell(root);header(root);
  LinearLayout box=col();card(root,box);box.addView(txt("Administrator sign in",19,WHITE,true));TextView info=txt("Admin only. Sign in using the username, Gmail/email or phone number saved in the website Admin > Account Management page.",12,MUTED,false);info.setLineSpacing(dp(3),1);LinearLayout.LayoutParams ip=new LinearLayout.LayoutParams(-1,-2);ip.topMargin=dp(8);box.addView(info,ip);
  label(box,"ADMIN USERNAME / EMAIL / PHONE");identifier=field("Username, Gmail or phone number",false);box.addView(identifier);label(box,"ADMIN PASSWORD");password=field("Password",true);box.addView(password);
  label(box,"WEBSITE API URL");apiInput=field("https://your-domain/website-mobile-api",false);apiInput.setText(api);box.addView(apiInput);
  loginButton=btn("ADMIN LOGIN");LinearLayout.LayoutParams bp=new LinearLayout.LayoutParams(-1,-2);bp.topMargin=dp(18);box.addView(loginButton,bp);loginButton.setOnClickListener(v->login());
  root.addView(txt("Only users with role=admin in the website database can sign in.",11,MUTED,false));
 }
 private interface Done{void call(JSONObject j,String err);}
 private void req(String path,String method,JSONObject body,boolean auth,Done done){
  new Thread(()->{HttpURLConnection c=null;try{String base=normalizeApiBase(apiInput!=null?apiInput.getText().toString():api);c=(HttpURLConnection)new URL(base+path).openConnection();c.setRequestMethod(method);c.setConnectTimeout(20000);c.setReadTimeout(20000);c.setRequestProperty("Accept","application/json");if(body!=null){c.setDoOutput(true);boolean loginRequest=path.equals("/login.php");if(loginRequest){c.setRequestProperty("Content-Type","application/x-www-form-urlencoded; charset=UTF-8");StringBuilder form=new StringBuilder();java.util.Iterator<String> it=body.keys();while(it.hasNext()){String k=it.next();if(form.length()>0)form.append('&');form.append(java.net.URLEncoder.encode(k,"UTF-8")).append('=').append(java.net.URLEncoder.encode(body.optString(k,""),"UTF-8"));}try(OutputStream o=c.getOutputStream()){o.write(form.toString().getBytes(StandardCharsets.UTF_8));}}else{c.setRequestProperty("Content-Type","application/json; charset=UTF-8");try(OutputStream o=c.getOutputStream()){o.write(body.toString().getBytes(StandardCharsets.UTF_8));}}}if(auth)c.setRequestProperty("Authorization","Bearer "+token);int code=c.getResponseCode();InputStream in=code>=200&&code<300?c.getInputStream():c.getErrorStream();ByteArrayOutputStream out=new ByteArrayOutputStream();byte[] buf=new byte[2048];int n;while((n=in.read(buf))>0)out.write(buf,0,n);String response=out.toString("UTF-8").trim();JSONObject j;try{j=new JSONObject(response);}catch(Exception parse){if(response.startsWith("<")||response.toLowerCase().contains("<html"))throw new Exception("Hosting returned an HTML page (HTTP "+code+") for "+path+". API URL used: "+base+". Check hosting security/redirect rules or upload the latest login.php.");throw new Exception("Invalid API response (HTTP "+code+"). Check the website API setup.");}if(code<200||code>=300)throw new Exception(j.optString("message","HTTP "+code));runOnUiThread(()->done.call(j,null));}catch(Exception e){String m=e.getMessage()==null?"Network error":e.getMessage();runOnUiThread(()->done.call(null,m));}finally{if(c!=null)c.disconnect();}}).start();
 }
 private String normalizeApiBase(String value){
  String v=value==null?"":value.trim();
  // The website package documents gamer.free; repair the common gamer.fr typo from setup.
  v=v.replaceFirst("(?i)^https://xtremetitanofficial\\.gamer\\.fr(?=/|$)","https://xtremetitanofficial.gamer.free");
  while(v.endsWith("/"))v=v.substring(0,v.length()-1);
  if(v.endsWith("/login.php"))v=v.substring(0,v.length()-10);
  if(v.endsWith("/health.php"))v=v.substring(0,v.length()-11);
  if(!v.toLowerCase().endsWith("/website-mobile-api"))v+="/website-mobile-api";
  return v;
 }
 private void login(){if(busy)return;String id=identifier.getText().toString().trim(),pw=password.getText().toString();if(id.isEmpty()||pw.isEmpty()){toast("Enter admin login details.");return;}api=normalizeApiBase(apiInput.getText().toString());apiInput.setText(api);JSONObject b=new JSONObject();try{b.put("identifier",id);b.put("password",pw);b.put("device_name","XTREME TITAN AutoPay Admin Phone");}catch(Exception e){}busy=true;loginButton.setEnabled(false);req("/login.php","POST",b,false,(j,e)->{busy=false;loginButton.setEnabled(true);if(e!=null){toast(e);return;}token=j.optString("token","");prefs.edit().putString("token",token).putString("api",api).apply();password.setText("");showDashboard();});}
 private void showDashboard(){
  LinearLayout root=col();root.setPadding(dp(20),dp(24),dp(20),dp(30));shell(root);header(root);
  LinearLayout top=col();card(root,top);top.addView(txt("Admin device connected",18,GREEN,true));top.addView(txt("Customers use the website only. This app listens for incoming payment notification SMS on this admin phone.",12,MUTED,false));
  LinearLayout methods=col();card(root,methods);methods.addView(txt("SUPPORTED PAYMENT SOURCES",11,GREEN,true));methods.addView(txt("bKash   ·   Nagad   ·   Rocket   ·   Upay",17,WHITE,true));
  LinearLayout sms=col();card(root,sms);sms.addView(txt("SMS capture",19,WHITE,true));status=txt("SMS permission is required to detect incoming payment alerts.",12,MUTED,false);LinearLayout.LayoutParams st=new LinearLayout.LayoutParams(-1,-2);st.topMargin=dp(8);sms.addView(status,st);
  smsButton=btn("ENABLE PAYMENT SMS ACCESS");LinearLayout.LayoutParams sb=new LinearLayout.LayoutParams(-1,-2);sb.topMargin=dp(16);sms.addView(smsButton,sb);smsButton.setOnClickListener(v->requestSmsPermission());
  LinearLayout recent=col();card(root,recent);recent.addView(txt("Last captured notification",17,WHITE,true));summary=txt(prefs.getString("last_sms","No payment SMS captured yet."),12,MUTED,false);summary.setLineSpacing(dp(3),1);LinearLayout.LayoutParams rp=new LinearLayout.LayoutParams(-1,-2);rp.topMargin=dp(8);recent.addView(summary,rp);
  Button logout=btn("LOG OUT");root.addView(logout);logout.setOnClickListener(v->{token="";prefs.edit().remove("token").apply();reqLogout();showLogin();});
  if(hasSmsPermission()){status.setText("SMS permission enabled. Waiting for supported payment alerts.");smsButton.setText("SMS ACCESS ENABLED");}
 }
 private void reqLogout(){new Thread(()->{try{String base=prefs.getString("api",api);HttpURLConnection c=(HttpURLConnection)new URL(base+"/logout.php").openConnection();c.setRequestMethod("POST");c.setRequestProperty("Authorization","Bearer "+token);c.getResponseCode();c.disconnect();}catch(Exception e){}}).start();}
 private boolean hasSmsPermission(){return Build.VERSION.SDK_INT<23||(checkSelfPermission(Manifest.permission.RECEIVE_SMS)==PackageManager.PERMISSION_GRANTED&&checkSelfPermission(Manifest.permission.READ_SMS)==PackageManager.PERMISSION_GRANTED);}
 private void requestSmsPermission(){if(Build.VERSION.SDK_INT>=23)requestPermissions(new String[]{Manifest.permission.RECEIVE_SMS,Manifest.permission.READ_SMS},REQ);}
 @Override public void onRequestPermissionsResult(int r,String[] p,int[] g){super.onRequestPermissionsResult(r,p,g);if(r==REQ){if(hasSmsPermission()){status.setText("SMS permission enabled. Waiting for supported payment alerts.");smsButton.setText("SMS ACCESS ENABLED");}else status.setText("Permission not granted. SMS capture is disabled.");}}
 public void showCaptured(String s){runOnUiThread(()->{if(summary!=null)summary.setText(s);if(status!=null)status.setText("Payment notification captured and sent for admin review.");});}
 private void toast(String s){Toast.makeText(this,s,Toast.LENGTH_LONG).show();}
}
