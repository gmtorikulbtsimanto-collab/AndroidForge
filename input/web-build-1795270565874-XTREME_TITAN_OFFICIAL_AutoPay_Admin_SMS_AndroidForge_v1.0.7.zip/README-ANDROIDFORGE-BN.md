# XTREME TITAN OFFICIAL AutoPay — Admin SMS Bridge v1.0.6

## Intended use
This app is for the website administrator's Android phone only. Customers do NOT install or log into this app. Customers continue to deposit through the website.

## AndroidForge
Upload this ZIP itself. The Android Gradle project is at the archive root (`settings.gradle`, `build.gradle`, `app/`). Select Android / Gradle project auto-detection.

## Setup
1. Upload the complete `website-mobile-api` directory to the same website root directory as `config.php`. The Website ZIP v1.0.7 below already includes this folder.
2. Confirm the website's `users.role` column has the administrator account set to `admin` (the existing website has `current_user_role()` using `admin`, `reseller`, `user`).
3. In the app, enter the admin username, email/Gmail or phone and password (the identifier must be saved in Admin > Account Management) and the HTTPS API base URL ending in `/website-mobile-api`.
4. Grant SMS permissions when prompted. Only incoming messages that appear to contain a supported provider and a parsable amount + transaction ID are submitted; the app does not read the inbox history.
5. Check the app's last captured notification and the server's `mobile_payment_sms` table.

## Payment methods detected
bKash, Nagad, Rocket, Upay. Parsing is generic; actual provider SMS formats vary. Provide genuine sample notification texts (mask phone/account details) to refine provider-specific parsing.

## Important safety / current limitations
- This is an ADMIN-ONLY login. The API rejects non-admin website accounts.
- The app captures only incoming SMS broadcasts, not the full inbox. It extracts provider, amount, transaction ID and sender address, then submits those fields over HTTPS.
- The API stores captured notices in `mobile_payment_sms` as `unmatched`. It rejects duplicate transaction IDs.
- **No customer wallet is credited automatically in this version.** A received SMS alone is not authoritative proof; the current website uses its existing hosted payment checkout/webhook for bKash/Nagad. The new SMS endpoint only records alerts for admin review. A separate, tested matching workflow is required before wallet credit.
- Android may restrict SMS permissions depending on device/OS and distribution channel. Google Play has strict SMS permission policies; sideloading via AndroidForge does not guarantee permission availability on every device.
- The source package was ZIP-structure checked but not compiled here. AndroidForge build is required. Test on an admin-owned device and staging website first.

## Admin account management
Use Admin Panel → Account Management to create or edit website accounts, set username/email/phone and change passwords. Leave New Password blank when editing to keep the existing password.
