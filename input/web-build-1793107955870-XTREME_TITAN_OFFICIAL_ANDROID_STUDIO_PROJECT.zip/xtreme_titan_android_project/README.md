# XTREME TITAN OFFICIAL Android WebView app

This Android Studio project wraps the existing live website in a WebView:
`https://xtremetitanofficial.gamer.free/`

It preserves the website UI and server-side features by loading the live website rather than copying PHP/database code into the APK.

## Build
Open this folder in Android Studio, install Android SDK Platform 35, sync Gradle, then use **Build > Build Bundle(s) / APK(s) > Build APK(s)**.

The APK has not been compiled in this environment because Android SDK/Gradle build tools are unavailable here. See `README_BN.txt` for Bengali instructions.
