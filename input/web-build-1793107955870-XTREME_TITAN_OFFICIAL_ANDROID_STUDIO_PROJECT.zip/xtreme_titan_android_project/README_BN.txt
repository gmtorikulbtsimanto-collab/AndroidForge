XTREME TITAN OFFICIAL Android App project

এই প্রজেক্টটি Android WebView অ্যাপের সোর্স কোড। এটি আপনার লাইভ ওয়েবসাইট
https://xtremetitanofficial.gamer.free/ খুলবে, তাই ওয়েবসাইটের বর্তমান ডিজাইন/ফিচার
সার্ভার থেকে লোড হবে। এই ZIP নিজে APK নয়।

APK বানাতে:
1. কম্পিউটারে Android Studio ইনস্টল করুন।
2. এই ZIP extract করুন।
3. Android Studio > Open দিয়ে XTREME_TITAN_OFFICIAL ফোল্ডার খুলুন।
4. SDK Platform 35 ও Gradle sync সম্পন্ন করুন।
5. Build > Build Bundle(s) / APK(s) > Build APK(s) নির্বাচন করুন।
6. Debug APK সাধারণত app/build/outputs/apk/debug/app-debug.apk এ তৈরি হবে।

দ্রষ্টব্য:
- APK চালাতে ইন্টারনেট প্রয়োজন।
- ওয়েবসাইটে HTTPS এবং সার্ভার চালু থাকতে হবে।
- এখানে APK compile করা হয়নি, কারণ এই পরিবেশে Android SDK/Gradle build tool নেই।
- Play Store-এ প্রকাশের জন্য release signing ও অতিরিক্ত নীতিমালা প্রয়োজন।
