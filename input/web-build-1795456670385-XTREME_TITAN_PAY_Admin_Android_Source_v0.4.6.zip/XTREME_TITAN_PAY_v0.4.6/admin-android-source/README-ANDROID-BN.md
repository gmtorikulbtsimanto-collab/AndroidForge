# Android AutoPay v0.4.5

এই APK একই XTREME TITAN AutoPay Central Platform-এর সঙ্গে যুক্ত হবে।

Login-এর জন্য তিনটি তথ্য লাগবে:
1. Domain Username — Dashboard-এ Create Domain করার সময় যে username তৈরি হয়েছে।
2. Registered Gmail — AutoPay account-এর email address।
3. Domain API Key — Dashboard-এর ওই Domain card থেকে Create API key করে পাওয়া `xt_pub_...` key।

API URL অ্যাপের source-এ central endpoint হিসেবে সেট করা আছে: `https://xtremetitanautopay.x10.network/autopay/api`। Merchant-কে URL আলাদা করে দিতে হবে না।

API Secret কখনো Android App-এ দেবেন না। API Secret শুধু merchant-এর server-side integration-এর জন্য।

সফল login-এর পর অ্যাপটি device-scoped session token ব্যবহার করে SMS event ও history sync করে। SMS permission কেবল ব্যবহারকারীর সম্মতির পর চাইবে। SMS event Dashboard-এ `Needs review` হিসেবে জমা হবে; SMS একা settlement proof নয়।

Build: AndroidForge-এ এই source ZIP upload করুন, Target platform Android (APK) নির্বাচন করে Build APK চালান। এই source পরিবর্তনের পরে নতুন APK build ও install করতে হবে।


## v0.4.1 diagnostic update
This build does not silently follow HTTP redirects during API requests. If the host redirects a POST request, the app reports the HTTP redirect status and Location header instead of parsing the resulting HTML page as an API response. Non-JSON server responses include the HTTP status, content type, endpoint URL and a short response excerpt for diagnosis.

## Binance ও PayPal
- Binance/PayPal কেবল তখনই SMS থেকে ধরা হবে, যখন ওই সার্ভিস ফোনে SMS পাঠায় এবং SMS-এ amount ও transaction/reference ID দুটোই থাকে।
- PayPal ও Binance অনেক সময় SMS নয়, push notification বা email পাঠায়। এই SMS-only অ্যাপ সেগুলো পড়তে পারে না।
- Android source-এ provider parser যোগ করা হয়েছে। কিন্তু central PHP API-তে `Binance` ও `PayPal` provider allow করতে হবে। এই ZIP-এ website/API PHP source নেই।
- SMS capture payment settlement-এর প্রমাণ নয়; Wallet-এ টাকা যোগ করার আগে server-side/manual verification আবশ্যক।
