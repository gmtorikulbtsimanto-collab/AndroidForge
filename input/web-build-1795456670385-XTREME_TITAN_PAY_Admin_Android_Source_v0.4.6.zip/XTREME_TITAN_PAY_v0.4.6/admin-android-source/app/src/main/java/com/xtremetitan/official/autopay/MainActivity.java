package com.xtremetitan.official.autopay;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import android.net.Uri;
import androidx.work.*;
import java.util.concurrent.TimeUnit;
import org.json.JSONObject;
import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;

public class MainActivity extends Activity {
 private static final int BG=0xff090b20,PANEL=0xff202746,LINE=0xff303a60,GREEN=0xff4263ff,WHITE=0xfff4f5ff,MUTED=0xffaeb5ca,REQ=501;
 private static final String API_BASE="https://xtremetitanautopay.x10.network/autopay_host_migration/api";
 private String api=API_BASE,token="";
 private EditText identifier,usernameInput,apiKeyInput; private TextView status,summary,queueStatus,historyText; private Button loginButton,smsButton; private boolean busy=false; private String activeTab="dashboard";
 private SharedPreferences prefs;
 @Override public void onCreate(Bundle b){super.onCreate(b);getWindow().setStatusBarColor(BG);getWindow().setNavigationBarColor(BG);prefs=getSharedPreferences("xtreme_titan_pay_v046",MODE_PRIVATE);String savedApi=prefs.getString("api","");token=prefs.getString("token","");api=API_BASE;if(!savedApi.equals(API_BASE)){token="";prefs.edit().remove("token").putString("api",API_BASE).apply();}if(!token.isEmpty()){scheduleBackgroundSync();showDashboard();}else showLogin();}
 private int dp(float v){return (int)(v*getResources().getDisplayMetrics().density+.5f);}
 private GradientDrawable bg(int c,int s,int r){GradientDrawable d=new GradientDrawable();d.setColor(c);d.setCornerRadius(dp(r));if(s!=0)d.setStroke(dp(1),s);return d;}
 private TextView txt(String s,int z,int c,boolean b){TextView t=new TextView(this);t.setText(s);t.setTextSize(z);t.setTextColor(c);if(b)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);return t;}
 private LinearLayout col(){LinearLayout l=new LinearLayout(this);l.setOrientation(1);return l;}
 private void pad(View v,int n){v.setPadding(dp(n),dp(n),dp(n),dp(n));}
 private EditText field(String h,boolean secret){EditText e=new EditText(this);e.setSingleLine(true);e.setHint(h);e.setTextColor(WHITE);e.setHintTextColor(MUTED);e.setPadding(dp(13),dp(10),dp(13),dp(10));e.setBackground(bg(0xff151b35,LINE,12));if(secret)e.setInputType(129);return e;}
 private Button btn(String s){Button b=new Button(this);b.setText(s);b.setTextColor(0xff102006);b.setTypeface(null,Typeface.BOLD);b.setAllCaps(false);b.setBackground(bg(GREEN,0,24));return b;}
 private void label(LinearLayout p,String s){TextView t=txt(s,10,MUTED,true);LinearLayout.LayoutParams x=new LinearLayout.LayoutParams(-1,-2);x.topMargin=dp(13);x.bottomMargin=dp(6);p.addView(t,x);}
 private void card(LinearLayout p,View v){v.setBackground(bg(PANEL,LINE,18));pad(v,16);LinearLayout.LayoutParams x=new LinearLayout.LayoutParams(-1,-2);x.bottomMargin=dp(14);p.addView(v,x);}
 private void shell(LinearLayout root){
  LinearLayout frame=col(); frame.setBackgroundColor(BG);
  ScrollView sc=new ScrollView(this);sc.setBackgroundColor(BG);sc.setFillViewport(true);sc.addView(root);
  frame.addView(sc,new LinearLayout.LayoutParams(-1,0,1));
  if(!token.isEmpty()) frame.addView(bottomNav());
  setContentView(frame);
 }
 private LinearLayout bottomNav(){
  LinearLayout bar=new LinearLayout(this);bar.setOrientation(0);bar.setGravity(Gravity.CENTER);bar.setBackgroundColor(0xff171b36);bar.setPadding(dp(6),dp(8),dp(6),dp(8));
  addNav(bar,"⌂","Dashboard","dashboard");addNav(bar,"✣","Filters","filters");addNav(bar,"⚙","Settings","settings");return bar;
 }
 private void addNav(LinearLayout bar,String icon,String title,String tab){
  LinearLayout item=col();item.setGravity(Gravity.CENTER);TextView i=txt(icon,26,activeTab.equals(tab)?GREEN:0xffc5c9d8,true);TextView t=txt(title,12,activeTab.equals(tab)?GREEN:MUTED,true);item.addView(i);item.addView(t);
  item.setOnClickListener(v->{if(tab.equals("dashboard"))showDashboard();else if(tab.equals("filters"))showFilters();else showSettings();});
  bar.addView(item,new LinearLayout.LayoutParams(0,-2,1));
 }
 private void header(LinearLayout root){ImageView logo=new ImageView(this);logo.setImageResource(com.xtremetitan.official.autopay.R.drawable.autopay_logo);logo.setScaleType(ImageView.ScaleType.FIT_CENTER);LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(dp(116),dp(116));lp.gravity=Gravity.CENTER_HORIZONTAL;lp.bottomMargin=dp(12);root.addView(logo,lp);TextView t=txt("XTREME TITAN PAY",11,GREEN,true);root.addView(t);TextView h=txt("PAY",31,WHITE,true);LinearLayout.LayoutParams x=new LinearLayout.LayoutParams(-1,-2);x.topMargin=dp(4);root.addView(h,x);TextView sub=txt("CENTRAL PAYMENT SMS VERIFICATION PLATFORM",11,MUTED,true);root.addView(sub);}
 private void showLogin(){
  LinearLayout root=col();root.setPadding(dp(20),dp(24),dp(20),dp(30));shell(root);header(root);
  LinearLayout box=col();card(root,box);
  box.addView(txt("XTREME TITAN PAY",20,WHITE,true));
  TextView info=txt("Connect this Admin App to your XTREME TITAN PAY website using the registered email, Base Name URL and Base API Key.",12,MUTED,false);info.setLineSpacing(dp(3),1);LinearLayout.LayoutParams ip=new LinearLayout.LayoutParams(-1,-2);ip.topMargin=dp(8);box.addView(info,ip);
  label(box,"REGISTERED EMAIL ADDRESS");identifier=field("admin@example.com",false);identifier.setInputType(33);box.addView(identifier);
  label(box,"BASE NAME");usernameInput=field("https://your-domain/pay/name/XTREME-TITAN-PAY",false);usernameInput.setInputType(android.text.InputType.TYPE_CLASS_TEXT|android.text.InputType.TYPE_TEXT_VARIATION_URI);box.addView(usernameInput);
  label(box,"BASE API KEY");apiKeyInput=field("Enter Base API Key",false);apiKeyInput.setInputType(1);box.addView(apiKeyInput);
  loginButton=btn("CONNECT");LinearLayout.LayoutParams bp=new LinearLayout.LayoutParams(-1,-2);bp.topMargin=dp(18);box.addView(loginButton,bp);
  loginButton.setOnClickListener(v->login());
  TextView note=txt("No admin password is required in this app. The server validates all three values and issues a secure device session. Keep your Base API Key private.",11,MUTED,false);note.setLineSpacing(dp(3),1);LinearLayout.LayoutParams np=new LinearLayout.LayoutParams(-1,-2);np.topMargin=dp(10);root.addView(note,np);
 }
 private interface Done{void call(JSONObject j,String err);}
 private void req(String path,String method,JSONObject body,boolean auth,Done done){
  new Thread(()->{
   HttpURLConnection c=null;
   try{
    String base=normalizeApiBase(api);
    URL target=new URL(base+path);
    c=(HttpURLConnection)target.openConnection();
    c.setRequestMethod(method);
    c.setConnectTimeout(25000);
    c.setReadTimeout(25000);
    c.setUseCaches(false);
    c.setInstanceFollowRedirects(false);
    c.setRequestProperty("Accept","application/json");
    c.setRequestProperty("User-Agent","XTREME-TITAN-PAY/0.4.6 Android");
    if(body!=null){
     c.setDoOutput(true);
     // Shared/free PHP hosts and WAF rules sometimes reject JSON POST bodies
     // with HTTP 400. The login endpoint already supports standard form POST.
     // Use form encoding for login; keep JSON for the other API endpoints.
     {
      c.setRequestProperty("Content-Type","application/x-www-form-urlencoded; charset=UTF-8");
      StringBuilder form=new StringBuilder();
      java.util.Iterator<String> keys=body.keys();
      while(keys.hasNext()){
       String key=keys.next();
       if(form.length()>0)form.append('&');
       form.append(URLEncoder.encode(key,"UTF-8"));
       form.append('=');
       form.append(URLEncoder.encode(body.optString(key,""),"UTF-8"));
      }
      try(OutputStream o=c.getOutputStream()){
       o.write(form.toString().getBytes(StandardCharsets.UTF_8));
       o.flush();
      }
     }
    }
    if(auth)c.setRequestProperty("Authorization","Bearer "+token);
    int code=c.getResponseCode();
    String contentType=c.getContentType();
    String location=c.getHeaderField("Location");
    if(code>=300&&code<400){
     throw new Exception("API redirect detected (HTTP "+code+"). Location: "+(location==null?"not provided":location)+". Check the API URL and hosting redirects.");
    }
    InputStream in=(code>=200&&code<300)?c.getInputStream():c.getErrorStream();
    String response="";
    if(in!=null){
     try(InputStream stream=in;ByteArrayOutputStream out=new ByteArrayOutputStream()){
      byte[] buf=new byte[4096];int n;
      while((n=stream.read(buf))!=-1)out.write(buf,0,n);
      response=out.toString("UTF-8").trim();
     }
    }
    JSONObject j;
    try{j=new JSONObject(response);}
    catch(Exception parse){
     String snippet=response.replaceAll("\\s+"," ");
     if(snippet.length()>1200)snippet=snippet.substring(0,1200);
     String ct=contentType;
     throw new Exception("XTREME TITAN PAY v0.4.6: non-JSON response. HTTP "+code+", Content-Type="+(ct==null?"unknown":ct)+", URL="+target+", Body="+(snippet.isEmpty()?"<empty>":snippet));
    }
    if(code<200||code>=300)throw new Exception(j.optString("message","API request failed (HTTP "+code+")"));
    runOnUiThread(()->done.call(j,null));
   }catch(Exception e){
    String m=e.getMessage();
    if(e instanceof java.net.UnknownHostException)m="Cannot find the website domain. Check the full Website API URL and internet connection.";
    else if(e instanceof javax.net.ssl.SSLException)m="Secure HTTPS connection failed: "+(m==null?"SSL error":m);
    else if(e instanceof java.net.SocketTimeoutException)m="Website did not respond within 25 seconds. Check hosting/server availability.";
    else if(e instanceof java.net.ConnectException)m="Could not connect to the website server: "+(m==null?"connection refused":m);
    if(m==null||m.trim().isEmpty())m=e.getClass().getSimpleName()+" while contacting website API.";
    final String message=m;
    runOnUiThread(()->done.call(null,message));
   }finally{if(c!=null)c.disconnect();}
  }).start();
 }

 private String normalizeApiBase(String value){
  String v=value==null?"":value.trim();
  while(v.endsWith("/"))v=v.substring(0,v.length()-1);
  if(v.endsWith("/api/login.php"))v=v.substring(0,v.length()-10);
  if(v.endsWith("/login.php"))v=v.substring(0,v.length()-10);
  if(v.endsWith("/api"))return v;
  if(!v.startsWith("https://"))return "";
  return v+"/api";
 }
 private void login(){
  if(busy)return;
  String baseName=usernameInput.getText().toString().trim();
  String email=identifier.getText().toString().trim().toLowerCase();
  String key=apiKeyInput.getText().toString().trim();
  if(baseName.isEmpty()||email.isEmpty()||key.isEmpty()){toast("Enter Registered Email Address, Base Name and Base API Key.");return;}
  if(!android.util.Patterns.WEB_URL.matcher(baseName).matches()||!baseName.startsWith("https://")){toast("Base Name must be the HTTPS payment URL created by your website.");return;}
  api=API_BASE;
  JSONObject b=new JSONObject();try{b.put("base_name",baseName);b.put("email",email);b.put("api_key",key);b.put("device_name",Build.MANUFACTURER+" "+Build.MODEL);}catch(Exception ignored){}
  busy=true;loginButton.setEnabled(false);loginButton.setText("CONNECTING…");
  req("/mobile-login.php","POST",b,false,(j,e)->{
   busy=false;loginButton.setEnabled(true);loginButton.setText("CONNECT");
   if(e!=null){showLoginError(e);return;}
   token=j.optString("token","");if(token.isEmpty()){toast("Server did not return a device session.");return;}
   JSONObject project=j.optJSONObject("project");
   prefs.edit().putString("token",token).putString("api",api).putString("base_name",baseName).putString("email",email).putString("username",project==null?"":project.optString("username")).apply();
   apiKeyInput.setText("");scheduleBackgroundSync();showDashboard();
  });
 }
 private void showDashboard(){
  LinearLayout root=col();root.setPadding(dp(20),dp(24),dp(20),dp(30));shell(root);header(root);
  LinearLayout top=col();card(root,top);top.addView(txt("XTREME TITAN PAY connected",18,GREEN,true));top.addView(txt("This one app reads supported payment notification fields only after you grant SMS permission, then securely sends parsed details to your XTREME TITAN PAY account.",12,MUTED,false));
  LinearLayout methods=col();card(root,methods);methods.addView(txt("SUPPORTED PAYMENT SOURCES",11,GREEN,true));methods.addView(txt("bKash   ·   Nagad   ·   Rocket   ·   Upay   ·   Binance   ·   PayPal",16,WHITE,true));
  LinearLayout sms=col();card(root,sms);sms.addView(txt("SMS capture",19,WHITE,true));status=txt("SMS permission is required to detect incoming payment alerts.",12,MUTED,false);LinearLayout.LayoutParams st=new LinearLayout.LayoutParams(-1,-2);st.topMargin=dp(8);sms.addView(status,st);
  smsButton=btn("ENABLE PAYMENT SMS ACCESS");LinearLayout.LayoutParams sb=new LinearLayout.LayoutParams(-1,-2);sb.topMargin=dp(16);sms.addView(smsButton,sb);smsButton.setOnClickListener(v->requestSmsPermission());
  LinearLayout recent=col();card(root,recent);recent.addView(txt("Last captured notification",17,WHITE,true));summary=txt(prefs.getString("last_sms","No payment SMS captured yet."),12,MUTED,false);summary.setLineSpacing(dp(3),1);LinearLayout.LayoutParams rp=new LinearLayout.LayoutParams(-1,-2);rp.topMargin=dp(8);recent.addView(summary,rp);
  LinearLayout sync=col();card(root,sync);sync.addView(txt("SYNC STATUS",16,GREEN,true));queueStatus=txt("Checking queued notifications…",12,MUTED,false);sync.addView(queueStatus);Button syncNow=btn("SYNC NOW");LinearLayout.LayoutParams snp=new LinearLayout.LayoutParams(-1,-2);snp.topMargin=dp(10);sync.addView(syncNow,snp);syncNow.setOnClickListener(v->{PaymentSmsSyncWorker.enqueue(this);updateQueueStatus();toast("Sync queued. It will run when internet is available.");});
  LinearLayout hist=col();card(root,hist);hist.addView(txt("TRANSACTION HISTORY",17,WHITE,true));historyText=txt("Loading recent payment notifications…",12,MUTED,false);historyText.setLineSpacing(dp(3),1);LinearLayout.LayoutParams hp=new LinearLayout.LayoutParams(-1,-2);hp.topMargin=dp(8);hist.addView(historyText,hp);Button refresh=btn("REFRESH HISTORY");LinearLayout.LayoutParams rhp=new LinearLayout.LayoutParams(-1,-2);rhp.topMargin=dp(10);hist.addView(refresh,rhp);refresh.setOnClickListener(v->loadHistory());
  Button logout=btn("LOG OUT");root.addView(logout);logout.setOnClickListener(v->{reqLogout();token="";prefs.edit().remove("token").apply();WorkManager.getInstance(this).cancelUniqueWork("xt-autopay-sms-periodic");showLogin();});
  updateQueueStatus(); loadHistory();
  if(hasSmsPermission()){status.setText("SMS permission enabled. Waiting for supported payment alerts.");smsButton.setText("SMS ACCESS ENABLED");}
 }

 private void showFilters(){
  activeTab="filters"; LinearLayout root=col();root.setPadding(dp(20),dp(24),dp(20),dp(24));shell(root);
  LinearLayout head=new LinearLayout(this);head.setGravity(Gravity.CENTER_VERTICAL);head.addView(txt("Whitelist Senders",23,WHITE,true),new LinearLayout.LayoutParams(0,-2,1));
  Button add=btn("+ Add");head.addView(add);root.addView(head);
  LinearLayout list=col();LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.topMargin=dp(18);root.addView(list,lp);
  String[] defaults={"bKash","NAGAD","Rocket","Upay","BINANCE","PayPal","16216","16269","CITY BANK","BRAC BANK","DHAKA BANK","EBL","IBBL","UCB"};
  java.util.Set<String> saved=prefs.getStringSet("sender_whitelist",null);
  java.util.LinkedHashSet<String> senders=new java.util.LinkedHashSet<>();if(saved!=null)senders.addAll(saved);else java.util.Collections.addAll(senders,defaults);
  for(String sender:new java.util.ArrayList<>(senders)){LinearLayout row=new LinearLayout(this);row.setGravity(Gravity.CENTER_VERTICAL);row.setPadding(dp(2),dp(12),dp(2),dp(12));LinearLayout labels=col();labels.addView(txt(sender,17,WHITE,true));labels.addView(txt("Status enabled · syncing transactions",12,MUTED,false));row.addView(labels,new LinearLayout.LayoutParams(0,-2,1));Switch enabled=new Switch(this);enabled.setChecked(true);enabled.setOnCheckedChangeListener((b,on)->{if(on)senders.add(sender);else senders.remove(sender);prefs.edit().putStringSet("sender_whitelist",new java.util.HashSet<>(senders)).apply();});row.addView(enabled);View line=new View(this);line.setBackgroundColor(LINE);LinearLayout.LayoutParams ll=new LinearLayout.LayoutParams(-1,dp(1));ll.topMargin=dp(8);list.addView(row);list.addView(line,ll);}
  add.setOnClickListener(v->{EditText input=field("Sender name or SMS number",false);new android.app.AlertDialog.Builder(this).setTitle("Add whitelist sender").setView(input).setNegativeButton("Cancel",null).setPositiveButton("Add",(d,w)->{String val=input.getText().toString().trim();if(!val.isEmpty()){senders.add(val);prefs.edit().putStringSet("sender_whitelist",new java.util.HashSet<>(senders)).apply();showFilters();}}).show();});
 }
 private void showSettings(){
  activeTab="settings";LinearLayout root=col();root.setPadding(dp(20),dp(24),dp(20),dp(28));shell(root);
  root.addView(txt("Setting",27,WHITE,true));
  LinearLayout profile=col();card(root,profile);profile.addView(txt(prefs.getString("username","xtreme titan official"),18,WHITE,true));profile.addView(txt(prefs.getString("email",""),13,MUTED,false));
  label(root,"DATA MANAGEMENT");LinearLayout stats=col();card(root,stats);stats.addView(txt("DATA MANAGEMENT",13,WHITE,true));stats.addView(txt("Total       Synced       Pending       Failed",12,MUTED,true));stats.addView(txt("Local queue: "+pendingCount()+" pending",13,WHITE,false));
  label(root,"STORAGE");LinearLayout clean=col();card(root,clean);TextView cleanText=txt("SMS Cleaning Setting   ›",16,WHITE,true);clean.addView(cleanText);clean.setOnClickListener(v->new android.app.AlertDialog.Builder(this).setTitle("SMS Cleaning Setting").setMessage("XTREME TITAN PAY stores only parsed payment fields in its local sync queue. It does not delete SMS messages from your phone.").setPositiveButton("OK",null).show());
  label(root,"FILTERING");LinearLayout kw=col();card(root,kw);kw.addView(txt("Ignore Keywords   ›",16,WHITE,true));kw.setOnClickListener(v->{EditText input=field("Comma-separated keywords",false);input.setText(prefs.getString("ignore_keywords",""));new android.app.AlertDialog.Builder(this).setTitle("Ignore Keywords").setView(input).setNegativeButton("Cancel",null).setPositiveButton("Save",(d,w)->prefs.edit().putString("ignore_keywords",input.getText().toString()).apply()).show();});
  label(root,"CORE SETTINGS");LinearLayout core=col();card(root,core);
  addSwitch(core,"Whitelist Sender Validation","whitelist_validation",true);
  addSwitch(core,"Battery Optimization Exemption","battery_disabled",isBatteryExempt());
  addSwitch(core,"Read SMS Permissions Enabled","sms_read_enabled",hasSmsPermission());
  addSwitch(core,"Cloud Sync Enabled","cloud_sync_enabled",true);
  Button logout=btn("LOG OUT");root.addView(logout);logout.setOnClickListener(v->{reqLogout();token="";prefs.edit().remove("token").apply();WorkManager.getInstance(this).cancelUniqueWork("xt-autopay-sms-periodic");showLogin();});
 }
 private int pendingCount(){PaymentSmsQueue q=new PaymentSmsQueue(this);int n=q.countPending();q.close();return n;}
 private boolean isBatteryExempt(){if(Build.VERSION.SDK_INT<23)return true;android.os.PowerManager pm=(android.os.PowerManager)getSystemService(POWER_SERVICE);return pm!=null&&pm.isIgnoringBatteryOptimizations(getPackageName());}
 private void addSwitch(LinearLayout parent,String title,String key,boolean def){
  Switch sw=new Switch(this);sw.setText(title);sw.setTextColor(WHITE);sw.setTextSize(15);sw.setPadding(0,dp(12),0,dp(12));
  boolean actual=def;
  if(key.equals("battery_disabled"))actual=isBatteryExempt();
  if(key.equals("sms_read_enabled"))actual=hasSmsPermission();
  if(key.equals("cloud_sync_enabled"))actual=prefs.getBoolean(key,true);
  sw.setChecked(actual);
  final android.widget.CompoundButton.OnCheckedChangeListener[] handler=new android.widget.CompoundButton.OnCheckedChangeListener[1];
  handler[0]=(button,on)->{
   if(key.equals("sms_read_enabled")){
    if(on&&!hasSmsPermission())requestSmsPermission();
    else if(!on)toast("To revoke SMS access, use Android App permissions.");
    sw.setOnCheckedChangeListener(null);sw.setChecked(hasSmsPermission());sw.setOnCheckedChangeListener(handler[0]);return;
   }
   if(key.equals("battery_disabled")){
    if(on&&!isBatteryExempt()&&Build.VERSION.SDK_INT>=23){
     try{Intent i=new Intent(android.provider.Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,Uri.parse("package:"+getPackageName()));startActivity(i);}
     catch(Exception ex){startActivity(new Intent(android.provider.Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS));}
    }else if(!on)startActivity(new Intent(android.provider.Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS));
    sw.setOnCheckedChangeListener(null);sw.setChecked(isBatteryExempt());sw.setOnCheckedChangeListener(handler[0]);return;
   }
   prefs.edit().putBoolean(key,on).apply();
   if(key.equals("cloud_sync_enabled")){
    if(on)scheduleBackgroundSync();else WorkManager.getInstance(this).cancelUniqueWork("xt-autopay-sms-periodic");
   }
  };
  sw.setOnCheckedChangeListener(handler[0]);parent.addView(sw);
  View divider=new View(this);divider.setBackgroundColor(LINE);LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,dp(1));parent.addView(divider,p);
 }
 private void updateQueueStatus(){ if(queueStatus==null)return; new Thread(()->{PaymentSmsQueue q=new PaymentSmsQueue(this);int n=q.countPending();q.close();runOnUiThread(()->{if(queueStatus!=null)queueStatus.setText(n==0?"All captured notifications are synced.":n+" notification(s) waiting to sync. Check internet and tap SYNC NOW.");});}).start(); }
 private void loadHistory(){ if(historyText==null)return; historyText.setText("Loading transaction history…"); req("/mobile-history.php?limit=30","GET",null,true,(j,e)->{if(historyText==null)return;if(e!=null){historyText.setText("Could not load history: "+e);return;}org.json.JSONArray a=j.optJSONArray("events");if(a==null||a.length()==0){historyText.setText("No payment notifications found yet.");return;}StringBuilder out=new StringBuilder();for(int i=0;i<a.length();i++){JSONObject x=a.optJSONObject(i);if(x==null)continue;out.append(x.optString("provider").toUpperCase()).append(" · ").append(x.optString("amount")).append(" ").append(x.optString("currency")).append("\nTX: ").append(x.optString("transaction_id")).append("\nStatus: ").append(x.optString("status")).append("\n\n");}historyText.setText(out.toString().trim());}); }
 private void reqLogout(){String oldToken=token;String base=prefs.getString("api",api);new Thread(()->{try{HttpURLConnection c=(HttpURLConnection)new URL(base+"/mobile-logout.php").openConnection();c.setRequestMethod("POST");c.setRequestProperty("Authorization","Bearer "+oldToken);c.getResponseCode();c.disconnect();}catch(Exception e){}}).start();}
 private void scheduleBackgroundSync(){if(!prefs.getBoolean("cloud_sync_enabled",true))return;Constraints constraints=new Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build();PeriodicWorkRequest periodic=new PeriodicWorkRequest.Builder(PaymentSmsSyncWorker.class,15,TimeUnit.MINUTES).setConstraints(constraints).build();WorkManager.getInstance(this).enqueueUniquePeriodicWork("xt-autopay-sms-periodic",ExistingPeriodicWorkPolicy.KEEP,periodic);PaymentSmsSyncWorker.enqueue(this);}
 private boolean hasSmsPermission(){return Build.VERSION.SDK_INT<23||(checkSelfPermission(Manifest.permission.RECEIVE_SMS)==PackageManager.PERMISSION_GRANTED);}
 private void requestSmsPermission(){if(Build.VERSION.SDK_INT>=23)requestPermissions(new String[]{Manifest.permission.RECEIVE_SMS},REQ);}
 @Override public void onRequestPermissionsResult(int r,String[] p,int[] g){super.onRequestPermissionsResult(r,p,g);if(r==REQ){if(hasSmsPermission()){status.setText("SMS permission enabled. Waiting for supported payment alerts.");smsButton.setText("SMS ACCESS ENABLED");}else status.setText("Permission not granted. SMS capture is disabled.");if(activeTab.equals("settings"))showSettings();}}
 public void showCaptured(String s){runOnUiThread(()->{if(summary!=null)summary.setText(s);if(status!=null)status.setText("Payment notification captured and sent to your central account for review.");});}
 private void showLoginError(String message){
  TextView detail=txt(message,13,0xff202020,false);detail.setTextIsSelectable(true);detail.setPadding(dp(18),dp(12),dp(18),dp(12));
  new android.app.AlertDialog.Builder(this).setTitle("XTREME TITAN PAY connection diagnostic").setView(detail).setPositiveButton("OK",(d,w)->{}).show();
 }
 private void toast(String s){Toast.makeText(this,s,Toast.LENGTH_LONG).show();}
}
