package com.xtremetitan.official.autopay;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.telephony.SmsMessage;
import org.json.JSONObject;
import java.util.regex.*;

/** Receives payment alerts on the explicitly enrolled admin phone and queues parsed fields for reliable sync. */
public class PaymentSmsReceiver extends BroadcastReceiver {
 @Override public void onReceive(Context context,Intent intent){
  if(!"android.provider.Telephony.SMS_RECEIVED".equals(intent.getAction()))return;
  SharedPreferences p=context.getSharedPreferences("xtreme_titan_pay_v046",Context.MODE_PRIVATE);
  if(p.getString("token","").isEmpty())return;
  if(intent.getExtras()==null)return; Object[] pdus=(Object[])intent.getExtras().get("pdus"); if(pdus==null||pdus.length==0)return;
  String format=intent.getStringExtra("format"); StringBuilder body=new StringBuilder();String sender="";
  for(Object obj:pdus){SmsMessage m=BuildSms.from(obj,format);if(m!=null){body.append(m.getMessageBody()).append(' ');sender=m.getOriginatingAddress();}}
  String msg=body.toString();String low=(sender+" "+msg).toLowerCase();
  String ignored=p.getString("ignore_keywords","");for(String word:ignored.split(",")){if(!word.trim().isEmpty()&&low.contains(word.trim().toLowerCase()))return;}
  String method="";
  if(low.contains("bkash")||low.contains("b-kash"))method="bKash";
  else if(low.contains("nagad"))method="Nagad";
  else if(low.contains("rocket")||low.contains("dbbl"))method="Rocket";
  else if(low.contains("upay"))method="Upay";
  else if(low.contains("binance"))method="Binance";
  else if(low.contains("paypal")||low.contains("pay pal"))method="PayPal";
  if(method.isEmpty())return;
  if(p.getBoolean("whitelist_validation",true)){
   java.util.Set<String> allowed=p.getStringSet("sender_whitelist",null);
   if(allowed==null){allowed=new java.util.HashSet<>();java.util.Collections.addAll(allowed,"bKash","NAGAD","Rocket","Upay","BINANCE","PayPal","16216","16269","CITY BANK","BRAC BANK","DHAKA BANK","EBL","IBBL","UCB");}
   String normalized=sender==null?"":sender.replaceAll("[^A-Za-z0-9]","").toLowerCase();
   boolean ok=false;for(String a:allowed){String n=a.replaceAll("[^A-Za-z0-9]","").toLowerCase();if(!n.isEmpty()&&(normalized.equals(n)||low.contains(a.toLowerCase()))){ok=true;break;}}
   if(!ok)return;
  }
  String trx=first(msg,"(?i)(?:trx\\s*id|txnid|transaction\\s*id|txn\\s*id|reference\\s*(?:id|no)|payment\\s*id|order\\s*id)\\s*[:#-]?\\s*([A-Z0-9-]{6,40})");
  String amount=first(msg,"(?i)(?:amount|received|payment|cash\\s*in|you\\s+received|paid)\\s*(?:of|is|:)?\\s*(?:usd|usdt|bdt|tk|\\$|৳)?\\s*([0-9][0-9,]*(?:\\.[0-9]{1,2})?)");
  String currency=low.contains("usdt")?"USDT":(low.contains("usd")||low.contains("$"))?"USD":"BDT";
  if(trx.isEmpty()||amount.isEmpty())return;
  try{double a=Double.parseDouble(amount.replace(",",""));if(a<=0)return;
   JSONObject j=new JSONObject();j.put("provider",method);j.put("amount",a);j.put("currency",currency);j.put("transaction_id",trx);j.put("sender",sender==null?"":sender);j.put("received_at",System.currentTimeMillis()/1000);
   PaymentSmsQueue queue=new PaymentSmsQueue(context);queue.add(j);queue.close();
   if(p.getBoolean("cloud_sync_enabled",true))PaymentSmsSyncWorker.enqueue(context);
   p.edit().putString("last_sms",method+" · "+currency+" "+amount+" · TXN "+trx+" · queued for secure sync").apply();
  }catch(Exception ignored){}
 }
 private String first(String s,String regex){Matcher m=Pattern.compile(regex).matcher(s);return m.find()?m.group(1):"";}
 static class BuildSms {static SmsMessage from(Object p,String f){try{if(android.os.Build.VERSION.SDK_INT>=23)return SmsMessage.createFromPdu((byte[])p,f);return SmsMessage.createFromPdu((byte[])p);}catch(Exception e){return null;}}}
}
