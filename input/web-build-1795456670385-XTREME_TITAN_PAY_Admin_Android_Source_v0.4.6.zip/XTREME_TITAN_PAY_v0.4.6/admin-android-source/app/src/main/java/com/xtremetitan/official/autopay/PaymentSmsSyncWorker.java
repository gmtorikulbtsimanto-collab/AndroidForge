package com.xtremetitan.official.autopay;

import android.content.Context;
import android.content.SharedPreferences;
import androidx.annotation.NonNull;
import androidx.work.Worker;
import androidx.work.WorkerParameters;
import androidx.work.OneTimeWorkRequest;
import androidx.work.WorkManager;
import androidx.work.ExistingWorkPolicy;
import androidx.work.Constraints;
import androidx.work.NetworkType;
import org.json.JSONObject;
import java.net.HttpURLConnection;
import java.net.URL;
import java.io.OutputStream;
import java.io.InputStream;
import java.io.ByteArrayOutputStream;
import java.nio.charset.StandardCharsets;
import java.util.List;

public class PaymentSmsSyncWorker extends Worker {
    public PaymentSmsSyncWorker(@NonNull Context c,@NonNull WorkerParameters p){super(c,p);}
    public static void enqueue(Context c){
        Constraints cs=new Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build();
        OneTimeWorkRequest req=new OneTimeWorkRequest.Builder(PaymentSmsSyncWorker.class).setConstraints(cs).build();
        WorkManager.getInstance(c).enqueueUniqueWork("xt-autopay-sms-sync",ExistingWorkPolicy.KEEP,req);
    }
    @NonNull @Override public Result doWork(){
        Context ctx=getApplicationContext(); SharedPreferences prefs=ctx.getSharedPreferences("xtreme_titan_pay_v046",Context.MODE_PRIVATE);
        String token=prefs.getString("token",""); String base=prefs.getString("api","");
        if(token.isEmpty()) return Result.success();
        PaymentSmsQueue queue=new PaymentSmsQueue(ctx);
        try {
            List<JSONObject> items=queue.pending(30);
            for(JSONObject item:items){
                long id=item.optLong("_queue_id"); item.remove("_queue_id");
                HttpURLConnection c=null;
                try {
                    c=(HttpURLConnection)new URL(base+"/mobile-sms.php").openConnection(); c.setRequestMethod("POST"); c.setConnectTimeout(20000); c.setReadTimeout(20000); c.setDoOutput(true);
                    c.setRequestProperty("Accept","application/json"); c.setRequestProperty("Content-Type","application/json; charset=UTF-8"); c.setRequestProperty("Authorization","Bearer "+token);
                    try(OutputStream o=c.getOutputStream()){o.write(item.toString().getBytes(StandardCharsets.UTF_8));}
                    int code=c.getResponseCode();
                    // 201=new record; 409=duplicate transaction. Both are terminal and safe to remove.
                    if(code==200||code==201||code==409){queue.remove(id);} else if(code>=500||code==408||code==429){queue.failed(id);return Result.retry();}
                    else { queue.failed(id); if(code==401||code==403)return Result.failure(); }
                } catch(Exception e){queue.failed(id);return Result.retry();} finally {if(c!=null)c.disconnect();}
            }
            return Result.success();
        } finally {queue.close();}
    }
}
