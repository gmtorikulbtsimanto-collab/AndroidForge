XTREME TITAN PAY — Admin Android Source v0.4.6

এই Android project-এ আপনার screenshot অনুযায়ী Dark Navy / Indigo UI রাখা হয়েছে:
- Dashboard / Filters / Settings bottom navigation
- SMS payment notification capture ও secure sync queue
- Sender whitelist enable/disable ও custom sender add
- Ignore Keywords, SMS permission, battery optimization ও Cloud Sync settings
- All supported providers: bKash, Nagad, Rocket, Upay, Binance, PayPal (SMS alerts থাকলে parse হবে)

নতুন Connection screen-এ ঠিক ৩টি field আছে:
1. Registered Email Address
2. Base Name — website থেকে তৈরি করা HTTPS URL
3. Base API Key

কোনো Admin Password field নেই। Base Name URL এবং API key website dashboard থেকে তৈরি করতে হবে।

API endpoint configured in source:
https://xtremetitanautopay.x10.network/autopay_host_migration/api

সতর্কতা:
- এই ZIP Android source project; compiled APK নয়। বর্তমান execution environment-এ Android SDK/Gradle নেই, তাই এখানে APK build ও real device test করা সম্ভব হয়নি। AndroidForge/Android Studio-তে project import করে build করতে হবে।
- Android app কেবল ফোনে SMS হিসেবে আসা supported alerts পড়তে পারে। Binance/PayPal-এর push/email notifications পড়তে পারে না।
- SMS notification payment settlement proof নয়। Server-side trusted provider verification/manual review ছাড়া balance credit করা যাবে না।
