package com.xtremetitan.autopay;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.*;
import android.text.InputType;
import org.json.JSONObject;
import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    private static final String DEFAULT_API = "https://xtremetitanofficial.gamer.free/website-mobile-api";
    private static final String PREF = "xt_autopay";
    private final ExecutorService io = Executors.newSingleThreadExecutor();
    private LinearLayout root;
    private EditText apiInput, identifierInput, passwordInput;
    private TextView status;
    private String token = "";
    private JSONObject account;
    private int cyan = Color.rgb(32,216,243), bg = Color.rgb(6,17,31), panel = Color.rgb(12,29,48), muted = Color.rgb(154,176,196);

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(bg);
        getWindow().setNavigationBarColor(bg);
        token = getSharedPreferences(PREF, MODE_PRIVATE).getString("token", "");
        if (!token.isEmpty()) loadMe(); else showLogin("");
    }

    private void base(String title, String subtitle) {
        ScrollView scroll = new ScrollView(this);
        root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(20), dp(28), dp(20), dp(30));
        root.setBackgroundColor(bg);
        scroll.addView(root);
        setContentView(scroll);
        TextView brand = text("XTREME TITAN", 13, cyan, true);
        brand.setLetterSpacing(.16f); root.addView(brand);
        TextView heading = text(title, 27, Color.WHITE, true);
        LinearLayout.LayoutParams hp = params(-1,-2); hp.topMargin=dp(8); root.addView(heading,hp);
        TextView sub = text(subtitle, 13, muted, false);
        LinearLayout.LayoutParams sp=params(-1,-2); sp.topMargin=dp(5); sp.bottomMargin=dp(22); root.addView(sub,sp);
    }

    private void showLogin(String message) {
        base("AutoPay", "OFFICIAL PAYMENT COMPANION");
        cardStart();
        root.addView(text("Connect your website account",18,Color.WHITE,true));
        label("Website API URL");
        apiInput = edit(DEFAULT_API, false);
        root.addView(apiInput);
        label("Admin / website email or phone");
        identifierInput = edit("Enter email or phone", false);
        root.addView(identifierInput);
        label("Password");
        passwordInput = edit("Enter website password", true);
        root.addView(passwordInput);
        Button login = button("CONNECT DEVICE");
        LinearLayout.LayoutParams bp=params(-1,dp(52)); bp.topMargin=dp(20); root.addView(login,bp);
        login.setOnClickListener(v -> login());
        if (!message.isEmpty()) root.addView(text(message,13,Color.rgb(255,140,140),false));
        cardEnd();
        root.addView(text("This initial build connects your account only. bKash, Nagad, Rocket and Upay SMS detection and automatic payment matching will be added in a later integration update.",12,muted,false));
    }

    private void showDashboard(JSONObject user, String message) {
        String name = user == null ? "Connected account" : user.optString("name","Connected account");
        base("AutoPay Dashboard", "Connected as " + name);
        LinearLayout c = cardStart();
        c.addView(text("DEVICE CONNECTION",11,cyan,true));
        TextView connected=text("●  WEBSITE ACCOUNT CONNECTED",14,Color.rgb(60,224,164),true);
        LinearLayout.LayoutParams cp=params(-1,-2); cp.topMargin=dp(12); c.addView(connected,cp);
        c.addView(text("Payment message sources",18,Color.WHITE,true),top(22));
        addMethod(c,"bKash","Ready for SMS integration");
        addMethod(c,"Nagad","Ready for SMS integration");
        addMethod(c,"Rocket","Ready for SMS integration");
        addMethod(c,"Upay","Ready for SMS integration");
        c.addView(text("Automatic SMS reading is not enabled in this starter build.",12,muted,false),top(8));
        cardEnd();
        LinearLayout c2=cardStart();
        c2.addView(text("SERVER STATUS",11,cyan,true));
        c2.addView(text(message.isEmpty()?"Account connection verified.":message,13,Color.WHITE,false),top(10));
        Button refresh=button("REFRESH CONNECTION"); c2.addView(refresh,top(16)); refresh.setOnClickListener(v->loadMe());
        Button logout=button("DISCONNECT DEVICE"); c2.addView(logout,top(10)); logout.setOnClickListener(v->logout());
        cardEnd();
        root.addView(text("XTREME TITAN OFFICIAL · Secure device session",11,muted,false),top(18));
    }

    private LinearLayout cardStart() {
        LinearLayout c=new LinearLayout(this); c.setOrientation(LinearLayout.VERTICAL); c.setPadding(dp(18),dp(18),dp(18),dp(18));
        GradientDrawable d=new GradientDrawable(); d.setColor(panel); d.setCornerRadius(dp(20)); d.setStroke(dp(1),Color.rgb(29,64,90)); c.setBackground(d);
        LinearLayout.LayoutParams p=params(-1,-2); p.bottomMargin=dp(16); root.addView(c,p); return c;
    }
    private void cardEnd() {}
    private void addMethod(LinearLayout parent,String name,String note) {
        LinearLayout row=new LinearLayout(this); row.setGravity(Gravity.CENTER_VERTICAL); row.setPadding(dp(12),dp(12),dp(12),dp(12));
        GradientDrawable d=new GradientDrawable(); d.setColor(Color.rgb(7,22,37)); d.setCornerRadius(dp(12)); d.setStroke(dp(1),Color.rgb(29,64,90)); row.setBackground(d);
        TextView left=text(name,15,Color.WHITE,true); row.addView(left,new LinearLayout.LayoutParams(0,-2,1));
        TextView right=text(note,11,muted,false); row.addView(right);
        LinearLayout.LayoutParams p=params(-1,-2); p.topMargin=dp(9); parent.addView(row,p);
    }
    private void login() {
        String api=apiInput.getText().toString().trim().replaceAll("/+$","");
        String id=identifierInput.getText().toString().trim();
        String pass=passwordInput.getText().toString();
        if (!api.startsWith("https://")) { toast("Use a secure HTTPS API URL."); return; }
        if (id.isEmpty() || pass.isEmpty()) { toast("Enter your website login details."); return; }
        setBusy(true);
        io.execute(() -> {
            try {
                JSONObject body=new JSONObject(); body.put("identifier",id); body.put("password",pass); body.put("device_name","XTREME TITAN Android AutoPay");
                JSONObject result=request(api+"/login.php","POST",null,body);
                String newToken=result.optString("token","");
                if (newToken.isEmpty()) throw new Exception(result.optString("message","Login failed."));
                getSharedPreferences(PREF,MODE_PRIVATE).edit().putString("api",api).putString("token",newToken).apply();
                token=newToken;
                JSONObject u=result.optJSONObject("user");
                runOnUiThread(() -> { setBusy(false); showDashboard(u,"Login successful."); });
            } catch(Exception e) { runOnUiThread(() -> { setBusy(false); showLogin(e.getMessage()); }); }
        });
    }
    private void loadMe() {
        String api=getSharedPreferences(PREF,MODE_PRIVATE).getString("api",DEFAULT_API);
        if(token.isEmpty()){showLogin("");return;}
        io.execute(() -> {
            try {
                JSONObject r=request(api+"/me.php","GET",token,null);
                JSONObject u=r.optJSONObject("user");
                runOnUiThread(() -> showDashboard(u,"Server connection active."));
            } catch(Exception e) {
                getSharedPreferences(PREF,MODE_PRIVATE).edit().remove("token").apply(); token="";
                runOnUiThread(() -> showLogin("Session check failed: "+e.getMessage()));
            }
        });
    }
    private void logout() {
        String api=getSharedPreferences(PREF,MODE_PRIVATE).getString("api",DEFAULT_API);
        io.execute(() -> {
            try { request(api+"/logout.php","POST",token,new JSONObject()); } catch(Exception ignored) {}
            getSharedPreferences(PREF,MODE_PRIVATE).edit().remove("token").apply(); token="";
            runOnUiThread(() -> showLogin("Device disconnected."));
        });
    }
    private JSONObject request(String url,String method,String bearer,JSONObject body) throws Exception {
        HttpURLConnection c=(HttpURLConnection)new URL(url).openConnection();
        c.setRequestMethod(method); c.setConnectTimeout(15000); c.setReadTimeout(20000);
        c.setRequestProperty("Accept","application/json");
        if(bearer!=null&&!bearer.isEmpty()) c.setRequestProperty("Authorization","Bearer "+bearer);
        if(body!=null){c.setDoOutput(true);c.setRequestProperty("Content-Type","application/json; charset=utf-8");try(OutputStream o=c.getOutputStream()){o.write(body.toString().getBytes(StandardCharsets.UTF_8));}}
        int code=c.getResponseCode(); InputStream in=code>=200&&code<300?c.getInputStream():c.getErrorStream();
        ByteArrayOutputStream out=new ByteArrayOutputStream(); byte[] buf=new byte[4096]; int n; while((n=in.read(buf))!=-1)out.write(buf,0,n);
        c.disconnect(); JSONObject result=new JSONObject(out.toString("UTF-8"));
        if(code<200||code>=300||!result.optBoolean("ok",true)) throw new Exception(result.optString("message","Server error ("+code+")."));
        return result;
    }
    private void setBusy(boolean b) { runOnUiThread(()->{ if(status!=null)status.setText(b?"Connecting…":""); }); }
    private void label(String s){root.addView(text(s,11,muted,true),top(16));}
    private EditText edit(String hint,boolean secret){
        EditText e=new EditText(this); e.setSingleLine(true); e.setTextSize(14); e.setTextColor(Color.WHITE); e.setHintTextColor(Color.rgb(96,120,141)); e.setHint(hint);
        e.setPadding(dp(13),dp(11),dp(13),dp(11)); e.setInputType(secret?InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_PASSWORD:InputType.TYPE_CLASS_TEXT);
        GradientDrawable d=new GradientDrawable(); d.setColor(Color.rgb(7,22,37)); d.setCornerRadius(dp(11)); d.setStroke(dp(1),Color.rgb(29,64,90)); e.setBackground(d); return e;
    }
    private Button button(String s){Button b=new Button(this);b.setText(s);b.setTextSize(12);b.setTypeface(null,Typeface.BOLD);b.setTextColor(bg);b.setBackground(tint(cyan));return b;}
    private GradientDrawable tint(int color){GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(dp(12));return d;}
    private TextView text(String s,int size,int color,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);if(bold)t.setTypeface(null,Typeface.BOLD);return t;}
    private LinearLayout.LayoutParams top(int margin){LinearLayout.LayoutParams p=params(-1,-2);p.topMargin=dp(margin);return p;}
    private LinearLayout.LayoutParams params(int w,int h){return new LinearLayout.LayoutParams(w,h);}
    private int dp(int v){return (int)(v*getResources().getDisplayMetrics().density+.5f);}
    private void toast(String s){Toast.makeText(this,s,Toast.LENGTH_LONG).show();}
    @Override protected void onDestroy(){super.onDestroy();io.shutdown();}
}
