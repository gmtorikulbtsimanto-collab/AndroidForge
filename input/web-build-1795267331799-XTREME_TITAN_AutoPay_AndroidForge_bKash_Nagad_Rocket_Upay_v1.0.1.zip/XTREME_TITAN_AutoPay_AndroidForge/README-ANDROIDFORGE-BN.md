# XTREME TITAN AutoPay — AndroidForge source (starter)

এই ZIP একটি Native Android Gradle project। এটি Expo project নয়।

## এই build-এ কী আছে
- XTREME TITAN AutoPay native Android app shell
- Website email/phone + password login
- HTTPS mobile API connection
- Server session check (`me.php`)
- Logout/revoke (`logout.php`)
- Dashboard-এ bKash ও Nagad source placeholder
- Rocket ও Upay ইচ্ছাকৃতভাবে বাদ

## এই build-এ এখনো কী নেই
- SMS read/receive permission বা SMS listener
- bKash/Nagad SMS parsing
- Automatic deposit matching / wallet credit
- Admin-side device approval workflow

এই অংশগুলো যোগ করার আগে নির্ভরযোগ্য SMS format, permission model, server-side verification, এবং user consent প্রয়োজন। SMS text একা পেমেন্টের চূড়ান্ত প্রমাণ নয়; provider API/statement verification প্রয়োজন।

## Website API
Login API URL default:
`https://xtremetitanofficial.gamer.free/website-mobile-api`

আপনার website-এ `website-mobile-api` folder upload করা না থাকলে আগে সেটি website root-এর `config.php`-এর পাশে upload করুন। HTTPS এবং PHP/MySQL support প্রয়োজন। API login ব্যবহারকারীর website email/phone এবং password ব্যবহার করে।

## AndroidForge
1. ZIP extract করে project root AndroidForge-এ দিন বা GitHub repository-তে upload করুন।
2. Android Gradle project হিসেবে build করুন।
3. Application ID: `com.xtremetitan.official.autopay`
4. Min SDK: 23; Target SDK: 28.
5. Build fail হলে complete Gradle log দিয়ে দিন।

## Security
- এই source-এ database password/API secret নেই।
- HTTPS ছাড়া API request গ্রহণ করে না।
- Login token Android private SharedPreferences-এ রাখা হয়।
- Production release-এর আগে device lock, token hardening, and backend rate limits যোগ করুন।


Payment scope: the Android app lists bKash, Nagad, Rocket and Upay. The website Deposit page is restricted to bKash and Nagad in BDT only. SMS reading and automatic SMS matching are not implemented in this starter build.
