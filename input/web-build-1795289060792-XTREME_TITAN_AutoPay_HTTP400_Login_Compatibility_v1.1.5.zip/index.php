<?php
require_once __DIR__ . '/config.php';
if (!empty($_SESSION['user_id'])) {
    header('Location: dashboard.php');
    exit;
}
$error = $_SESSION['error'] ?? '';
unset($_SESSION['error']);
$site = site_settings();
?>
<!doctype html>
<html lang="en">
<head>
<link rel="stylesheet" href="theme.php?v=20261022-lightfix3">
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no">
<title>XTREME TITAN OFFICIAL SHOP</title>
<link rel="stylesheet" href="style.css">
<style>
*{box-sizing:border-box}
html,body{margin:0;min-height:100%;background:#050912;color:#fff;font-family:Arial,Helvetica,sans-serif}
body{position:relative;isolation:isolate;overflow-x:hidden;display:flex;align-items:flex-start;justify-content:center;padding:18px 14px 30px}
body::before{content:"";position:fixed;inset:0;z-index:-3;background:url('<?=e($site['background_path'])?>') center/cover no-repeat}
body::after{content:"";position:fixed;inset:0;z-index:-2;background:rgba(3,8,16,.72)}
.decor{position:fixed;z-index:-1;width:96px;height:96px;object-fit:cover;border-radius:24px;opacity:.92;filter:drop-shadow(0 12px 24px rgba(0,0,0,.38));animation:floaty 5s ease-in-out infinite}.decor.one{left:max(10px,calc(50% - 270px));top:15%;transform:rotate(-8deg)}.decor.two{right:max(10px,calc(50% - 270px));bottom:18%;transform:rotate(8deg);animation-delay:-2.5s}@keyframes floaty{0%,100%{translate:0 0}50%{translate:0 -9px}}.card{width:min(430px,100%);margin:14px auto 0;padding:22px 18px;border-radius:24px;background:rgba(10,18,32,.92);border:1px solid rgba(130,153,190,.22);box-shadow:0 22px 70px rgba(0,0,0,.48);text-align:center}
h1{margin:0 auto 8px;font-size:23px;line-height:1.15;font-weight:900;max-width:100%;overflow-wrap:anywhere;word-break:normal}.muted{margin:0 0 18px;color:#9aa9bf;font-size:13px}
.alert{padding:11px;border-radius:12px;margin-bottom:12px;background:#3b1c24;color:#ff9aaa;border:1px solid #6b2b38;font-size:12px}
.actions{display:grid;gap:10px}.actions .btn{display:flex;align-items:center;justify-content:center;min-height:46px;padding:11px 14px;border-radius:12px;text-decoration:none;font-size:14px;font-weight:900;background:linear-gradient(135deg,#10d8ff,#1681ff);color:#fff}.actions .secondary{background:linear-gradient(135deg,#12e58e,#63ff16);color:#06101c}
</style>
<link rel="stylesheet" href="site-polish.css?v=20261022-lightfix3">
<script src="theme-client.js?v=20260928-19" defer></script><link rel="stylesheet" href="premium-global.css?v=20261022-lightfix3"><script src="currency-client.js?v=20261018-fx1" defer></script><link rel="stylesheet" href="responsive-lock.css?v=20260929-28">

<link rel="icon" type="image/png" sizes="48x48" href="favicon.png">
<link rel="apple-touch-icon" sizes="180x180" href="assets/pwa-icon-180.png">
<link rel="manifest" href="pwa-manifest.json">
<meta name="apple-mobile-web-app-title" content="XTREME TITAN">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="theme-color" content="#080a14">
<meta name="mobile-web-app-capable" content="yes">
<style id="landing-premium-v14">
:root{color-scheme:dark}html,body{min-height:100%;}body{padding:clamp(22px,6vh,64px) 18px 36px;align-items:center;background:#050710;}body::after{background:radial-gradient(ellipse at 50% 12%,rgba(91,54,173,.34),transparent 52%),linear-gradient(180deg,rgba(3,7,15,.70),rgba(3,7,15,.94));}
.card{position:relative;width:min(100%,480px);margin:0 auto;padding:clamp(26px,6vw,42px) clamp(20px,5vw,34px) 30px;border-radius:30px;background:linear-gradient(155deg,rgba(23,24,49,.94),rgba(8,13,27,.97) 70%);border:1px solid rgba(170,151,255,.38);box-shadow:0 28px 90px rgba(0,0,0,.52),inset 0 1px 0 rgba(255,255,255,.08);overflow:hidden;backdrop-filter:blur(18px);}
.card:before{content:"";position:absolute;inset:0 18% auto;height:2px;background:linear-gradient(90deg,transparent,#9c65ff,#19d8ff,transparent);opacity:.95}.brand-mark{width:94px;height:94px;object-fit:cover;border-radius:26px;display:block;margin:0 auto 20px;box-shadow:0 12px 34px rgba(0,0,0,.45),0 0 28px rgba(106,255,37,.13);border:1px solid rgba(255,255,255,.14)}
h1{font-size:clamp(18px,4.5vw,25px);line-height:1.18;letter-spacing:-.35px;margin:0 auto 10px;max-width:100%;overflow-wrap:normal;word-break:normal;text-wrap:balance;text-shadow:0 3px 24px rgba(0,0,0,.25)}.muted{font-size:14px;line-height:1.6;color:#aab7ce;margin:0 auto 28px;max-width:300px}.eyebrow{display:inline-flex;align-items:center;gap:7px;margin:0 auto 22px;padding:8px 12px;border:1px solid rgba(25,216,255,.20);border-radius:999px;background:rgba(10,213,255,.07);color:#75eaff;font-size:10px;font-weight:900;letter-spacing:1.5px}.actions{gap:13px}.actions .btn{min-height:58px;border-radius:16px;font-size:15px;letter-spacing:.1px;background:linear-gradient(135deg,#a855f7 0%,#6366f1 52%,#3b82f6 100%);color:#fff;box-shadow:0 12px 30px rgba(99,102,241,.25),inset 0 1px 0 rgba(255,255,255,.22);border:1px solid rgba(255,255,255,.12);transition:transform .18s ease,filter .18s ease}.actions .btn:active{transform:scale(.985);filter:brightness(1.08)}.actions .btn:focus-visible{outline:3px solid rgba(255,255,255,.8);outline-offset:3px}.actions .secondary{background:linear-gradient(135deg,#20203b 0%,#322653 52%,#263a62 100%);color:#f7f5ff;border:1px solid rgba(192,163,255,.38);box-shadow:0 12px 30px rgba(90,60,160,.20),inset 0 1px 0 rgba(255,255,255,.10)}.landing-foot{margin:24px 0 0;color:#74829b;font-size:10px;letter-spacing:.7px;font-weight:700}.mini-features{display:flex;justify-content:center;gap:8px;flex-wrap:wrap;margin-top:21px}.mini-features span{font-size:10px;color:#a9b7cc;border:1px solid rgba(143,160,192,.18);background:rgba(255,255,255,.025);border-radius:999px;padding:7px 10px}.decor{width:72px;height:72px;border-radius:20px;opacity:.48;filter:drop-shadow(0 12px 25px rgba(0,0,0,.4))}.decor.one{left:max(12px,calc(50% - 300px));top:12%}.decor.two{right:max(12px,calc(50% - 300px));bottom:13%}@media(max-width:480px){body{padding:22px 14px 28px}.card{border-radius:26px}.brand-mark{width:86px;height:86px}}@media(prefers-reduced-motion:reduce){.decor{animation:none}.actions .btn{transition:none}}
</style>
<style id="landing-premium-final-v16">
/* Landing page only: compact, balanced brand title and premium button finishes. */
body .card h1{
  font-size:clamp(19px,4.8vw,23px)!important;
  line-height:1.13!important;
  letter-spacing:-.65px!important;
  font-weight:900!important;
  max-width:100%!important;
  overflow-wrap:normal!important;
  word-break:normal!important;
  text-wrap:balance!important;
  margin:0 auto 12px!important;
  color:#f8f7ff!important;
  text-shadow:0 2px 22px rgba(154,112,255,.14)!important;
}
body .card .actions{gap:12px!important}
body .card .actions .btn{
  min-height:56px!important;
  padding:14px 16px!important;
  border-radius:16px!important;
  font-size:15px!important;
  line-height:1.2!important;
  font-weight:850!important;
  letter-spacing:.15px!important;
  color:#fff!important;
  border:1px solid rgba(255,255,255,.19)!important;
  background:linear-gradient(135deg,#9b5cf6 0%,#7554e8 48%,#456de8 100%)!important;
  box-shadow:0 10px 28px rgba(104,78,221,.24),inset 0 1px 0 rgba(255,255,255,.24)!important;
  text-decoration:none!important;
  transition:transform .18s ease,filter .18s ease!important;
}
body .card .actions .btn.secondary{
  color:#fbf8ff!important;
  background:linear-gradient(135deg,#28223f 0%,#34294e 52%,#242d48 100%)!important;
  border:1px solid rgba(196,166,255,.48)!important;
  box-shadow:0 10px 26px rgba(43,30,78,.26),inset 0 1px 0 rgba(255,255,255,.13)!important;
}
body .card .actions .btn:active{transform:scale(.985)!important;filter:brightness(1.1)!important}
body .card .actions .btn:focus-visible{outline:3px solid rgba(205,190,255,.9)!important;outline-offset:3px!important}
@media(max-width:380px){body .card h1{font-size:19px!important;letter-spacing:-.75px!important}body .card .actions .btn{font-size:14px!important;min-height:53px!important}}
@media(prefers-reduced-motion:reduce){body .card .actions .btn{transition:none!important}}
</style>
<script src="/admin/admin-action-progress.js?v=20261023-inline-progress25" defer></script>

<script>
/* XTREME TITAN PWA: register service worker for Android installation support. */
if ('serviceWorker' in navigator) {
  window.addEventListener('load', function () {
    navigator.serviceWorker.register('./service-worker.js', { scope: './' })
      .catch(function (error) {
        console.warn('PWA service worker registration failed:', error);
      });
  });
}
</script>


<link rel="stylesheet" href="pwa-install-prompt.css?v=1">
</head>
<body>
<img class="decor one" src="<?=e($site['logo_path'])?>" alt="" aria-hidden="true"><img class="decor two" src="<?=e($site['logo_path'])?>" alt="" aria-hidden="true">
<main class="card">
<div class="eyebrow">✦ SECURE ACCESS</div>
<img class="brand-mark" src="<?=e($site['logo_path'])?>" alt="XTREME TITAN OFFICIAL">
<h1><?=e(trim(preg_replace('/\s+/', ' ', str_replace('_', ' ', (string)($site['site_title'] ?? 'XTREME TITAN OFFICIAL SHOP')))))?></h1>
<p class="muted"><?=e($site['site_subtitle'])?></p>
<?php if($error): ?><div class="alert"><?=htmlspecialchars($error,ENT_QUOTES,'UTF-8')?></div><?php endif; ?>
<div class="actions"><a class="btn" href="login.php">Sign In&nbsp; →</a><a class="btn secondary" href="register.php">Create Account&nbsp; ✦</a></div>
<div class="mini-features"><span>✦ Premium Digital Products</span><span>◈ Secure Account Access</span></div>
<p class="landing-foot">© <?=date('Y')?> XTREME TITAN OFFICIAL SHOP</p>
</main>

<script src="pwa-install-prompt.js?v=1" defer></script>
</body>
</html>
