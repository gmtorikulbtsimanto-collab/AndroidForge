XTREME TITAN Dashboard UI v31

Changes: dashboard icon styling and neon color grading are placed in the actual store page head (not the database-error page). Compact Quick Access buttons are retained. Balance warning logic and purchase/payment behavior are unchanged.

Upload this ZIP using your usual deployment process after backing up the current site. Test on the live host before replacing the backup.
