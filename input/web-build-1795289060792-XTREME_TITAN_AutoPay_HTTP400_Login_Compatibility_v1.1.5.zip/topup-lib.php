<?php
// XTREME TITAN dynamic gaming top-up catalog and order helpers.
function xt_topup_ensure_tables(): void {
    $pdo=db();
    $pdo->exec("CREATE TABLE IF NOT EXISTS topup_products (
      id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
      name VARCHAR(150) NOT NULL,
      category_slug VARCHAR(60) NOT NULL DEFAULT 'diamond',
      category_name VARCHAR(80) NOT NULL DEFAULT 'Diamond',
      description TEXT NULL,
      image_path VARCHAR(255) NULL,
      amount_label VARCHAR(100) NOT NULL DEFAULT '',
      price DECIMAL(12,2) NOT NULL DEFAULT 0,
      min_qty INT NOT NULL DEFAULT 1,
      max_qty INT NOT NULL DEFAULT 1,
      sort_order INT NOT NULL DEFAULT 0,
      status TINYINT(1) NOT NULL DEFAULT 1,
      created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
      updated_at DATETIME NULL,
      INDEX idx_topup_active(status,sort_order),
      INDEX idx_topup_category(category_slug)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    $pdo->exec("CREATE TABLE IF NOT EXISTS topup_orders (
      id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
      user_id INT NOT NULL,
      product_id BIGINT UNSIGNED NULL,
      purchase_id BIGINT UNSIGNED NULL,
      product_name VARCHAR(150) NOT NULL,
      category_slug VARCHAR(60) NOT NULL DEFAULT 'other',
      amount_label VARCHAR(100) NOT NULL DEFAULT '',
      player_uid VARCHAR(100) NOT NULL,
      server_id VARCHAR(80) NULL,
      quantity INT NOT NULL DEFAULT 1,
      unit_price DECIMAL(12,2) NOT NULL,
      total_amount DECIMAL(12,2) NOT NULL,
      status VARCHAR(20) NOT NULL DEFAULT 'pending',
      admin_note VARCHAR(500) NULL,
      created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
      updated_at DATETIME NULL,
      INDEX idx_topup_user(user_id,created_at),
      INDEX idx_topup_status(status,created_at)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    // Existing stores already use this table as the wallet purchase ledger.
    $pdo->exec("CREATE TABLE IF NOT EXISTS user_purchases (
      id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
      user_id INT NOT NULL,
      product_id INT NOT NULL DEFAULT 0,
      product_name VARCHAR(150) NOT NULL,
      plan_name VARCHAR(150) NOT NULL,
      duration_days INT NOT NULL DEFAULT 0,
      quantity INT NOT NULL DEFAULT 1,
      unit_price DECIMAL(12,2) NOT NULL DEFAULT 0,
      total_amount DECIMAL(12,2) NOT NULL DEFAULT 0,
      created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
      INDEX idx_user_purchase_user(user_id,created_at)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    xt_topup_upgrade_columns($pdo,'topup_orders',[
      'user_id'=>'INT NOT NULL DEFAULT 0','product_id'=>'BIGINT UNSIGNED NULL','purchase_id'=>'BIGINT UNSIGNED NULL',
      'product_name'=>"VARCHAR(150) NOT NULL DEFAULT ''",'category_slug'=>"VARCHAR(60) NOT NULL DEFAULT 'other'",
      'amount_label'=>"VARCHAR(100) NOT NULL DEFAULT ''",'player_uid'=>"VARCHAR(100) NOT NULL DEFAULT ''",
      'server_id'=>'VARCHAR(80) NULL','quantity'=>'INT NOT NULL DEFAULT 1','unit_price'=>'DECIMAL(12,2) NOT NULL DEFAULT 0',
      'total_amount'=>'DECIMAL(12,2) NOT NULL DEFAULT 0','status'=>"VARCHAR(20) NOT NULL DEFAULT 'pending'",
      'created_at'=>'DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP','updated_at'=>'DATETIME NULL'
    ]);
    xt_topup_upgrade_columns($pdo,'user_purchases',[
      'user_id'=>'INT NOT NULL DEFAULT 0','product_id'=>'INT NOT NULL DEFAULT 0',
      'product_name'=>"VARCHAR(150) NOT NULL DEFAULT ''",'plan_name'=>"VARCHAR(150) NOT NULL DEFAULT ''",
      'duration_days'=>'INT NOT NULL DEFAULT 0','quantity'=>'INT NOT NULL DEFAULT 1',
      'unit_price'=>'DECIMAL(12,2) NOT NULL DEFAULT 0','total_amount'=>'DECIMAL(12,2) NOT NULL DEFAULT 0',
      'created_at'=>'DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP'
    ]);
    xt_topup_upgrade_columns($pdo,'topup_products',[
      'name'=>"VARCHAR(150) NOT NULL DEFAULT ''",'category_slug'=>"VARCHAR(60) NOT NULL DEFAULT 'diamond'",'category_name'=>"VARCHAR(80) NOT NULL DEFAULT 'Diamond'",
      'description'=>'TEXT NULL','image_path'=>'VARCHAR(255) NULL','amount_label'=>"VARCHAR(100) NOT NULL DEFAULT ''",
      'price'=>'DECIMAL(12,2) NOT NULL DEFAULT 0','min_qty'=>'INT NOT NULL DEFAULT 1','max_qty'=>'INT NOT NULL DEFAULT 1',
      'sort_order'=>'INT NOT NULL DEFAULT 0','status'=>'TINYINT(1) NOT NULL DEFAULT 1','created_at'=>'DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP','updated_at'=>'DATETIME NULL',
      'custom_fields_json'=>'LONGTEXT NULL'
    ]);
    xt_topup_upgrade_columns($pdo,'topup_orders',[
      'custom_fields_json'=>'LONGTEXT NULL'
    ]);
}

function xt_topup_upgrade_columns(PDO $pdo,string $table,array $defs): void {
    $table=preg_replace('/[^a-zA-Z0-9_]/','',$table);
    $cols=[];
    try{$cols=$pdo->query("SHOW COLUMNS FROM `$table`")->fetchAll(PDO::FETCH_COLUMN);}catch(Throwable $e){return;}
    foreach($defs as $name=>$definition){
        if(!in_array($name,$cols,true)){
            try{$pdo->exec("ALTER TABLE `$table` ADD COLUMN `$name` $definition");}catch(Throwable $e){error_log("XT topup schema upgrade $table.$name: ".$e->getMessage());}
        }
    }
}

function xt_topup_slug(string $v): string {
    $v=strtolower(trim($v)); $v=preg_replace('/[^a-z0-9]+/','-',$v);
    return trim((string)$v,'-') ?: 'other';
}

function xt_topup_sync_history_categories(): void {
    $pdo=db();
    $pdo->exec("CREATE TABLE IF NOT EXISTS history_categories (
      id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
      name VARCHAR(60) NOT NULL,
      slug VARCHAR(60) NOT NULL UNIQUE,
      keywords TEXT NULL,
      kind VARCHAR(20) NOT NULL DEFAULT 'purchase',
      sort_order INT NOT NULL DEFAULT 0,
      enabled TINYINT(1) NOT NULL DEFAULT 1,
      created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    $st=$pdo->query("SELECT category_slug,MAX(category_name) AS category_name FROM topup_products GROUP BY category_slug");
    $up=$pdo->prepare("INSERT INTO history_categories(name,slug,keywords,kind,sort_order,enabled) VALUES(?,?,?,'purchase',70,1) ON DUPLICATE KEY UPDATE enabled=1");
    foreach($st->fetchAll(PDO::FETCH_ASSOC) as $r){
      $slug=(string)$r['category_slug'];$name=(string)$r['category_name'];
      $up->execute([mb_substr($name,0,60),$slug,$slug.','.str_replace(' ',',',strtolower($name))]);
    }
}


/** Customer in-app notifications used for Top-Up request updates. */
function xt_user_notification_tables(): void {
    db()->exec("CREATE TABLE IF NOT EXISTS user_notifications (
      id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
      user_id INT NOT NULL,
      event_type VARCHAR(40) NOT NULL DEFAULT 'general',
      title VARCHAR(160) NOT NULL,
      body VARCHAR(500) NOT NULL,
      target_url VARCHAR(255) NOT NULL DEFAULT 'history.php',
      created_at DATETIME NOT NULL,
      read_at DATETIME NULL,
      INDEX idx_user_notice_unread (user_id,read_at,id),
      INDEX idx_user_notice_type (user_id,event_type,id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
}

/** Send an in-app notice to every registered customer. */
function xt_user_notify_all(string $eventType, string $title, string $body, string $targetUrl='history.php'): void {
    try {
        xt_user_notification_tables();
        $pdo=db();
        $targetUrl=ltrim($targetUrl,'/');
        if ($targetUrl==='' || strpos($targetUrl,'..')!==false || preg_match('~^[a-z]+:~i',$targetUrl)) $targetUrl='history.php';
        $ids=$pdo->query('SELECT id FROM users')->fetchAll(PDO::FETCH_COLUMN);
        if (!$ids) return;
        $st=$pdo->prepare('INSERT INTO user_notifications(user_id,event_type,title,body,target_url,created_at) VALUES(?,?,?,?,?,UTC_TIMESTAMP())');
        foreach ($ids as $id) {
            $uid=(int)$id; if($uid<1) continue;
            $st->execute([$uid,mb_substr($eventType,0,40),mb_substr($title,0,160),mb_substr($body,0,500),mb_substr($targetUrl,0,255)]);
        }
    } catch(Throwable $e) { error_log('XT broadcast notification: '.$e->getMessage()); }
}

function xt_user_notify(int $userId, string $eventType, string $title, string $body, string $targetUrl='history.php'): void {
    if ($userId < 1) return;
    try {
        $targetUrl=ltrim($targetUrl,'/');
        if ($targetUrl==='' || strpos($targetUrl,'..')!==false || preg_match('~^[a-z]+:~i',$targetUrl)) $targetUrl='history.php';
        $st=db()->prepare('INSERT INTO user_notifications(user_id,event_type,title,body,target_url,created_at) VALUES(?,?,?,?,?,UTC_TIMESTAMP())');
        $st->execute([$userId,mb_substr($eventType,0,40),mb_substr($title,0,160),mb_substr($body,0,500),mb_substr($targetUrl,0,255)]);
    } catch(Throwable $e) {
        // A notification failure must never cancel a valid top-up order or status update.
        error_log('XT customer notification: '.$e->getMessage());
    }
}


/** Admin in-panel notification for newly submitted customer Top-Up requests. */
function xt_topup_admin_notification_tables(): void {
    db()->exec("CREATE TABLE IF NOT EXISTS admin_notifications (
      id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
      event_type VARCHAR(40) NOT NULL,
      title VARCHAR(160) NOT NULL,
      body VARCHAR(500) NOT NULL,
      target_url VARCHAR(255) NOT NULL DEFAULT 'dashboard.php',
      created_at DATETIME NOT NULL,
      read_at DATETIME NULL,
      INDEX idx_admin_notice_unread (read_at,id),
      INDEX idx_admin_notice_type (event_type,id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
}

function xt_topup_admin_notify(string $title, string $body, string $targetUrl='topup-orders.php'): void {
    try {
        $url=ltrim($targetUrl,'/');
        if ($url==='' || strpos($url,'..')!==false || preg_match('~^[a-z]+:~i',$url)) $url='topup-orders.php';
        $st=db()->prepare("INSERT INTO admin_notifications(event_type,title,body,target_url,created_at)
            VALUES('topup_request',?,?,?,UTC_TIMESTAMP())");
        $st->execute([mb_substr($title,0,160),mb_substr($body,0,500),mb_substr($url,0,255)]);
    } catch (Throwable $e) {
        error_log('XT Top-Up admin notification: '.$e->getMessage());
    }
}
