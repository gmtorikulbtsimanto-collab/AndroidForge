XTREME TITAN V37 — PRODUCT PLAN HOURS + VIDEO UPLOAD

Changes in this update:
- Product plan editor displays the absolute duration number for existing hour plans (e.g. stored -12 now displays 12).
- Saving a plan whose name says HOUR/HOURS/HR/HRS stores the existing negative-hour convention and updates duration_seconds consistently. Day plans continue to store positive days.
- Product video chunk-upload maximum raised from 100 MiB to 300 MiB, with 2 MiB chunks to reduce the number of requests.
- Product photo upload limit remains 8 MiB.
- Existing product descriptions and media links are preserved by the existing save flow.

Important hosting note:
The app now accepts files up to 300 MiB in its own validation, but shared hosting can still block requests, storage use, or repeated chunk requests. This ZIP cannot override host-level restrictions. If uploads still fail on InfinityFree, use an externally hosted MP4/WebM URL or a host that permits large uploads.

Install:
Back up the site first. Upload the ZIP contents over the matching existing files. The changed files are admin/products.php and chunked-video-upload.php.
