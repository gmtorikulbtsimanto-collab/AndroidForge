<?php
declare(strict_types=1);

// Keep notices/warnings from config or included files out of the JSON response.
ob_start();
ini_set('display_errors', '0');
ini_set('display_startup_errors', '0');
error_reporting(E_ALL);

function googleJson(array $data, int $status = 200): void
{
    while (ob_get_level() > 0) { @ob_end_clean(); }
    http_response_code($status);
    header('Content-Type: application/json; charset=utf-8');
    header('Cache-Control: no-store, max-age=0');
    echo json_encode($data, JSON_UNESCAPED_SLASHES | JSON_INVALID_UTF8_SUBSTITUTE);
    exit;
}

function googleFail(string $message, int $status = 400): void
{
    googleJson(['ok' => false, 'error' => $message], $status);
}

function googleGet(string $url): array
{
    $body = false;
    $code = 0;
    if (function_exists('curl_init')) {
        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT => 20,
            CURLOPT_SSL_VERIFYPEER => true,
            CURLOPT_SSL_VERIFYHOST => 2,
        ]);
        $body = curl_exec($ch);
        $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
    }
    if (($body === false || $code >= 400) && ini_get('allow_url_fopen')) {
        $ctx = stream_context_create(['http' => ['timeout' => 20, 'ignore_errors' => true]]);
        $body = @file_get_contents($url, false, $ctx);
        if ($body !== false) {
            // Parse the actual HTTP status when the stream wrapper provides it.
            $headers = $http_response_header ?? [];
            foreach ($headers as $header) {
                if (preg_match('~^HTTP/\S+\s+(\d{3})~i', $header, $m)) $code = (int)$m[1];
            }
        }
    }
    if ($body === false || $code < 200 || $code >= 400) {
        throw new RuntimeException('Google verification service is unavailable.');
    }
    $json = json_decode((string)$body, true);
    if (!is_array($json)) throw new RuntimeException('Invalid response from Google verification service.');
    return $json;
}

$clientId = '865419675972-n8g84i701iu6ngui7c9auvoqv889v17n.apps.googleusercontent.com';

try {
    require_once __DIR__ . '/config.php';
    if (session_status() !== PHP_SESSION_ACTIVE) session_start();
    if (!empty($_SESSION['user_id'])) googleJson(['ok' => true]);
    if (($_SERVER['REQUEST_METHOD'] ?? 'GET') !== 'POST') googleFail('Please start Google Login from the login or register page.', 405);
    $credential = trim((string)($_POST['credential'] ?? ''));
    if ($credential === '') googleFail('Google login was not completed. Please try again.');

    $info = googleGet('https://oauth2.googleapis.com/tokeninfo?id_token=' . rawurlencode($credential));
    $aud = (string)($info['aud'] ?? $info['issued_to'] ?? '');
    $email = strtolower(trim((string)($info['email'] ?? '')));
    $verifiedRaw = $info['email_verified'] ?? $info['verified_email'] ?? false;
    $verified = ($verifiedRaw === true || $verifiedRaw === 1 || $verifiedRaw === '1' || strtolower((string)$verifiedRaw) === 'true');
    if (!hash_equals($clientId, $aud)) googleFail('Google Client ID verification failed.');
    if (!filter_var($email, FILTER_VALIDATE_EMAIL) || !$verified) googleFail('Google account email could not be verified.');

    $jwtParts = explode('.', $credential);
    if (count($jwtParts) !== 3) googleFail('Invalid Google credential.');
    $payloadPart = strtr($jwtParts[1], '-_', '+/');
    $payloadPart .= str_repeat('=', (4 - strlen($payloadPart) % 4) % 4);
    $payload = json_decode((string)base64_decode($payloadPart, true), true);
    if (!is_array($payload)) googleFail('Invalid Google credential payload.');
    $sub = trim((string)($payload['sub'] ?? $info['user_id'] ?? ''));
    $name = trim((string)($payload['name'] ?? 'Google User'));
    $issuer = (string)($payload['iss'] ?? '');
    $exp = (int)($payload['exp'] ?? 0);
    if (($issuer !== 'https://accounts.google.com' && $issuer !== 'accounts.google.com') || $sub === '' || $exp <= time()) {
        googleFail('Google account token is not valid.');
    }
    $expectedNonce = (string)($_SESSION['google_login_nonce'] ?? '');
    $tokenNonce = (string)($payload['nonce'] ?? '');
    if ($expectedNonce !== '' && $tokenNonce !== '' && !hash_equals($expectedNonce, $tokenNonce)) {
        googleFail('Google security verification expired. Refresh the page and try again.');
    }
    // Some Google Identity Services account-selection paths may omit the nonce
    // claim even when the credential itself is valid. In that case continue to
    // rely on Google's tokeninfo validation plus audience, issuer, expiry and
    // verified-email checks above; reject an explicit nonce mismatch.

    $pdo = db();
    $stmt = $pdo->prepare('SELECT * FROM users WHERE email = ? LIMIT 1');
    $stmt->execute([$email]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$user) {
        $columnsInfo = $pdo->query('SHOW COLUMNS FROM users')->fetchAll(PDO::FETCH_ASSOC);
        $has = [];
        foreach ($columnsInfo as $column) $has[$column['Field']] = $column;
        $columns = [];
        $values = [];
        $add = static function (string $column, $value) use (&$columns, &$values, $has): void {
            if (isset($has[$column])) {
                $columns[] = '`' . str_replace('`', '``', $column) . '`';
                $values[] = $value;
            }
        };
        if (isset($has['name'])) $add('name', $name);
        elseif (isset($has['full_name'])) $add('full_name', $name);
        elseif (isset($has['username'])) $add('username', $name);
        if (isset($has['email'])) $add('email', $email);
        elseif (isset($has['email_address'])) $add('email_address', $email);
        foreach (['phone', 'phone_number', 'mobile'] as $phoneCol) {
            if (isset($has[$phoneCol])) {
                $nullable = strtoupper((string)$has[$phoneCol]['Null']) === 'YES';
                if ($nullable) $add($phoneCol, null);
                elseif (($has[$phoneCol]['Default'] ?? null) === null) $add($phoneCol, 'G' . substr(hash('sha256', $sub), 0, 14));
                break;
            }
        }
        $passwordHash = password_hash(bin2hex(random_bytes(32)), PASSWORD_DEFAULT);
        if (isset($has['password'])) $add('password', $passwordHash);
        elseif (isset($has['password_hash'])) $add('password_hash', $passwordHash);
        elseif (isset($has['pass'])) $add('pass', $passwordHash);
        foreach (['otp_hash', 'otp_expires_at'] as $column) {
            if (isset($has[$column]) && strtoupper((string)$has[$column]['Null']) === 'YES') $add($column, null);
        }
        if (isset($has['otp_attempts']) && ($has['otp_attempts']['Default'] ?? null) === null) $add('otp_attempts', 0);
        if (!$columns) googleFail('Could not determine the users table fields.', 500);
        $marks = implode(',', array_fill(0, count($columns), '?'));
        $insert = $pdo->prepare('INSERT INTO users (' . implode(',', $columns) . ') VALUES (' . $marks . ')');
        $insert->execute($values);
        $newId = (int)$pdo->lastInsertId();
        $idColumn = isset($has['id']) ? 'id' : (isset($has['user_id']) ? 'user_id' : 'id');
        $stmt = $pdo->prepare("SELECT * FROM users WHERE `$idColumn` = ? LIMIT 1");
        $stmt->execute([$newId]);
        $user = $stmt->fetch(PDO::FETCH_ASSOC);
    }
    if (!$user) googleFail('Could not create or load your account.', 500);
    $userId = (int)($user['id'] ?? $user['user_id'] ?? 0);
    if ($userId <= 0) googleFail('Invalid user account ID.', 500);

    // The region chosen immediately before Google sign-in must be persisted to the account.
    $region = strtoupper(trim((string)($_POST['region'] ?? 'BD')));
    $regionSettings = [
        'BD'=>['currency'=>'BDT','language'=>'bn'],
        'IN'=>['currency'=>'INR','language'=>'hi'],
        'NP'=>['currency'=>'NPR','language'=>'ne'],
        'BT'=>['currency'=>'BTN','language'=>'dz'],
        'VN'=>['currency'=>'VND','language'=>'vi'],
        'OT'=>['currency'=>'USD','language'=>'en'],
    ];
    if (!isset($regionSettings[$region])) $region = 'BD';
    try {
        ensure_user_preference_columns();
        $pref = $regionSettings[$region];
        $userIdColumn = isset($user['id']) ? 'id' : (isset($user['user_id']) ? 'user_id' : 'id');
        $up = $pdo->prepare('UPDATE users SET currency=?, country_code=?, language=? WHERE `' . $userIdColumn . '`=?');
        $up->execute([$pref['currency'], $region, $pref['language'], $userId]);
    } catch (Throwable $prefError) {
        error_log('Google login preference save failed: ' . $prefError->getMessage());
        googleFail('Google login succeeded but country preferences could not be saved. Please try again.', 500);
    }

    session_regenerate_id(true);
    $_SESSION['user_id'] = $userId;
    $_SESSION['user_name'] = (string)($user['name'] ?? $user['full_name'] ?? $user['username'] ?? $name);
    $_SESSION['user_email'] = (string)($user['email'] ?? $user['email_address'] ?? $email);
    $_SESSION['user_country'] = $region;
    $_SESSION['user_currency'] = $regionSettings[$region]['currency'];
    $_SESSION['user_language'] = $regionSettings[$region]['language'];
    unset($_SESSION['google_login_nonce']);
    googleJson(['ok' => true, 'country'=>$region, 'currency'=>$regionSettings[$region]['currency'], 'language'=>$regionSettings[$region]['language']]);
} catch (Throwable $e) {
    // Keep technical details in server logs only; return JSON to the browser.
    error_log('Google Login error: ' . $e->getMessage());
    googleFail('Google Login error. Please check the hosting PHP Error Log.', 500);
}
