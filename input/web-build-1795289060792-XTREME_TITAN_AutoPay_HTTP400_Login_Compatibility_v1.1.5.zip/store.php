<?php

declare(strict_types=1);

require_once __DIR__ . '/config.php';
ensure_product_plan_type_column();

/*
|--------------------------------------------------------------------------
| ERROR HANDLING
|--------------------------------------------------------------------------
| White screen বন্ধ করার জন্য development error display রাখা হয়েছে।
| কাজ হয়ে গেলে চাইলে display_errors = 0 করতে পারবেন।
|--------------------------------------------------------------------------
*/

error_reporting(E_ALL);
ini_set('display_errors', '1');
ini_set('display_startup_errors', '1');


/*
|--------------------------------------------------------------------------
| SESSION / LOGIN
|--------------------------------------------------------------------------
*/

if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}


/*
|--------------------------------------------------------------------------
| USER ID
|--------------------------------------------------------------------------
| আপনার login system-এ সাধারণত $_SESSION['user_id'] থাকার কথা।
|--------------------------------------------------------------------------
*/

$userId = (int)($_SESSION['user_id'] ?? 0);

if (empty($_SESSION['buy_csrf'])) {
    $_SESSION['buy_csrf'] = bin2hex(random_bytes(32));
}
$buyCsrf = $_SESSION['buy_csrf'];
$purchaseErrorFlash = (string)($_SESSION['purchase_error_flash'] ?? '');
$purchaseErrorAmounts = $_SESSION['purchase_error_amounts'] ?? null;
unset($_SESSION['purchase_error_flash'], $_SESSION['purchase_error_amounts']);
$site = site_settings();
$userRole = current_user_role();
$resellerDiscount = ($userRole === 'reseller') ? max(0.0, min(90.0, (float)site_setting('reseller_discount_percent', '20'))) : 0.0;

if ($userId <= 0) {
    header('Location: login.php');
    exit;
}


/*
|--------------------------------------------------------------------------
| DATABASE
|--------------------------------------------------------------------------
*/

try {
    $pdo = db();

    if (!$pdo instanceof PDO) {
        throw new RuntimeException('Database connection failed.');
    }

} catch (Throwable $e) {

    http_response_code(500);

    echo '<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no,viewport-fit=cover"><title>Store Error</title><style>body{margin:0;padding:28px 16px;background:#07101d;color:#f4f6fb;font:15px Arial,sans-serif}.box{max-width:680px;margin:30px auto;padding:22px;border:1px solid #344155;border-radius:16px;background:#111d2d}h2{margin-top:0;color:#ff8194}pre{white-space:pre-wrap;overflow-wrap:anywhere;color:#ffd2d8;font-size:13px}</style><link rel="stylesheet" href="store-redesign.css?v=1"><link rel="stylesheet" href="store-redesign.css?v=20261114-premium2">
<style id="xt-topup-premium-final">
.xt-topup-entry{position:relative!important;isolation:isolate!important;overflow:hidden!important;padding:18px!important;border:1px solid rgba(112,132,255,.52)!important;border-radius:24px!important;background:radial-gradient(circle at 8% 0%,rgba(0,220,220,.18),transparent 34%),radial-gradient(circle at 100% 100%,rgba(214,46,255,.18),transparent 38%),linear-gradient(145deg,#11182e,#17132f 52%,#0b1428)!important;box-shadow:0 18px 42px #0006,inset 0 1px 0 #ffffff14!important}
.xt-topup-head>a,.xt-topup-tiles a,.xt-topup-tiles a:link,.xt-topup-tiles a:visited{color:#f5f7ff!important;text-decoration:none!important;-webkit-text-decoration:none!important}
.xt-topup-head>a{display:inline-flex!important;align-items:center!important;justify-content:center!important;min-height:42px!important;padding:0 17px!important;border:1px solid #ffffff40!important;border-radius:14px!important;background:linear-gradient(115deg,#00d5bb,#2687ff 58%,#8756ff)!important;color:#061323!important;font-weight:950!important;box-shadow:0 8px 22px #14aaff38!important}
.xt-topup-tiles{display:grid!important;grid-template-columns:repeat(5,minmax(0,1fr))!important;gap:9px!important;margin-top:17px!important}
.xt-topup-tiles a,.xt-topup-tiles a:link,.xt-topup-tiles a:visited{position:relative!important;display:flex!important;min-width:0!important;min-height:94px!important;flex-direction:column!important;align-items:center!important;justify-content:center!important;gap:9px!important;padding:12px 5px!important;border:1px solid #7e99dc61!important;border-radius:17px!important;background:linear-gradient(150deg,#1f2f52f5,#0d1429fa)!important;text-align:center!important;box-shadow:0 9px 22px #0005,inset 0 1px 0 #ffffff14!important;transition:transform .18s,border-color .18s,box-shadow .18s!important}
.xt-topup-tiles a:nth-child(1){border-color:#27daff9e!important;background:linear-gradient(150deg,#0a5e857f,#0f1935fa)!important}.xt-topup-tiles a:nth-child(2){border-color:#ff5bab8c!important;background:linear-gradient(150deg,#701e5e73,#131631fa)!important}.xt-topup-tiles a:nth-child(3){border-color:#ffcc5294!important;background:linear-gradient(150deg,#744f176b,#151831fa)!important}.xt-topup-tiles a:nth-child(4){border-color:#a379ff94!important;background:linear-gradient(150deg,#522c8973,#121631fa)!important}.xt-topup-tiles a:nth-child(5){border-color:#2fe1b28c!important;background:linear-gradient(150deg,#0d65536b,#10172ffa)!important}
.xt-topup-tiles a:active{transform:translateY(1px) scale(.985)!important}.xt-topup-tiles a span{display:grid!important;place-items:center!important;width:42px!important;height:42px!important;border-radius:13px!important;background:#050d1e8f!important;border:1px solid #ffffff20!important;font-size:25px!important;line-height:1!important;box-shadow:0 5px 14px #0006!important}.xt-topup-tiles a b{display:block!important;color:#f6f8ff!important;font-size:clamp(9px,2.5vw,12px)!important;font-weight:950!important;line-height:1.25!important;text-decoration:none!important;overflow-wrap:anywhere!important}
@media(max-width:520px){.xt-topup-entry{padding:13px!important}.xt-topup-tiles{grid-template-columns:repeat(3,minmax(0,1fr))!important;gap:8px!important}.xt-topup-tiles a{min-height:88px!important}.xt-topup-head{align-items:flex-start!important}.xt-topup-head>a{min-height:38px!important;padding:0 12px!important}}
</style>

</head><body><main class="box"><h2>Store temporarily unavailable</h2><pre>' . htmlspecialchars($e->getMessage(), ENT_QUOTES, 'UTF-8') . '</pre></main>
<style id="xt-topup-category-card-final-fix">
section.xt-topup-entry .xt-topup-head>a,
section.xt-topup-entry .xt-topup-head>a:link,
section.xt-topup-entry .xt-topup-head>a:visited,
section.xt-topup-entry .xt-topup-tiles>a,
section.xt-topup-entry .xt-topup-tiles>a:link,
section.xt-topup-entry .xt-topup-tiles>a:visited{
  display:flex!important;position:relative!important;align-items:center!important;
  justify-content:center!important;flex-direction:column!important;gap:9px!important;
  min-width:0!important;min-height:88px!important;padding:12px 8px!important;
  border:1px solid rgba(114,164,255,.58)!important;border-radius:18px!important;
  background:linear-gradient(145deg,rgba(26,48,83,.98),rgba(15,20,43,.98))!important;
  color:#f5f7ff!important;text-decoration:none!important;-webkit-text-decoration:none!important;
  font-weight:950!important;text-align:center!important;line-height:1.25!important;
  box-shadow:0 8px 22px rgba(0,0,0,.34),inset 0 1px 0 rgba(255,255,255,.12)!important;
  overflow:hidden!important;
}
section.xt-topup-entry .xt-topup-head>a{
  min-height:42px!important;flex-direction:row!important;padding:0 18px!important;
  border-color:rgba(44,225,232,.65)!important;
  background:linear-gradient(110deg,#06c9b5,#2687ff 58%,#9255ef)!important;
  color:#071323!important;
}
section.xt-topup-entry .xt-topup-tiles>a:nth-child(5n/**/+1){border-color:#24d8ef!important;background:linear-gradient(145deg,#075b79,#101b38)!important}
section.xt-topup-entry .xt-topup-tiles>a:nth-child(5n/**/+2){border-color:#f05cb8!important;background:linear-gradient(145deg,#612052,#17152f)!important}
section.xt-topup-entry .xt-topup-tiles>a:nth-child(5n/**/+3){border-color:#f4c45d!important;background:linear-gradient(145deg,#60451b,#17182e)!important}
section.xt-topup-entry .xt-topup-tiles>a:nth-child(5n/**/+4){border-color:#a77aff!important;background:linear-gradient(145deg,#482b79,#15172f)!important}
section.xt-topup-entry .xt-topup-tiles>a:nth-child(5n){border-color:#37d6a8!important;background:linear-gradient(145deg,#075448,#111a30)!important}
section.xt-topup-entry .xt-topup-tiles>a span{
  display:grid!important;place-items:center!important;width:43px!important;height:43px!important;
  border-radius:14px!important;background:rgba(4,12,28,.78)!important;
  border:1px solid rgba(255,255,255,.2)!important;font-size:25px!important;line-height:1!important;
}
section.xt-topup-entry .xt-topup-tiles>a b{
  display:block!important;color:#f7f8ff!important;font-size:clamp(10px,2.8vw,13px)!important;
  font-weight:950!important;text-decoration:none!important;overflow-wrap:anywhere!important;
}
section.xt-topup-entry .xt-topup-tiles>a:active{transform:translateY(1px) scale(.985)!important}
@media(max-width:520px){
 section.xt-topup-entry .xt-topup-tiles{grid-template-columns:repeat(3,minmax(0,1fr))!important;gap:8px!important}
 section.xt-topup-entry .xt-topup-tiles>a{min-height:86px!important;padding:10px 5px!important}
}
</style>



<style id="xt-balance-single-logo-final-v41">
/* Balance card only: one real logo image, one amount, one Add Funds action. */
.store-dashboard .dashboard-balance{
  display:block!important;
  position:relative!important;
  min-width:0!important;
  min-height:0!important;
  padding:20px 18px!important;
  overflow:hidden!important;
  box-sizing:border-box!important;
  animation:none!important;
  transition:none!important;
}
/* Disable legacy wallet pseudo-icons that caused duplicate logos and overlap. */
.store-dashboard .dashboard-balance:before,
.store-dashboard .dashboard-balance:after,
.store-dashboard .dashboard-balance-value:before,
.store-dashboard .dashboard-balance-value:after,
.store-dashboard .dashboard-topup:before,
.store-dashboard .dashboard-topup:after{
  content:none!important;
  display:none!important;
  background:none!important;
}
.store-dashboard .dashboard-balance>.dashboard-label{
  display:block!important;
  position:static!important;
  margin:0 0 14px!important;
  padding:0!important;
  line-height:1.3!important;
  transform:none!important;
}
.store-dashboard .dashboard-balance>.xt-balance-row{
  display:grid!important;
  grid-template-columns:clamp(40px,11vw,50px) minmax(0,1fr) auto!important;
  align-items:center!important;
  justify-content:normal!important;
  gap:clamp(7px,2vw,13px)!important;
  width:100%!important;
  min-width:0!important;
  margin:0!important;
  padding:0!important;
}
.store-dashboard .xt-balance-logo-link{
  display:flex!important;
  align-items:center!important;
  justify-content:center!important;
  width:clamp(40px,11vw,50px)!important;
  height:clamp(40px,11vw,50px)!important;
  min-width:0!important;
  margin:0!important;
  padding:0!important;
  flex:none!important;
}
.store-dashboard .xt-balance-logo-link>.xt-balance-logo{
  display:block!important;
  width:100%!important;
  height:100%!important;
  max-width:50px!important;
  max-height:50px!important;
  object-fit:contain!important;
  opacity:1!important;
  visibility:visible!important;
}
.store-dashboard .dashboard-balance>.xt-balance-row>.xt-balance-amount{
  display:block!important;
  position:static!important;
  min-width:0!important;
  max-width:100%!important;
  margin:0!important;
  padding:0!important;
  text-align:center!important;
  white-space:nowrap!important;
  overflow:hidden!important;
  text-overflow:clip!important;
  overflow-wrap:normal!important;
  word-break:normal!important;
  font-size:clamp(20px,5.8vw,34px)!important;
  line-height:1.15!important;
  letter-spacing:-.035em!important;
  font-weight:1000!important;
  transform:none!important;
}
.store-dashboard .dashboard-balance>.xt-balance-row>.xt-balance-addfunds{
  display:inline-flex!important;
  align-items:center!important;
  justify-content:center!important;
  justify-self:end!important;
  width:auto!important;
  min-width:0!important;
  max-width:100%!important;
  min-height:48px!important;
  height:48px!important;
  margin:0!important;
  padding:0 clamp(9px,2.5vw,15px)!important;
  box-sizing:border-box!important;
  white-space:nowrap!important;
  overflow:hidden!important;
  text-overflow:ellipsis!important;
  font-size:clamp(9px,2.6vw,13px)!important;
  line-height:1.15!important;
  transform:none!important;
  animation:none!important;
  transition:none!important;
}
.store-dashboard .dashboard-balance>.xt-balance-row>.xt-balance-addfunds>span{
  display:inline-flex!important;
  flex:0 0 23px!important;
  align-items:center!important;
  justify-content:center!important;
  width:23px!important;
  height:23px!important;
  margin:0 5px 0 0!important;
  border-radius:50%!important;
  background:#fff!important;
  color:#6850d8!important;
  font-size:19px!important;
  line-height:1!important;
}
@media(max-width:390px){
  .store-dashboard .dashboard-balance{padding:18px 12px!important}
  .store-dashboard .dashboard-balance>.xt-balance-row{
    grid-template-columns:38px minmax(0,1fr) auto!important;
    gap:7px!important;
  }
  .store-dashboard .xt-balance-logo-link{width:38px!important;height:38px!important}
  .store-dashboard .dashboard-balance>.xt-balance-row>.xt-balance-amount{
    font-size:clamp(18px,5.2vw,25px)!important;
    letter-spacing:-.045em!important;
  }
  .store-dashboard .dashboard-balance>.xt-balance-row>.xt-balance-addfunds{
    min-height:43px!important;height:43px!important;padding:0 7px!important;
    font-size:9px!important;
  }
  .store-dashboard .dashboard-balance>.xt-balance-row>.xt-balance-addfunds>span{
    flex-basis:19px!important;width:19px!important;height:19px!important;
    margin-right:3px!important;font-size:16px!important;
  }
}
</style>




</body></html>';

    exit;
}

// Admin-managed gaming top-up categories. These feed the Store's category tiles.
require_once __DIR__ . '/topup-lib.php';
require_once __DIR__ . '/history-category-lib.php';
xt_topup_ensure_tables();
xt_topup_sync_history_categories();
$topupStoreCategories = array_values(array_filter(xt_history_categories(), static function($category) {
    return ($category['kind'] ?? '') === 'purchase' && !in_array((string)($category['slug'] ?? ''), ['other','key-purchases'], true);
}));
$topupCategoryIcons = ['diamond'=>'💎','like'=>'👍','weekly'=>'⭐','monthly'=>'📅','guild-war'=>'🛡️','top-up'=>'⚡'];


/*
|--------------------------------------------------------------------------
| HELPER
|--------------------------------------------------------------------------
*/

function h($value): string
{
    return htmlspecialchars(
        (string)$value,
        ENT_QUOTES,
        'UTF-8'
    );
}

function productLinks(string $description): array
{
    $links = [];
    foreach (preg_split('/\R/', $description) ?: [] as $line) {
        if (preg_match('/^\s*\[(UPDATE|SETUP|LINK|MEDIA|IMAGE|VIDEO|GROUP|SETUP_LABEL|GROUP_LABEL|EXTRA1|EXTRA1_LABEL|EXTRA1_ON|EXTRA2|EXTRA2_LABEL|EXTRA2_ON|FEATURE_ON|FEATURE_OFF|STATUS_TAGS)\]\s*(.*?)\s*$/i', $line, $m)) {
            $type = strtoupper($m[1]);
            $url = trim($m[2]);
            if (in_array($type, ['SETUP_LABEL','GROUP_LABEL','EXTRA1_LABEL','EXTRA1_ON','EXTRA2_LABEL','EXTRA2_ON','STATUS_TAGS'], true)) { $links[$type] = $url; continue; }
            // Stored upload paths are relative in older products. Convert them to site-root paths
            // so media URLs resolve consistently from Store, nested pages, and the inline player.
            if (preg_match('~^/?uploads/product-media/[A-Za-z0-9._/-]+$~', $url)) {
                $url = '/' . ltrim($url, '/');
            }
            if (filter_var($url, FILTER_VALIDATE_URL) || preg_match('#^/(?!/)[A-Za-z0-9._~!$&\'()*+,;=:@%/-]+$#', $url)) $links[] = ['type'=>$type,'url'=>$url];
        }
    }
    return $links;
}


/*
|--------------------------------------------------------------------------
| LOAD PRODUCTS
|--------------------------------------------------------------------------
|
| Expected:
| catalog_products
|   id
|   name
|   status
|
|--------------------------------------------------------------------------
*/

$products = [];
ensure_catalog_product_columns();

try {

    $stmt = $pdo->query("
        SELECT
            id,
            name,
            description,
            category,
            platform,
            live_status,
            reseller_discount_percent
        FROM catalog_products
        WHERE status = 1
        ORDER BY id DESC
    ");

    $products = $stmt->fetchAll(PDO::FETCH_ASSOC);

} catch (Throwable $e) {

    http_response_code(500);

    echo '<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no,viewport-fit=cover"><title>Store Error</title><style>body{margin:0;padding:28px 16px;background:#07101d;color:#f4f6fb;font:15px Arial,sans-serif}.box{max-width:680px;margin:30px auto;padding:22px;border:1px solid #344155;border-radius:16px;background:#111d2d}h2{margin-top:0;color:#ff8194}pre{white-space:pre-wrap;overflow-wrap:anywhere;color:#ffd2d8;font-size:13px}</style></head><body><main class="box"><h2>Store temporarily unavailable</h2><pre>' . htmlspecialchars($e->getMessage(), ENT_QUOTES, 'UTF-8') . '</pre></main>
<style id="xt-topup-category-card-final-fix">
section.xt-topup-entry .xt-topup-head>a,
section.xt-topup-entry .xt-topup-head>a:link,
section.xt-topup-entry .xt-topup-head>a:visited,
section.xt-topup-entry .xt-topup-tiles>a,
section.xt-topup-entry .xt-topup-tiles>a:link,
section.xt-topup-entry .xt-topup-tiles>a:visited{
  display:flex!important;position:relative!important;align-items:center!important;
  justify-content:center!important;flex-direction:column!important;gap:9px!important;
  min-width:0!important;min-height:88px!important;padding:12px 8px!important;
  border:1px solid rgba(114,164,255,.58)!important;border-radius:18px!important;
  background:linear-gradient(145deg,rgba(26,48,83,.98),rgba(15,20,43,.98))!important;
  color:#f5f7ff!important;text-decoration:none!important;-webkit-text-decoration:none!important;
  font-weight:950!important;text-align:center!important;line-height:1.25!important;
  box-shadow:0 8px 22px rgba(0,0,0,.34),inset 0 1px 0 rgba(255,255,255,.12)!important;
  overflow:hidden!important;
}
section.xt-topup-entry .xt-topup-head>a{
  min-height:42px!important;flex-direction:row!important;padding:0 18px!important;
  border-color:rgba(44,225,232,.65)!important;
  background:linear-gradient(110deg,#06c9b5,#2687ff 58%,#9255ef)!important;
  color:#071323!important;
}
section.xt-topup-entry .xt-topup-tiles>a:nth-child(5n/**/+1){border-color:#24d8ef!important;background:linear-gradient(145deg,#075b79,#101b38)!important}
section.xt-topup-entry .xt-topup-tiles>a:nth-child(5n/**/+2){border-color:#f05cb8!important;background:linear-gradient(145deg,#612052,#17152f)!important}
section.xt-topup-entry .xt-topup-tiles>a:nth-child(5n/**/+3){border-color:#f4c45d!important;background:linear-gradient(145deg,#60451b,#17182e)!important}
section.xt-topup-entry .xt-topup-tiles>a:nth-child(5n/**/+4){border-color:#a77aff!important;background:linear-gradient(145deg,#482b79,#15172f)!important}
section.xt-topup-entry .xt-topup-tiles>a:nth-child(5n){border-color:#37d6a8!important;background:linear-gradient(145deg,#075448,#111a30)!important}
section.xt-topup-entry .xt-topup-tiles>a span{
  display:grid!important;place-items:center!important;width:43px!important;height:43px!important;
  border-radius:14px!important;background:rgba(4,12,28,.78)!important;
  border:1px solid rgba(255,255,255,.2)!important;font-size:25px!important;line-height:1!important;
}
section.xt-topup-entry .xt-topup-tiles>a b{
  display:block!important;color:#f7f8ff!important;font-size:clamp(10px,2.8vw,13px)!important;
  font-weight:950!important;text-decoration:none!important;overflow-wrap:anywhere!important;
}
section.xt-topup-entry .xt-topup-tiles>a:active{transform:translateY(1px) scale(.985)!important}
@media(max-width:520px){
 section.xt-topup-entry .xt-topup-tiles{grid-template-columns:repeat(3,minmax(0,1fr))!important;gap:8px!important}
 section.xt-topup-entry .xt-topup-tiles>a{min-height:86px!important;padding:10px 5px!important}
}
</style>

</body></html>';

    exit;
}


/*
|--------------------------------------------------------------------------
| LOAD PLANS + REAL KEY STOCK
|--------------------------------------------------------------------------
|
| IMPORTANT:
| Stock is calculated from user_keys.
|
| user_keys:
| id
| user_id
| product_id
| plan_id
| license_key
| price
| purchased_at
|
| user_id IS NULL = available key
|--------------------------------------------------------------------------
*/

$plansByProduct = [];

try {

    $stmt = $pdo->query("
        SELECT
            pp.id,
            pp.product_id,
            pp.plan_type,
            pp.duration_days,
            pp.duration_seconds,
            pp.duration_label,
            pp.price,
            pp.status,
            cp.reseller_discount_percent,

            (
                SELECT COUNT(*)
                FROM user_keys uk
                WHERE uk.product_id = pp.product_id
                  AND uk.plan_id = pp.id
                  AND uk.user_id IS NULL
            ) AS available_keys

        FROM product_plans pp
        LEFT JOIN catalog_products cp ON cp.id = pp.product_id

        WHERE pp.status = 1

        ORDER BY
            pp.product_id ASC,
            FIELD(UPPER(pp.plan_type),'PRO','BASIC','NORMAL'),
            COALESCE(pp.duration_seconds, CASE WHEN pp.duration_days < 0 THEN ABS(pp.duration_days)*3600 ELSE pp.duration_days*86400 END) ASC,
            pp.id ASC
    ");

    $plans = $stmt->fetchAll(PDO::FETCH_ASSOC);

    foreach ($plans as $plan) {

        $productId = (int)$plan['product_id'];

        if (!isset($plansByProduct[$productId])) {
            $plansByProduct[$productId] = [];
        }

        $plansByProduct[$productId][] = $plan;
    }

} catch (Throwable $e) {

    http_response_code(500);

    echo '<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no,viewport-fit=cover"><title>Store Error</title><style>body{margin:0;padding:28px 16px;background:#07101d;color:#f4f6fb;font:15px Arial,sans-serif}.box{max-width:680px;margin:30px auto;padding:22px;border:1px solid #344155;border-radius:16px;background:#111d2d}h2{margin-top:0;color:#ff8194}pre{white-space:pre-wrap;overflow-wrap:anywhere;color:#ffd2d8;font-size:13px}</style></head><body><main class="box"><h2>Store temporarily unavailable</h2><pre>' . htmlspecialchars($e->getMessage(), ENT_QUOTES, 'UTF-8') . '</pre></main>
<style id="xt-topup-category-card-final-fix">
section.xt-topup-entry .xt-topup-head>a,
section.xt-topup-entry .xt-topup-head>a:link,
section.xt-topup-entry .xt-topup-head>a:visited,
section.xt-topup-entry .xt-topup-tiles>a,
section.xt-topup-entry .xt-topup-tiles>a:link,
section.xt-topup-entry .xt-topup-tiles>a:visited{
  display:flex!important;position:relative!important;align-items:center!important;
  justify-content:center!important;flex-direction:column!important;gap:9px!important;
  min-width:0!important;min-height:88px!important;padding:12px 8px!important;
  border:1px solid rgba(114,164,255,.58)!important;border-radius:18px!important;
  background:linear-gradient(145deg,rgba(26,48,83,.98),rgba(15,20,43,.98))!important;
  color:#f5f7ff!important;text-decoration:none!important;-webkit-text-decoration:none!important;
  font-weight:950!important;text-align:center!important;line-height:1.25!important;
  box-shadow:0 8px 22px rgba(0,0,0,.34),inset 0 1px 0 rgba(255,255,255,.12)!important;
  overflow:hidden!important;
}
section.xt-topup-entry .xt-topup-head>a{
  min-height:42px!important;flex-direction:row!important;padding:0 18px!important;
  border-color:rgba(44,225,232,.65)!important;
  background:linear-gradient(110deg,#06c9b5,#2687ff 58%,#9255ef)!important;
  color:#071323!important;
}
section.xt-topup-entry .xt-topup-tiles>a:nth-child(5n/**/+1){border-color:#24d8ef!important;background:linear-gradient(145deg,#075b79,#101b38)!important}
section.xt-topup-entry .xt-topup-tiles>a:nth-child(5n/**/+2){border-color:#f05cb8!important;background:linear-gradient(145deg,#612052,#17152f)!important}
section.xt-topup-entry .xt-topup-tiles>a:nth-child(5n/**/+3){border-color:#f4c45d!important;background:linear-gradient(145deg,#60451b,#17182e)!important}
section.xt-topup-entry .xt-topup-tiles>a:nth-child(5n/**/+4){border-color:#a77aff!important;background:linear-gradient(145deg,#482b79,#15172f)!important}
section.xt-topup-entry .xt-topup-tiles>a:nth-child(5n){border-color:#37d6a8!important;background:linear-gradient(145deg,#075448,#111a30)!important}
section.xt-topup-entry .xt-topup-tiles>a span{
  display:grid!important;place-items:center!important;width:43px!important;height:43px!important;
  border-radius:14px!important;background:rgba(4,12,28,.78)!important;
  border:1px solid rgba(255,255,255,.2)!important;font-size:25px!important;line-height:1!important;
}
section.xt-topup-entry .xt-topup-tiles>a b{
  display:block!important;color:#f7f8ff!important;font-size:clamp(10px,2.8vw,13px)!important;
  font-weight:950!important;text-decoration:none!important;overflow-wrap:anywhere!important;
}
section.xt-topup-entry .xt-topup-tiles>a:active{transform:translateY(1px) scale(.985)!important}
@media(max-width:520px){
 section.xt-topup-entry .xt-topup-tiles{grid-template-columns:repeat(3,minmax(0,1fr))!important;gap:8px!important}
 section.xt-topup-entry .xt-topup-tiles>a{min-height:86px!important;padding:10px 5px!important}
}
</style>

</body></html>';

    exit;
}


/*
|--------------------------------------------------------------------------
| STORE DASHBOARD SUMMARY
|--------------------------------------------------------------------------
| The dashboard is intentionally merged into Store. There is no separate
| Home Shop button. Store is the user's shop + dashboard landing page.
|--------------------------------------------------------------------------
*/
$dashBalance = 0.00;
$dashDeposits = 0.00;
$dashPurchases = 0.00;
$dashKeys = 0;
$dashActiveKeys = 0;

try {
    try { $depCols=$pdo->query('SHOW COLUMNS FROM deposits')->fetchAll(PDO::FETCH_COLUMN); } catch(Throwable $ignore) { $depCols=[]; }
    $depExpr = in_array('amount_bdt',$depCols,true) ? 'SUM(COALESCE(amount_bdt, amount))' : 'SUM(amount)';
    $st = $pdo->prepare("SELECT COALESCE({$depExpr},0) FROM deposits WHERE user_id = ? AND LOWER(status) = 'approved'");
    $st->execute([$userId]);
    $dashDeposits = (float)$st->fetchColumn();
} catch (Throwable $e) {}

try {
    $st = $pdo->prepare("SELECT COALESCE(SUM(total_amount),0) FROM user_purchases WHERE user_id = ?");
    $st->execute([$userId]);
    $dashPurchases = (float)$st->fetchColumn();
} catch (Throwable $e) {}

$dashBalance = max(0, $dashDeposits - $dashPurchases);
$dashDepositsUsd = $dashDeposits / 122.0;

try {
    $st = $pdo->prepare("SELECT COUNT(*) FROM user_keys WHERE user_id = ?");
    $st->execute([$userId]);
    $dashKeys = (int)$st->fetchColumn();
} catch (Throwable $e) {}

try {
    // Count only keys that have not expired; zero/unknown duration means no expiry timer.
    $ukCols = []; $planCols = [];
    try { $ukCols = $pdo->query('SHOW COLUMNS FROM user_keys')->fetchAll(PDO::FETCH_COLUMN); } catch (Throwable $ignore) {}
    try { $planCols = $pdo->query('SHOW COLUMNS FROM product_plans')->fetchAll(PDO::FETCH_COLUMN); } catch (Throwable $ignore) {}
    $durationParts = [];
    if (in_array('duration_seconds', $ukCols, true)) $durationParts[] = 'uk.duration_seconds';
    if (in_array('duration_seconds', $planCols, true)) $durationParts[] = 'pp.duration_seconds';
    if (in_array('duration_days', $planCols, true)) $durationParts[] = 'CASE WHEN pp.duration_days < 0 THEN ABS(pp.duration_days)*3600 ELSE COALESCE(pp.duration_days,0)*86400 END';
    $durationExpr = $durationParts ? 'COALESCE(' . implode(',', $durationParts) . ',0)' : '0';
    $activeSql = "SELECT COUNT(*) FROM user_keys uk
        LEFT JOIN product_plans pp ON pp.id=uk.plan_id AND pp.product_id=uk.product_id
        WHERE uk.user_id=? AND uk.purchased_at IS NOT NULL
        AND (" . $durationExpr . " <= 0 OR TIMESTAMPDIFF(SECOND, uk.purchased_at, UTC_TIMESTAMP()) < " . $durationExpr . ")";
    $st = $pdo->prepare($activeSql);
    $st->execute([$userId]);
    $dashActiveKeys = (int)$st->fetchColumn();
} catch (Throwable $e) {}

?>
<!doctype html>

<html lang="en">

<head>

<meta charset="utf-8">

<meta
    name="viewport"
    content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no,viewport-fit=cover"
>

<title>Store</title>
<link rel="stylesheet" href="theme.php?v=20261022-lightfix3">
<link rel="stylesheet" href="reference-theme.css?v=20260929-25">
<link rel="stylesheet" href="site-polish.css?v=20261022-lightfix3">
<link rel="stylesheet" href="premium-global.css?v=20261022-lightfix3">
<link rel="stylesheet" href="assets/xtreme-bottom-nav.css?v=20261117-store-nav-v13">
<link rel="stylesheet" href="store-premium.css?v=20260929-25">
<script src="theme-client.js?v=20260929-25" defer></script>
<script src="currency-client.js?v=20261023-warning-balance-v28" defer></script>
<script src="language-client.js?v=20261114-payment-history-v4" defer></script>
<script src="preference-sync.js?v=20260929-25" defer></script>





<style id="store-dashboard-ui">
.store-dashboard{width:100%;max-width:900px;margin:0 auto;padding:16px 14px 4px;position:relative;z-index:1}
.dashboard-balance{padding:17px;border:1px solid rgba(55,94,125,.75);border-radius:19px;background:rgba(8,20,34,.82);backdrop-filter:blur(8px);-webkit-backdrop-filter:blur(8px);margin-bottom:10px}
.dashboard-label{color:#9aa9bf;font-size:10px;font-weight:900;letter-spacing:.08em}
.dashboard-balance-value{margin:4px 0 12px;font-size:31px;line-height:1;font-weight:900;color:#eef4ff}
.xt-purchase-warning{margin-top:12px;padding:11px 13px;border:1px solid #fb7185;background:rgba(190,24,93,.16);color:#fecdd3;border-radius:13px;font-size:12px;font-weight:800;line-height:1.45;overflow-wrap:anywhere}
.dashboard-topup{display:inline-flex;align-items:center;justify-content:center;height:39px;padding:0 16px;border-radius:11px;background:#63ff16;color:#06101c;text-decoration:none;font-size:11px;font-weight:900}
.dashboard-stats{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:9px;margin-bottom:10px}
.dashboard-stat{min-width:0;padding:12px;border:1px solid rgba(38,56,78,.9);border-radius:14px;background:rgba(10,22,36,.80);backdrop-filter:blur(7px);-webkit-backdrop-filter:blur(7px)}
.dashboard-stat span{display:block;color:#9aa9bf;font-size:9px;font-weight:900;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.dashboard-stat strong{display:block;margin-top:4px;color:#eef4ff;font-size:17px;font-weight:900;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.dashboard-quick{padding:13px;border:1px solid rgba(38,56,78,.9);border-radius:17px;background:rgba(10,22,36,.80);backdrop-filter:blur(7px);-webkit-backdrop-filter:blur(7px);margin-bottom:17px}
.dashboard-quick-title{font-size:16px;font-weight:900;margin-bottom:9px}
.dashboard-actions{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:8px}
.dashboard-actions a{display:flex;align-items:center;justify-content:center;min-height:62px;padding:15px 12px;border-radius:13px;border:1px solid rgba(34,52,74,.95);background:rgba(17,31,49,.92);color:#eef4ff;text-decoration:none;font-size:14px;font-weight:900;line-height:1.35}
.dashboard-actions a:hover{text-decoration:none}.xt-addfunds-banner{display:block;width:100%;margin:0 0 12px;border-radius:13px;overflow:hidden;line-height:0}.xt-addfunds-banner img{display:block;width:100%;height:auto;max-height:240px;object-fit:cover;border-radius:13px}.xt-addfunds-banner{margin:0 0 12px}.dashboard-topup{margin-bottom:2px}
@media(max-width:600px){.store-dashboard{padding:12px 10px 2px}.dashboard-balance-value{font-size:28px}.dashboard-stat{padding:11px}.dashboard-stat strong{font-size:15px}.dashboard-quick{padding:12px}}
</style>
<style id="store-final-ui">
html,body{width:100%;overflow-x:hidden}
.topbar{height:auto!important;min-height:92px!important;padding:10px 12px 12px!important;display:flex!important;align-items:center!important;justify-content:center!important;position:sticky!important;top:0!important;z-index:100!important;background:#071220!important;border-bottom:1px solid #18283c!important}
.topbar .brand-with-logo{width:100%!important;display:flex!important;flex-direction:column!important;align-items:center!important;justify-content:center!important;gap:5px!important;text-align:center!important}
.topbar .header-logo{display:block!important;width:42px!important;height:42px!important;max-width:42px!important;max-height:42px!important;flex:0 0 42px!important;object-fit:cover!important;border-radius:10px!important;margin:0 auto!important}
.topbar .top-title{display:block!important;margin:0!important;font-size:20px!important;line-height:1.15!important;font-weight:900!important;color:#eef4ff!important;text-align:center!important}
.product-image img[src*="xtreme-titan-logo"],.product-image img[src*="tanofficial_neon_background"]{display:none!important}





@media(max-width:600px){.topbar{min-height:88px!important;padding:8px 10px 10px!important}.topbar .header-logo{width:40px!important;height:40px!important;max-width:40px!important;max-height:40px!important;flex-basis:40px!important}.topbar .top-title{font-size:19px!important}}
@media(max-width:380px){.topbar .header-logo{width:38px!important;height:38px!important;max-width:38px!important;max-height:38px!important;flex-basis:38px!important}.topbar .top-title{font-size:18px!important}}
</style>

<style id="store-dashboard-neon-polish-v29">
/* Dashboard-only polish: preserve compact button dimensions and existing behavior. */
.store-dashboard .dashboard-balance{
  border:1px solid rgba(255,49,174,.72)!important;
  background:linear-gradient(125deg,rgba(9,18,37,.96),rgba(24,12,38,.92))!important;
  box-shadow:0 0 0 1px rgba(76,65,255,.18),0 0 18px rgba(255,35,169,.12),inset 0 0 20px rgba(25,120,255,.06)!important;
}
.store-dashboard .dashboard-topup{
  min-height:38px!important;height:38px!important;padding:0 15px!important;
  border:1px solid rgba(255,255,255,.24)!important;border-radius:12px!important;
  background:linear-gradient(110deg,#10cfff 0%,#665bff 48%,#ff2d9b 100%)!important;
  color:#fff!important;box-shadow:0 0 13px rgba(29,155,240,.2)!important;
}
.store-dashboard .dashboard-stats{gap:8px!important}
.store-dashboard .dashboard-stat{
  padding:11px!important;border-radius:15px!important;
  background:linear-gradient(135deg,rgba(9,19,39,.94),rgba(18,14,42,.92))!important;
  border:1px solid rgba(118,105,255,.48)!important;
  box-shadow:inset 0 0 16px rgba(35,110,255,.06)!important;
}
.store-dashboard .dashboard-stat:nth-child(1){border-color:rgba(20,235,153,.52)!important}
.store-dashboard .dashboard-stat:nth-child(2){border-color:rgba(255,53,156,.5)!important}
.store-dashboard .dashboard-stat:nth-child(3){border-color:rgba(255,190,48,.48)!important}
.store-dashboard .dashboard-stat:nth-child(4){border-color:rgba(174,68,255,.55)!important}
.store-dashboard .dashboard-stat span{font-size:10px!important;letter-spacing:.01em!important;color:#bdc9ff!important}




.store-dashboard .dashboard-quick{
  padding:12px!important;border-radius:18px!important;
  border:1px solid rgba(108,115,255,.48)!important;
  background:linear-gradient(145deg,rgba(7,17,35,.96),rgba(20,12,43,.94))!important;
  box-shadow:0 0 17px rgba(89,64,255,.09)!important;
}
.store-dashboard .dashboard-quick-title{font-size:15px!important;margin-bottom:8px!important}
.store-dashboard .dashboard-actions{gap:7px!important}
.store-dashboard .dashboard-actions a{
  min-height:56px!important;height:auto!important;padding:9px 10px!important;
  gap:7px!important;justify-content:flex-start!important;border-radius:13px!important;
  font-size:12px!important;line-height:1.2!important;
  border:1px solid rgba(95,122,255,.6)!important;
  background:linear-gradient(120deg,rgba(12,36,69,.96),rgba(18,20,58,.96))!important;
  box-shadow:inset 0 0 13px rgba(45,115,255,.08)!important;
}
.store-dashboard .dashboard-actions a:nth-child(1){
  border-color:rgba(17,238,156,.72)!important;
  background:linear-gradient(120deg,rgba(0,108,74,.62),rgba(7,35,51,.96))!important;
  box-shadow:0 0 10px rgba(17,238,156,.10),inset 0 0 12px rgba(17,238,156,.07)!important;
}
.store-dashboard .dashboard-actions a:nth-child(2){
  border-color:rgba(20,166,255,.78)!important;
  background:linear-gradient(120deg,rgba(0,79,172,.65),rgba(9,24,64,.97))!important;
  box-shadow:0 0 10px rgba(20,166,255,.11),inset 0 0 12px rgba(20,166,255,.07)!important;
}
.store-dashboard .dashboard-actions a:nth-child(3){
  border-color:rgba(255,183,45,.75)!important;
  background:linear-gradient(120deg,rgba(133,75,0,.62),rgba(51,25,20,.97))!important;
}
.store-dashboard .dashboard-actions a:nth-child(4){
  border-color:rgba(221,48,255,.75)!important;
  background:linear-gradient(120deg,rgba(103,0,151,.62),rgba(36,12,57,.97))!important;
}
.store-dashboard .dashboard-actions .qa-icon{font-size:24px!important;line-height:1!important;flex:0 0 auto!important;filter:drop-shadow(0 0 5px currentColor)!important}
.store-dashboard .dashboard-actions .qa-label{flex:1 1 auto!important;min-width:0!important}
.store-dashboard .dashboard-actions .qa-arrow{
  width:22px!important;height:22px!important;min-width:22px!important;
  display:inline-flex!important;align-items:center!important;justify-content:center!important;
  border:1px solid currentColor!important;border-radius:50%!important;font-size:20px!important;
  line-height:1!important;opacity:.95!important;
}
@media(max-width:600px){
 .store-dashboard .dashboard-stat{padding:10px!important}
 .store-dashboard .dashboard-actions a{min-height:54px!important;padding:8px!important;font-size:11px!important}
 .store-dashboard .dashboard-actions .qa-icon{font-size:22px!important}
}
</style>




<style id="store-dashboard-reference-icons-v31">
/* Reference-style icon treatment; preserve compact button dimensions and existing actions. */
.store-dashboard .dashboard-balance{
  border-color:rgba(255,48,174,.78)!important;
  background:radial-gradient(ellipse at 92% 0%,rgba(0,180,255,.14),transparent 42%),linear-gradient(135deg,rgba(8,16,36,.97),rgba(28,11,42,.96))!important;
  box-shadow:0 0 0 1px rgba(126,67,255,.2),0 0 17px rgba(255,45,170,.11),inset 0 0 18px rgba(37,119,255,.06)!important;
}
.store-dashboard .dashboard-balance-value{display:flex!important;align-items:center!important;gap:9px!important;flex-wrap:wrap!important}
.store-dashboard .dashboard-balance-value:before{content:"💳";display:inline-flex;align-items:center;justify-content:center;font-size:31px;line-height:1;filter:drop-shadow(0 0 8px rgba(0,190,255,.42))}
.store-dashboard .dashboard-topup{position:relative!important;gap:7px!important;min-height:38px!important;height:38px!important;padding:0 13px!important;border-radius:12px!important;background:linear-gradient(110deg,#10cfff,#665bff 48%,#ff2d9b)!important;border:1px solid rgba(255,255,255,.25)!important;color:#fff!important;font-size:11px!important;box-shadow:0 0 12px rgba(29,155,240,.2)!important}
.store-dashboard .dashboard-topup:before{content:"＋";display:inline-flex;align-items:center;justify-content:center;width:19px;height:19px;border-radius:50%;background:#fff;color:#6553dc;font-size:16px;font-weight:1000;line-height:1}
.store-dashboard .dashboard-stats{gap:9px!important}
.store-dashboard .dashboard-stat{position:relative!important;min-height:78px!important;padding:12px 9px 11px 54px!important;border-radius:16px!important;overflow:hidden!important;background:linear-gradient(135deg,rgba(9,19,39,.95),rgba(22,13,43,.94))!important;border:1px solid rgba(117,104,255,.52)!important;box-shadow:inset 0 0 15px rgba(35,110,255,.07)!important}
.store-dashboard .dashboard-stat:before{content:"";position:absolute;left:10px;top:50%;transform:translateY(-50%);width:34px;height:34px;display:flex;align-items:center;justify-content:center;border-radius:50%;font-size:21px;line-height:1;background:linear-gradient(145deg,rgba(0,255,160,.2),rgba(0,85,255,.22));border:1px solid rgba(70,205,255,.38);filter:drop-shadow(0 0 7px rgba(70,130,255,.2))}
.store-dashboard .dashboard-stat:nth-child(1):before{content:"✓";color:#8affcf;background:linear-gradient(145deg,rgba(0,255,128,.35),rgba(0,145,91,.15));border-color:rgba(0,255,145,.7);font-size:23px;font-weight:1000}
.store-dashboard .dashboard-stat:nth-child(2):before{content:"🛒";background:linear-gradient(145deg,rgba(255,40,190,.3),rgba(98,0,180,.2));border-color:rgba(255,65,194,.65)}
.store-dashboard .dashboard-stat:nth-child(3):before{content:"🔑";background:linear-gradient(145deg,rgba(255,186,40,.3),rgba(154,83,0,.2));border-color:rgba(255,190,67,.65)}
.store-dashboard .dashboard-stat:nth-child(4):before{content:"📦";background:linear-gradient(145deg,rgba(177,64,255,.3),rgba(69,0,180,.2));border-color:rgba(190,80,255,.65)}

.store-dashboard .dashboard-stat strong{display:block!important;margin-top:5px!important;font-size:19px!important;line-height:1.15!important}

.store-dashboard .dashboard-quick{padding:12px!important;border-radius:18px!important;border:1px solid rgba(108,115,255,.5)!important;background:linear-gradient(145deg,rgba(7,17,35,.96),rgba(20,12,43,.94))!important;box-shadow:0 0 17px rgba(89,64,255,.09)!important}


.store-dashboard .dashboard-actions a{min-height:56px!important;height:auto!important;padding:8px 9px!important;gap:7px!important;border-radius:13px!important;font-size:12px!important;line-height:1.2!important;box-shadow:inset 0 0 12px rgba(45,115,255,.08),0 0 8px rgba(70,80,255,.06)!important}
.store-dashboard .dashboard-actions .qa-icon{flex:0 0 27px!important;font-size:24px!important;line-height:1!important;filter:drop-shadow(0 0 6px rgba(255,255,255,.2))!important}
.store-dashboard .dashboard-actions .qa-label{font-size:12px!important;line-height:1.2!important}
.store-dashboard .dashboard-actions .qa-arrow{width:22px!important;height:22px!important;min-width:22px!important;font-size:19px!important}
.store-dashboard .dashboard-actions a:nth-child(1){background:linear-gradient(120deg,rgba(0,108,74,.72),rgba(7,35,51,.96))!important;border-color:rgba(17,238,156,.8)!important}
.store-dashboard .dashboard-actions a:nth-child(2){background:linear-gradient(120deg,rgba(0,79,172,.72),rgba(9,24,64,.97))!important;border-color:rgba(20,166,255,.82)!important}
.store-dashboard .dashboard-actions a:nth-child(3){background:linear-gradient(120deg,rgba(133,75,0,.7),rgba(51,25,20,.97))!important;border-color:rgba(255,183,45,.8)!important}
.store-dashboard .dashboard-actions a:nth-child(4){background:linear-gradient(120deg,rgba(103,0,151,.7),rgba(36,12,57,.97))!important;border-color:rgba(221,48,255,.8)!important}
@media(max-width:600px){
 .store-dashboard .dashboard-stat{min-height:72px!important;padding:10px 6px 10px 47px!important}
 .store-dashboard .dashboard-stat:before{left:7px;width:31px;height:31px;font-size:18px}
 .store-dashboard .dashboard-stat span{font-size:9px!important}
 .store-dashboard .dashboard-stat strong{font-size:17px!important}
 .store-dashboard .dashboard-actions a{min-height:54px!important;padding:8px 7px!important;font-size:11px!important}
 .store-dashboard .dashboard-actions .qa-icon{font-size:22px!important;flex-basis:24px!important}
 .store-dashboard .dashboard-actions .qa-label{font-size:11px!important}
}
</style>

<link rel="icon" type="image/png" sizes="48x48" href="/assets/pwa-icon-48.png">
<link rel="apple-touch-icon" sizes="180x180" href="/assets/pwa-icon-180.png">
<link rel="manifest" href="/pwa-manifest.json">
<meta name="apple-mobile-web-app-title" content="XTREME TITAN">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="mobile-web-app-capable" content="yes">
<meta name="theme-color" content="#080a14">
<style id="store-dashboard-precise-reference-v32">
/* Exact dashboard-only override: vivid reference-style icons/gradients, compact controls. */
html[data-theme] .store-dashboard .dashboard-balance{
  border:1px solid rgba(255,43,171,.82)!important;border-radius:22px!important;
  background:radial-gradient(ellipse at 92% 0%,rgba(22,168,255,.15),transparent 43%),linear-gradient(140deg,#090f22 0%,#17112d 58%,#21102e 100%)!important;
  box-shadow:0 0 0 2px rgba(109,62,255,.13),0 0 18px rgba(255,40,171,.13),inset 0 1px 0 rgba(255,255,255,.08)!important;
}
html[data-theme] .store-dashboard .dashboard-label{color:#aebcff!important;letter-spacing:.12em!important}
html[data-theme] .store-dashboard .dashboard-balance-value{color:#3ff0b6!important;text-shadow:0 0 18px rgba(63,240,182,.22)!important}
html[data-theme] .store-dashboard .dashboard-topup{
 display:inline-flex!important;align-items:center!important;justify-content:center!important;gap:7px!important;
 min-height:38px!important;height:38px!important;padding:0 13px!important;border-radius:12px!important;
 background:linear-gradient(110deg,#13d7ff 0%,#665cff 52%,#ff3b9e 100%)!important;
 border:1px solid rgba(255,255,255,.32)!important;color:#fff!important;font-size:11px!important;
 box-shadow:0 0 14px rgba(28,174,255,.18)!important;
}
html[data-theme] .store-dashboard .dashboard-topup:before{content:"＋"!important;display:inline-flex!important;align-items:center!important;justify-content:center!important;width:19px!important;height:19px!important;border-radius:50%!important;background:#fff!important;color:#6952e8!important;font-size:16px!important;font-weight:1000!important;line-height:1!important}
html[data-theme] .store-dashboard .dashboard-stat{
 position:relative!important;min-height:76px!important;padding:11px 8px 10px 52px!important;border-radius:16px!important;overflow:hidden!important;
 background:linear-gradient(135deg,rgba(10,19,41,.97),rgba(28,13,47,.96))!important;
 border:1px solid rgba(129,113,255,.58)!important;box-shadow:inset 0 0 15px rgba(37,111,255,.07)!important;
}
html[data-theme] .store-dashboard .dashboard-stat:before{position:absolute!important;left:9px!important;top:50%!important;transform:translateY(-50%)!important;width:34px!important;height:34px!important;display:flex!important;align-items:center!important;justify-content:center!important;border-radius:50%!important;font-size:21px!important;line-height:1!important;border:1px solid rgba(70,205,255,.38)!important;filter:drop-shadow(0 0 7px rgba(70,130,255,.2))!important}
html[data-theme] .store-dashboard .dashboard-stat:nth-child(1):before{content:"✓"!important;color:#8affcf!important;background:linear-gradient(145deg,rgba(0,255,128,.35),rgba(0,145,91,.15))!important;border-color:rgba(0,255,145,.7)!important;font-size:23px!important;font-weight:1000!important}
html[data-theme] .store-dashboard .dashboard-stat:nth-child(2):before{content:"🛒"!important;background:linear-gradient(145deg,rgba(255,40,190,.3),rgba(98,0,180,.2))!important;border-color:rgba(255,65,194,.65)!important}
html[data-theme] .store-dashboard .dashboard-stat:nth-child(3):before{content:"🔑"!important;background:linear-gradient(145deg,rgba(255,186,40,.3),rgba(154,83,0,.2))!important;border-color:rgba(255,190,67,.65)!important}
html[data-theme] .store-dashboard .dashboard-stat:nth-child(4):before{content:"📦"!important;background:linear-gradient(145deg,rgba(177,64,255,.3),rgba(69,0,180,.2))!important;border-color:rgba(190,80,255,.65)!important}
html[data-theme] .store-dashboard .dashboard-stat span{font-size:10px!important;line-height:1.3!important;white-space:normal!important;color:#bdc9ff!important}
html[data-theme] .store-dashboard .dashboard-stat strong{display:block!important;margin-top:5px!important;font-size:19px!important;line-height:1.15!important}
html[data-theme] .store-dashboard .dashboard-stat:nth-child(1) strong{color:#38efb0!important}html[data-theme] .store-dashboard .dashboard-stat:nth-child(2) strong{color:#ff6ab3!important}html[data-theme] .store-dashboard .dashboard-stat:nth-child(3) strong{color:#c49bff!important}html[data-theme] .store-dashboard .dashboard-stat:nth-child(4) strong{color:#ffc33d!important}
html[data-theme] .store-dashboard .dashboard-quick{padding:12px!important;border-radius:18px!important;border:1px solid rgba(108,115,255,.55)!important;background:linear-gradient(145deg,rgba(7,17,35,.97),rgba(25,12,44,.96))!important;box-shadow:0 0 17px rgba(89,64,255,.09)!important}
html[data-theme] .store-dashboard .dashboard-quick-title{font-size:15px!important;margin:0 0 8px!important;color:#f5f6ff!important}
html[data-theme] .store-dashboard .dashboard-quick-title:before{content:"ϟ"!important;display:inline-block!important;margin-right:7px!important;color:#ffe84a!important;font-size:22px!important;text-shadow:0 0 12px rgba(255,221,40,.35)!important}
html[data-theme] .store-dashboard .dashboard-actions{gap:7px!important;margin-top:8px!important}
html[data-theme] .store-dashboard .dashboard-actions a{display:flex!important;align-items:center!important;min-height:56px!important;height:auto!important;padding:8px 9px!important;gap:7px!important;border-radius:13px!important;font-size:12px!important;line-height:1.2!important;color:#fff!important;box-shadow:inset 0 0 12px rgba(45,115,255,.08),0 0 8px rgba(70,80,255,.08)!important}
html[data-theme] .store-dashboard .dashboard-actions a:nth-child(1){background:linear-gradient(120deg,rgba(0,170,105,.9),rgba(4,43,51,.98))!important;border:1px solid rgba(17,238,156,.9)!important;box-shadow:0 0 12px rgba(0,225,151,.12),inset 0 0 12px rgba(0,255,163,.08)!important}
html[data-theme] .store-dashboard .dashboard-actions a:nth-child(2){background:linear-gradient(120deg,rgba(0,116,235,.92),rgba(12,28,81,.98))!important;border:1px solid rgba(20,183,255,.9)!important;box-shadow:0 0 12px rgba(20,166,255,.12),inset 0 0 12px rgba(20,166,255,.08)!important}
html[data-theme] .store-dashboard .dashboard-actions a:nth-child(3){background:linear-gradient(120deg,rgba(195,112,0,.92),rgba(67,29,19,.98))!important;border:1px solid rgba(255,190,55,.9)!important;box-shadow:0 0 12px rgba(255,183,45,.12),inset 0 0 12px rgba(255,183,45,.08)!important}
html[data-theme] .store-dashboard .dashboard-actions a:nth-child(4){background:linear-gradient(120deg,rgba(143,0,205,.92),rgba(51,13,77,.98))!important;border:1px solid rgba(225,65,255,.9)!important;box-shadow:0 0 12px rgba(221,48,255,.12),inset 0 0 12px rgba(221,48,255,.08)!important}
html[data-theme] .store-dashboard .dashboard-actions .qa-icon{display:inline-flex!important;align-items:center!important;justify-content:center!important;flex:0 0 27px!important;font-size:24px!important;line-height:1!important;filter:drop-shadow(0 0 6px rgba(255,255,255,.22))!important}
html[data-theme] .store-dashboard .dashboard-actions .qa-label{display:block!important;min-width:0!important;flex:1 1 auto!important;font-size:12px!important;font-weight:950!important;line-height:1.2!important;white-space:normal!important;overflow-wrap:anywhere!important}
html[data-theme] .store-dashboard .dashboard-actions .qa-arrow{display:inline-flex!important;align-items:center!important;justify-content:center!important;flex:0 0 22px!important;width:22px!important;height:22px!important;border:1.5px solid currentColor!important;border-radius:50%!important;font-size:19px!important;line-height:1!important;opacity:.98!important}
html[data-theme] .xt-purchase-warning{border:1px solid #ff4f91!important;border-radius:15px!important;background:linear-gradient(100deg,rgba(104,12,68,.45),rgba(48,12,49,.62))!important;color:#ffe0ef!important;box-shadow:0 0 12px rgba(255,48,145,.1)!important}
@media(max-width:600px){html[data-theme] .store-dashboard .dashboard-stat{min-height:72px!important;padding:10px 6px 10px 47px!important}html[data-theme] .store-dashboard .dashboard-stat:before{left:7px!important;width:31px!important;height:31px!important;font-size:18px!important}html[data-theme] .store-dashboard .dashboard-stat span{font-size:9px!important}html[data-theme] .store-dashboard .dashboard-stat strong{font-size:17px!important}html[data-theme] .store-dashboard .dashboard-actions a{min-height:54px!important;padding:8px 7px!important;font-size:11px!important}html[data-theme] .store-dashboard .dashboard-actions .qa-icon{font-size:22px!important;flex-basis:24px!important}html[data-theme] .store-dashboard .dashboard-actions .qa-label{font-size:11px!important}}
</style>
<style id="xt-dashboard-final-unscoped-v33">
/* Final dashboard-only icon and neon color fix. Deliberately unscoped by theme attribute. */
.store-dashboard .dashboard-balance{border:1px solid rgba(255,45,174,.82)!important;border-radius:22px!important;background:radial-gradient(ellipse at 92% 0%,rgba(22,168,255,.14),transparent 43%),linear-gradient(140deg,#090f22 0%,#17112d 58%,#21102e 100%)!important;box-shadow:0 0 0 2px rgba(109,62,255,.13),0 0 18px rgba(255,40,171,.13),inset 0 1px 0 rgba(255,255,255,.08)!important}
.store-dashboard .dashboard-label{color:#aebcff!important;letter-spacing:.12em!important}
.store-dashboard .dashboard-balance-value{color:#3ff0b6!important;text-shadow:0 0 18px rgba(63,240,182,.22)!important}
.store-dashboard .dashboard-topup{display:inline-flex!important;align-items:center!important;justify-content:center!important;gap:7px!important;min-height:38px!important;height:38px!important;padding:0 13px!important;border-radius:12px!important;background:linear-gradient(110deg,#13d7ff,#665cff 52%,#ff3b9e)!important;border:1px solid rgba(255,255,255,.32)!important;color:#fff!important;font-size:11px!important;box-shadow:0 0 14px rgba(28,174,255,.18)!important}
.store-dashboard .dashboard-topup:before{content:"＋"!important;display:inline-flex!important;align-items:center!important;justify-content:center!important;width:19px!important;height:19px!important;border-radius:50%!important;background:#fff!important;color:#6952e8!important;font-size:16px!important;font-weight:1000!important;line-height:1!important}
.store-dashboard .dashboard-stat{position:relative!important;min-height:76px!important;padding:11px 8px 10px 52px!important;border-radius:16px!important;overflow:hidden!important;background:linear-gradient(135deg,rgba(10,19,41,.97),rgba(28,13,47,.96))!important;border:1px solid rgba(129,113,255,.58)!important;box-shadow:inset 0 0 15px rgba(37,111,255,.07)!important}
.store-dashboard .dashboard-stat:before{position:absolute!important;left:9px!important;top:50%!important;transform:translateY(-50%)!important;width:34px!important;height:34px!important;display:flex!important;align-items:center!important;justify-content:center!important;border-radius:50%!important;font-size:21px!important;line-height:1!important;border:1px solid rgba(70,205,255,.38)!important;filter:drop-shadow(0 0 7px rgba(70,130,255,.2))!important}
.store-dashboard .dashboard-stat:nth-child(1):before{content:"✓"!important;color:#8affcf!important;background:linear-gradient(145deg,rgba(0,255,128,.35),rgba(0,145,91,.15))!important;border-color:rgba(0,255,145,.7)!important;font-size:23px!important;font-weight:1000!important}
.store-dashboard .dashboard-stat:nth-child(2):before{content:"🛒"!important;background:linear-gradient(145deg,rgba(255,40,190,.3),rgba(98,0,180,.2))!important;border-color:rgba(255,65,194,.65)!important}


.store-dashboard .dashboard-stat span{font-size:10px!important;line-height:1.3!important;white-space:normal!important;color:#bdc9ff!important}
.store-dashboard .dashboard-stat strong{display:block!important;margin-top:5px!important;font-size:19px!important;line-height:1.15!important;white-space:normal!important;overflow-wrap:anywhere!important}

.store-dashboard .dashboard-quick{padding:12px!important;border-radius:18px!important;border:1px solid rgba(108,115,255,.55)!important;background:linear-gradient(145deg,rgba(7,17,35,.97),rgba(25,12,44,.96))!important;box-shadow:0 0 17px rgba(89,64,255,.09)!important}
.store-dashboard .dashboard-quick-title{font-size:15px!important;margin:0 0 8px!important;color:#f5f6ff!important}
.store-dashboard .dashboard-quick-title:before{content:"⚡"!important;display:inline-block!important;margin-right:7px!important;color:#ffe84a!important;font-size:20px!important;text-shadow:0 0 12px rgba(255,221,40,.35)!important}
.store-dashboard .dashboard-actions{gap:7px!important;margin-top:8px!important}
.store-dashboard .dashboard-actions a{display:flex!important;align-items:center!important;min-height:56px!important;height:auto!important;padding:8px 9px!important;gap:7px!important;justify-content:flex-start!important;border-radius:13px!important;font-size:12px!important;line-height:1.2!important;color:#fff!important;border:1px solid rgba(95,122,255,.6)!important;background:linear-gradient(120deg,rgba(12,36,69,.96),rgba(18,20,58,.96))!important;box-shadow:inset 0 0 12px rgba(45,115,255,.08),0 0 8px rgba(70,80,255,.08)!important}
.store-dashboard .dashboard-actions a:nth-child(1){background:linear-gradient(120deg,rgba(0,170,105,.9),rgba(4,43,51,.98))!important;border:1px solid rgba(17,238,156,.9)!important;box-shadow:0 0 12px rgba(0,225,151,.12),inset 0 0 12px rgba(0,255,163,.08)!important}
.store-dashboard .dashboard-actions a:nth-child(2){background:linear-gradient(120deg,rgba(0,116,235,.92),rgba(12,28,81,.98))!important;border:1px solid rgba(20,183,255,.9)!important;box-shadow:0 0 12px rgba(20,166,255,.12),inset 0 0 12px rgba(20,166,255,.08)!important}
.store-dashboard .dashboard-actions a:nth-child(3){background:linear-gradient(120deg,rgba(195,112,0,.92),rgba(67,29,19,.98))!important;border:1px solid rgba(255,190,55,.9)!important;box-shadow:0 0 12px rgba(255,183,45,.12),inset 0 0 12px rgba(255,183,45,.08)!important}
.store-dashboard .dashboard-actions a:nth-child(4){background:linear-gradient(120deg,rgba(143,0,205,.92),rgba(51,13,77,.98))!important;border:1px solid rgba(225,65,255,.9)!important;box-shadow:0 0 12px rgba(221,48,255,.12),inset 0 0 12px rgba(221,48,255,.08)!important}
.store-dashboard .dashboard-actions .qa-icon{display:inline-flex!important;align-items:center!important;justify-content:center!important;flex:0 0 27px!important;font-size:24px!important;line-height:1!important;filter:drop-shadow(0 0 6px rgba(255,255,255,.22))!important}
.store-dashboard .dashboard-actions .qa-label{display:block!important;min-width:0!important;flex:1 1 auto!important;font-size:12px!important;font-weight:950!important;line-height:1.2!important;white-space:normal!important;overflow-wrap:anywhere!important}
.store-dashboard .dashboard-actions .qa-arrow{display:inline-flex!important;align-items:center!important;justify-content:center!important;flex:0 0 22px!important;width:22px!important;height:22px!important;border:1.5px solid currentColor!important;border-radius:50%!important;font-size:19px!important;line-height:1!important;opacity:.98!important}
.store-dashboard .xt-purchase-warning{border:1px solid #ff4f91!important;border-radius:15px!important;background:linear-gradient(100deg,rgba(104,12,68,.45),rgba(48,12,49,.62))!important;color:#ffe0ef!important;box-shadow:0 0 12px rgba(255,48,145,.1)!important}
@media(max-width:600px){.store-dashboard .dashboard-stat{min-height:72px!important;padding:10px 6px 10px 47px!important}.store-dashboard .dashboard-stat:before{left:7px!important;width:31px!important;height:31px!important;font-size:18px!important}.store-dashboard .dashboard-stat span{font-size:9px!important}.store-dashboard .dashboard-stat strong{font-size:17px!important}.store-dashboard .dashboard-actions a{min-height:54px!important;padding:8px 7px!important;font-size:11px!important}.store-dashboard .dashboard-actions .qa-icon{font-size:22px!important;flex-basis:24px!important}.store-dashboard .dashboard-actions .qa-label{font-size:11px!important}}
</style>

<style id="xtreme-dashboard-icon-correction-v38">
/* One large wallet icon beside the balance, matching the supplied dashboard reference. */
.store-dashboard .dashboard-balance:before{content:""!important;display:block!important;position:absolute!important;left:25px!important;top:55px!important;width:66px!important;height:56px!important;float:none!important;margin:0!important;background:url("data:image/svg+xml,%3Csvg%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20width%3D%22100%22%20height%3D%2278%22%20viewBox%3D%220%200%20100%2078%22%3E%3Cdefs%3E%3ClinearGradient%20id%3D%22w%22%20x1%3D%220%22%20y1%3D%220%22%20x2%3D%221%22%20y2%3D%221%22%3E%3Cstop%20stop-color%3D%22%2321e6ff%22%2F%3E%3Cstop%20offset%3D%221%22%20stop-color%3D%22%230875ff%22%2F%3E%3C%2FlinearGradient%3E%3ClinearGradient%20id%3D%22c%22%20x1%3D%220%22%20y1%3D%220%22%20x2%3D%220%22%20y2%3D%221%22%3E%3Cstop%20stop-color%3D%22%23ffe86b%22%2F%3E%3Cstop%20offset%3D%221%22%20stop-color%3D%22%23ff9e00%22%2F%3E%3C%2FlinearGradient%3E%3C%2Fdefs%3E%3Cellipse%20cx%3D%2231%22%20cy%3D%2217%22%20rx%3D%2213%22%20ry%3D%2213%22%20fill%3D%22url%28%23c%29%22%20stroke%3D%22%23fff08a%22%20stroke-width%3D%222%22%2F%3E%3Cellipse%20cx%3D%2231%22%20cy%3D%2217%22%20rx%3D%226%22%20ry%3D%226%22%20fill%3D%22%23fff5a6%22%2F%3E%3Cellipse%20cx%3D%2248%22%20cy%3D%2222%22%20rx%3D%2213%22%20ry%3D%2213%22%20fill%3D%22url%28%23c%29%22%20stroke%3D%22%23fff08a%22%20stroke-width%3D%222%22%2F%3E%3Cellipse%20cx%3D%2248%22%20cy%3D%2222%22%20rx%3D%226%22%20ry%3D%226%22%20fill%3D%22%23fff5a6%22%2F%3E%3Cpath%20d%3D%22M12%2026h57a8%208%200%200%201%208%208v34H13a8%208%200%200%201-8-8V34a8%208%200%200%201%207-8z%22%20fill%3D%22url%28%23w%29%22%20stroke%3D%22%2339dfff%22%20stroke-width%3D%222%22%2F%3E%3Cpath%20d%3D%22M62%2039h25a9%209%200%200%201%200%2018H62a9%209%200%200%201%200-18z%22%20fill%3D%22%230875d8%22%20stroke%3D%22%233ce5ff%22%20stroke-width%3D%222%22%2F%3E%3Ccircle%20cx%3D%2278%22%20cy%3D%2248%22%20r%3D%223%22%20fill%3D%22%23b8f7ff%22%2F%3E%3C%2Fsvg%3E") center/contain no-repeat!important;filter:drop-shadow(0 0 9px rgba(0,190,255,.5))!important;z-index:2!important}
.store-dashboard .dashboard-balance-value:before{content:none!important;display:none!important}

/* Replace the unclear purse/card emoji in Quick Access with a clear wallet + icon. */
.store-dashboard .dashboard-actions .xt-wallet-add-icon{font-size:0!important;line-height:0!important;display:inline-flex!important;position:relative!important;flex:0 0 48px!important;width:48px!important;height:42px!important;background:url("data:image/svg+xml,%3Csvg%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20width%3D%22100%22%20height%3D%2278%22%20viewBox%3D%220%200%20100%2078%22%3E%3Cdefs%3E%3ClinearGradient%20id%3D%22w%22%20x1%3D%220%22%20y1%3D%220%22%20x2%3D%221%22%20y2%3D%221%22%3E%3Cstop%20stop-color%3D%22%2322e7ff%22%2F%3E%3Cstop%20offset%3D%221%22%20stop-color%3D%22%230876ff%22%2F%3E%3C%2FlinearGradient%3E%3C%2Fdefs%3E%3Cpath%20d%3D%22M12%2028h57a8%208%200%200%201%208%208v33H13a8%208%200%200%201-8-8V36a8%208%200%200%201%207-8z%22%20fill%3D%22url%28%23w%29%22%20stroke%3D%22%2345e7ff%22%20stroke-width%3D%222%22%2F%3E%3Cpath%20d%3D%22M16%2027%2037%2013h29a6%206%200%200%201%206%206v7H16z%22%20fill%3D%22%2320c9ff%22%20stroke%3D%22%236cecff%22%20stroke-width%3D%222%22%2F%3E%3Cpath%20d%3D%22M62%2039h25a9%209%200%200%201%200%2018H62a9%209%200%200%201%200-18z%22%20fill%3D%22%230875d8%22%20stroke%3D%22%233ce5ff%22%20stroke-width%3D%222%22%2F%3E%3Ccircle%20cx%3D%2278%22%20cy%3D%2248%22%20r%3D%223%22%20fill%3D%22%23b8f7ff%22%2F%3E%3Ccircle%20cx%3D%2276%22%20cy%3D%2219%22%20r%3D%2215%22%20fill%3D%22%23fff%22%20stroke%3D%22%236deaff%22%20stroke-width%3D%223%22%2F%3E%3Cpath%20d%3D%22M76%2010v18M67%2019h18%22%20stroke%3D%22%233d6dff%22%20stroke-width%3D%224%22%20stroke-linecap%3D%22round%22%2F%3E%3C%2Fsvg%3E") center/contain no-repeat!important;filter:drop-shadow(0 0 8px rgba(0,190,255,.42))!important}
.store-dashboard .dashboard-actions .xt-wallet-add-icon .xt-wallet-plus{display:none!important}
@media(max-width:600px){.store-dashboard .dashboard-balance:before{left:15px!important;top:53px!important;width:52px!important;height:45px!important}.store-dashboard .dashboard-balance-value{margin-left:62px!important}.store-dashboard .dashboard-actions .xt-wallet-add-icon{flex-basis:36px!important;width:36px!important;height:34px!important}}
@media(max-width:380px){.store-dashboard .dashboard-balance:before{left:11px!important;top:51px!important;width:43px!important;height:38px!important}.store-dashboard .dashboard-balance-value{margin-left:51px!important}.store-dashboard .dashboard-actions .xt-wallet-add-icon{flex-basis:30px!important;width:30px!important;height:29px!important}}
</style>
<style id="xt-dashboard-icon-redesign-v15">
/* Dashboard-only: visibly replace the Balance and Add Funds icons. */
.store-dashboard .dashboard-balance:before{content:""!important;display:block!important;position:absolute!important;left:24px!important;top:54px!important;width:68px!important;height:58px!important;margin:0!important;float:none!important;font-size:0!important;line-height:0!important;background-image:url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='100' height='82' viewBox='0 0 100 82'%3E%3Cdefs%3E%3ClinearGradient id='coin' x1='0' y1='0' x2='0' y2='1'%3E%3Cstop stop-color='%23fff08a'/%3E%3Cstop offset='.48' stop-color='%23ffc52e'/%3E%3Cstop offset='1' stop-color='%23e88b00'/%3E%3C/linearGradient%3E%3ClinearGradient id='bill' x1='0' y1='0' x2='1' y2='1'%3E%3Cstop stop-color='%233ef5c2'/%3E%3Cstop offset='1' stop-color='%2300a887'/%3E%3C/linearGradient%3E%3C/defs%3E%3Cellipse cx='33' cy='24' rx='18' ry='18' fill='url(%23coin)' stroke='%23fff5ad' stroke-width='2'/%3E%3Cellipse cx='55' cy='20' rx='18' ry='18' fill='url(%23coin)' stroke='%23fff5ad' stroke-width='2'/%3E%3Cellipse cx='45' cy='43' rx='18' ry='18' fill='url(%23coin)' stroke='%23fff5ad' stroke-width='2'/%3E%3Cpath d='M22 43h48a9 9 0 0 1 9 9v18H22a9 9 0 0 1-9-9v-9a9 9 0 0 1 9-9z' fill='url(%23bill)' stroke='%236affd8' stroke-width='2'/%3E%3Ctext x='47' y='62' text-anchor='middle' font-family='Arial,sans-serif' font-size='21' font-weight='bold' fill='%230b4e47'%3E%E0%A7%B3%3C/text%3E%3C/svg%3E")!important;background-position:center!important;background-size:contain!important;background-repeat:no-repeat!important;filter:drop-shadow(0 0 10px rgba(35,244,194,.45))!important;z-index:3!important}
.store-dashboard .dashboard-balance-value{margin-left:84px!important}
.store-dashboard .dashboard-actions a[href*="deposit.php"] .xt-wallet-add-icon,.store-dashboard .dashboard-actions a[href*="deposit.php"] .qa-icon{display:inline-flex!important;position:relative!important;align-items:center!important;justify-content:center!important;flex:0 0 48px!important;width:48px!important;height:48px!important;min-width:48px!important;min-height:48px!important;margin:0!important;padding:0!important;border:0!important;border-radius:0!important;background:none!important;background-image:none!important;box-shadow:none!important;overflow:visible!important;font-size:0!important;line-height:0!important}
.store-dashboard .dashboard-actions a[href*="deposit.php"] .xt-wallet-add-icon img,.store-dashboard .dashboard-actions a[href*="deposit.php"] .qa-icon img{display:none!important;visibility:hidden!important}
.store-dashboard .dashboard-actions a[href*="deposit.php"] .xt-wallet-add-icon:before,.store-dashboard .dashboard-actions a[href*="deposit.php"] .qa-icon:before{content:""!important;display:block!important;width:48px!important;height:44px!important;background-image:url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='100' height='82' viewBox='0 0 100 82'%3E%3Cdefs%3E%3ClinearGradient id='w' x1='0' y1='0' x2='1' y2='1'%3E%3Cstop stop-color='%2345f1ff'/%3E%3Cstop offset='1' stop-color='%23005bff'/%3E%3C/linearGradient%3E%3ClinearGradient id='p' x1='0' y1='0' x2='1' y2='1'%3E%3Cstop stop-color='%23fff'/%3E%3Cstop offset='1' stop-color='%23dce8ff'/%3E%3C/linearGradient%3E%3C/defs%3E%3Cpath d='M12 25h59a8 8 0 0 1 8 8v37H15a8 8 0 0 1-8-8V33a8 8 0 0 1 5-8z' fill='url(%23w)' stroke='%2371f4ff' stroke-width='3'/%3E%3Cpath d='M18 24l17-12h30a6 6 0 0 1 6 6v7z' fill='%2325caff' stroke='%2371f4ff' stroke-width='2'/%3E%3Cpath d='M61 39h26a10 10 0 0 1 0 20H61a10 10 0 0 1 0-20z' fill='%230a3b9d' stroke='%2368eaff' stroke-width='3'/%3E%3Ccircle cx='78' cy='49' r='3.5' fill='%23d9ffff'/%3E%3Ccircle cx='76' cy='17' r='16' fill='url(%23p)' stroke='%2364eaff' stroke-width='3'/%3E%3Cpath d='M76 8v18M67 17h18' stroke='%233a6bff' stroke-width='5' stroke-linecap='round'/%3E%3C/svg%3E")!important;background-position:center!important;background-size:contain!important;background-repeat:no-repeat!important;filter:drop-shadow(0 0 9px rgba(0,207,255,.55))!important}
@media(max-width:600px){.store-dashboard .dashboard-balance:before{left:14px!important;top:51px!important;width:53px!important;height:47px!important}.store-dashboard .dashboard-balance-value{margin-left:64px!important}.store-dashboard .dashboard-actions a[href*="deposit.php"] .xt-wallet-add-icon,.store-dashboard .dashboard-actions a[href*="deposit.php"] .qa-icon{flex-basis:40px!important;width:40px!important;height:40px!important;min-width:40px!important;min-height:40px!important}.store-dashboard .dashboard-actions a[href*="deposit.php"] .xt-wallet-add-icon:before,.store-dashboard .dashboard-actions a[href*="deposit.php"] .qa-icon:before{width:40px!important;height:38px!important}}
</style>

<style id="xtreme-v23-header-announcement-banner">
/* Banner sits in page flow below the fixed brand header and directly above the balance card. */
.xt-header-announcement{
  display:flex!important;flex-direction:column!important;align-items:center!important;justify-content:center!important;
  gap:6px!important;width:min(94%,560px)!important;max-width:560px!important;margin:10px auto 14px!important;
  padding:7px 9px!important;border:1px solid rgba(64,210,255,.55)!important;border-radius:13px!important;
  background:linear-gradient(110deg,rgba(14,36,68,.86),rgba(54,20,75,.88))!important;
  box-shadow:0 0 12px rgba(0,190,255,.12),inset 0 1px 0 rgba(255,255,255,.10)!important;
  color:#eaf7ff!important;text-decoration:none!important;overflow:hidden!important;box-sizing:border-box!important;
}
.xt-header-announcement img{display:block!important;width:100%!important;max-width:100%!important;max-height:125px!important;object-fit:contain!important;border-radius:8px!important}
.xt-header-announcement span{display:block!important;width:100%!important;text-align:center!important;font-size:11px!important;line-height:1.4!important;font-weight:800!important;letter-spacing:.025em!important;overflow-wrap:anywhere!important;color:#dff8ff!important}
@media(max-width:600px){.xt-header-announcement{width:94%!important;margin:8px auto 12px!important;padding:6px 7px!important;border-radius:11px!important}.xt-header-announcement img{max-height:92px!important}.xt-header-announcement span{font-size:10px!important}}
</style>


<style id="xt-global-header-logo-unified-v29">
/* One consistent site-header logo and title scale on every customer page */
header.top, header.topbar {
  box-sizing:border-box!important;
  width:100%!important;
  min-height:0!important;
  height:auto!important;
  padding:14px 14px 16px!important;
  margin:0 auto!important;
  display:flex!important;
  align-items:center!important;
  justify-content:center!important;
  text-align:center!important;
}
header.top .brand-with-logo, header.topbar .brand-with-logo {
  box-sizing:border-box!important;
  width:100%!important;
  max-width:100%!important;
  display:flex!important;
  flex-direction:column!important;
  align-items:center!important;
  justify-content:center!important;
  gap:7px!important;
  margin:0 auto!important;
  text-align:center!important;
}
header.top .header-logo, header.topbar .header-logo {
  display:block!important;
  box-sizing:border-box!important;
  width:46px!important;height:46px!important;
  min-width:46px!important;min-height:46px!important;
  max-width:46px!important;max-height:46px!important;
  flex:0 0 46px!important;
  object-fit:contain!important;object-position:center!important;
  background:transparent!important;
  border:0!important;padding:0!important;margin:0 auto!important;
  border-radius:10px!important;
}
header.top .brand-text, header.topbar .top-title {
  display:block!important;
  max-width:100%!important;
  margin:0 auto!important;padding:0!important;
  text-align:center!important;
  font-size:clamp(17px,4.6vw,25px)!important;
  line-height:1.2!important;
  font-weight:900!important;
  letter-spacing:0!important;
  overflow-wrap:anywhere!important;
}
header.topbar .xt-dashboard-tagline {
  margin:0 auto!important;
  text-align:center!important;
  line-height:1.2!important;
}
@media(max-width:420px) {
  header.top,header.topbar{padding:12px 10px 14px!important}
  header.top .header-logo,header.topbar .header-logo {
    width:46px!important;height:46px!important;min-width:46px!important;min-height:46px!important;
    max-width:46px!important;max-height:46px!important;flex-basis:46px!important;
  }
}
</style>

<style id="xt-dashboard-panel-inset-v29">
/* Keep the large dashboard panel visibly inset from both phone edges.
   The contents stay inside this panel; only its outer spacing changes. */
.store-dashboard {
  box-sizing:border-box!important;
  width:calc(100% - 28px)!important;
  max-width:1000px!important;
  margin:18px auto 20px!important;
  padding:18px!important;
  border-radius:26px!important;
  overflow:hidden!important;
}
.store-dashboard .dashboard-balance,
.store-dashboard .dashboard-stats,
.store-dashboard .dashboard-quick,
.store-dashboard .dashboard-actions-wrap {
  box-sizing:border-box!important;
  max-width:100%!important;
  min-width:0!important;
}
.store-dashboard .dashboard-balance{width:100%!important;margin-left:auto!important;margin-right:auto!important}
.store-dashboard .dashboard-stats {
  width:100%!important;
  display:grid!important;
  grid-template-columns:repeat(2,minmax(0,1fr))!important;
  gap:12px!important;
  margin-left:auto!important;margin-right:auto!important;
}
.store-dashboard .dashboard-stat{box-sizing:border-box!important;min-width:0!important;max-width:100%!important}
.store-dashboard .dashboard-quick {
  width:100%!important;
  margin-left:auto!important;margin-right:auto!important;
}
.store-dashboard .dashboard-actions {
  width:100%!important;
  box-sizing:border-box!important;
  display:grid!important;
  grid-template-columns:repeat(2,minmax(0,1fr))!important;
  gap:10px!important;
}
.store-dashboard .dashboard-actions a {
  box-sizing:border-box!important;
  min-width:0!important;
  max-width:100%!important;
}
@media(max-width:480px) {
  .store-dashboard {
    width:calc(100% - 28px)!important;
    margin:16px auto 18px!important;
    padding:14px!important;
    border-radius:24px!important;
  }
  .store-dashboard .dashboard-stats{gap:10px!important}
  .store-dashboard .dashboard-actions{gap:9px!important}
}
</style>

<style id="xt-banner-dashboard-width-and-image-fit-v30">
/* V30: Make the large dashboard panel match the announcement banner's side margins. */
.xt-header-announcement,
.store-dashboard {
  box-sizing:border-box!important;
  width:94%!important;
  max-width:560px!important;
  margin-left:auto!important;
  margin-right:auto!important;
}
.store-dashboard {
  margin-top:18px!important;
  margin-bottom:20px!important;
  padding:16px!important;
  border-radius:24px!important;
  overflow:hidden!important;
}
.store-dashboard .dashboard-balance,
.store-dashboard .dashboard-stats,
.store-dashboard .dashboard-quick,
.store-dashboard .dashboard-actions-wrap {
  box-sizing:border-box!important;
  width:100%!important;
  max-width:100%!important;
  min-width:0!important;
}
.store-dashboard .dashboard-stats {
  display:grid!important;
  grid-template-columns:repeat(2,minmax(0,1fr))!important;
  gap:10px!important;
  margin-left:0!important;
  margin-right:0!important;
}
.store-dashboard .dashboard-stat {min-width:0!important;max-width:100%!important;box-sizing:border-box!important}
.store-dashboard .dashboard-quick {margin-left:0!important;margin-right:0!important}
.store-dashboard .dashboard-actions {
  display:grid!important;
  grid-template-columns:repeat(2,minmax(0,1fr))!important;
  width:100%!important;
  gap:9px!important;
  box-sizing:border-box!important;
}
.store-dashboard .dashboard-actions a {min-width:0!important;max-width:100%!important;box-sizing:border-box!important}

/* Fill the banner card with the uploaded banner instead of leaving the image tiny
   or letterboxed. The whole image remains responsive on narrow phone screens. */
.xt-header-announcement {
  padding:7px!important;
  gap:0!important;
  overflow:hidden!important;
}
.xt-header-announcement img {
  display:block!important;
  width:100%!important;
  max-width:100%!important;
  height:clamp(105px,25vw,145px)!important;
  max-height:none!important;
  object-fit:cover!important;
  object-position:center!important;
  border-radius:8px!important;
}
@media(max-width:480px) {
  .xt-header-announcement,.store-dashboard {width:94%!important}
  .store-dashboard {padding:13px!important}
  .store-dashboard .dashboard-stats {gap:9px!important}
  .store-dashboard .dashboard-actions {gap:8px!important}
  .xt-header-announcement img {height:clamp(100px,28vw,125px)!important}
}
</style>

<style id="xt-dashboard-sides-match-banner-v31">
/* Match the outer dashboard panel's left/right inset to the banner card. */
html[data-theme] section.store-dashboard,
section.store-dashboard {
  box-sizing:border-box!important;
  width:calc(100% - 48px)!important;
  max-width:560px!important;
  margin-left:auto!important;
  margin-right:auto!important;
  overflow:hidden!important;
}
html[data-theme] .xt-header-announcement,
.xt-header-announcement {
  box-sizing:border-box!important;
  width:calc(100% - 48px)!important;
  max-width:560px!important;
  margin-left:auto!important;
  margin-right:auto!important;
}

@media(max-width:480px) {
  html[data-theme] section.store-dashboard,
  section.store-dashboard,
  html[data-theme] .xt-header-announcement,
  .xt-header-announcement {
    width:calc(100% - 48px)!important;
  }
}
</style>

<style id="xt-dashboard-banner-match-product-card-width-v32">
/* Match the outer dashboard and banner card to the product-card side inset. */
html[data-theme] .xt-header-announcement,
.xt-header-announcement,
html[data-theme] section.store-dashboard,
section.store-dashboard {
  box-sizing:border-box!important;
  width:calc(100% - 20px)!important;
  max-width:900px!important;
  margin-left:auto!important;
  margin-right:auto!important;
}
html[data-theme] section.store-dashboard {
  padding:16px!important;
  border-radius:24px!important;
  overflow:hidden!important;
}
html[data-theme] section.store-dashboard .dashboard-balance,
html[data-theme] section.store-dashboard .dashboard-stats,
html[data-theme] section.store-dashboard .dashboard-quick,
html[data-theme] section.store-dashboard .dashboard-actions,
section.store-dashboard .dashboard-balance,
section.store-dashboard .dashboard-stats,
section.store-dashboard .dashboard-quick,
section.store-dashboard .dashboard-actions {
  box-sizing:border-box!important;
  max-width:100%!important;
  min-width:0!important;
}
@media(max-width:600px) {
  html[data-theme] .xt-header-announcement,
  .xt-header-announcement,
  html[data-theme] section.store-dashboard,
  section.store-dashboard {
    width:calc(100% - 20px)!important;
  }
  html[data-theme] section.store-dashboard,
  section.store-dashboard {padding:13px!important}
}
</style>
<link rel="stylesheet" href="assets/xtreme-music.css?v=3">

<style id="xt-balance-restored-single-row-v1">
.store-dashboard .xt-balance-restored{display:block!important;width:100%;min-width:0;padding:18px 16px!important;margin:0 0 12px!important;}
.store-dashboard .xt-balance-restored>.dashboard-label{display:block!important;margin:0 0 12px!important;}
.store-dashboard .xt-balance-row{display:flex!important;align-items:center!important;justify-content:space-between!important;gap:clamp(8px,2.5vw,16px)!important;width:100%!important;min-width:0!important;}
.store-dashboard .xt-balance-logo-link{display:flex!important;align-items:center!important;justify-content:center!important;flex:0 0 clamp(38px,11vw,52px)!important;width:clamp(38px,11vw,52px)!important;height:clamp(38px,11vw,52px)!important;text-decoration:none!important;}
.store-dashboard .xt-balance-logo{display:block!important;width:100%!important;height:100%!important;max-width:52px!important;max-height:52px!important;object-fit:contain!important;}
.store-dashboard .xt-balance-amount{display:block!important;flex:1 1 auto!important;min-width:0!important;margin:0!important;padding:0!important;font-size:clamp(21px,6vw,34px)!important;line-height:1.15!important;font-weight:900!important;white-space:nowrap!important;letter-spacing:-.04em!important;}
.store-dashboard .xt-balance-addfunds{display:inline-flex!important;align-items:center!important;justify-content:center!important;gap:6px!important;flex:0 0 auto!important;min-width:0!important;max-width:46%!important;height:clamp(38px,10vw,48px)!important;padding:0 clamp(9px,2.8vw,16px)!important;border-radius:12px!important;font-size:clamp(9px,2.7vw,12px)!important;white-space:nowrap!important;}
.store-dashboard .xt-balance-addfunds span{font-size:1.5em!important;line-height:1!important;}
.store-dashboard .xt-balance-amount:before,.store-dashboard .xt-balance-amount:after{content:none!important;display:none!important;background:none!important;}
@media(max-width:360px){.store-dashboard .xt-balance-restored{padding:15px 11px!important}.store-dashboard .xt-balance-row{gap:7px!important}.store-dashboard .xt-balance-logo-link{flex-basis:34px!important;width:34px!important;height:34px!important}.store-dashboard .xt-balance-addfunds{padding:0 8px!important;font-size:9px!important}.store-dashboard .xt-balance-amount{font-size:20px!important}}
</style>

<style id="xt-store-mobile-category-product-fix-v1">
/* Store category tiles: render as compact premium cards, never browser-style links. */
body .xt-topup-entry,
body section.xt-topup-entry{width:calc(100% - 24px)!important;max-width:1100px!important;margin:14px auto 16px!important;box-sizing:border-box!important}
body section.xt-topup-entry .xt-topup-tiles{
  display:grid!important;grid-template-columns:repeat(3,minmax(0,1fr))!important;
  gap:8px!important;width:100%!important;min-width:0!important;
}
body section.xt-topup-entry .xt-topup-tiles>a,
body section.xt-topup-entry .xt-topup-tiles>a:link,
body section.xt-topup-entry .xt-topup-tiles>a:visited,
body section.xt-topup-entry .xt-topup-tiles>a:hover,
body section.xt-topup-entry .xt-topup-tiles>a:active{
  box-sizing:border-box!important;display:flex!important;flex-direction:column!important;
  align-items:center!important;justify-content:center!important;gap:6px!important;
  width:100%!important;min-width:0!important;min-height:76px!important;height:auto!important;
  padding:9px 5px!important;border:1px solid rgba(70,205,235,.42)!important;
  border-radius:14px!important;background:linear-gradient(145deg,#142b49,#11152d)!important;
  color:#f7fbff!important;text-decoration:none!important;-webkit-text-decoration:none!important;
  font-size:12px!important;font-weight:900!important;line-height:1.15!important;
  text-align:center!important;white-space:normal!important;overflow-wrap:anywhere!important;
  box-shadow:0 5px 14px rgba(0,0,0,.24),inset 0 1px rgba(255,255,255,.08)!important;
}
body section.xt-topup-entry .xt-topup-tiles>a span{
  display:grid!important;place-items:center!important;width:29px!important;height:29px!important;
  min-width:29px!important;margin:0!important;padding:0!important;border-radius:9px!important;
  background:rgba(15,205,236,.13)!important;font-size:19px!important;line-height:1!important;
}
body section.xt-topup-entry .xt-topup-tiles>a b{
  display:block!important;max-width:100%!important;margin:0!important;padding:0!important;
  color:#f7fbff!important;font-size:clamp(9px,2.6vw,12px)!important;
  font-weight:950!important;line-height:1.15!important;text-decoration:none!important;
  white-space:normal!important;overflow-wrap:anywhere!important;word-break:normal!important;
}
body section.xt-topup-entry .xt-topup-tiles>a:nth-child(3n/**/+2){border-color:rgba(231,91,185,.5)!important;background:linear-gradient(145deg,#392044,#17162f)!important}
body section.xt-topup-entry .xt-topup-tiles>a:nth-child(3n){border-color:rgba(255,198,76,.5)!important;background:linear-gradient(145deg,#40331d,#17182e)!important}

/* Product card links remain functional, but must look like designed action buttons. */
body .product a,body .product a:link,body .product a:visited{
  text-decoration:none!important;-webkit-text-decoration:none!important;
}
body .product .product-action-row .product-action,
body .product .product-action-row .product-action:link,
body .product .product-action-row .product-action:visited{
  display:inline-flex!important;align-items:center!important;justify-content:center!important;
  min-width:0!important;max-width:100%!important;min-height:42px!important;padding:9px 11px!important;
  border:1px solid rgba(55,194,230,.35)!important;border-radius:12px!important;
  color:#f7fbff!important;text-decoration:none!important;-webkit-text-decoration:none!important;
  font-size:clamp(10px,2.8vw,13px)!important;font-weight:900!important;line-height:1.2!important;
  white-space:normal!important;overflow-wrap:anywhere!important;
}

/* Keep product poster and status/update badges inside their own card. */
body .product .product-image{
  width:100%!important;height:clamp(170px,48vw,260px)!important;min-height:0!important;
  overflow:hidden!important;display:flex!important;align-items:center!important;justify-content:center!important;
  border-radius:17px!important;background:#0b1425!important;
}
body .product .product-image img,
body .product .product-image video,
body .product .product-image .product-media{
  display:block!important;width:100%!important;height:100%!important;max-width:100%!important;
  max-height:100%!important;object-fit:contain!important;object-position:center!important;
}
body .product .product-name{
  font-size:clamp(17px,4.5vw,23px)!important;line-height:1.2!important;
  overflow-wrap:anywhere!important;word-break:normal!important;
}
body .product .xt-product-tags{
  top:8px!important;left:8px!important;max-width:48%!important;gap:5px!important;
}
body .product .xt-product-tag{
  display:inline-flex!important;max-width:100%!important;width:max-content!important;
  min-height:0!important;padding:4px 8px 4px 16px!important;border-radius:999px!important;
  font-size:clamp(9px,2.3vw,11px)!important;line-height:1.1!important;letter-spacing:.02em!important;
  white-space:normal!important;overflow-wrap:anywhere!important;
}
body .product .xt-product-tag:before{left:6px!important;width:5px!important;height:5px!important}
@media(max-width:390px){
  body .xt-topup-entry{width:calc(100% - 20px)!important}
  body .product .product-image{height:clamp(155px,46vw,220px)!important}
}
</style>

<link rel="stylesheet" href="store-v14-stability.css?v=20261117-v34" media="all">
<style id="xt-product-category-carousel-v12">
.xt-product-filter-wrap{
  width:100%;max-width:100%;margin:10px auto 3px;padding:0 14px;
  box-sizing:border-box;position:relative;z-index:2;
}
.xt-product-filter-track{
  display:flex;align-items:center;gap:9px;width:100%;
  overflow-x:auto;overflow-y:hidden;padding:3px 1px 8px;
  scroll-snap-type:x mandatory;-webkit-overflow-scrolling:touch;
  scrollbar-width:none;overscroll-behavior-x:contain;
}
.xt-product-filter-track::-webkit-scrollbar{display:none}
.xt-product-filter-btn,.xt-product-filter-btn:link,.xt-product-filter-btn:visited{
  appearance:none;-webkit-appearance:none;text-decoration:none!important;outline:none;
  color:#c9efff!important;background:linear-gradient(135deg,rgba(12,31,57,.96),rgba(37,21,61,.96))!important;
  flex:0 0 calc((100% - 9px)/2);min-width:0;max-width:calc((100% - 9px)/2);
  min-height:39px;padding:8px 9px;border-radius:13px;
  display:flex;align-items:center;justify-content:center;gap:6px;
  border:1px solid rgba(76,211,255,.35);
  background:linear-gradient(135deg,rgba(12,31,57,.96),rgba(37,21,61,.96));
  color:#c9efff;font:800 10px/1.15 Inter,system-ui,sans-serif;
  letter-spacing:.035em;text-align:center;white-space:normal;
  box-shadow:inset 0 1px 0 rgba(255,255,255,.08),0 5px 15px rgba(0,0,0,.22);
  scroll-snap-align:start;cursor:pointer;transition:border-color .18s,background .18s,box-shadow .18s,transform .18s;
  -webkit-tap-highlight-color:transparent;
}
.xt-product-filter-btn span{font-size:14px;line-height:1;flex:0 0 auto}
.xt-product-filter-btn b{font-size:10px;font-weight:900;overflow-wrap:anywhere}
.xt-product-filter-btn.is-active,.xt-product-filter-btn.is-active:link,.xt-product-filter-btn.is-active:visited{
  color:#fff!important;border-color:#35e2ef;
  background:linear-gradient(110deg,#087dbd,#7142d6 55%,#bd36c5);
  box-shadow:0 0 0 1px rgba(65,220,255,.18),0 0 16px rgba(24,183,255,.25),inset 0 1px 0 rgba(255,255,255,.2);
}
.xt-product-filter-btn:active{transform:scale(.98)}
main.container > section.product.xt-filtered-out{display:none!important}
main.container > section.product:first-of-type{margin-top:0!important}
body .xt-product-tag{position:relative!important;padding-left:19px!important}
body .xt-product-tag:before{
  position:absolute!important;left:5px!important;top:50%!important;
  display:block!important;width:5px!important;height:5px!important;
  min-width:5px!important;margin:0!important;flex:none!important;
  transform:translateY(-50%)!important;
  animation:xt-tag-dot-soft-pulse-v13 1.15s ease-in-out infinite!important;
}
@keyframes xt-tag-dot-soft-pulse-v13{
  0%,100%{opacity:1;filter:brightness(1)}
  50%{opacity:.55;filter:brightness(1.2)}
}
.xt-product-filter-empty{
  display:none;margin:10px 0 18px;padding:18px 14px;text-align:center;
  border:1px solid rgba(85,180,230,.24);border-radius:16px;
  background:linear-gradient(135deg,rgba(12,26,49,.9),rgba(38,20,55,.9));
  color:#cbd8ed;font-size:13px;font-weight:800;
}
.xt-product-filter-empty.is-visible{display:block}
@media(min-width:600px){
 .xt-product-filter-wrap{max-width:900px}
 .xt-product-filter-btn{flex-basis:calc((100% - 9px)/2);max-width:calc((100% - 9px)/2);min-height:42px;font-size:12px}
}
</style>

<style id="xt-product-category-premium-motion-v14">
/* Move product status dots farther left without changing the badge size. */
html body main.container > section.product .xt-product-tag{
  position:relative!important;
  padding-left:15px!important;
}
html body main.container > section.product .xt-product-tag:before{
  position:absolute!important;
  left:1px!important;
  top:50%!important;
  display:block!important;
  width:5px!important;
  height:5px!important;
  min-width:5px!important;
  margin:0!important;
  flex:none!important;
  transform:translateY(-50%)!important;
}

/* Premium animated multicolor border for every product category button. */
@property --xt-filter-border-angle-v14{
  syntax:"<angle>";
  inherits:false;
  initial-value:0deg;
}
@keyframes xt-filter-border-rotate-v14{
  to{--xt-filter-border-angle-v14:360deg}
}
#xtProductFilterTrack .xt-product-filter-btn,
#xtProductFilterTrack .xt-product-filter-btn:link,
#xtProductFilterTrack .xt-product-filter-btn:visited{
  position:relative!important;
  isolation:isolate!important;
  border:1.5px solid transparent!important;
  background:
    linear-gradient(135deg,rgba(12,31,57,.98),rgba(37,21,61,.98)) padding-box,
    conic-gradient(from var(--xt-filter-border-angle-v14),#22eaff,#8b5cf6,#ff3bc8,#ffc247,#26e6a8,#22eaff) border-box!important;
  color:#e8f7ff!important;
  text-decoration:none!important;
  animation:xt-filter-border-rotate-v14 3.2s linear infinite!important;
  box-shadow:0 0 12px rgba(34,211,238,.12),inset 0 1px 0 rgba(255,255,255,.08)!important;
}
#xtProductFilterTrack .xt-product-filter-btn.is-active,
#xtProductFilterTrack .xt-product-filter-btn.is-active:link,
#xtProductFilterTrack .xt-product-filter-btn.is-active:visited{
  background:
    linear-gradient(110deg,#087dbd,#7142d6 55%,#bd36c5) padding-box,
    conic-gradient(from var(--xt-filter-border-angle-v14),#22eaff,#8b5cf6,#ff3bc8,#ffc247,#26e6a8,#22eaff) border-box!important;
  color:#fff!important;
  box-shadow:0 0 0 1px rgba(65,220,255,.18),0 0 18px rgba(24,183,255,.28)!important;
}
#xtProductFilterTrack .xt-product-filter-btn b,
#xtProductFilterTrack .xt-product-filter-btn span{
  position:relative!important;
  z-index:1!important;
}
@media(prefers-reduced-motion:reduce){
  #xtProductFilterTrack .xt-product-filter-btn{animation:none!important}
}
</style>

<style id="xt-product-status-purchase-ui">
.product-image.xt-inline-media{position:relative!important}
.xt-product-status{position:absolute;z-index:5;top:12px;right:12px;display:inline-flex;align-items:center;gap:8px;padding:9px 14px;border-radius:999px;font-size:clamp(11px,2.8vw,15px);font-weight:950;letter-spacing:.06em;line-height:1.1;box-shadow:0 4px 18px rgba(0,0,0,.35);backdrop-filter:blur(8px);-webkit-backdrop-filter:blur(8px);animation:xt-status-breathe 1.8s ease-in-out infinite}
.xt-product-tags{position:absolute;z-index:6;top:12px;left:12px;display:flex;flex-direction:column;align-items:flex-start;gap:6px;max-width:55%;pointer-events:none}.xt-product-tag{display:inline-flex;align-items:center;padding:6px 10px;border-radius:999px;color:#fff;font-size:clamp(10px,2.4vw,13px);font-weight:950;letter-spacing:.05em;line-height:1.1;border:1px solid rgba(255,255,255,.4);box-shadow:0 3px 12px rgba(0,0,0,.32);backdrop-filter:blur(7px);-webkit-backdrop-filter:blur(7px);overflow-wrap:anywhere}.xt-product-tag.tag-safe{background:rgba(5,120,75,.92);border-color:#34d399}.xt-product-tag.tag-risk{background:rgba(185,28,28,.94);border-color:#fb4545}.xt-product-tag.tag-updating{background:rgba(180,83,9,.94);border-color:#fbbf24}.xt-product-tag.tag-testing{background:rgba(91,33,182,.94);border-color:#c4b5fd}
.xt-product-tag{position:relative;padding-left:19px!important}
.xt-product-tag:before{content:"";position:absolute;left:7px;top:50%;width:6px;height:6px;border-radius:50%;transform:translateY(-50%);background:currentColor;box-shadow:0 0 7px currentColor;animation:xt-dot-pulse 1.15s ease-in-out infinite}
.xt-maintenance-overlay{position:fixed;inset:0;z-index:99999;display:flex;align-items:center;justify-content:center;padding:20px;background:rgba(1,5,13,.78);backdrop-filter:blur(9px);-webkit-backdrop-filter:blur(9px)}
.xt-maintenance-dialog{width:min(100%,420px);padding:25px 22px;border:1px solid rgba(54,210,255,.5);border-radius:22px;background:linear-gradient(145deg,#101e32,#171329);box-shadow:0 20px 70px rgba(0,0,0,.6),0 0 28px rgba(0,200,255,.12);color:#f5f8ff;text-align:center}
.xt-maintenance-icon{margin:0 auto 12px;width:48px;height:48px;display:grid;place-items:center;border-radius:50%;background:rgba(255,58,68,.15);border:1px solid rgba(255,58,68,.55)}
.xt-maintenance-icon .xt-status-dot{width:12px;height:12px;flex-basis:12px;background:#ff414d;box-shadow:0 0 14px #ff414d}
.xt-maintenance-dialog h2{margin:4px 0 10px;font-size:22px;font-weight:900}
.xt-maintenance-dialog p{margin:0 0 22px;color:#bdc9da;line-height:1.55;font-size:15px}
.xt-maintenance-actions{display:grid;grid-template-columns:1fr 1fr;gap:11px}
.xt-maintenance-actions button{min-height:48px;border-radius:12px;font-weight:900;font-size:15px;cursor:pointer}
.xt-maintenance-cancel{background:#202b3b;border:1px solid #45536a;color:#e8edf5}
.xt-maintenance-continue{background:linear-gradient(100deg,#06b9ee,#10c79b);border:0;color:#04111a}

.xt-product-status.is-online{color:#a7ffdc;background:rgba(5,100,72,.88);border:2px solid #34d399}
.xt-product-status.is-maintenance{color:#fff;background:rgba(153,27,27,.94);border:2px solid #fb4545}
.xt-status-dot{width:10px;height:10px;flex:0 0 10px;border-radius:50%;display:inline-block;animation:xt-dot-pulse 1.15s ease-in-out infinite}
.is-online .xt-status-dot{background:#4dffb0;box-shadow:0 0 12px #34d399}
.is-maintenance .xt-status-dot{background:#ff3838;box-shadow:0 0 12px #ff3838}
.xt-maintenance-countdown{display:inline-grid;place-items:center;min-width:19px;height:19px;padding:0 4px;border-radius:50%;font-size:11px;font-weight:1000;color:#fff;background:#b91c1c;border:1px solid #fca5a5;animation:xt-status-breathe .8s ease-in-out infinite}
.xt-product-tag{position:relative}.xt-product-tag:before{content:"";display:inline-block;width:7px;height:7px;flex:0 0 7px;border-radius:50%;margin-right:6px;background:currentColor;box-shadow:0 0 8px currentColor;animation:xt-dot-pulse 1.15s ease-in-out infinite}
@keyframes xt-status-breathe{0%,100%{transform:scale(1);filter:brightness(1)}50%{transform:scale(1.045);filter:brightness(1.18)}}
@keyframes xt-dot-pulse{0%,100%{opacity:1;transform:scale(1)}50%{opacity:.45;transform:scale(.72)}}
.xt-purchase-toggle{display:block;width:100%;min-height:62px;margin:18px 0 14px;padding:14px 18px;border:0;border-radius:17px;background:linear-gradient(105deg,#09b9e7,#397cff,#10c69a);color:#fff;font-size:clamp(17px,4vw,23px);font-weight:950;letter-spacing:.06em;box-shadow:0 10px 28px rgba(0,190,230,.25);cursor:pointer}
.xt-purchase-toggle:active{transform:scale(.99)}n.xt-purchase-toggle.is-maintenance-purchase{background:linear-gradient(105deg,#7f1d1d,#b91c1c,#7f1d1d);border:1px solid #fb4545;color:#fff;box-shadow:0 10px 28px rgba(239,68,68,.22)}n.xt-purchase-countdown{display:inline-grid;place-items:center;min-width:25px;height:25px;margin-left:10px;padding:0 5px;border-radius:50%;background:#fff;color:#991b1b;font-weight:1000;animation:xt-status-breathe .8s ease-in-out infinite}.xt-purchase-toggle.is-maintenance-purchase{display:flex;align-items:center;justify-content:center;gap:3px}
.product .plan-list[hidden],.product .buy-area[hidden]{display:none!important}
.product-action-row .product-action{border-radius:12px!important}
@media(max-width:480px){.xt-product-tags{top:8px;left:8px;gap:4px}.xt-product-tag{padding:5px 7px;font-size:10px}.xt-product-status{top:8px;right:8px;padding:7px 10px;gap:6px}.xt-status-dot{width:8px;height:8px;flex-basis:8px}.xt-purchase-toggle{min-height:56px}}
</style>
<style id="xt-dashboard-wallet-icons-final-v39">
/* Final icon override: exactly one wallet in balance and one wallet-plus in Quick Access. */
.store-dashboard .dashboard-balance:before{content:""!important;display:block!important;position:absolute!important;left:25px!important;top:55px!important;width:66px!important;height:56px!important;float:none!important;margin:0!important;font-size:0!important;line-height:0!important;background-image:url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='100' height='78' viewBox='0 0 100 78'%3E%3Cdefs%3E%3ClinearGradient id='w' x1='0' y1='0' x2='1' y2='1'%3E%3Cstop stop-color='%2321e6ff'/%3E%3Cstop offset='1' stop-color='%230875ff'/%3E%3C/linearGradient%3E%3ClinearGradient id='c' x1='0' y1='0' x2='0' y2='1'%3E%3Cstop stop-color='%23ffe86b'/%3E%3Cstop offset='1' stop-color='%23ff9e00'/%3E%3C/linearGradient%3E%3C/defs%3E%3Cellipse cx='31' cy='17' rx='13' ry='13' fill='url(%23c)' stroke='%23fff08a' stroke-width='2'/%3E%3Cellipse cx='48' cy='22' rx='13' ry='13' fill='url(%23c)' stroke='%23fff08a' stroke-width='2'/%3E%3Cpath d='M12 26h57a8 8 0 0 1 8 8v34H13a8 8 0 0 1-8-8V34a8 8 0 0 1 7-8z' fill='url(%23w)' stroke='%2339dfff' stroke-width='2'/%3E%3Cpath d='M62 39h25a9 9 0 0 1 0 18H62a9 9 0 0 1 0-18z' fill='%230875d8' stroke='%233ce5ff' stroke-width='2'/%3E%3Ccircle cx='78' cy='48' r='3' fill='%23b8f7ff'/%3E%3C/svg%3E")!important;background-position:center!important;background-size:contain!important;background-repeat:no-repeat!important;filter:drop-shadow(0 0 9px rgba(0,190,255,.5))!important;z-index:2!important}
.store-dashboard .dashboard-balance-value:before,.store-dashboard .dashboard-balance-value:after{content:none!important;display:none!important}
.store-dashboard .dashboard-balance-value{margin-left:82px!important;position:relative!important;z-index:1!important}
.store-dashboard .dashboard-actions a[href*="deposit.php"] .qa-icon{font-size:0!important;line-height:0!important;display:inline-flex!important;position:relative!important;flex:0 0 48px!important;width:48px!important;height:42px!important;background-image:url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='100' height='78' viewBox='0 0 100 78'%3E%3Cdefs%3E%3ClinearGradient id='w' x1='0' y1='0' x2='1' y2='1'%3E%3Cstop stop-color='%2322e7ff'/%3E%3Cstop offset='1' stop-color='%230876ff'/%3E%3C/linearGradient%3E%3C/defs%3E%3Cpath d='M12 28h57a8 8 0 0 1 8 8v33H13a8 8 0 0 1-8-8V36a8 8 0 0 1 7-8z' fill='url(%23w)' stroke='%2345e7ff' stroke-width='2'/%3E%3Cpath d='M16 27 37 13h29a6 6 0 0 1 6 6v7H16z' fill='%2320c9ff' stroke='%236cecff' stroke-width='2'/%3E%3Cpath d='M62 39h25a9 9 0 0 1 0 18H62a9 9 0 0 1 0-18z' fill='%230875d8' stroke='%233ce5ff' stroke-width='2'/%3E%3Ccircle cx='78' cy='48' r='3' fill='%23b8f7ff'/%3E%3Ccircle cx='76' cy='19' r='15' fill='%23fff' stroke='%236deaff' stroke-width='3'/%3E%3Cpath d='M76 10v18M67 19h18' stroke='%233d6dff' stroke-width='4' stroke-linecap='round'/%3E%3C/svg%3E")!important;background-position:center!important;background-size:contain!important;background-repeat:no-repeat!important;filter:drop-shadow(0 0 8px rgba(0,190,255,.42))!important}
.store-dashboard .dashboard-actions a[href*="deposit.php"] .qa-icon .xt-wallet-plus{display:none!important}
@media(max-width:600px){.store-dashboard .dashboard-balance:before{left:15px!important;top:53px!important;width:52px!important;height:45px!important}.store-dashboard .dashboard-balance-value{margin-left:62px!important}.store-dashboard .dashboard-actions a[href*="deposit.php"] .qa-icon{flex-basis:36px!important;width:36px!important;height:34px!important}}
@media(max-width:380px){.store-dashboard .dashboard-balance:before{left:11px!important;top:51px!important;width:43px!important;height:38px!important}.store-dashboard .dashboard-balance-value{margin-left:51px!important}.store-dashboard .dashboard-actions a[href*="deposit.php"] .qa-icon{flex-basis:30px!important;width:30px!important;height:29px!important}}
</style>
<style id="xtreme-dashboard-only-finish-v13">
/* V13: apply the requested premium treatment to the actual dashboard panel only.
   Product listing cards and other pages are deliberately not targeted. */
.store-dashboard .dashboard-balance{
  background:radial-gradient(circle at 8% 100%,rgba(16,216,255,.12),transparent 38%),linear-gradient(135deg,#10142e 0%,#21102f 58%,#10152f 100%)!important;
  border:2px solid rgba(255,64,205,.86)!important;
  box-shadow:0 0 0 1px rgba(44,220,255,.14),0 0 26px rgba(255,45,198,.16),inset 0 0 22px rgba(98,76,180,.16)!important;
}
.store-dashboard .dashboard-stat:nth-child(1){background:linear-gradient(135deg,rgba(4,75,69,.62),rgba(19,17,47,.97))!important;border:1px solid rgba(40,238,178,.62)!important}
.store-dashboard .dashboard-stat:nth-child(2){background:linear-gradient(135deg,rgba(78,22,78,.56),rgba(19,17,47,.97))!important;border:1px solid rgba(239,76,198,.58)!important}
.store-dashboard .dashboard-stat:nth-child(3){background:linear-gradient(135deg,rgba(83,59,18,.5),rgba(19,17,47,.97))!important;border:1px solid rgba(255,194,69,.58)!important}
.store-dashboard .dashboard-stat:nth-child(4){background:linear-gradient(135deg,rgba(73,28,104,.52),rgba(19,17,47,.97))!important;border:1px solid rgba(182,90,255,.62)!important}
.store-dashboard .dashboard-quick{background:radial-gradient(ellipse at 0% 0%,rgba(25,204,255,.08),transparent 48%),linear-gradient(145deg,rgba(16,19,47,.98),rgba(24,10,38,.98))!important;border:1px solid rgba(111,115,255,.72)!important;box-shadow:0 0 24px rgba(100,74,255,.1),inset 0 1px 0 rgba(255,255,255,.05)!important}
.store-dashboard .dashboard-actions a[href="my-keys.php"]{background:linear-gradient(115deg,#00a878,#064f4d)!important;border-color:#35f2b7!important}
.store-dashboard .dashboard-actions a[href="deposit.php"]{background:linear-gradient(115deg,#078fe9,#183c9c)!important;border-color:#35d8ff!important}
.store-dashboard .dashboard-actions a[href="history.php"]{background:linear-gradient(115deg,#b87912,#71330f)!important;border-color:#ffc24e!important}
.store-dashboard .dashboard-actions a[href="profile.php"]{background:linear-gradient(115deg,#a000cf,#59158b)!important;border-color:#ed62ff!important}
.store-dashboard .dashboard-actions .qa-image-icon,
.store-dashboard .dashboard-actions .xt-wallet-add-icon{width:46px!important;height:46px!important;min-width:46px!important;min-height:46px!important;flex-basis:46px!important;display:inline-flex!important;align-items:center!important;justify-content:center!important}
.store-dashboard .dashboard-actions .qa-image-icon img,
.store-dashboard .dashboard-actions .xt-wallet-add-icon img{width:44px!important;height:44px!important;max-width:44px!important;max-height:44px!important;object-fit:contain!important;display:block!important;visibility:visible!important;opacity:1!important}
.store-dashboard .dashboard-actions .qa-label{font-size:clamp(13px,3.6vw,17px)!important;font-weight:950!important;line-height:1.22!important}
.store-dashboard .dashboard-actions .qa-arrow{width:31px!important;height:31px!important;min-width:31px!important;border:2px solid rgba(255,255,255,.94)!important;border-radius:50%!important;display:inline-flex!important;align-items:center!important;justify-content:center!important;color:#fff!important}
@media(max-width:600px){.store-dashboard .dashboard-actions .qa-image-icon,.store-dashboard .dashboard-actions .xt-wallet-add-icon{width:40px!important;height:40px!important;min-width:40px!important;min-height:40px!important;flex-basis:40px!important}.store-dashboard .dashboard-actions .qa-image-icon img,.store-dashboard .dashboard-actions .xt-wallet-add-icon img{width:39px!important;height:39px!important;max-width:39px!important;max-height:39px!important}}

/* V16 true fix: target the actual dashboard balance and top-up pseudo-icons, after all legacy CSS. */
.store-dashboard .dashboard-balance{position:relative!important;padding-left:24px!important;}
.store-dashboard .dashboard-balance:before{content:""!important;display:block!important;position:absolute!important;left:24px!important;top:72px!important;width:76px!important;height:62px!important;margin:0!important;float:none!important;font-size:0!important;line-height:0!important;background-image:url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='100' height='82' viewBox='0 0 100 82'%3E%3Cdefs%3E%3ClinearGradient id='c' x1='0' y1='0' x2='0' y2='1'%3E%3Cstop stop-color='%23fff18b'/%3E%3Cstop offset='1' stop-color='%23f4a900'/%3E%3C/linearGradient%3E%3ClinearGradient id='b' x1='0' y1='0' x2='1' y2='1'%3E%3Cstop stop-color='%2300e6ff'/%3E%3Cstop offset='1' stop-color='%23005cff'/%3E%3C/linearGradient%3E%3C/defs%3E%3Ccircle cx='31' cy='23' r='17' fill='url(%23c)' stroke='%23fff19a' stroke-width='2'/%3E%3Ccircle cx='52' cy='25' r='17' fill='url(%23c)' stroke='%23ffd84a' stroke-width='2'/%3E%3Cpath d='M10 37 Q10 32 16 32 H67 Q73 32 73 38 V43 H83 Q91 43 91 51 V61 Q91 68 83 68 H72 V74 H17 Q10 74 10 67 Z' fill='url(%23b)' stroke='%2349eaff' stroke-width='3'/%3E%3Cpath d='M72 46 H84 Q91 46 91 53 V59 Q91 65 84 65 H72' fill='%230b8cff' stroke='%2349eaff' stroke-width='3'/%3E%3Ccircle cx='81' cy='55' r='3' fill='%23b7ffff'/%3E%3C/svg%3E")!important;background-position:center!important;background-size:contain!important;background-repeat:no-repeat!important;filter:drop-shadow(0 0 8px rgba(0,205,255,.55))!important;z-index:4!important;}

.store-dashboard .dashboard-topup:before{content:""!important;display:inline-block!important;flex:0 0 40px!important;width:40px!important;height:34px!important;min-width:40px!important;max-width:40px!important;margin:0 9px 0 0!important;padding:0!important;font-size:0!important;line-height:0!important;background-image:url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='100' height='82' viewBox='0 0 100 82'%3E%3Cdefs%3E%3ClinearGradient id='w' x1='0' y1='0' x2='1' y2='1'%3E%3Cstop stop-color='%2300e9ff'/%3E%3Cstop offset='1' stop-color='%23004dff'/%3E%3C/linearGradient%3E%3C/defs%3E%3Cpath d='M13 28 L34 13 H68 Q73 13 73 19 V26 H22 Q13 26 13 35 V62 Q13 69 21 69 H75 V57 H83 V72 H21 Q8 72 8 60 V38 Q8 30 13 28Z' fill='url(%23w)' stroke='%234ceaff' stroke-width='3'/%3E%3Cpath d='M20 31 H80 Q87 31 87 38 V57 Q87 63 80 63 H23 Q17 63 17 56 V38 Q17 31 20 31Z' fill='url(%23w)' stroke='%234ceaff' stroke-width='3'/%3E%3Cpath d='M77 42 H89 Q95 42 95 48 V52 Q95 58 89 58 H77' fill='%23006dff' stroke='%234ceaff' stroke-width='3'/%3E%3Ccircle cx='85' cy='50' r='3' fill='%23d4ffff'/%3E%3Ccircle cx='74' cy='15' r='13' fill='%23f8fbff' stroke='%234ceaff' stroke-width='3'/%3E%3Cpath d='M74 8 V22 M67 15 H81' stroke='%234f55ff' stroke-width='4' stroke-linecap='round'/%3E%3C/svg%3E")!important;background-position:center!important;background-size:contain!important;background-repeat:no-repeat!important;border:0!important;border-radius:0!important;box-shadow:none!important;filter:drop-shadow(0 0 7px rgba(0,205,255,.5))!important;vertical-align:middle!important;}
.store-dashboard .dashboard-topup{display:inline-flex!important;align-items:center!important;justify-content:center!important;gap:6px!important;}
@media(max-width:600px){.store-dashboard .dashboard-balance:before{left:15px!important;top:53px!important;width:55px!important;height:47px!important}.store-dashboard .dashboard-balance-value{margin-left:62px!important}.store-dashboard .dashboard-topup:before{flex-basis:30px!important;width:30px!important;height:28px!important;min-width:30px!important;max-width:30px!important;margin-right:5px!important}}
@media(max-width:380px){.store-dashboard .dashboard-balance:before{left:11px!important;top:51px!important;width:45px!important;height:39px!important}.store-dashboard .dashboard-balance-value{margin-left:51px!important}}

/* V18: Use the exact same cyan wallet icon in both Dashboard and Store balance/Add Funds areas. */
.store-dashboard .dashboard-balance:before{
 content:""!important;display:block!important;position:absolute!important;
 left:24px!important;top:54px!important;width:68px!important;height:58px!important;
 margin:0!important;float:none!important;font-size:0!important;line-height:0!important;
 background:url("assets/nav-icons/wallet-cyan-reference.png?v=18") center/contain no-repeat!important;
 filter:drop-shadow(0 0 8px rgba(0,205,255,.55))!important;z-index:4!important;
}
.store-dashboard .dashboard-balance-value{position:relative!important;z-index:5!important;margin-left:82px!important}
.store-dashboard .dashboard-actions a[href*="deposit.php"] .xt-wallet-add-icon,
.store-dashboard .dashboard-actions a[href*="deposit.php"] .qa-icon{
 display:inline-flex!important;align-items:center!important;justify-content:center!important;
 width:46px!important;height:46px!important;min-width:46px!important;min-height:46px!important;
 flex:0 0 46px!important;background:url("assets/nav-icons/wallet-cyan-reference.png?v=18") center/contain no-repeat!important;
 background-color:transparent!important;border:0!important;border-radius:0!important;box-shadow:none!important;
 font-size:0!important;line-height:0!important;filter:drop-shadow(0 0 7px rgba(0,205,255,.42))!important;
}

.store-dashboard .dashboard-topup:before{
 content:""!important;display:inline-block!important;flex:0 0 40px!important;width:40px!important;height:34px!important;
 min-width:40px!important;max-width:40px!important;margin:0 9px 0 0!important;padding:0!important;
 background:url("assets/nav-icons/wallet-cyan-reference.png?v=18") center/contain no-repeat!important;
 border:0!important;border-radius:0!important;box-shadow:none!important;font-size:0!important;line-height:0!important;
 filter:drop-shadow(0 0 7px rgba(0,205,255,.5))!important;vertical-align:middle!important;
}
@media(max-width:600px){
 .store-dashboard .dashboard-balance:before{left:15px!important;top:53px!important;width:52px!important;height:45px!important}
 .store-dashboard .dashboard-balance-value{margin-left:62px!important}
 .store-dashboard .dashboard-actions a[href*="deposit.php"] .xt-wallet-add-icon,
 .store-dashboard .dashboard-actions a[href*="deposit.php"] .qa-icon{width:39px!important;height:39px!important;min-width:39px!important;min-height:39px!important;flex-basis:39px!important}
 .store-dashboard .dashboard-topup:before{flex-basis:30px!important;width:30px!important;height:28px!important;min-width:30px!important;max-width:30px!important;margin-right:5px!important}
}
@media(max-width:380px){
 .store-dashboard .dashboard-balance:before{left:11px!important;top:51px!important;width:43px!important;height:38px!important}
 .store-dashboard .dashboard-balance-value{margin-left:51px!important}
 .store-dashboard .dashboard-actions a[href*="deposit.php"] .xt-wallet-add-icon,
 .store-dashboard .dashboard-actions a[href*="deposit.php"] .qa-icon{width:32px!important;height:32px!important;min-width:32px!important;min-height:32px!important;flex-basis:32px!important}
}
</style>
<style id="xtreme-dashboard-balance-fit-v19-from-v18">
/* V19 based directly on the original V18 archive. Keep this final block after legacy overrides. */
.store-dashboard .dashboard-balance{position:relative!important;min-width:0!important;}
.store-dashboard .dashboard-balance:before{
  content:""!important;display:block!important;position:absolute!important;
  left:18px!important;top:34px!important;width:88px!important;height:76px!important;
  margin:0!important;float:none!important;font-size:0!important;line-height:0!important;
  background-image:url("assets/nav-icons/wallet-cyan-reference.png?v=19")!important;
  background-position:center!important;background-size:contain!important;background-repeat:no-repeat!important;
  filter:drop-shadow(0 0 9px rgba(0,205,255,.58))!important;z-index:4!important;
}
.store-dashboard .dashboard-balance-value{
  position:relative!important;z-index:5!important;margin-left:96px!important;
  min-width:0!important;max-width:100%!important;white-space:nowrap!important;
  overflow-wrap:normal!important;word-break:normal!important;
  font-size:clamp(21px,5.8vw,37px)!important;line-height:1.08!important;
  letter-spacing:-.045em!important;font-weight:1000!important;
}
.store-dashboard .dashboard-topup{
  min-width:0!important;max-width:168px!important;padding:0 10px!important;
  gap:4px!important;font-size:clamp(10px,2.7vw,13px)!important;
  letter-spacing:0!important;white-space:nowrap!important;justify-self:end!important;
  overflow:hidden!important;
}
.store-dashboard .dashboard-topup:before{
  content:""!important;display:inline-block!important;flex:0 0 25px!important;
  width:25px!important;height:25px!important;min-width:25px!important;max-width:25px!important;
  margin:0 3px 0 0!important;padding:0!important;
  background:url("assets/nav-icons/wallet-cyan-reference.png?v=19") center/contain no-repeat!important;
  border:0!important;border-radius:0!important;box-shadow:none!important;
}
.store-dashboard .dashboard-actions a[href*="deposit.php"] .xt-wallet-add-icon,
.store-dashboard .dashboard-actions a[href*="deposit.php"] .qa-icon{
  display:inline-flex!important;align-items:center!important;justify-content:center!important;
  width:50px!important;height:48px!important;min-width:50px!important;min-height:48px!important;
  flex:0 0 50px!important;background:transparent!important;background-image:none!important;
}
.store-dashboard .dashboard-actions a[href*="deposit.php"] .xt-wallet-add-icon:before,
.store-dashboard .dashboard-actions a[href*="deposit.php"] .qa-icon:before{
  content:""!important;display:block!important;width:50px!important;height:48px!important;
  background:url("assets/nav-icons/wallet-cyan-reference.png?v=19") center/contain no-repeat!important;
  filter:drop-shadow(0 0 7px rgba(0,205,255,.48))!important;
}
.store-dashboard .dashboard-actions a[href*="deposit.php"] .xt-wallet-add-icon img,
.store-dashboard .dashboard-actions a[href*="deposit.php"] .qa-icon img{display:none!important}
@media(max-width:600px){
  .store-dashboard .dashboard-balance{grid-template-columns:minmax(0,1fr) auto!important;padding-left:12px!important;padding-right:10px!important;column-gap:7px!important}
  .store-dashboard .dashboard-balance:before{left:10px!important;top:34px!important;width:70px!important;height:62px!important}
  .store-dashboard .dashboard-balance-value{margin-left:72px!important;font-size:clamp(20px,5.5vw,29px)!important;letter-spacing:-.05em!important}
  .store-dashboard .dashboard-topup{max-width:138px!important;padding:0 7px!important;font-size:10px!important;min-height:42px!important;gap:3px!important}
  .store-dashboard .dashboard-topup:before{flex-basis:22px!important;width:22px!important;height:22px!important;min-width:22px!important;max-width:22px!important;margin-right:1px!important}
  .store-dashboard .dashboard-actions a[href*="deposit.php"] .xt-wallet-add-icon,
  .store-dashboard .dashboard-actions a[href*="deposit.php"] .qa-icon{width:48px!important;height:46px!important;min-width:48px!important;min-height:46px!important;flex-basis:48px!important}
  .store-dashboard .dashboard-actions a[href*="deposit.php"] .xt-wallet-add-icon:before,
  .store-dashboard .dashboard-actions a[href*="deposit.php"] .qa-icon:before{width:48px!important;height:46px!important}
}
@media(max-width:390px){
  .store-dashboard .dashboard-balance:before{left:8px!important;top:35px!important;width:62px!important;height:55px!important}
  .store-dashboard .dashboard-balance-value{margin-left:63px!important;font-size:clamp(18px,5.1vw,23px)!important;letter-spacing:-.055em!important}
  .store-dashboard .dashboard-topup{max-width:122px!important;padding:0 5px!important;font-size:9px!important}
  .store-dashboard .dashboard-topup:before{flex-basis:19px!important;width:19px!important;height:20px!important;min-width:19px!important;max-width:19px!important;margin-right:1px!important}
}
</style>
<style id="xtreme-v21-dashboard-polish">
/* V21: Use the supplied purple diamond logo for the Active Key dashboard stat. */
.store-dashboard .dashboard-stat:nth-child(4)::before,
html[data-theme] .store-dashboard .dashboard-stat:nth-child(4)::before{
  content:""!important;
  width:44px!important;height:44px!important;min-width:44px!important;
  background-image:url("assets/nav-icons/active-key-diamond.png?v=21")!important;
  background-position:center!important;background-repeat:no-repeat!important;
  background-size:contain!important;background-color:transparent!important;
  border:0!important;border-radius:0!important;box-shadow:none!important;
  filter:drop-shadow(0 0 7px rgba(151,70,255,.25))!important;
}
/* Keep the four Quick Access buttons premium, but lighter and less saturated/dark. */
.store-dashboard .dashboard-actions a,
html[data-theme] .store-dashboard .dashboard-actions a{
  box-shadow:inset 0 1px 0 rgba(255,255,255,.16),0 5px 14px rgba(0,0,0,.10)!important;
  border-width:1px!important;
}
.store-dashboard .dashboard-actions a:nth-child(1),
html[data-theme] .store-dashboard .dashboard-actions a:nth-child(1){
  background:linear-gradient(135deg,rgba(16,185,129,.42),rgba(20,145,112,.30))!important;
  border-color:rgba(52,211,153,.78)!important;
}
.store-dashboard .dashboard-actions a:nth-child(2),
html[data-theme] .store-dashboard .dashboard-actions a:nth-child(2){
  background:linear-gradient(135deg,rgba(14,165,233,.42),rgba(37,99,235,.32))!important;
  border-color:rgba(56,189,248,.78)!important;
}
.store-dashboard .dashboard-actions a:nth-child(3),
html[data-theme] .store-dashboard .dashboard-actions a:nth-child(3){
  background:linear-gradient(135deg,rgba(245,158,11,.40),rgba(217,119,6,.30))!important;
  border-color:rgba(251,191,36,.78)!important;
}
.store-dashboard .dashboard-actions a:nth-child(4),
html[data-theme] .store-dashboard .dashboard-actions a:nth-child(4){
  background:linear-gradient(135deg,rgba(168,85,247,.42),rgba(147,51,234,.32))!important;
  border-color:rgba(216,180,254,.76)!important;
}
.store-dashboard .dashboard-actions a .qa-label{color:#f8faff!important}
</style>
<style id="xtreme-v22-active-key-icon-sizing">
/* V22: Make the supplied Active Key diamond smaller and give its label/count breathing room. */
.store-dashboard .dashboard-stat:nth-child(4)::before,
html[data-theme] .store-dashboard .dashboard-stat:nth-child(4)::before{
  width:34px!important;height:34px!important;min-width:34px!important;
  background-size:contain!important;
}
.store-dashboard .dashboard-stat:nth-child(4),
html[data-theme] .store-dashboard .dashboard-stat:nth-child(4){
  padding-left:70px!important;
}
@media(max-width:600px){
  .store-dashboard .dashboard-stat:nth-child(4)::before,
  html[data-theme] .store-dashboard .dashboard-stat:nth-child(4)::before{
    width:31px!important;height:31px!important;min-width:31px!important;
  }
  .store-dashboard .dashboard-stat:nth-child(4),
  html[data-theme] .store-dashboard .dashboard-stat:nth-child(4){padding-left:61px!important}
}
@media(max-width:390px){
  .store-dashboard .dashboard-stat:nth-child(4),
  html[data-theme] .store-dashboard .dashboard-stat:nth-child(4){padding-left:57px!important}
}
</style>
<style id="xtreme-v23-active-key-icon-slightly-larger">
.store-dashboard .dashboard-stat:nth-child(4)::before,html[data-theme] .store-dashboard .dashboard-stat:nth-child(4)::before{width:39px!important;height:39px!important;min-width:39px!important;background-size:contain!important}
.store-dashboard .dashboard-stat:nth-child(4),html[data-theme] .store-dashboard .dashboard-stat:nth-child(4){padding-left:73px!important}
@media(max-width:600px){.store-dashboard .dashboard-stat:nth-child(4)::before,html[data-theme] .store-dashboard .dashboard-stat:nth-child(4)::before{width:36px!important;height:36px!important;min-width:36px!important}.store-dashboard .dashboard-stat:nth-child(4),html[data-theme] .store-dashboard .dashboard-stat:nth-child(4){padding-left:65px!important}}
@media(max-width:390px){.store-dashboard .dashboard-stat:nth-child(4),html[data-theme] .store-dashboard .dashboard-stat:nth-child(4){padding-left:61px!important}}
</style>
<style id="xtreme-store-topup-category-compact-v1">
/* Compact 3-column category tiles: five/six categories naturally wrap into two rows.
   Scoped only to the Gaming Top-Up category cards; history and bottom navigation are untouched. */
section.xt-topup-entry .xt-topup-tiles{
  display:grid!important;
  grid-template-columns:repeat(3,minmax(0,1fr))!important;
  gap:8px!important;
  align-items:stretch!important;
}
section.xt-topup-entry .xt-topup-tiles>a,
section.xt-topup-entry .xt-topup-tiles>a:link,
section.xt-topup-entry .xt-topup-tiles>a:visited{
  box-sizing:border-box!important;
  width:100%!important;
  min-width:0!important;
  min-height:72px!important;
  height:auto!important;
  padding:8px 5px!important;
  gap:5px!important;
  border-radius:15px!important;
  display:flex!important;
  flex-direction:column!important;
  align-items:center!important;
  justify-content:center!important;
  text-align:center!important;
  text-decoration:none!important;
  line-height:1.15!important;
}
section.xt-topup-entry .xt-topup-tiles>a span{
  width:29px!important;
  height:29px!important;
  min-width:29px!important;
  border-radius:10px!important;
  font-size:18px!important;
  line-height:1!important;
}
section.xt-topup-entry .xt-topup-tiles>a b{
  display:block!important;
  max-width:100%!important;
  font-size:clamp(9px,2.6vw,11px)!important;
  line-height:1.2!important;
  font-weight:900!important;
  white-space:normal!important;
  overflow-wrap:anywhere!important;
  word-break:normal!important;
  text-decoration:none!important;
}
@media(min-width:700px){
  section.xt-topup-entry .xt-topup-tiles{grid-template-columns:repeat(3,minmax(0,1fr))!important;gap:10px!important}
  section.xt-topup-entry .xt-topup-tiles>a{min-height:78px!important}
}
@media(max-width:360px){
  section.xt-topup-entry .xt-topup-tiles{gap:6px!important}
  section.xt-topup-entry .xt-topup-tiles>a{min-height:68px!important;padding:7px 3px!important}
  section.xt-topup-entry .xt-topup-tiles>a b{font-size:9px!important}
}
</style>
<style id="xtreme-topup-explore-full-width-v1">
.xt-topup-entry .xt-topup-head{display:flex!important;flex-direction:column!important;align-items:stretch!important;gap:12px!important}
.xt-topup-entry .xt-topup-head>div{width:100%!important;min-width:0!important}
.xt-topup-entry .xt-topup-head>a{display:flex!important;width:100%!important;min-height:48px!important;box-sizing:border-box!important;align-self:stretch!important;text-align:center!important;justify-content:center!important;text-decoration:none!important}
</style>
<style id="xtreme-balance-topup-stable-v1">
/* Stable first-paint layout for the balance / Add Funds card.
   Scoped only to the balance card; no other dashboard controls are changed. */
.store-dashboard .dashboard-balance{
  display:grid!important;
  grid-template-columns:minmax(0,1fr) minmax(170px,32%)!important;
  grid-template-rows:auto auto!important;
  grid-template-areas:"label label" "value action"!important;
  align-items:center!important;
  column-gap:18px!important;
  row-gap:18px!important;
  min-height:180px!important;
  padding:22px 24px!important;
  box-sizing:border-box!important;
  overflow:hidden!important;
  transition:none!important;
  animation:none!important;
}
.store-dashboard .dashboard-balance>.dashboard-label{
  grid-area:label!important;
  display:block!important;
  position:static!important;
  margin:0!important;
  min-height:20px!important;
  line-height:1.3!important;
  font-size:clamp(13px,2vw,18px)!important;
  transform:none!important;
  transition:none!important;
  animation:none!important;
}
.store-dashboard .dashboard-balance>.dashboard-balance-value{
  grid-area:value!important;
  display:flex!important;
  align-items:center!important;
  justify-self:start!important;
  position:relative!important;
  min-width:0!important;
  max-width:100%!important;
  min-height:76px!important;
  margin:0!important;
  padding:0 0 0 88px!important;
  box-sizing:border-box!important;
  white-space:nowrap!important;
  overflow:visible!important;
  font-size:clamp(27px,4.5vw,46px)!important;
  line-height:1.12!important;
  letter-spacing:-.035em!important;
  transform:none!important;
  transition:none!important;
  animation:none!important;
}
.store-dashboard .dashboard-balance>.dashboard-balance-value:before{
  content:""!important;
  display:block!important;
  position:absolute!important;
  left:0!important;
  top:50%!important;
  width:70px!important;
  height:66px!important;
  min-width:70px!important;
  margin:0!important;
  transform:translateY(-50%)!important;
  background:url("assets/nav-icons/wallet-cyan-reference.png?v=19") center/contain no-repeat!important;
  filter:drop-shadow(0 0 7px rgba(0,205,255,.45))!important;
}
.store-dashboard .dashboard-balance>.dashboard-topup{
  grid-area:action!important;
  display:inline-flex!important;
  align-items:center!important;
  justify-content:center!important;
  justify-self:stretch!important;
  align-self:center!important;
  width:100%!important;
  min-width:0!important;
  max-width:none!important;
  min-height:62px!important;
  height:62px!important;
  margin:0!important;
  padding:0 16px!important;
  box-sizing:border-box!important;
  border-radius:18px!important;
  font-family:inherit!important;
  font-size:clamp(13px,1.8vw,18px)!important;
  line-height:1.2!important;
  font-weight:900!important;
  white-space:nowrap!important;
  overflow:hidden!important;
  text-overflow:ellipsis!important;
  transform:none!important;
  transition:none!important;
  animation:none!important;
}
.store-dashboard .dashboard-balance>.dashboard-topup:before{
  content:"＋"!important;
  display:inline-flex!important;
  flex:0 0 30px!important;
  align-items:center!important;
  justify-content:center!important;
  width:30px!important;
  height:30px!important;
  min-width:30px!important;
  max-width:30px!important;
  margin:0 8px 0 0!important;
  background:#fff!important;
  color:#6553dc!important;
  border-radius:50%!important;
  font-size:23px!important;
  line-height:1!important;
  filter:none!important;
}
.store-dashboard .dashboard-balance>.dashboard-topup:hover,
.store-dashboard .dashboard-balance>.dashboard-topup:active,
.store-dashboard .dashboard-balance>.dashboard-topup:focus{
  transform:none!important;
  transition:none!important;
  animation:none!important;
}
.store-dashboard .dashboard-balance>.xt-addfunds-banner{
  grid-column:1/-1!important;
}
@media(max-width:600px){
  .store-dashboard .dashboard-balance{
    grid-template-columns:minmax(0,1fr) minmax(138px,44%)!important;
    grid-template-rows:auto auto!important;
    column-gap:8px!important;
    row-gap:13px!important;
    min-height:154px!important;
    padding:16px 13px!important;
    border-radius:20px!important;
  }
  .store-dashboard .dashboard-balance>.dashboard-label{
    font-size:14px!important;
  }
  .store-dashboard .dashboard-balance>.dashboard-balance-value{
    min-height:62px!important;
    padding-left:59px!important;
    font-size:clamp(21px,5.8vw,30px)!important;
    letter-spacing:-.045em!important;
  }
  .store-dashboard .dashboard-balance>.dashboard-balance-value:before{
    width:48px!important;
    height:46px!important;
    min-width:48px!important;
  }
  .store-dashboard .dashboard-balance>.dashboard-topup{
    min-height:52px!important;
    height:52px!important;
    padding:0 7px!important;
    border-radius:15px!important;
    font-size:clamp(10px,2.8vw,13px)!important;
    gap:4px!important;
  }
  .store-dashboard .dashboard-balance>.dashboard-topup:before{
    flex-basis:23px!important;
    width:23px!important;
    height:23px!important;
    min-width:23px!important;
    max-width:23px!important;
    margin-right:2px!important;
    font-size:18px!important;
  }
}
@media(max-width:360px){
  .store-dashboard .dashboard-balance{
    grid-template-columns:minmax(0,1fr) minmax(126px,43%)!important;
    padding-left:10px!important;
    padding-right:10px!important;
    column-gap:5px!important;
  }
  .store-dashboard .dashboard-balance>.dashboard-balance-value{
    padding-left:51px!important;
    font-size:20px!important;
  }
  .store-dashboard .dashboard-balance>.dashboard-balance-value:before{
    width:43px!important;height:41px!important;min-width:43px!important;
  }
  .store-dashboard .dashboard-balance>.dashboard-topup{
    font-size:10px!important;padding:0 4px!important;
  }
}
</style>
<style id="xt-balance-stable-first-paint-v40">
/* Stable first paint: one deterministic wallet icon and one aligned balance row. */
.store-dashboard .dashboard-balance{
  position:relative!important;
  display:grid!important;
  grid-template-columns:52px minmax(0,1fr) auto!important;
  grid-template-rows:auto auto auto!important;
  align-items:center!important;
  column-gap:12px!important;
  row-gap:12px!important;
  min-width:0!important;
  padding:20px 18px!important;
  overflow:hidden!important;
}
.store-dashboard .dashboard-balance>.dashboard-label{
  grid-column:1/-1!important;grid-row:1!important;
  margin:0!important;align-self:start!important;
}
.store-dashboard .dashboard-balance:before{
  content:""!important;display:block!important;position:static!important;
  grid-column:1!important;grid-row:2!important;
  width:48px!important;height:48px!important;margin:0!important;
  background-image:url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 64 64'%3E%3Cpath d='M9 15a5 5 0 0 1 5-5h35a5 5 0 0 1 5 5v5H14a5 5 0 0 0-5 5z' fill='none' stroke='%2367dfff' stroke-width='4' stroke-linejoin='round'/%3E%3Cpath d='M9 20h42a5 5 0 0 1 5 5v24a5 5 0 0 1-5 5H14a5 5 0 0 1-5-5z' fill='%230b1b35' stroke='%2367dfff' stroke-width='4' stroke-linejoin='round'/%3E%3Cpath d='M42 31h17v15H42a7.5 7.5 0 0 1 0-15z' fill='%230b1b35' stroke='%2367dfff' stroke-width='4'/%3E%3Ccircle cx='45' cy='38.5' r='2.5' fill='%2367dfff'/%3E%3C/svg%3E")!important;
  background-position:center!important;background-size:contain!important;background-repeat:no-repeat!important;
  transform:translateY(3px)!important;z-index:1!important;
}
.store-dashboard .dashboard-balance>.dashboard-balance-value{
  grid-column:2!important;grid-row:2!important;
  display:block!important;min-width:0!important;margin:0!important;padding:0!important;
  align-self:center!important;justify-self:start!important;
  font-size:clamp(25px,6.5vw,42px)!important;line-height:1.12!important;
  white-space:nowrap!important;overflow:visible!important;flex:none!important;
}
.store-dashboard .dashboard-balance>.dashboard-balance-value:before,
.store-dashboard .dashboard-balance>.dashboard-balance-value:after{content:none!important;display:none!important}
.store-dashboard .dashboard-balance>.dashboard-topup{
  grid-column:3!important;grid-row:2!important;
  position:relative!important;justify-self:end!important;align-self:center!important;
  display:inline-flex!important;align-items:center!important;justify-content:center!important;
  width:auto!important;max-width:100%!important;min-width:0!important;
  height:44px!important;min-height:44px!important;margin:0!important;
  padding:0 12px!important;white-space:nowrap!important;
  font-size:clamp(9px,2.7vw,13px)!important;line-height:1!important;
}
.store-dashboard .dashboard-balance>.xt-addfunds-banner{
  grid-column:1/-1!important;grid-row:3!important;width:100%!important;margin:0!important;
}
.store-dashboard .dashboard-balance:has(>.xt-addfunds-banner){
  grid-template-rows:auto auto auto!important;
}
@media(max-width:390px){
 .store-dashboard .dashboard-balance{grid-template-columns:42px minmax(0,1fr) auto!important;column-gap:8px!important;padding:18px 12px!important}
 .store-dashboard .dashboard-balance:before{width:40px!important;height:40px!important}
 .store-dashboard .dashboard-balance>.dashboard-balance-value{font-size:clamp(22px,6vw,28px)!important}
 .store-dashboard .dashboard-balance>.dashboard-topup{height:41px!important;min-height:41px!important;padding:0 8px!important;font-size:9px!important}
}
@media(max-width:350px){
 .store-dashboard .dashboard-balance{grid-template-columns:34px minmax(0,1fr) auto!important;column-gap:6px!important;padding-left:10px!important;padding-right:10px!important}
 .store-dashboard .dashboard-balance:before{width:34px!important;height:34px!important}
 .store-dashboard .dashboard-balance>.dashboard-balance-value{font-size:21px!important}
 .store-dashboard .dashboard-balance>.dashboard-topup{padding:0 6px!important;font-size:8px!important}
}
</style>
<style id="xt-balance-final-single-icon-no-overlap-v42">
/* Final Balance-only correction: keep the real linked image; remove all legacy pseudo wallet icons. */
.store-dashboard .dashboard-balance.xt-balance-restored:before,
.store-dashboard .dashboard-balance.xt-balance-restored:after,
.store-dashboard .dashboard-balance.xt-balance-restored>.dashboard-label:before,
.store-dashboard .dashboard-balance.xt-balance-restored>.dashboard-label:after,
.store-dashboard .dashboard-balance.xt-balance-restored>.xt-balance-row:before,
.store-dashboard .dashboard-balance.xt-balance-restored>.xt-balance-row:after,
.store-dashboard .dashboard-balance.xt-balance-restored .xt-balance-amount:before,
.store-dashboard .dashboard-balance.xt-balance-restored .xt-balance-amount:after,
.store-dashboard .dashboard-balance.xt-balance-restored .xt-balance-logo-link:before,
.store-dashboard .dashboard-balance.xt-balance-restored .xt-balance-logo-link:after {
  content:none!important;
  display:none!important;
  background:none!important;
  background-image:none!important;
}
.store-dashboard .dashboard-balance.xt-balance-restored {
  display:block!important;
  position:relative!important;
  min-width:0!important;
  box-sizing:border-box!important;
  overflow:hidden!important;
}
.store-dashboard .dashboard-balance.xt-balance-restored>.xt-balance-row {
  display:grid!important;
  grid-template-columns:44px minmax(0,1fr) minmax(112px,auto)!important;
  align-items:center!important;
  justify-content:initial!important;
  gap:clamp(7px,2vw,12px)!important;
  width:100%!important;
  min-width:0!important;
  margin:0!important;
  padding:0!important;
}
.store-dashboard .dashboard-balance.xt-balance-restored .xt-balance-logo-link {
  display:flex!important;
  position:static!important;
  align-items:center!important;
  justify-content:center!important;
  grid-column:1!important;
  grid-row:1!important;
  width:44px!important;
  height:44px!important;
  min-width:44px!important;
  max-width:44px!important;
  margin:0!important;
  padding:0!important;
  flex:none!important;
}
.store-dashboard .dashboard-balance.xt-balance-restored .xt-balance-logo-link>.xt-balance-logo {
  display:block!important;
  position:static!important;
  width:100%!important;
  height:100%!important;
  max-width:44px!important;
  max-height:44px!important;
  object-fit:contain!important;
  opacity:1!important;
  visibility:visible!important;
}
.store-dashboard .dashboard-balance.xt-balance-restored .xt-balance-amount {
  display:block!important;
  position:static!important;
  grid-column:2!important;
  grid-row:1!important;
  align-self:center!important;
  justify-self:stretch!important;
  min-width:0!important;
  max-width:100%!important;
  margin:0!important;
  padding:0!important;
  text-align:center!important;
  white-space:nowrap!important;
  overflow:hidden!important;
  text-overflow:clip!important;
  overflow-wrap:normal!important;
  word-break:normal!important;
  font-size:clamp(19px,5.3vw,30px)!important;
  line-height:1.15!important;
  letter-spacing:-.04em!important;
  font-weight:1000!important;
  transform:none!important;
}
.store-dashboard .dashboard-balance.xt-balance-restored .xt-balance-addfunds {
  display:inline-flex!important;
  position:static!important;
  grid-column:3!important;
  grid-row:1!important;
  align-items:center!important;
  justify-content:center!important;
  justify-self:end!important;
  width:100%!important;
  min-width:0!important;
  max-width:100%!important;
  min-height:44px!important;
  height:44px!important;
  margin:0!important;
  padding:0 8px!important;
  box-sizing:border-box!important;
  white-space:nowrap!important;
  overflow:hidden!important;
  text-overflow:ellipsis!important;
  font-size:clamp(9px,2.5vw,12px)!important;
  line-height:1.1!important;
  transform:none!important;
  animation:none!important;
}
.store-dashboard .dashboard-balance.xt-balance-restored .xt-balance-addfunds>span {
  display:inline-flex!important;
  flex:0 0 19px!important;
  align-items:center!important;
  justify-content:center!important;
  width:19px!important;
  height:19px!important;
  margin:0 4px 0 0!important;
  font-size:16px!important;
  line-height:1!important;
}
@media(max-width:390px) {
  .store-dashboard .dashboard-balance.xt-balance-restored {padding-left:12px!important;padding-right:12px!important}
  .store-dashboard .dashboard-balance.xt-balance-restored>.xt-balance-row {grid-template-columns:38px minmax(0,1fr) minmax(108px,auto)!important;gap:7px!important}
  .store-dashboard .dashboard-balance.xt-balance-restored .xt-balance-logo-link {width:38px!important;height:38px!important;min-width:38px!important;max-width:38px!important}
  .store-dashboard .dashboard-balance.xt-balance-restored .xt-balance-logo-link>.xt-balance-logo {max-width:38px!important;max-height:38px!important}
  .store-dashboard .dashboard-balance.xt-balance-restored .xt-balance-amount {font-size:clamp(18px,5vw,24px)!important;letter-spacing:-.045em!important}
  .store-dashboard .dashboard-balance.xt-balance-restored .xt-balance-addfunds {min-height:41px!important;height:41px!important;padding:0 6px!important;font-size:9px!important}
}
@media(max-width:350px) {
  .store-dashboard .dashboard-balance.xt-balance-restored>.xt-balance-row {grid-template-columns:34px minmax(0,1fr) minmax(100px,auto)!important;gap:5px!important}
  .store-dashboard .dashboard-balance.xt-balance-restored .xt-balance-logo-link {width:34px!important;height:34px!important;min-width:34px!important;max-width:34px!important}
  .store-dashboard .dashboard-balance.xt-balance-restored .xt-balance-logo-link>.xt-balance-logo {max-width:34px!important;max-height:34px!important}
  .store-dashboard .dashboard-balance.xt-balance-restored .xt-balance-amount {font-size:18px!important}
  .store-dashboard .dashboard-balance.xt-balance-restored .xt-balance-addfunds {font-size:8px!important;padding:0 4px!important}
}
</style>
<style id="xt-balance-amount-right-card-compact-v43">
/* Only adjust Balance amount position and remove excess card height. */
.store-dashboard .dashboard-balance.xt-balance-restored {
  min-height:0!important;
  height:auto!important;
  padding-top:16px!important;
  padding-bottom:14px!important;
  box-sizing:border-box!important;
}
.store-dashboard .dashboard-balance.xt-balance-restored>.dashboard-label {
  margin:0 0 10px!important;
}
.store-dashboard .dashboard-balance.xt-balance-restored>.xt-balance-row {
  min-height:44px!important;
}
.store-dashboard .dashboard-balance.xt-balance-restored .xt-balance-amount {
  text-align:left!important;
  padding-left:clamp(10px,2.8vw,20px)!important;
  justify-self:stretch!important;
}
@media(max-width:390px) {
  .store-dashboard .dashboard-balance.xt-balance-restored {
    padding-top:14px!important;
    padding-bottom:12px!important;
  }
  .store-dashboard .dashboard-balance.xt-balance-restored .xt-balance-amount {
    padding-left:10px!important;
  }
}
</style>
<style id="xt-balance-final-amount-plus-fix">
/* Final Balance-only adjustment: enlarge and nudge the amount right. */
.store-dashboard .dashboard-balance.xt-balance-restored .xt-balance-amount {
  font-size:clamp(27px,6.2vw,41px)!important;
  transform:translateX(clamp(7px,1.5vw,12px))!important;
  padding-left:0!important;
  line-height:1.12!important;
  white-space:nowrap!important;
}
/* Remove the extra pseudo plus; keep the existing HTML plus as one round icon. */
.store-dashboard .dashboard-balance.xt-balance-restored .xt-balance-addfunds::before,
.store-dashboard .dashboard-balance.xt-balance-restored .xt-balance-addfunds::after {
  content:none!important;
  display:none!important;
  background:none!important;
}
.store-dashboard .dashboard-balance.xt-balance-restored .xt-balance-addfunds>span {
  display:inline-flex!important;
  flex:0 0 22px!important;
  width:22px!important;
  min-width:22px!important;
  height:22px!important;
  align-items:center!important;
  justify-content:center!important;
  margin:0 6px 0 0!important;
  padding:0!important;
  border-radius:50%!important;
  background:#fff!important;
  color:#6850d8!important;
  font-size:18px!important;
  font-weight:1000!important;
  line-height:1!important;
}
@media(max-width:390px) {
  .store-dashboard .dashboard-balance.xt-balance-restored .xt-balance-amount {
    font-size:clamp(25px,6vw,36px)!important;
    transform:translateX(7px)!important;
  }
}
@media(max-width:350px) {
  .store-dashboard .dashboard-balance.xt-balance-restored .xt-balance-amount {
    font-size:24px!important;
    transform:translateX(5px)!important;
  }
  .store-dashboard .dashboard-balance.xt-balance-restored .xt-balance-addfunds>span {
    flex-basis:19px!important;width:19px!important;min-width:19px!important;height:19px!important;
    margin-right:4px!important;font-size:16px!important;
  }
}
</style>


<style>
      .xt-inline-media{position:relative;overflow:hidden;aspect-ratio:16/9;background:#000}
      .xt-inline-media .xt-inline-poster{width:100%;height:100%;object-fit:cover;display:block}
      .xt-inline-play{position:absolute;left:50%;top:50%;transform:translate(-50%,-50%);width:64px;height:64px;border-radius:50%;border:2px solid rgba(255,255,255,.9);background:rgba(0,0,0,.68);color:#fff;font-size:27px;display:flex;align-items:center;justify-content:center;cursor:pointer;box-shadow:0 0 24px rgba(0,220,255,.45)}
      .xt-inline-media video,.xt-inline-media iframe{position:absolute;inset:0;width:100%;height:100%;border:0;display:block;object-fit:contain;background:#000}
    </style>
<style>.xt-feature-cards{display:flex;flex-wrap:wrap;gap:8px;justify-content:center;margin:12px 0 15px}.xt-feature-card{display:inline-flex;align-items:center;justify-content:center;padding:9px 13px;border-radius:12px;border:1px solid rgba(34,211,238,.28);background:linear-gradient(135deg,rgba(8,45,61,.94),rgba(17,35,54,.96));color:#50c9ff;font-weight:800;font-size:13px;text-align:center;max-width:100%;overflow-wrap:anywhere;box-shadow:inset 0 1px rgba(255,255,255,.05)}</style>
<style id="consolidated-mobile-repair">html{max-width:100%;overflow-x:clip}body{max-width:100%;overflow-x:clip}*,*::before,*::after{box-sizing:border-box}img,video,iframe,canvas,svg{max-width:100%}input,select,textarea,button{max-width:100%;font:inherit}.container,.wrap,.panel,.card,.product,.product-card,.payment-box,.payment-methods,.premium-methods{min-width:0;max-width:100%}.product,.product-card{overflow-wrap:anywhere}.product img,.product-media{object-fit:contain;max-width:100%}premium-methods .premium-method{grid-template-columns:minmax(46px,58px) minmax(0,1fr)!important;grid-template-rows:auto auto!important;min-height:82px!important;overflow:visible!important}.premium-method .payment-logo{grid-column:1;grid-row:1/3;width:48px!important;height:42px!important;object-fit:cover!important}.premium-method .method-name,.premium-method .method-note{min-width:0;white-space:normal!important;overflow-wrap:anywhere}@media(max-width:420px){.premium-methods .premium-method{padding:10px!important;gap:5px 8px!important}.premium-method .method-name{font-size:13px!important}.premium-method .method-note{font-size:10px!important}.container,.wrap{padding-left:10px!important;padding-right:10px!important}}</style>
<style id="xt-premium-product-presentation">
/* XTREME TITAN product presentation: neon poster, readable details, clean plan selection. */
.product{position:relative!important;isolation:isolate!important;overflow:hidden!important;border:1px solid rgba(76,213,255,.24)!important;border-radius:25px!important;padding:14px!important;margin:18px 0!important;background:linear-gradient(145deg,rgba(11,18,33,.98),rgba(8,12,24,.98))!important;box-shadow:0 16px 46px rgba(0,0,0,.28),inset 0 1px 0 rgba(255,255,255,.045)!important}
.product:before{content:"";position:absolute;inset:0 0 auto;height:3px;background:linear-gradient(90deg,#12d8ff,#a855f7,#ff35d3,#12d8ff);background-size:220% 100%;animation:xt-product-edge 7s linear infinite;pointer-events:none;z-index:0}
.product>*{position:relative;z-index:1;min-width:0}
.product-image{width:100%!important;max-width:100%!important;aspect-ratio:16/9!important;min-height:0!important;max-height:none!important;display:flex!important;align-items:center!important;justify-content:center!important;overflow:hidden!important;border-radius:18px!important;background:radial-gradient(circle at 50% 0%,rgba(136,40,255,.18),transparent 55%),#080b15!important;border:1px solid rgba(190,100,255,.28)!important;box-shadow:0 0 24px rgba(124,58,237,.12)!important}
.product-image .product-media,.product-image img,.product-image video,.product-image iframe{display:block!important;width:100%!important;height:100%!important;max-width:100%!important;max-height:100%!important;aspect-ratio:16/9!important;object-fit:cover!important;border:0!important;border-radius:0!important}
.product-name{font-size:clamp(20px,5vw,28px)!important;line-height:1.18!important;font-weight:950!important;letter-spacing:.025em!important;overflow-wrap:anywhere!important;margin:18px 2px 10px!important;color:#f7f9ff!important;text-shadow:0 0 18px rgba(147,51,234,.22)!important}
.product-badges{display:flex!important;flex-wrap:wrap!important;gap:7px!important;margin:8px 0 13px!important}
.product-badge{max-width:100%!important;border-radius:999px!important;padding:6px 10px!important;font-size:10px!important;line-height:1.2!important;font-weight:900!important;letter-spacing:.06em!important;overflow-wrap:anywhere!important}
.product-description{white-space:pre-line!important;overflow-wrap:anywhere!important;line-height:1.65!important;color:#d5dfef!important;font-size:14px!important;background:linear-gradient(135deg,rgba(12,28,45,.85),rgba(15,18,36,.75))!important;border:1px solid rgba(34,211,238,.18)!important;border-radius:16px!important;padding:14px!important;margin:12px 0 15px!important}
.product-action-row{display:grid!important;grid-template-columns:repeat(2,minmax(0,1fr))!important;gap:9px!important;margin:12px 0 16px!important}
.product-action-row .product-action{width:100%!important;min-width:0!important;min-height:44px!important;padding:10px 8px!important;text-align:center!important;white-space:normal!important;overflow-wrap:anywhere!important;border-radius:13px!important;border:1px solid rgba(34,211,238,.25)!important;background:rgba(8,31,47,.8)!important;color:#67d8ff!important;font-size:12px!important;font-weight:850!important;line-height:1.3!important}
.product-action-row .product-action.disabled{opacity:.55!important}
.product-extra-video{margin:12px 0!important;border:1px solid rgba(168,85,247,.35)!important;box-shadow:0 8px 25px rgba(0,0,0,.22)!important}
.product-extra-video video,.product-extra-video iframe{width:100%!important;max-width:100%!important;aspect-ratio:16/9!important;max-height:320px!important;object-fit:cover!important;border:0!important}
.plan-list{display:grid!important;grid-template-columns:minmax(0,1fr)!important;gap:10px!important;margin:14px 0!important}
.plan{min-width:0!important;border:1px solid rgba(66,190,255,.25)!important;border-radius:16px!important;background:linear-gradient(110deg,rgba(11,29,47,.98),rgba(21,17,40,.98))!important;padding:13px!important;transition:border-color .18s ease,box-shadow .18s ease,transform .18s ease!important}
.plan:focus,.plan:hover,.plan.selected{border-color:#20d9ff!important;box-shadow:0 0 0 2px rgba(32,217,255,.12),0 10px 28px rgba(0,0,0,.2)!important;outline:none!important}
.plan-row{display:grid!important;grid-template-columns:auto minmax(0,1fr) auto!important;align-items:center!important;gap:9px!important}
.plan-duration{min-width:0!important;overflow-wrap:anywhere!important;font-weight:850!important;color:#f4f7ff!important}
.plan-price{font-size:clamp(16px,4vw,21px)!important;font-weight:950!important;color:#55e7b0!important;white-space:nowrap!important}
.plan-stock{margin-top:7px!important;color:#9caec5!important;font-size:12px!important;line-height:1.45!important}
.product .buy-btn,.product .product-action.buy-btn{width:100%!important;min-height:58px!important;margin-top:12px!important;border-radius:16px!important;background:linear-gradient(100deg,#08b9ec,#377cf5,#13c9a2)!important;color:#fff!important;font-size:17px!important;letter-spacing:.06em!important;font-weight:950!important;box-shadow:0 12px 30px rgba(13,174,226,.22)!important}
@keyframes xt-product-edge{from{background-position:0 0}to{background-position:220% 0}}
@media(max-width:480px){.product{padding:10px!important;border-radius:21px!important}.product-image{border-radius:15px!important}.product-description{font-size:13px!important;padding:12px!important}.product-action-row{gap:7px!important}.product-action-row .product-action{font-size:11px!important}.plan{padding:11px!important}.plan-row{grid-template-columns:auto minmax(0,1fr) auto!important;gap:7px!important}}
@media(prefers-reduced-motion:reduce){.product:before{animation:none!important}}
</style>
<style id="xt-dashboard-neon-final-v34">
/* Dashboard visual-only corrections: preserve links, balance and warning logic. */
.store-dashboard{max-width:920px!important;margin:0 auto!important;padding:12px 10px 100px!important;color:#f5f4ff!important}
.store-dashboard .dashboard-balance{position:relative!important;overflow:hidden!important;padding:18px 16px 16px!important;border:1.5px solid rgba(255,49,177,.82)!important;border-radius:23px!important;background:radial-gradient(ellipse at 92% 12%,rgba(30,87,255,.16),transparent 43%),linear-gradient(145deg,rgba(11,16,42,.98),rgba(29,13,45,.98))!important;box-shadow:0 0 0 1px rgba(255,42,172,.12),0 0 24px rgba(239,40,180,.14),inset 0 1px 0 rgba(255,255,255,.07)!important}
.store-dashboard .dashboard-balance:before{content:"👛"!important;float:left!important;font-size:44px!important;line-height:1.15!important;margin:22px 14px 8px 0!important;filter:drop-shadow(0 0 11px rgba(0,190,255,.48))!important}
.store-dashboard .dashboard-label{color:#b9c5ff!important;font-size:12px!important;letter-spacing:.14em!important;font-weight:900!important}
.store-dashboard .dashboard-balance-value{color:#43f2bd!important;font-size:clamp(32px,8vw,46px)!important;font-weight:1000!important;line-height:1.12!important;text-shadow:0 0 22px rgba(57,229,177,.25)!important;margin:8px 0 14px!important}
.store-dashboard .dashboard-topup{display:inline-flex!important;align-items:center!important;justify-content:center!important;min-height:44px!important;height:auto!important;padding:0 18px!important;border-radius:15px!important;border:1px solid rgba(79,231,255,.85)!important;background:linear-gradient(105deg,#13c8f4 0%,#526bff 52%,#f22b9e 100%)!important;color:#fff!important;font-size:13px!important;font-weight:950!important;box-shadow:0 7px 22px rgba(20,160,255,.2)!important}
.store-dashboard .xt-purchase-warning{clear:both!important;display:block!important;margin-top:14px!important;padding:12px 14px!important;border:1.5px solid #ff438d!important;border-radius:17px!important;background:linear-gradient(110deg,rgba(103,12,52,.55),rgba(50,10,47,.62))!important;color:#ffe6f0!important;font-size:13px!important;font-weight:850!important;line-height:1.5!important;box-shadow:0 0 15px rgba(255,45,137,.1)!important}
.store-dashboard .dashboard-stats{display:grid!important;grid-template-columns:repeat(2,minmax(0,1fr))!important;gap:10px!important;margin:14px 0!important}
.store-dashboard .dashboard-stat{position:relative!important;min-width:0!important;min-height:86px!important;box-sizing:border-box!important;padding:14px 10px 12px 52px!important;border-radius:19px!important;border:1px solid rgba(119,112,255,.58)!important;background:linear-gradient(145deg,rgba(15,20,49,.98),rgba(28,17,49,.96))!important;box-shadow:inset 0 1px 0 rgba(255,255,255,.04)!important;overflow:hidden!important}
.store-dashboard .dashboard-stat:before{left:10px!important;width:34px!important;height:34px!important;border-radius:50%!important;box-shadow:0 0 12px rgba(90,90,255,.12)!important}
.store-dashboard .dashboard-stat:nth-child(1){border-color:rgba(22,211,154,.48)!important}.store-dashboard .dashboard-stat:nth-child(1):before{content:"✓"!important;color:#8affcf!important;background:linear-gradient(145deg,rgba(0,255,128,.35),rgba(0,145,91,.15))!important;border-color:rgba(0,255,145,.7)!important}
.store-dashboard .dashboard-stat:nth-child(2){border-color:rgba(238,65,197,.5)!important}.store-dashboard .dashboard-stat:nth-child(2):before{content:"🛒"!important;color:#fff!important;background:linear-gradient(145deg,rgba(255,40,190,.3),rgba(98,0,180,.2))!important;border-color:rgba(255,65,194,.65)!important}
.store-dashboard .dashboard-stat:nth-child(3){border-color:rgba(245,180,50,.48)!important}.store-dashboard .dashboard-stat:nth-child(3):before{content:"🔑"!important;background:linear-gradient(145deg,rgba(255,186,40,.3),rgba(154,83,0,.2))!important;border-color:rgba(255,190,67,.65)!important}
.store-dashboard .dashboard-stat:nth-child(4){border-color:rgba(183,80,255,.52)!important}.store-dashboard .dashboard-stat:nth-child(4):before{content:"📦"!important;background:linear-gradient(145deg,rgba(177,64,255,.3),rgba(69,0,180,.2))!important;border-color:rgba(190,80,255,.65)!important}
.store-dashboard .dashboard-stat span{display:block!important;font-size:10px!important;line-height:1.35!important;color:#c2cbff!important;font-weight:850!important}
.store-dashboard .dashboard-stat strong{display:block!important;margin-top:4px!important;font-size:20px!important;line-height:1.15!important;font-weight:1000!important;white-space:normal!important;overflow-wrap:anywhere!important}
.store-dashboard .dashboard-stat:nth-child(1) strong{color:#35eab0!important}.store-dashboard .dashboard-stat:nth-child(2) strong{color:#ff6da9!important}.store-dashboard .dashboard-stat:nth-child(3) strong{color:#c29aff!important}
.store-dashboard .dashboard-quick{padding:12px!important;margin:14px 0!important;border:1px solid rgba(111,114,255,.6)!important;border-radius:20px!important;background:linear-gradient(145deg,rgba(9,18,43,.98),rgba(27,14,48,.98))!important;box-shadow:inset 0 1px 0 rgba(255,255,255,.05)!important}
.store-dashboard .dashboard-quick-title{font-size:16px!important;line-height:1.25!important;margin:0 0 9px!important;color:#f5f5ff!important;font-weight:1000!important}
.store-dashboard .dashboard-actions{display:grid!important;grid-template-columns:repeat(2,minmax(0,1fr))!important;gap:7px!important;margin-top:8px!important}
.store-dashboard .dashboard-actions a{display:flex!important;align-items:center!important;justify-content:flex-start!important;gap:8px!important;min-width:0!important;min-height:58px!important;height:auto!important;box-sizing:border-box!important;padding:9px 9px!important;border-radius:15px!important;color:#fff!important;font-size:13px!important;font-weight:950!important;line-height:1.15!important;text-decoration:none!important;box-shadow:inset 0 1px 0 rgba(255,255,255,.12)!important;overflow:hidden!important}
.store-dashboard .dashboard-actions a:nth-child(1){background:linear-gradient(120deg,rgba(0,156,99,.96),rgba(0,55,60,.98))!important;border:1px solid #00e4a2!important;box-shadow:0 0 13px rgba(0,225,160,.13)!important}
.store-dashboard .dashboard-actions a:nth-child(2){background:linear-gradient(120deg,rgba(0,117,230,.96),rgba(13,33,91,.98))!important;border:1px solid #18bfff!important;box-shadow:0 0 13px rgba(24,191,255,.13)!important}
.store-dashboard .dashboard-actions a:nth-child(3){background:linear-gradient(120deg,rgba(183,105,0,.96),rgba(78,34,16,.98))!important;border:1px solid #ffbd43!important;box-shadow:0 0 13px rgba(255,189,67,.11)!important}
.store-dashboard .dashboard-actions a:nth-child(4){background:linear-gradient(120deg,rgba(128,0,196,.96),rgba(60,13,94,.98))!important;border:1px solid #e34dff!important;box-shadow:0 0 13px rgba(227,77,255,.12)!important}
.store-dashboard .dashboard-actions .qa-icon{flex:0 0 28px!important;width:28px!important;font-size:26px!important;line-height:1!important;text-align:center!important;filter:drop-shadow(0 0 6px rgba(255,255,255,.18))!important}
.store-dashboard .dashboard-actions .qa-label{flex:1 1 auto!important;min-width:0!important;font-size:12px!important;white-space:normal!important;overflow-wrap:anywhere!important}
.store-dashboard .dashboard-actions .qa-arrow{flex:0 0 24px!important;width:24px!important;height:24px!important;display:inline-flex!important;align-items:center!important;justify-content:center!important;border:1.5px solid rgba(255,255,255,.92)!important;border-radius:50%!important;font-size:21px!important;line-height:1!important;color:#fff!important}
/* The five-item bottom navigation remains fixed, with a compact neon active tile. */





@media(max-width:390px){.store-dashboard .dashboard-balance{padding:16px 12px!important}.store-dashboard .dashboard-stat{padding-left:48px!important;min-height:82px!important}.store-dashboard .dashboard-stat:before{left:8px!important;width:31px!important;height:31px!important}.store-dashboard .dashboard-actions a{gap:6px!important;padding:8px 7px!important;min-height:54px!important}.store-dashboard .dashboard-actions .qa-icon{flex-basis:25px!important;width:25px!important;font-size:23px!important}.store-dashboard .dashboard-actions .qa-label{font-size:11px!important}.store-dashboard .dashboard-actions .qa-arrow{flex-basis:22px!important;width:22px!important;height:22px!important;font-size:19px!important}}
</style>
<style id="xt-dashboard-reference-match-v36">
/* Dashboard layout tuned to the supplied neon mobile reference; links/data remain unchanged. */
.store-dashboard{width:100%!important;max-width:940px!important;margin:0 auto!important;padding:16px 14px 8px!important;box-sizing:border-box!important}
.store-dashboard .dashboard-balance{display:grid!important;grid-template-columns:minmax(0,1fr) auto!important;align-items:center!important;column-gap:14px!important;row-gap:8px!important;position:relative!important;overflow:hidden!important;min-width:0!important;padding:20px 18px 17px 30px!important;margin-bottom:14px!important;border:1.5px solid rgba(255,48,174,.88)!important;border-radius:25px!important;background:radial-gradient(ellipse at 90% 10%,rgba(18,174,255,.16),transparent 42%),linear-gradient(145deg,#080f22 0%,#10102a 55%,#160d2b 100%)!important;box-shadow:0 0 0 2px rgba(65,105,255,.12),0 0 24px rgba(255,35,169,.14),inset 0 1px 0 rgba(255,255,255,.08)!important}
.store-dashboard .dashboard-label{grid-column:1/-1!important;font-size:12px!important;letter-spacing:.16em!important;color:#aab9e8!important;margin:0!important}
.store-dashboard .dashboard-balance:before{content:"👛"!important;position:absolute!important;left:27px!important;top:55px!important;float:none!important;margin:0!important;font-size:42px!important;line-height:1.15!important;filter:drop-shadow(0 0 12px rgba(0,190,255,.45))!important}
.store-dashboard .dashboard-balance-value{grid-column:1!important;grid-row:auto!important;min-width:0!important;margin:0 0 0 82px!important;font-size:clamp(32px,8vw,46px)!important;line-height:1.1!important;font-weight:1000!important;color:#43f2bd!important;text-shadow:0 0 22px rgba(57,229,177,.25)!important;overflow-wrap:anywhere!important}
.store-dashboard .dashboard-topup{grid-column:2!important;grid-row:2!important;align-self:center!important;min-height:52px!important;height:auto!important;padding:0 22px!important;border:1px solid rgba(255,255,255,.24)!important;border-radius:17px!important;background:linear-gradient(105deg,#09c7f4,#6d66ff 55%,#f329a5)!important;color:#fff!important;font-size:clamp(12px,3.2vw,16px)!important;font-weight:950!important;letter-spacing:.04em!important;white-space:nowrap!important;box-shadow:0 7px 22px rgba(20,160,255,.22)!important}
.store-dashboard .xt-addfunds-banner{grid-column:1/-1!important;grid-row:auto!important;margin:4px 0!important}
.store-dashboard .xt-purchase-warning{grid-column:1/-1!important;grid-row:auto!important;clear:none!important;margin:8px 0 0!important;padding:15px 16px!important;border:1.5px solid #ff3d88!important;border-radius:18px!important;background:linear-gradient(110deg,rgba(103,12,52,.55),rgba(50,10,47,.55))!important;color:#ffe0ec!important;font-size:clamp(12px,3.2vw,15px)!important;font-weight:850!important;line-height:1.5!important;box-shadow:inset 0 1px 0 rgba(255,255,255,.04),0 0 18px rgba(255,45,130,.08)!important}
.store-dashboard .dashboard-stats{display:grid!important;grid-template-columns:repeat(2,minmax(0,1fr))!important;gap:12px!important;margin:14px 0 18px!important}
.store-dashboard .dashboard-stat{position:relative!important;min-width:0!important;min-height:108px!important;padding:18px 12px 14px 76px!important;border:1px solid rgba(100,120,255,.58)!important;border-radius:22px!important;background:radial-gradient(circle at 100% 100%,rgba(68,49,255,.15),transparent 48%),linear-gradient(145deg,rgba(10,20,43,.97),rgba(20,15,42,.97))!important;box-shadow:inset 0 1px 0 rgba(255,255,255,.05),0 10px 25px rgba(0,0,0,.14)!important}
.store-dashboard .dashboard-stat:before{position:absolute!important;left:17px!important;top:50%!important;transform:translateY(-50%)!important;display:grid!important;place-items:center!important;width:48px!important;height:48px!important;border-radius:50%!important;font-size:27px!important;line-height:1!important;background:rgba(40,90,170,.2)!important;border:1px solid rgba(100,150,255,.5)!important;box-shadow:0 0 14px rgba(65,120,255,.14)!important}
.store-dashboard .dashboard-stat:nth-child(1):before{content:"✓"!important;color:#a7ffdc!important;background:linear-gradient(145deg,#00b86a,#005c4b)!important;border-color:#00e99a!important}
.store-dashboard .dashboard-stat:nth-child(2):before{content:"🛒"!important;color:#ffc0f0!important;background:linear-gradient(145deg,#6d1c8b,#28134e)!important;border-color:#e34dff!important}
.store-dashboard .dashboard-stat:nth-child(3):before{content:"🔑"!important;color:#ffe78a!important;background:linear-gradient(145deg,#8c5916,#39200d)!important;border-color:#ffc04d!important}
.store-dashboard .dashboard-stat:nth-child(4):before{content:"⬡"!important;color:#e8c6ff!important;background:linear-gradient(145deg,#7623d7,#32116f)!important;border-color:#bd6cff!important}
.store-dashboard .dashboard-stat span{display:block!important;font-size:clamp(10px,2.8vw,14px)!important;letter-spacing:.01em!important;color:#bdc9ff!important;white-space:normal!important;overflow:visible!important;text-overflow:clip!important;line-height:1.3!important}
.store-dashboard .dashboard-stat strong{display:block!important;margin-top:5px!important;font-size:clamp(20px,5vw,27px)!important;font-weight:1000!important;line-height:1.1!important;white-space:normal!important;overflow-wrap:anywhere!important;text-overflow:clip!important;color:#43f2bd!important}
.store-dashboard .dashboard-stat:nth-child(1) strong{color:#38efb0!important}.store-dashboard .dashboard-stat:nth-child(2) strong{color:#ff6ab3!important}.store-dashboard .dashboard-stat:nth-child(3) strong{color:#c49bff!important}.store-dashboard .dashboard-stat:nth-child(4) strong{color:#ffc33d!important}
.store-dashboard .dashboard-quick{padding:16px!important;margin:14px 0 18px!important;border:1px solid rgba(108,115,255,.58)!important;border-radius:24px!important;background:radial-gradient(ellipse at 100% 0%,rgba(75,49,255,.16),transparent 45%),linear-gradient(145deg,rgba(8,16,36,.98),rgba(20,13,39,.98))!important;box-shadow:inset 0 1px 0 rgba(255,255,255,.05)!important}
.store-dashboard .dashboard-quick-title{font-size:clamp(19px,5vw,25px)!important;line-height:1.25!important;margin:0 0 5px!important;color:#f5f5ff!important;font-weight:1000!important}
.store-dashboard .dashboard-actions{display:grid!important;grid-template-columns:repeat(2,minmax(0,1fr))!important;gap:11px!important;margin-top:14px!important}
.store-dashboard .dashboard-actions a{display:flex!important;align-items:center!important;justify-content:flex-start!important;gap:9px!important;min-width:0!important;min-height:94px!important;height:auto!important;box-sizing:border-box!important;padding:13px 12px!important;border-radius:21px!important;color:#fff!important;font-size:15px!important;font-weight:950!important;line-height:1.2!important;text-decoration:none!important;box-shadow:inset 0 1px 0 rgba(255,255,255,.12)!important;overflow:hidden!important}
.store-dashboard .dashboard-actions a:nth-child(1){background:linear-gradient(120deg,rgba(0,156,99,.96),rgba(0,55,60,.98))!important;border:1.5px solid #00e4a2!important;box-shadow:0 0 13px rgba(0,225,160,.13)!important}
.store-dashboard .dashboard-actions a:nth-child(2){background:linear-gradient(120deg,rgba(0,117,230,.96),rgba(13,33,91,.98))!important;border:1.5px solid #18bfff!important;box-shadow:0 0 13px rgba(24,191,255,.13)!important}
.store-dashboard .dashboard-actions a:nth-child(3){background:linear-gradient(120deg,rgba(183,105,0,.96),rgba(78,34,16,.98))!important;border:1.5px solid #ffbd43!important;box-shadow:0 0 13px rgba(255,189,67,.11)!important}
.store-dashboard .dashboard-actions a:nth-child(4){background:linear-gradient(120deg,rgba(128,0,196,.96),rgba(60,13,94,.98))!important;border:1.5px solid #e34dff!important;box-shadow:0 0 13px rgba(227,77,255,.12)!important}
.store-dashboard .dashboard-actions .qa-icon{flex:0 0 38px!important;width:38px!important;font-size:34px!important;line-height:1!important;text-align:center!important;filter:drop-shadow(0 0 6px rgba(255,255,255,.18))!important}
.store-dashboard .dashboard-actions .qa-label{flex:1 1 auto!important;min-width:0!important;font-size:clamp(12px,3.4vw,17px)!important;white-space:normal!important;overflow-wrap:anywhere!important}
.store-dashboard .dashboard-actions .qa-arrow{flex:0 0 30px!important;width:30px!important;height:30px!important;display:inline-flex!important;align-items:center!important;justify-content:center!important;border:1.5px solid rgba(255,255,255,.92)!important;border-radius:50%!important;font-size:25px!important;line-height:1!important;color:#fff!important}
@media(max-width:600px){.store-dashboard{padding:12px 10px 8px!important}.store-dashboard .dashboard-balance{padding:18px 12px 15px 17px!important;column-gap:5px!important}.store-dashboard .dashboard-balance:before{left:15px!important;top:53px!important;font-size:34px!important}.store-dashboard .dashboard-balance-value{margin-left:62px!important;font-size:clamp(30px,8vw,42px)!important}.store-dashboard .dashboard-topup{min-height:48px!important;padding:0 13px!important;border-radius:15px!important;font-size:12px!important}.store-dashboard .dashboard-stat{min-height:100px!important;padding:15px 8px 12px 60px!important}.store-dashboard .dashboard-stat:before{left:9px!important;width:40px!important;height:40px!important;font-size:22px!important}.store-dashboard .dashboard-stat span{font-size:10px!important}.store-dashboard .dashboard-stat strong{font-size:clamp(18px,5vw,25px)!important}.store-dashboard .dashboard-quick{padding:13px!important}.store-dashboard .dashboard-actions{gap:9px!important}.store-dashboard .dashboard-actions a{min-height:84px!important;padding:11px 8px!important;gap:6px!important}.store-dashboard .dashboard-actions .qa-icon{font-size:29px!important;flex-basis:30px!important;width:30px!important}.store-dashboard .dashboard-actions .qa-arrow{flex-basis:25px!important;width:25px!important;height:25px!important;font-size:22px!important}.store-dashboard .dashboard-actions .qa-label{font-size:12px!important}}
@media(max-width:380px){.store-dashboard .dashboard-balance{grid-template-columns:minmax(0,1fr) auto!important;padding-left:12px!important}.store-dashboard .dashboard-balance:before{left:11px!important;font-size:30px!important}.store-dashboard .dashboard-balance-value{margin-left:48px!important;font-size:29px!important}.store-dashboard .dashboard-topup{padding:0 9px!important;font-size:10px!important}.store-dashboard .dashboard-stat{padding-left:52px!important}.store-dashboard .dashboard-stat:before{left:7px!important;width:35px!important;height:35px!important;font-size:19px!important}.store-dashboard .dashboard-actions a{min-height:75px!important;padding:9px 6px!important}.store-dashboard .dashboard-actions .qa-icon{font-size:25px!important;flex-basis:25px!important;width:25px!important}.store-dashboard .dashboard-actions .qa-arrow{display:none!important}}
</style>
<style id="xt-live-chat-widget-css">
#xtLiveChat{position:fixed;right:16px;bottom:96px;z-index:99999;font-family:Arial,Helvetica,sans-serif}
#xtLiveChat .xt-chat-launch{width:58px;height:58px;border:1px solid rgba(99,255,22,.85);border-radius:50%;display:flex;align-items:center;justify-content:center;background:radial-gradient(circle at 30% 25%,#1bff9a,#087c70 48%,#052c3b);box-shadow:0 0 0 5px rgba(99,255,22,.10),0 0 22px rgba(16,216,255,.42);color:#fff;text-decoration:none;animation:xtChatPulse 1.8s ease-in-out infinite;position:relative}
#xtLiveChat .xt-chat-launch svg{width:29px;height:29px;filter:drop-shadow(0 1px 3px #003)}
#xtLiveChat .xt-chat-launch:after{content:"";position:absolute;inset:-5px;border:2px solid rgba(99,255,22,.48);border-radius:50%;animation:xtChatRing 2.2s ease-out infinite}
#xtLiveChat .xt-chat-bubble{position:absolute;right:0;bottom:70px;max-width:235px;min-width:155px;padding:11px 14px;border:1px solid rgba(99,255,22,.6);border-radius:14px 14px 14px 4px;background:rgba(4,13,25,.97);color:#f3fff7;font-size:12px;font-weight:800;line-height:1.45;box-shadow:0 8px 28px #0009,0 0 18px #10d8ff26;opacity:0;visibility:hidden;transform:translateY(7px) scale(.97);transition:opacity .22s,transform .22s,visibility .22s;pointer-events:none}
#xtLiveChat .xt-chat-bubble.show{opacity:1;visibility:visible;transform:translateY(0) scale(1)}
#xtLiveChat .xt-chat-bubble:after{content:"";position:absolute;right:15px;bottom:-7px;width:12px;height:12px;transform:rotate(45deg);background:#040d19;border-right:1px solid rgba(99,255,22,.5);border-bottom:1px solid rgba(99,255,22,.5)}
#xtLiveChat .xt-chat-caption{position:absolute;right:0;bottom:68px;padding:7px 11px;border-radius:9px;background:linear-gradient(135deg,#06121f,#102b35);color:#8cff72;border:1px solid #63ff1680;font-size:10px;font-weight:900;letter-spacing:.6px;white-space:nowrap;box-shadow:0 0 14px #10d8ff22}
@keyframes xtChatPulse{0%,100%{transform:scale(1)}50%{transform:scale(1.07)}}
@keyframes xtChatRing{0%{transform:scale(.9);opacity:.8}100%{transform:scale(1.45);opacity:0}}
@media(max-width:480px){#xtLiveChat{right:12px;bottom:92px}#xtLiveChat .xt-chat-launch{width:52px;height:52px}#xtLiveChat .xt-chat-caption{right:0;bottom:62px}#xtLiveChat .xt-chat-bubble{max-width:min(235px,calc(100vw - 90px))}}
@media(prefers-reduced-motion:reduce){#xtLiveChat .xt-chat-launch,#xtLiveChat .xt-chat-launch:after{animation:none!important}}
</style>
<style id="xtreme-dashboard-quick-access-final-v14">
/* V14 dashboard-only Quick Access correction: fixed columns prevent icon/arrow stretching. */
.store-dashboard .dashboard-actions{display:grid!important;grid-template-columns:repeat(2,minmax(0,1fr))!important;gap:12px!important;align-items:stretch!important}
.store-dashboard .dashboard-actions>a{display:grid!important;grid-template-columns:44px minmax(0,1fr) 36px!important;align-items:center!important;justify-content:initial!important;column-gap:10px!important;min-width:0!important;min-height:94px!important;padding:14px 14px!important;box-sizing:border-box!important;text-align:left!important;overflow:hidden!important}
.store-dashboard .dashboard-actions .qa-image-icon,.store-dashboard .dashboard-actions .xt-wallet-add-icon{display:flex!important;align-items:center!important;justify-content:center!important;position:relative!important;inset:auto!important;float:none!important;flex:none!important;width:44px!important;height:44px!important;min-width:44px!important;min-height:44px!important;margin:0!important;padding:0!important;border:0!important;border-radius:0!important;background:none!important;background-image:none!important;box-shadow:none!important;filter:drop-shadow(0 2px 5px rgba(0,0,0,.2))!important;overflow:visible!important}
.store-dashboard .dashboard-actions .qa-image-icon img,.store-dashboard .dashboard-actions .xt-wallet-add-icon img{display:block!important;position:static!important;width:44px!important;height:44px!important;min-width:44px!important;min-height:44px!important;max-width:44px!important;max-height:44px!important;object-fit:contain!important;object-position:center!important;margin:0!important;padding:0!important;border:0!important;border-radius:0!important;background:none!important;filter:none!important}
.store-dashboard .dashboard-actions .qa-label{display:block!important;min-width:0!important;margin:0!important;padding:0!important;align-self:center!important;justify-self:stretch!important;font-size:clamp(13px,3.3vw,17px)!important;font-weight:950!important;line-height:1.2!important;white-space:normal!important;overflow-wrap:anywhere!important;text-align:left!important;transform:none!important}
.store-dashboard .dashboard-actions .qa-arrow{display:flex!important;align-items:center!important;justify-content:center!important;justify-self:end!important;align-self:center!important;flex:none!important;width:36px!important;height:36px!important;min-width:36px!important;min-height:36px!important;max-width:36px!important;box-sizing:border-box!important;margin:0!important;padding:0!important;border:2px solid rgba(255,255,255,.95)!important;border-radius:50%!important;background:rgba(0,0,0,.12)!important;color:#fff!important;font-size:27px!important;line-height:1!important;white-space:nowrap!important;transform:none!important}
.store-dashboard .dashboard-actions a[href*="my-keys"]{background:linear-gradient(115deg,#00b982,#064d4d)!important;border-color:#35ffc1!important}
.store-dashboard .dashboard-actions a[href*="deposit.php"]{background:linear-gradient(115deg,#079eff,#153aa0)!important;border-color:#38d8ff!important}
.store-dashboard .dashboard-actions a[href*="history.php"]{background:linear-gradient(115deg,#c98212,#743514)!important;border-color:#ffd05a!important}
.store-dashboard .dashboard-actions a[href*="profile.php"]{background:linear-gradient(115deg,#a000cf,#59158b)!important;border-color:#ed62ff!important}
@media(max-width:600px){.store-dashboard .dashboard-actions{gap:10px!important}.store-dashboard .dashboard-actions>a{grid-template-columns:38px minmax(0,1fr) 32px!important;column-gap:7px!important;min-height:78px!important;padding:10px 9px!important}.store-dashboard .dashboard-actions .qa-image-icon,.store-dashboard .dashboard-actions .xt-wallet-add-icon,.store-dashboard .dashboard-actions .qa-image-icon img,.store-dashboard .dashboard-actions .xt-wallet-add-icon img{width:38px!important;height:38px!important;min-width:38px!important;min-height:38px!important;max-width:38px!important;max-height:38px!important}.store-dashboard .dashboard-actions .qa-arrow{width:32px!important;height:32px!important;min-width:32px!important;min-height:32px!important;max-width:32px!important;font-size:24px!important}.store-dashboard .dashboard-actions .qa-label{font-size:clamp(12px,3.3vw,16px)!important}}
@media(max-width:380px){.store-dashboard .dashboard-actions>a{grid-template-columns:32px minmax(0,1fr) 28px!important;column-gap:5px!important;padding:9px 7px!important}.store-dashboard .dashboard-actions .qa-image-icon,.store-dashboard .dashboard-actions .xt-wallet-add-icon,.store-dashboard .dashboard-actions .qa-image-icon img,.store-dashboard .dashboard-actions .xt-wallet-add-icon img{width:32px!important;height:32px!important;min-width:32px!important;min-height:32px!important;max-width:32px!important;max-height:32px!important}.store-dashboard .dashboard-actions .qa-arrow{width:28px!important;height:28px!important;min-width:28px!important;min-height:28px!important;max-width:28px!important;font-size:21px!important}}
</style>
<style id="xtreme-dashboard-wallet-icon-final-v17">
/* Use the exact supplied cyan wallet icon for the dashboard Balance and Add Funds. */
.store-dashboard .dashboard-balance:before{
 content:""!important;display:block!important;position:absolute!important;
 left:25px!important;top:55px!important;width:66px!important;height:56px!important;
 margin:0!important;float:none!important;font-size:0!important;line-height:0!important;
 background:url("assets/nav-icons/wallet-cyan-reference.png") center/contain no-repeat!important;
 filter:drop-shadow(0 0 7px rgba(34,215,255,.30))!important;z-index:3!important;
}

/* Quick Access > Add Funds */
.store-dashboard .dashboard-actions a[href*="deposit.php"] .xt-wallet-add-icon,
.store-dashboard .dashboard-actions a[href*="deposit.php"] .qa-icon{
 background:transparent!important;background-image:none!important;
}
.store-dashboard .dashboard-actions a[href*="deposit.php"] .xt-wallet-add-icon:before,
.store-dashboard .dashboard-actions a[href*="deposit.php"] .qa-icon:before{
 content:""!important;display:block!important;width:48px!important;height:48px!important;
 background:url("assets/nav-icons/wallet-cyan-reference.png") center/contain no-repeat!important;
 filter:drop-shadow(0 0 6px rgba(34,215,255,.30))!important;
}
/* Main Add Funds button */
.store-dashboard .dashboard-topup:before{
 content:""!important;display:inline-block!important;width:30px!important;height:30px!important;
 background:url("assets/nav-icons/wallet-cyan-reference.png") center/contain no-repeat!important;
 border-radius:0!important;filter:drop-shadow(0 0 5px rgba(34,215,255,.30))!important;
}
@media(max-width:600px){
 .store-dashboard .dashboard-topup:before{width:26px!important;height:26px!important}
}
</style>
<style id="xt-topup-category-card-final-fix">
section.xt-topup-entry .xt-topup-head>a,
section.xt-topup-entry .xt-topup-head>a:link,
section.xt-topup-entry .xt-topup-head>a:visited,
section.xt-topup-entry .xt-topup-tiles>a,
section.xt-topup-entry .xt-topup-tiles>a:link,
section.xt-topup-entry .xt-topup-tiles>a:visited{
  display:flex!important;position:relative!important;align-items:center!important;
  justify-content:center!important;flex-direction:column!important;gap:9px!important;
  min-width:0!important;min-height:88px!important;padding:12px 8px!important;
  border:1px solid rgba(114,164,255,.58)!important;border-radius:18px!important;
  background:linear-gradient(145deg,rgba(26,48,83,.98),rgba(15,20,43,.98))!important;
  color:#f5f7ff!important;text-decoration:none!important;-webkit-text-decoration:none!important;
  font-weight:950!important;text-align:center!important;line-height:1.25!important;
  box-shadow:0 8px 22px rgba(0,0,0,.34),inset 0 1px 0 rgba(255,255,255,.12)!important;
  overflow:hidden!important;
}
section.xt-topup-entry .xt-topup-head>a{
  min-height:42px!important;flex-direction:row!important;padding:0 18px!important;
  border-color:rgba(44,225,232,.65)!important;
  background:linear-gradient(110deg,#06c9b5,#2687ff 58%,#9255ef)!important;
  color:#071323!important;
}
section.xt-topup-entry .xt-topup-tiles>a:nth-child(5n/**/+1){border-color:#24d8ef!important;background:linear-gradient(145deg,#075b79,#101b38)!important}
section.xt-topup-entry .xt-topup-tiles>a:nth-child(5n/**/+2){border-color:#f05cb8!important;background:linear-gradient(145deg,#612052,#17152f)!important}
section.xt-topup-entry .xt-topup-tiles>a:nth-child(5n/**/+3){border-color:#f4c45d!important;background:linear-gradient(145deg,#60451b,#17182e)!important}
section.xt-topup-entry .xt-topup-tiles>a:nth-child(5n/**/+4){border-color:#a77aff!important;background:linear-gradient(145deg,#482b79,#15172f)!important}
section.xt-topup-entry .xt-topup-tiles>a:nth-child(5n){border-color:#37d6a8!important;background:linear-gradient(145deg,#075448,#111a30)!important}
section.xt-topup-entry .xt-topup-tiles>a span{
  display:grid!important;place-items:center!important;width:43px!important;height:43px!important;
  border-radius:14px!important;background:rgba(4,12,28,.78)!important;
  border:1px solid rgba(255,255,255,.2)!important;font-size:25px!important;line-height:1!important;
}
section.xt-topup-entry .xt-topup-tiles>a b{
  display:block!important;color:#f7f8ff!important;font-size:clamp(10px,2.8vw,13px)!important;
  font-weight:950!important;text-decoration:none!important;overflow-wrap:anywhere!important;
}
section.xt-topup-entry .xt-topup-tiles>a:active{transform:translateY(1px) scale(.985)!important}
@media(max-width:520px){
 section.xt-topup-entry .xt-topup-tiles{grid-template-columns:repeat(3,minmax(0,1fr))!important;gap:8px!important}
 section.xt-topup-entry .xt-topup-tiles>a{min-height:86px!important;padding:10px 5px!important}
}
</style>
<style id="xt-store-symmetric-gutters-final-v10">
/*
 * Keep the equal left/right page gutters from V9.
 * Restore the wallet header's original compact 3-column layout:
 * logo/profile | balance | add funds.
 */
:root {
  --xt-store-side-gap-v9: clamp(12px, 3.6vw, 16px);
}
html, body {
  width: 100% !important;
  max-width: 100% !important;
  margin-left: 0 !important;
  margin-right: 0 !important;
  overflow-x: clip !important;
  box-sizing: border-box !important;
}
body {
  padding-left: 0 !important;
  padding-right: 0 !important;
}

/* All outer Store cards retain equal centered side gutters. */
html body .xt-customer-wallet-header,
html body .xt-header-announcement,
html body section.store-dashboard,
html body section.xt-topup-entry {
  box-sizing: border-box !important;
  position: relative !important;
  left: auto !important;
  right: auto !important;
  transform: none !important;
  width: calc(100% - (2 * var(--xt-store-side-gap-v9))) !important;
  max-width: 1100px !important;
  min-width: 0 !important;
  margin-left: auto !important;
  margin-right: auto !important;
}

/* Explicitly restore the original compact wallet-header structure.
   Keep the existing V9 outer width/gutters; do not enlarge its height. */
html body .xt-customer-wallet-header {
  display: grid !important;
  grid-template-columns: minmax(0, 1fr) auto auto !important;
  align-items: center !important;
  justify-content: stretch !important;
  gap: 9px !important;
  padding: 9px 10px !important;
  overflow: hidden !important;
}
html body .xt-customer-wallet-header > .xt-customer-brand {
  display: flex !important;
  min-width: 0 !important;
  width: auto !important;
  max-width: 100% !important;
}
html body .xt-customer-wallet-header > .xt-customer-balance,
html body .xt-customer-wallet-header > .xt-customer-topup {
  width: auto !important;
  min-width: 0 !important;
  max-width: 100% !important;
  justify-self: stretch !important;
}
html body .xt-customer-wallet-header > .xt-customer-balance {
  display: flex !important;
  white-space: nowrap !important;
}
html body .xt-customer-wallet-header > .xt-customer-topup {
  display: inline-flex !important;
  white-space: nowrap !important;
}
@media (max-width: 430px) {
  html body .xt-customer-wallet-header {
    display: grid !important;
    grid-template-columns: minmax(0, 1fr) auto auto !important;
    gap: 6px !important;
    padding: 8px 7px !important;
  }
}
@media (max-width: 380px) {
  :root { --xt-store-side-gap-v9: 12px; }
}

/* Product list uses the same outer left/right gutters as the upper cards. */
html body main.container {
  display: block !important;
  box-sizing: border-box !important;
  position: relative !important;
  left: auto !important;
  right: auto !important;
  transform: none !important;
  width: 100% !important;
  max-width: 100% !important;
  min-width: 0 !important;
  padding-left: var(--xt-store-side-gap-v9) !important;
  padding-right: var(--xt-store-side-gap-v9) !important;
  margin-left: 0 !important;
  margin-right: 0 !important;
  overflow: visible !important;
}
html body main.container > section.product {
  display: block !important;
  box-sizing: border-box !important;
  position: relative !important;
  left: auto !important;
  right: auto !important;
  transform: none !important;
  width: 100% !important;
  max-width: 100% !important;
  min-width: 0 !important;
  margin-left: 0 !important;
  margin-right: 0 !important;
}

/* Prevent inner content from creating horizontal overflow. */
html body .xt-header-announcement img,
html body section.store-dashboard *,
html body section.xt-topup-entry *,
html body main.container > section.product * {
  max-width: 100%;
  box-sizing: border-box;
}
</style>
<style id="xt-hide-license-order-panel-until-purchase-v11">
/* Keep the existing license confirmation panel in the page for BUY flow,
   but never show it automatically when Store loads. */
html body .xt-license-order-modal:not(.show) {
  display: none !important;
  visibility: hidden !important;
  opacity: 0 !important;
  pointer-events: none !important;
}
html body .xt-license-order-modal.show {
  visibility: visible !important;
  pointer-events: auto !important;
}
</style>
<style id="xt-live-key-inventory-view-v15">
/* LIVE KEY: show product name and all plan names with stock availability only. */
main.container.xt-live-key-filter-active > section.product.xt-live-key-match > :not(.product-name):not(.plan-list){
  display:none!important;
}
main.container.xt-live-key-filter-active > section.product.xt-live-key-match .product-name{
  display:block!important;
  margin:8px 0 12px!important;
}
main.container.xt-live-key-filter-active > section.product.xt-live-key-match .plan-list,
main.container.xt-live-key-filter-active > section.product.xt-live-key-match .plan-list[hidden]{
  display:grid!important;
  grid-template-columns:minmax(0,1fr)!important;
  gap:9px!important;
  margin:0 0 12px!important;
}
main.container.xt-live-key-filter-active > section.product.xt-live-key-match .plan{
  display:flex!important;
  align-items:center!important;
  justify-content:space-between!important;
  gap:10px!important;
  padding:11px 13px!important;
  cursor:default!important;
}
main.container.xt-live-key-filter-active > section.product.xt-live-key-match .plan-info{
  min-width:0!important;
  flex:1 1 auto!important;
}
main.container.xt-live-key-filter-active > section.product.xt-live-key-match .plan-price,
main.container.xt-live-key-filter-active > section.product.xt-live-key-match .plan-get-controls,
main.container.xt-live-key-filter-active > section.product.xt-live-key-match .plan-stock{
  display:none!important;
}
main.container.xt-live-key-filter-active > section.product.xt-live-key-match .plan.out{
  opacity:1!important;
  filter:none!important;
}
.xt-live-key-stock-status{
  display:inline-flex!important;
  align-items:center!important;
  justify-content:center!important;
  flex:0 0 auto!important;
  min-width:76px!important;
  padding:5px 9px!important;
  border-radius:999px!important;
  font-size:11px!important;
  line-height:1.2!important;
  font-weight:900!important;
  white-space:nowrap!important;
  border:1px solid currentColor!important;
}
.xt-live-key-stock-status.is-available{
  color:#34e6a0!important;
  background:rgba(16,185,129,.12)!important;
}
.xt-live-key-stock-status.is-out{
  color:#ff8298!important;
  background:rgba(244,63,94,.12)!important;
}
</style>
<style id="xt-product-status-dot-adjust-v15">
html body main.container > section.product .xt-product-tag{
  padding-left:22px!important;
}
html body main.container > section.product .xt-product-tag:before{
  left:9px!important;
  width:7px!important;
  height:7px!important;
  min-width:7px!important;
}
</style>
<style id="xt-store-single-source-card-layout-v4">
/* Final, single authority for Store card geometry; prevents old rules from re-overriding the new layout. */
:root{--xt-store-side-gap-final:clamp(12px,3.6vw,16px)}
html,body{max-width:100%!important;overflow-x:clip!important}
html body .xt-customer-wallet-header,html body .xt-header-announcement,html body section.store-dashboard,html body section.xt-topup-entry,html body main.container>section.product{box-sizing:border-box!important;position:relative!important;left:auto!important;right:auto!important;transform:none!important;width:calc(100% - (2 * var(--xt-store-side-gap-final)))!important;max-width:1100px!important;min-width:0!important;margin-left:auto!important;margin-right:auto!important}
html body .xt-customer-wallet-header,html body .xt-header-announcement,html body section.store-dashboard,html body section.xt-topup-entry{transition:none!important}
html body main.container{box-sizing:border-box!important;width:100%!important;max-width:100%!important;min-width:0!important;padding-left:var(--xt-store-side-gap-final)!important;padding-right:var(--xt-store-side-gap-final)!important;margin-left:0!important;margin-right:0!important;overflow:visible!important}
html body main.container>section.product{display:block!important;min-height:0!important;transition:none!important;animation:none!important}
html body .xt-header-announcement img{display:block!important;width:100%!important;max-width:100%!important;height:auto!important;object-fit:cover!important}
html body .xt-topup-entry .xt-topup-tiles{max-width:100%!important;min-width:0!important}
html body .xt-customer-wallet-header *,html body .xt-header-announcement *,html body section.store-dashboard *,html body section.xt-topup-entry *,html body main.container>section.product *{box-sizing:border-box!important;min-width:0}
@media(max-width:480px){:root{--xt-store-side-gap-final:12px}html body .xt-topup-entry .xt-topup-tiles{grid-template-columns:repeat(3,minmax(0,1fr))!important;gap:8px!important}html body .xt-topup-entry .xt-topup-tiles>a{min-height:82px!important}}
</style>
</head>

<body>


<div class="site-decoration-wrap" aria-hidden="true"></div>

<?php $xtHeaderSite = $site; require __DIR__ . '/customer-wallet-header.php'; ?>

        <?php if (trim((string)($site['header_banner_path'] ?? '')) !== '' || trim((string)($site['header_banner_text'] ?? '')) !== ''): ?>
          <?php $headerBannerUrl = trim((string)($site['header_banner_url'] ?? '')); ?>
          <?php if ($headerBannerUrl !== ''): ?><a class="xt-header-announcement" href="<?=h($headerBannerUrl)?>" target="_blank" rel="noopener noreferrer"><?php else: ?><div class="xt-header-announcement"><?php endif; ?>
            <?php if (trim((string)($site['header_banner_path'] ?? '')) !== ''): ?><img src="<?=h($site['header_banner_path'])?>" alt="Shop announcement banner" loading="lazy"><?php endif; ?>
            <?php if (trim((string)($site['header_banner_text'] ?? '')) !== ''): ?><span><?=h($site['header_banner_text'])?></span><?php endif; ?>
          <?php if ($headerBannerUrl !== ''): ?></a><?php else: ?></div><?php endif; ?>
        <?php endif; ?>

<section class="store-dashboard">

        <?php if ($purchaseErrorFlash !== ''): ?>
          <?php
            // Always source the displayed available balance from the same canonical BDT
            // calculation used by the dashboard. Old flash messages may contain a
            // previously formatted currency amount; parsing that as BDT caused a
            // second conversion (e.g. $2.26 becoming $0.02).
            // Always use the same canonical balance shown in the dashboard.
            // Session-stored values may be stale or were captured before a prior
            // currency conversion, causing e.g. $2.26 in the dashboard but $0.02 here.
            $warnHave = (float)$dashBalance;
            $warnNeed = is_array($purchaseErrorAmounts ?? null) && isset($purchaseErrorAmounts['need_bdt'])
                ? (float)$purchaseErrorAmounts['need_bdt'] : null;
            if ($warnNeed === null && preg_match('/but you need\s*(?:৳|\$|€|£|₹|₫|د\.إ|Nu\.)?\s*([\d,]+\.\d{2})/i', $purchaseErrorFlash, $wm)) {
                // The fallback is only for older sessions without raw numeric values.
                $warnNeed = (float)str_replace(',', '', $wm[1]);
            }
          ?>
          <div class="xt-purchase-warning" role="alert" aria-live="polite" data-raw-message="<?= htmlspecialchars($purchaseErrorFlash, ENT_QUOTES, 'UTF-8') ?>" <?php if($warnNeed!==null): ?>data-balance-bdt="<?=h($warnHave)?>" data-needed-bdt="<?=h($warnNeed)?>"<?php endif; ?>><?= htmlspecialchars($purchaseErrorFlash, ENT_QUOTES, 'UTF-8') ?></div>
        <?php endif; ?>


    <?php if ($userRole === 'reseller'): ?>
      <div class="reseller-access-panel" style="margin-top:12px;padding:14px 16px;border-radius:18px;border:1px solid rgba(16,216,255,.28);background:linear-gradient(135deg,rgba(16,216,255,.10),rgba(139,92,246,.12));color:var(--xt-text)">
        <strong style="display:block;font-size:14px">RESELLER PRICING · PRODUCT-WISE DISCOUNTS</strong>
        <?php if ($dashDepositsUsd < 50): ?>
          <p style="margin:7px 0;color:var(--xt-muted);font-size:12px;line-height:1.5">Purchases are locked until your approved deposits reach $50. Approved deposits: $<?=h(number_format($dashDepositsUsd,2))?> / $50.00.</p>
          <div style="height:8px;background:rgba(100,116,139,.22);border-radius:999px;overflow:hidden"><div style="height:100%;width:<?=h((string)max(0,min(100,($dashDeposits/50)*100)))?>%;background:linear-gradient(90deg,#06b6d4,#8b5cf6);border-radius:999px"></div></div>
          <a href="deposit.php" style="display:inline-block;margin-top:10px;padding:9px 13px;border-radius:11px;background:linear-gradient(135deg,#06b6d4,#7c3aed);color:#fff;text-decoration:none;font-weight:900;font-size:12px">ADD FUNDS TO UNLOCK</a>
        <?php else: ?>
          <p style="margin:7px 0;color:var(--xt-money);font-size:12px">✓ $50 deposit requirement met. Reseller purchases are unlocked.</p>
        <?php endif; ?>
      </div>
    <?php endif; ?>
</section>

<section class="xt-topup-entry" aria-label="Gaming top-up services">
  <div class="xt-topup-tiles">
    <?php foreach($topupStoreCategories as $topupCategory): $topupSlug=(string)$topupCategory['slug']; $topupName=(string)$topupCategory['name']; $topupIcon=$topupCategoryIcons[$topupSlug]??'🎮'; ?>
      <a href="topup.php?category=<?=h($topupSlug)?>"><span aria-hidden="true"><?=h($topupIcon)?></span><b data-auto-button-label="1" data-original-button-label="<?=h($topupName)?>"><?=h($topupName)?></b></a>
    <?php endforeach; ?>
  </div>
</section>

<!-- Compact swipeable product category filters -->
<section class="xt-product-filter-wrap" aria-label="Product categories">
  <div class="xt-product-filter-track" id="xtProductFilterTrack" role="group" aria-label="Filter products">
    <button type="button" class="xt-product-filter-btn" data-product-filter="LIVE_KEY" aria-pressed="false"><span>🔑</span><b>LIVE KEY</b></button>
    <button type="button" class="xt-product-filter-btn is-active" data-product-filter="ALL" aria-pressed="true"><span>✦</span><b>ALL PRODUCTS</b></button>
    <button type="button" class="xt-product-filter-btn" data-product-filter="ANDROID_NONROOT" aria-pressed="false"><span>🤖</span><b>ANDROID NON ROOT</b></button>
    <button type="button" class="xt-product-filter-btn" data-product-filter="IPHONE" aria-pressed="false"><span></span><b>iOS iPHONE</b></button>
    <button type="button" class="xt-product-filter-btn" data-product-filter="ANDROID_ROOT" aria-pressed="false"><span>📱</span><b>ANDROID ROOT</b></button>
    <button type="button" class="xt-product-filter-btn" data-product-filter="PC_PANEL_FF" aria-pressed="false"><span>🖥️</span><b>PC PRODUCT</b></button>
  </div>
</section>

<main class="container">

<?php if (!$products): ?>

    <div class="empty">

        <div class="empty-icon">
            🛒
        </div>

        <div class="empty-title">
            No Products Available
        </div>

        <div>
            Products will appear here when they are added.
        </div>

    </div>

<?php else: ?>


<?php foreach ($products as $product): ?>

<?php

$productId = (int)$product['id'];
$productDescription = trim((string)($product['description'] ?? ''));
$productLinks = productLinks($productDescription);

$productPlans =
    $plansByProduct[$productId] ?? [];
$productResellerDiscount = ($userRole === 'reseller') ? (isset($product['reseller_discount_percent']) && $product['reseller_discount_percent'] !== null ? max(0.0, min(90.0, (float)$product['reseller_discount_percent'])) : $resellerDiscount) : 0.0;
$productAvailableTotal = 0;
foreach ($productPlans as $pp0) { $productAvailableTotal += (int)($pp0['available_keys'] ?? 0); }

?>

<section
    class="product"
    data-product-id="<?= $productId ?>"
    data-platforms="<?= h((function($raw,$n){$parts=array_map('trim',explode(',',strtoupper((string)$raw)));$out=[];foreach($parts as $p){if($p==='ALL'||$p==='')continue;if(in_array($p,['IOS','APPLE','APPLE_IOS','APPLE_IOS_PRODUCT','IPHONE_PRODUCT'],true))$p='IPHONE';if(in_array($p,['ANDROID_NON_ROOT','ANDROID_NONROOTED','ANDROID_NONROOT_PRODUCT'],true))$p='ANDROID_NONROOT';if(in_array($p,['PC','PC_PANEL','PC_FF'],true))$p='PC_PANEL_FF';if(in_array($p,['ANDROID_NONROOT','IPHONE','ANDROID_ROOT','PC_PANEL_FF','LIVE_KEY'],true)&&!in_array($p,$out,true))$out[]=$p;}if(!$out){$n=strtoupper((string)$n);if(str_contains($n,'PC PANEL FF'))$out[]='PC_PANEL_FF';if(str_contains($n,'ANDROID ROOT')&&!str_contains($n,'NON ROOT'))$out[]='ANDROID_ROOT';if(str_contains($n,'ANDROID NON ROOT')||str_contains($n,'ANDROID NONROOT'))$out[]='ANDROID_NONROOT';if(str_contains($n,'APPLE IOS')||str_contains($n,'IOS PRODUCT')||str_contains($n,'IPHONE'))$out[]='IPHONE';}return implode(',', $out ?: $parts);})($product['platform'] ?? 'ALL',$product['name'] ?? '')) ?>"
    data-platform="<?= h((function($raw,$n){$v=explode(',',(string)$raw)[0]??'ALL';return strtoupper(trim($v));})($product['platform'] ?? 'ALL',$product['name'] ?? '')) ?>"
    data-live="<?= ((int)($product['live_status'] ?? 1) === 1 ? '1' : '0') ?>"
    data-available="<?= $productAvailableTotal ?>"
    data-has-plans="<?= !empty($productPlans) ? '1' : '0' ?>"
>


    <?php
    $mediaUrl = '';
    $imageUrl = '';
    $videoUrl = '';
    foreach ($productLinks as $pl) {
        if (!is_array($pl)) continue;
        $candidate = trim((string)($pl['url'] ?? ''));
        if (($pl['type'] ?? '') === 'IMAGE' && $candidate !== '') $imageUrl = $candidate;
        if (($pl['type'] ?? '') === 'VIDEO' && $candidate !== '') $videoUrl = $candidate;
    }
    foreach ($productLinks as $pl) {
        if (!is_array($pl) || ($pl['type'] ?? '') !== 'MEDIA') continue;
        $candidateMedia = trim((string)($pl['url'] ?? ''));
        // The XTREME TITAN logo is branding only; never render it as a giant product poster.
        if (preg_match('~(?:^|/)(?:xtreme-titan-logo\.jpg|tanofficial_neon_background\.(?:gif|mp4)|payment-(?:paypal|bkash|nagad)\.svg)(?:$|\?)~i', $candidateMedia)) continue;
        $mediaUrl = $candidateMedia;
        break;
    }
    if ($mediaUrl === '') {
        foreach ($productLinks as $pl) {
            if (!is_array($pl) || ($pl['type'] ?? '') !== 'SETUP') continue;
            $candidateMedia = trim((string)($pl['url'] ?? ''));
            if (preg_match('~(?:^|/)(?:xtreme-titan-logo\.jpg|tanofficial_neon_background\.(?:gif|mp4)|payment-(?:paypal|bkash|nagad)\.svg)(?:$|\?)~i', $candidateMedia)) continue;
            $mediaUrl = $candidateMedia;
            break;
        }
    }
    if ($imageUrl !== '') $mediaUrl = $imageUrl;
    elseif ($videoUrl !== '') $mediaUrl = $videoUrl;
    ?>
    <div class="product-image xt-inline-media" data-inline-media>
        <?php
        $lowerMedia = strtolower(parse_url($mediaUrl, PHP_URL_PATH) ?? '');
        $isDirectVideo = (bool)preg_match('/\.(mp4|webm|ogg|mov)$/i', $lowerMedia);
        $isYoutube = (bool)preg_match('/(?:youtube\.com\/(?:watch\?v=|shorts\/|embed\/)|youtu\.be\/)/i', $mediaUrl);
        $isVimeo = (bool)preg_match('/vimeo\.com\//i', $mediaUrl);
        $videoEmbed = '';
        if ($isYoutube) {
            if (preg_match('~youtu\.be/([A-Za-z0-9_-]{6,})~', $mediaUrl, $ym)) $videoEmbed = 'https://www.youtube-nocookie.com/embed/'.$ym[1].'?autoplay=1';
            elseif (preg_match('~youtube\.com/(?:watch\?v=|shorts/|embed/)([A-Za-z0-9_-]{6,})~', $mediaUrl, $ym)) $videoEmbed = 'https://www.youtube-nocookie.com/embed/'.$ym[1].'?autoplay=1';
        } elseif ($isVimeo && preg_match('~vimeo\.com/(?:video/)?([0-9]+)~', $mediaUrl, $vm)) {
            $videoEmbed = 'https://player.vimeo.com/video/'.$vm[1].'?autoplay=1';
        }
        $inlineVideo = $videoUrl !== '' ? $videoUrl : (($isDirectVideo || $isYoutube || $isVimeo) ? $mediaUrl : '');
        $inlineIsDirect = $inlineVideo !== '' && (bool)preg_match('/\.(mp4|webm|ogg|mov)$/i', strtolower(parse_url($inlineVideo, PHP_URL_PATH) ?? ''));
        $inlineEmbed = '';
        if ($inlineVideo !== '' && !$inlineIsDirect) {
            if (preg_match('~(?:youtube\.com/(?:watch\?v=|shorts/|embed/)|youtu\.be/)~i', $inlineVideo)) {
                if (preg_match('~youtu\.be/([A-Za-z0-9_-]{6,})~', $inlineVideo, $ym)) $inlineEmbed = 'https://www.youtube-nocookie.com/embed/'.$ym[1].'?autoplay=1';
                elseif (preg_match('~youtube\.com/(?:watch\?v=|shorts/|embed/)([A-Za-z0-9_-]{6,})~', $inlineVideo, $ym)) $inlineEmbed = 'https://www.youtube-nocookie.com/embed/'.$ym[1].'?autoplay=1';
            } elseif (preg_match('~vimeo\.com/(?:video/)?([0-9]+)~', $inlineVideo, $vm)) $inlineEmbed = 'https://player.vimeo.com/video/'.$vm[1].'?autoplay=1';
        }
        $posterUrl = $imageUrl !== '' ? $imageUrl : (($inlineVideo === '' ? $mediaUrl : ''));
        ?>
        <?php if ($posterUrl !== ''): ?>
            <img class="product-media xt-inline-poster" src="<?= h($posterUrl) ?>" alt="<?= h($product['name']) ?>" loading="lazy">
        <?php else: ?>
            <div class="product-media-link">🔑</div>
        <?php endif; ?>
        <?php if ($inlineVideo !== ''): ?>
            <button type="button" class="xt-inline-play" aria-label="Play <?= h($product['name']) ?> video" data-video="<?= h($inlineVideo) ?>" data-embed="<?= h($inlineEmbed) ?>">▶</button>
        <?php endif; ?>
        <?php $topLeftTags = array_values(array_intersect(['SAFE','RISK','UPDATING','TESTING'], array_map('strtoupper', array_filter(array_map('trim', explode(',', (string)($productLinks['STATUS_TAGS'] ?? ''))))))); ?>
        <?php if ($topLeftTags): ?><div class="xt-product-tags" aria-label="Product status badges"><?php foreach ($topLeftTags as $tag): ?><span class="xt-product-tag tag-<?= strtolower(h($tag)) ?>"><?= h($tag) ?></span><?php endforeach; ?></div><?php endif; ?>
        <div class="xt-product-status <?= ((int)($product['live_status'] ?? 1) === 1) ? 'is-online' : 'is-maintenance' ?>" aria-label="<?= ((int)($product['live_status'] ?? 1) === 1) ? 'Online' : 'Maintenance' ?>">
          <span class="xt-status-dot"></span>
          <span><?= ((int)($product['live_status'] ?? 1) === 1) ? 'ONLINE' : 'MAINTENANCE' ?></span>
          <?php if ((int)($product['live_status'] ?? 1) !== 1): ?><span class="xt-maintenance-countdown" aria-label="Maintenance countdown" data-countdown-start="<?= (int)(microtime(true) * 1000) ?>">3</span><?php endif; ?>
        </div>
    </div>
    
    <script>
    document.addEventListener('click', function(ev){
      const btn = ev.target.closest('.xt-inline-play');
      if(!btn) return;
      const wrap = btn.closest('[data-inline-media]');
      if(!wrap || wrap.dataset.playing === '1') return;
      const url = btn.getAttribute('data-video') || '';
      const embed = btn.getAttribute('data-embed') || '';
      if(!url) return;
      wrap.dataset.playing = '1';
      const media = embed ? document.createElement('iframe') : document.createElement('video');
      if(embed){ media.src = embed; media.allow='autoplay; fullscreen; picture-in-picture'; media.allowFullscreen=true; media.title='Product video'; }
      else { media.src=url; media.controls=true; media.playsInline=true; media.preload='metadata'; media.autoplay=true; }
      media.setAttribute('aria-label','Product video');
      wrap.querySelector('.xt-inline-poster')?.remove();
      btn.remove();
      wrap.appendChild(media);
      if(!embed){ const p=media.play(); if(p && p.catch) p.catch(()=>{media.controls=true;}); }
    });
    </script>

    <h2 class="product-name">
        <?= h($product['name']) ?>
    </h2>
    <div class="product-badges">
        <span class="product-badge type-badge"><?= h(strtoupper((string)($product['category'] ?? 'PRO'))) ?></span>
        <?php if (strtoupper((string)($product['platform'] ?? 'ALL')) !== 'ALL'): ?>
            <span class="product-badge platform-badge"><?= h((function($v){$m=['ANDROID_NONROOT'=>'Android Non Root','IPHONE'=>'Apple iOS Product','ANDROID_ROOT'=>'Android Root','PC_PANEL_FF'=>'PC PANEL FF','LIVE_KEY'=>'LIVE KEYS'];$parts=array_map('trim',explode(',',strtoupper((string)$v)));return implode(' + ',array_map(static fn($p)=>$m[$p]??$p,$parts));})(strtoupper((string)$product['platform'])) ) ?></span>
        <?php endif; ?>
        <?php if ((int)($product['live_status'] ?? 1) === 1): ?>
            <span class="product-badge live-badge">● LIVE</span>
        <?php endif; ?>
    </div>


        <?php
      $featureCards = [];
      foreach (preg_split('/\R/', $productDescription) ?: [] as $featureLine) {
        if (preg_match('/^\s*\[FEATURE_ON\]\s*(.*?)\s*$/i', $featureLine, $fm) && trim($fm[1]) !== '') $featureCards[] = trim($fm[1]);
      }
      $visibleDescription = trim((string)preg_replace('/^\s*\[(UPDATE|SETUP|LINK|MEDIA|IMAGE|VIDEO|GROUP|SETUP_LABEL|GROUP_LABEL|EXTRA1|EXTRA1_LABEL|EXTRA1_ON|EXTRA2|EXTRA2_LABEL|EXTRA2_ON|FEATURE_ON|FEATURE_OFF|STATUS_TAGS)\]\s*.*?\s*$/im', '', $productDescription));
    ?>
    <?php if ($featureCards): ?>
      <div class="xt-feature-cards"><?php foreach ($featureCards as $featureText): ?><span class="xt-feature-card"><?= h($featureText) ?></span><?php endforeach; ?></div>
    <?php endif; ?>
    <?php if ($visibleDescription !== ''): ?><div class="product-description"><?= h($visibleDescription) ?></div><?php endif; ?>
    
    <?php
    $setupUrl = ''; $groupUrl = ''; $setupLabel = '🎥 Setup Video'; $groupLabel = '👥 Join Product Group';
    foreach ($productLinks as $pl) {
        if (!is_array($pl)) continue;
        if (($pl['type'] ?? '') === 'SETUP' && $setupUrl === '') $setupUrl = $pl['url'];
        if (($pl['type'] ?? '') === 'MEDIA' && $setupUrl === '') $setupUrl = $pl['url'];
        if (($pl['type'] ?? '') === 'GROUP') $groupUrl = $pl['url'];
    }
    $setupLabel = !empty($productLinks['SETUP_LABEL']) ? $productLinks['SETUP_LABEL'] : $setupLabel;
    $groupLabel = !empty($productLinks['GROUP_LABEL']) ? $productLinks['GROUP_LABEL'] : $groupLabel;
    $extra1Url = ''; $extra2Url = '';
    foreach ($productLinks as $pl) { if (is_array($pl) && ($pl['type'] ?? '') === 'EXTRA1') $extra1Url = $pl['url']; if (is_array($pl) && ($pl['type'] ?? '') === 'EXTRA2') $extra2Url = $pl['url']; }
    $extra1Label = !empty($productLinks['EXTRA1_LABEL']) ? $productLinks['EXTRA1_LABEL'] : '📁 Download File';
    $extra2Label = !empty($productLinks['EXTRA2_LABEL']) ? $productLinks['EXTRA2_LABEL'] : '🔗 More Info';
    $extra1On = (($productLinks['EXTRA1_ON'] ?? '0') === '1');
    $extra2On = (($productLinks['EXTRA2_ON'] ?? '0') === '1');
    ?>
    <div class="product-action-row">
        <?php if ($setupUrl !== ''): ?><a class="product-action setup-action" href="<?= h($setupUrl) ?>" target="_blank" rel="noopener noreferrer" data-auto-button-label="1" data-original-button-label="<?= h($setupLabel) ?>"><?= h($setupLabel) ?></a><?php else: ?><span class="product-action setup-action disabled" data-auto-button-label="1" data-original-button-label="<?= h($setupLabel) ?>"><?= h($setupLabel) ?></span><?php endif; ?>
        <?php if ($groupUrl !== ''): ?><a class="product-action group-action" href="<?= h($groupUrl) ?>" target="_blank" rel="noopener noreferrer" data-auto-button-label="1" data-original-button-label="<?= h($groupLabel) ?>"><?= h($groupLabel) ?></a><?php else: ?><span class="product-action group-action disabled" data-auto-button-label="1" data-original-button-label="<?= h($groupLabel) ?>"><?= h($groupLabel) ?></span><?php endif; ?>
        <?php if ($extra1On): ?><?php if ($extra1Url !== ''): ?><a class="product-action extra1-action" href="<?= h($extra1Url) ?>" target="_blank" rel="noopener noreferrer" data-auto-button-label="1" data-original-button-label="<?= h($extra1Label) ?>"><?= h($extra1Label) ?></a><?php else: ?><span class="product-action extra1-action disabled" title="Add a link in Admin Product Editor" data-auto-button-label="1" data-original-button-label="<?= h($extra1Label) ?>"><?= h($extra1Label) ?></span><?php endif; ?><?php endif; ?>
        <?php if ($extra2On): ?><?php if ($extra2Url !== ''): ?><a class="product-action extra2-action" href="<?= h($extra2Url) ?>" target="_blank" rel="noopener noreferrer" data-auto-button-label="1" data-original-button-label="<?= h($extra2Label) ?>"><?= h($extra2Label) ?></a><?php else: ?><span class="product-action extra2-action disabled" title="Add a link in Admin Product Editor" data-auto-button-label="1" data-original-button-label="<?= h($extra2Label) ?>"><?= h($extra2Label) ?></span><?php endif; ?><?php endif; ?>
    </div>


    <?php if (!$productPlans): ?>

        <div class="empty">

            <div class="empty-title">
                No plans available
            </div>

        </div>

    <?php else: ?>

    <button type="button" class="xt-purchase-toggle <?= ((int)($product['live_status'] ?? 1) !== 1) ? 'is-maintenance-purchase' : '' ?>" aria-expanded="false" data-maintenance="<?= ((int)($product['live_status'] ?? 1) !== 1) ? '1' : '0' ?>" onclick="requestProductPurchase(this)"><?php if ((int)($product['live_status'] ?? 1) !== 1): ?><span>MAINTENANCE</span><?php else: ?>PURCHASE KEY 🔑<?php endif; ?></button>

    <div class="plan-list" hidden>


    <?php foreach ($productPlans as $plan): ?>

    <?php

    $planId =
        (int)$plan['id'];

    $duration =
        (int)$plan['duration_days'];

    $label =
        trim((string)$plan['duration_label']);

    if ($label === '') {
        $label = $duration . ' Days';
    }

    $originalPrice = (float)$plan['price'];
    $price = $originalPrice * (1 - $productResellerDiscount / 100);

    $available =
        (int)$plan['available_keys'];

    $hasStock =
        $available > 0;

    ?>

    <div
        class="plan <?= $hasStock ? '' : 'out' ?>"
        data-plan-type="<?= h(strtoupper((string)($plan['plan_type'] ?? 'PRO'))) ?>"
        data-plan-id="<?= $planId ?>"
        data-price="<?= h($price) ?>"
        data-stock="<?= $available ?>"
        onclick="if(!event.target.closest('button')) selectPlan(this);"
    >
        <div class="plan-info">
            <div class="plan-duration-line">
                <span class="plan-type-pill <?= strtolower((string)($plan['plan_type'] ?? 'PRO'))==='basic'?'basic':(strtolower((string)($plan['plan_type'] ?? 'PRO'))==='normal'?'normal':'pro') ?>"><?= h(strtoupper((string)($plan['plan_type'] ?? 'PRO'))) ?></span>
                <span class="plan-duration"><?= h($label) ?></span>
            </div>
            <div class="plan-price">
                <?php if ($userRole === 'reseller' && $productResellerDiscount > 0): ?>
                    <span class="plan-original-price" data-currency-amount="<?=h($originalPrice)?>"><?=h(number_format($originalPrice,2))?></span>
                <?php endif; ?>
                <span data-currency-amount="<?=h($price)?>"><?=h(number_format($price,2))?></span>
            </div>
            <div class="xt-live-key-stock-status <?= $hasStock ? 'is-available' : 'is-out' ?>" data-live-stock-label="<?= $hasStock ? 'available' : 'out' ?>">
                <?= $hasStock ? 'স্টক আছে' : 'স্টক নেই' ?>
            </div>
            <?php if (!$hasStock): ?>
                <div class="plan-stock plan-out-of-stock">Out of stock</div>
            <?php endif; ?>
        </div>
        <div class="plan-get-controls">
            <div class="plan-quantity" aria-label="Select quantity">
                <button type="button" class="plan-qty-btn" aria-label="Decrease quantity" <?= !$hasStock ? 'disabled' : '' ?> onclick="changePlanQty(this,-1);event.stopPropagation();">−</button>
                <span class="plan-qty-number">1</span>
                <button type="button" class="plan-qty-btn" aria-label="Increase quantity" <?= !$hasStock ? 'disabled' : '' ?> onclick="changePlanQty(this,1);event.stopPropagation();">+</button>
            </div>
            <button type="button" class="plan-get-btn" <?= !$hasStock ? 'disabled' : '' ?> onclick="getPlan(this);event.stopPropagation();">GET</button>
        </div>
    </div>

    <?php endforeach; ?>


    </div>


    <div class="buy-area" hidden>


        <div class="quantity">

            <button
                type="button"
                class="qty-btn"
                onclick="event.stopPropagation(); changeQty(this, -1)"
            >
                −
            </button>


            <div class="qty-number">
                1
            </div>


            <button
                type="button"
                class="qty-btn"
                onclick="event.stopPropagation(); changeQty(this, 1)"
            >
                +
            </button>

        </div>


        <div class="total">

            Total:
            <strong class="total-value">
                Select a plan
            </strong>

        </div>


        <button
            type="button"
            class="buy-btn"
            onclick="event.stopPropagation(); buyProduct(this)"
        >
            BUY / CONFIRM
        </button>


    </div>


    <?php endif; ?>


</section>

<?php endforeach; ?>


<?php endif; ?>


</main>


<!-- -------------------------------------------------------
     CONFIRM MODAL
-------------------------------------------------------- -->

<div class="modal xt-license-order-modal" id="confirmModal" aria-hidden="true">
  <div class="modal-box xt-license-order-box" role="dialog" aria-modal="true" aria-labelledby="xtLicenseOrderTitle">
    <div class="xt-license-order-topline"></div>
    <div class="xt-license-order-heading">
      <div id="xtLicenseOrderTitle">🛡️ লাইসেন্স চাবি অর্ডার</div>
      <button type="button" class="xt-license-order-close" onclick="closeModal()" aria-label="Close">×</button>
    </div>
    <div class="modal-text xt-license-order-content" id="confirmText" aria-live="polite"></div>
    <div class="modal-actions xt-license-order-actions">
      <button type="button" class="modal-btn close-btn" onclick="closeModal()">বাতিল</button>
      <button type="button" class="modal-btn xt-deposit-btn" id="xtDepositNow" onclick="window.location.href='deposit.php'">▣ এখনই ডিপোজিট করুন</button>
      <button type="button" class="modal-btn confirm-btn" id="confirmBuy">নিশ্চিত করুন</button>
    </div>
  </div>
</div>

<!-- -------------------------------------------------------
     BOTTOM NAV
-------------------------------------------------------- -->

<nav class="xt-bottom-navigation-card xt-nav-store" aria-label="Main navigation">
<a href="store.php" class="is-active" data-nav="store" aria-label="Store"><span class="xt-nav-icon"><img src="assets/nav-icons/store.png" alt="" aria-hidden="true"></span><span class="xt-nav-label">Store</span></a>
<a href="my-keys.php" data-nav="keys" aria-label="My Keys"><span class="xt-nav-icon"><img src="assets/nav-icons/keys.png" alt="" aria-hidden="true"></span><span class="xt-nav-label">My Keys</span></a>
<a href="deposit.php" data-nav="funds" aria-label="Add Funds"><span class="xt-nav-icon"><img src="assets/nav-icons/funds.png" alt="" aria-hidden="true"></span><span class="xt-nav-label">Add Funds</span></a>
<a href="history.php" data-nav="history" aria-label="History"><span class="xt-nav-icon"><img src="assets/nav-icons/history.png" alt="" aria-hidden="true"></span><span class="xt-nav-label">History</span></a>
<a href="profile.php" data-nav="profile" aria-label="Profile"><span class="xt-nav-icon"><img src="assets/nav-icons/profile.png" alt="" aria-hidden="true"></span><span class="xt-nav-label">Profile</span></a>
</nav>

<script>


function requestProductPurchase(button){
    if(button.dataset.maintenance !== '1'){
        toggleProductPlans(button);
        return;
    }
    let modal=document.getElementById('xt-maintenance-confirm');
    if(!modal){
        modal=document.createElement('div');
        modal.id='xt-maintenance-confirm';
        modal.className='xt-maintenance-overlay';
        modal.innerHTML='<section class="xt-maintenance-dialog" role="dialog" aria-modal="true" aria-labelledby="xt-maintenance-title"><div class="xt-maintenance-icon"><span class="xt-status-dot"></span></div><h2 id="xt-maintenance-title">Product Maintenance</h2><p>This product is currently under maintenance. Do you still want to continue with the purchase?</p><div class="xt-maintenance-actions"><button type="button" class="xt-maintenance-cancel">Cancel</button><button type="button" class="xt-maintenance-continue">Continue</button></div></section>';
        document.body.appendChild(modal);
        modal.addEventListener('click',function(ev){
            if(ev.target===modal || ev.target.closest('.xt-maintenance-cancel')) modal.remove();
            if(ev.target.closest('.xt-maintenance-continue')){
                const target=modal._purchaseButton;
                modal.remove();
                if(target) toggleProductPlans(target);
            }
        });
        document.addEventListener('keydown',function(ev){if(ev.key==='Escape'){const m=document.getElementById('xt-maintenance-confirm');if(m)m.remove();}});
    }
    modal._purchaseButton=button;
    modal.style.display='flex';
}

function toggleProductPlans(button){
    const product = button.closest('.product');
    if(!product) return;
    const list = product.querySelector('.plan-list');
    const buyArea = product.querySelector('.buy-area');
    const opening = !!(list && list.hidden);
    if(list) list.hidden = !opening;
    if(buyArea) buyArea.hidden = true;
    button.setAttribute('aria-expanded', opening ? 'true' : 'false');
    button.textContent = opening ? 'HIDE PLANS ▲' : 'PURCHASE KEY 🔑';
    if(opening && list) {
        list.scrollTop = 0;
        /* Bring the newly opened plan choices into the middle of the phone screen. */
        window.requestAnimationFrame(function(){
            window.setTimeout(function(){
                try {
                    list.scrollIntoView({behavior:'smooth', block:'center', inline:'nearest'});
                } catch(e) {
                    list.scrollIntoView();
                }
            }, 80);
        });
    }
}

let selectedPlan = null;
let selectedProduct = null;
let selectedQuantity = 1;


/*
|--------------------------------------------------------------------------
| SELECT PLAN
|--------------------------------------------------------------------------
*/

function changePlanQty(button, amount){
    const plan = button.closest('.plan');
    if(!plan || plan.classList.contains('out')) return;
    const stock = Math.max(0, parseInt(plan.dataset.stock || '0', 10));
    const maxQty = Math.min(10, stock);
    const display = plan.querySelector('.plan-qty-number');
    if(!display || maxQty < 1) return;
    let qty = parseInt(display.textContent || '1', 10) || 1;
    qty = Math.max(1, Math.min(maxQty, qty + amount));
    display.textContent = String(qty);
}

function xtPlanLanguage(){
    try { return (localStorage.getItem('xtreme_language') || document.documentElement.lang || 'bn').toLowerCase().split('-')[0]; }
    catch(e){ return 'bn'; }
}
function xtTranslatePlanLabels(){
    const lang=xtPlanLanguage();
    const words={
      bn:{normal:'নরমাল',pro:'প্রো',basic:'বেসিক',hour:'ঘণ্টা',hours:'ঘণ্টা',day:'দিন',days:'দিন',week:'সপ্তাহ',weeks:'সপ্তাহ',month:'মাস',months:'মাস',get:'নিন',out:'স্টক শেষ',quantity:'পরিমাণ নির্বাচন করুন'},
      en:{normal:'NORMAL',pro:'PRO',basic:'BASIC',hour:'HOUR',hours:'HOURS',day:'DAY',days:'DAYS',week:'WEEK',weeks:'WEEKS',month:'MONTH',months:'MONTHS',get:'GET',out:'Out of stock',quantity:'Select quantity'},
      it:{normal:'NORMALE',pro:'PRO',basic:'BASE',hour:'ORA',hours:'ORE',day:'GIORNO',days:'GIORNI',week:'SETTIMANA',weeks:'SETTIMANE',month:'MESE',months:'MESI',get:'ACQUISTA',out:'Esaurito',quantity:'Seleziona quantità'}
    };
    const t=words[lang]||words.en;
    document.querySelectorAll('.product .plan-type-pill').forEach(el=>{
      const key=(el.textContent||'').trim().toLowerCase();
      if(t[key]) el.textContent=t[key];
    });
    document.querySelectorAll('.product .plan-duration').forEach(el=>{
      let value=el.textContent||'';
      const map={HOURS:t.hours,HOUR:t.hour,DAYS:t.days,DAY:t.day,WEEKS:t.weeks,WEEK:t.week,MONTHS:t.months,MONTH:t.month};
      Object.keys(map).sort((a,b)=>b.length-a.length).forEach(k=>{
        value=value.replace(new RegExp('\\\\b'+k+'\\\\b','gi'),map[k]);
      });
      el.textContent=value;
    });
    document.querySelectorAll('.product .plan-stock.plan-out-of-stock').forEach(el=>el.textContent=t.out);
    document.querySelectorAll('.product .plan-get-btn').forEach(el=>{ if(!el.disabled) el.textContent=t.get; });
    document.querySelectorAll('.product .plan-quantity').forEach(el=>el.setAttribute('aria-label',t.quantity));
}
function getPlan(button){
    const plan = button.closest('.plan');
    if(!plan || plan.classList.contains('out')) return;
    selectPlan(plan);
    /* Keep the selected plan visible so the user sees which plan was tapped. */
    try {
        plan.scrollIntoView({behavior:'smooth', block:'center', inline:'nearest'});
    } catch(e) {
        plan.scrollIntoView();
    }
    /* Let the scroll finish first; then show the order confirmation. */
    window.setTimeout(function(){ buyProduct(button); }, 280);
}

function selectPlan(planElement){

    if(!planElement){
        return;
    }

    const stock =
        parseInt(
            planElement.dataset.stock || '0',
            10
        );

    if(stock <= 0){
        return;
    }

    const product =
        planElement.closest('.product');

    if(!product){
        return;
    }


    /*
     * Remove selection from ONLY this product.
     */
    product
        .querySelectorAll('.plan')
        .forEach(function(item){

            item.classList.remove('selected');

        });


    planElement.classList.add('selected');


    selectedPlan = {
        id: parseInt(
            planElement.dataset.planId,
            10
        ),

        price: parseFloat(
            planElement.dataset.price
        ),

        stock: stock
    };


    selectedProduct =
        parseInt(
            product.dataset.productId,
            10
        );


    selectedQuantity = 1;


    const quantityElement =
        product.querySelector('.qty-number');

    if(quantityElement){
        quantityElement.textContent = '1';
    }


    updateTotal(product);
}


/*
|--------------------------------------------------------------------------
| QUANTITY
|--------------------------------------------------------------------------
*/

function changeQty(button, amount){

    if(!button){
        return;
    }

    const product =
        button.closest('.product');

    if(!product){
        return;
    }


    const selected =
        product.querySelector('.plan.selected');

    if(!selected){
        return;
    }


    const stock =
        parseInt(
            selected.dataset.stock || '0',
            10
        );


    let current =
        parseInt(
            product
                .querySelector('.qty-number')
                .textContent || '1',
            10
        );


    current += amount;


    if(current < 1){
        current = 1;
    }


    if(stock > 0 && current > stock){
        current = stock;
    }


    product
        .querySelector('.qty-number')
        .textContent = current;


    selectedQuantity = current;


    updateTotal(product);
}


/*
|--------------------------------------------------------------------------
| TOTAL
|--------------------------------------------------------------------------
*/

function updateTotal(product){

    const total =
        product.querySelector('.total-value');

    const selected =
        product.querySelector('.plan.selected');

    if(!selected){

        total.textContent =
            'Select a plan';

        return;
    }


    const price =
        parseFloat(
            selected.dataset.price || '0'
        );


    const quantity =
        parseInt(
            product
                .querySelector('.qty-number')
                .textContent || '1',
            10
        );


    const amount =
        price * quantity;


    total.textContent = window.XtremeCurrency ? window.XtremeCurrency.format(amount) : ('৳' + amount.toFixed(2));
}


/*
|--------------------------------------------------------------------------
| BUY
|--------------------------------------------------------------------------
*/

function buyProduct(button){

    const product =
        button.closest('.product');

    if(!product){
        return;
    }


    const selected =
        product.querySelector('.plan.selected');


    /*
     * THIS fixes:
     * "Please select a plan first"
     */

    if(!selected){

        showModal(
            'Please select a plan first.'
        );

        return;
    }


    const stock =
        parseInt(
            selected.dataset.stock || '0',
            10
        );


    if(stock <= 0){

        showModal(
            'This plan is out of stock.'
        );

        return;
    }


    const planId =
        parseInt(
            selected.dataset.planId,
            10
        );


    const productId =
        parseInt(
            product.dataset.productId,
            10
        );


    const price =
        parseFloat(
            selected.dataset.price || '0'
        );


    const quantityNode = selected.querySelector('.plan-qty-number');
    const quantity = Math.max(1, Math.min(10, parseInt(quantityNode ? quantityNode.textContent : '1', 10) || 1));


    const total =
        price * quantity;


    selectedProduct =
        productId;

    selectedPlan = {
        id: planId,
        price: price,
        stock: stock
    };

    selectedQuantity =
        quantity;


    const formattedTotal = window.XtremeCurrency ? window.XtremeCurrency.format(total) : ('৳' + total.toLocaleString('en-BD',{minimumFractionDigits:2,maximumFractionDigits:2}));
    const balance = Math.max(0, Number(<?= json_encode((float)$dashBalance) ?>) || 0);
    const shortage = Math.max(0, total - balance);
    const fmt = (v) => window.XtremeCurrency ? window.XtremeCurrency.format(v) : ('৳' + Number(v).toFixed(2));
    const escapeHtml = (v) => String(v).replace(/[&<>"']/g, ch => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[ch]));
    const productName = product.querySelector('.product-name')?.textContent.trim() || 'Product';
    const planName = selected.querySelector('.plan-duration')?.textContent.trim() || 'Selected plan';
    const planType = selected.querySelector('.plan-type-pill')?.textContent.trim() || '';
    const productImage = product.querySelector('.xt-inline-poster')?.getAttribute('src') || '';
    const lang = (() => { try { return (localStorage.getItem('xtreme_language') || document.documentElement.lang || 'bn').toLowerCase().split('-')[0]; } catch(e) { return 'bn'; } })();
    const translations = {
      bn:{quantity:'পরিমাণ',price:'প্ল্যানের মূল্য',balance:'আপনার বর্তমান ব্যালেন্স',shortage:'ব্যালেন্স ঘাটতি',warning:'আপনার ওয়ালেটে পর্যাপ্ত ব্যালেন্স নেই। ডিপোজিট করলে সাথে সাথে চাবি কিনতে পারবেন।',success:'আপনার ব্যালেন্স যথেষ্ট। অর্ডার নিশ্চিত করতে নিচের বাটনে চাপ দিন।',cancel:'বাতিল',deposit:'এখনই ডিপোজিট করুন',confirm:'নিশ্চিত করুন',title:'লাইসেন্স চাবি অর্ডার'},
      en:{quantity:'Quantity',price:'Plan price',balance:'Your current balance',shortage:'Balance shortage',warning:'Your wallet balance is insufficient. Deposit now to purchase the key.',success:'Your balance is sufficient. Press Confirm Order below to continue.',cancel:'Cancel',deposit:'Deposit now',confirm:'Confirm order',title:'License Key Order'},
      it:{quantity:'Quantità',price:'Prezzo del piano',balance:'Saldo attuale',shortage:'Saldo mancante',warning:'Il saldo del portafoglio non è sufficiente. Ricarica per acquistare la chiave.',success:'Il saldo è sufficiente. Premi Conferma ordine per continuare.',cancel:'Annulla',deposit:'Ricarica ora',confirm:'Conferma ordine',title:'Ordine chiave licenza'}
    };
    const tr = translations[lang] || translations.en;
    document.getElementById('xtLicenseOrderTitle').textContent = '🛡️ ' + tr.title;
    document.querySelector('.xt-license-order-actions .close-btn').textContent = tr.cancel;
    document.getElementById('xtDepositNow').textContent = '▣ ' + tr.deposit;
    document.getElementById('confirmBuy').textContent = tr.confirm;
    const confirmText = document.getElementById('confirmText');
    confirmText.innerHTML = `
      <div class="xt-order-product">
        ${productImage ? `<img src="${escapeHtml(productImage)}" alt="">` : `<div class="xt-order-placeholder">🔑</div>`}
        <div class="xt-order-product-meta">
          <div class="xt-order-product-name">🩸 ${escapeHtml(productName)} 🩸</div>
          <div class="xt-order-plan-chip">◷ ${escapeHtml(planName)} · ${escapeHtml(planType)}</div>
          <div class="xt-order-qty">${escapeHtml(tr.quantity)}: ${quantity}</div>
        </div>
      </div>
      <div class="xt-order-summary">
        <div><span>${escapeHtml(tr.price)}</span><strong class="price">${escapeHtml(fmt(total))}</strong></div>
        <div><span>${escapeHtml(tr.balance)}</span><strong>${escapeHtml(fmt(balance))}</strong></div>
        <div><span>${escapeHtml(tr.shortage)}</span><strong class="${shortage > 0 ? 'shortage' : 'covered'}">${shortage > 0 ? '− ' + escapeHtml(fmt(shortage)) : escapeHtml(fmt(0))}</strong></div>
      </div>
      ${shortage > 0 ? `<div class="xt-order-warning">❗ ${escapeHtml(tr.warning)}</div>` : `<div class="xt-order-success">✓ ${escapeHtml(tr.success)}</div>`}
    `;
    const depositBtn = document.getElementById('xtDepositNow');
    const confirmBtn = document.getElementById('confirmBuy');
    depositBtn.hidden = shortage <= 0;
    confirmBtn.hidden = shortage > 0;


    document.getElementById(
        'confirmBuy'
    ).onclick = function(){

        /*
         * Send purchase to buy.php
         *
         * product_id
         * plan_id
         * quantity
         */

        const form =
            document.createElement('form');

        form.method =
            'POST';

        form.action =
            'buy.php';


        const fields = {
            csrf: <?= json_encode($buyCsrf) ?>,
            product_id: selectedProduct,
            plan_id: selectedPlan.id,
            quantity: selectedQuantity
        };


        Object.keys(fields).forEach(
            function(name){

                const input =
                    document.createElement(
                        'input'
                    );

                input.type =
                    'hidden';

                input.name =
                    name;

                input.value =
                    fields[name];

                form.appendChild(
                    input
                );
            }
        );


        document.body.appendChild(
            form
        );

        form.submit();
    };


    document.getElementById('confirmModal').classList.add('show');
    document.getElementById('confirmModal').setAttribute('aria-hidden','false');
}


/*
|--------------------------------------------------------------------------
| MODAL
|--------------------------------------------------------------------------
*/

function showModal(message){

    document.getElementById(
        'confirmText'
    ).textContent = message;


    document.getElementById('confirmBuy').style.display = 'none';
    document.getElementById('xtDepositNow').hidden = true;
    document.getElementById('confirmModal').classList.add('show');
    document.getElementById('confirmModal').setAttribute('aria-hidden','false');
}


function closeModal(){

    document.getElementById('confirmModal').classList.remove('show');
    document.getElementById('confirmModal').setAttribute('aria-hidden','true');
    document.getElementById('confirmBuy').style.display = '';
    document.getElementById('xtDepositNow').hidden = true;
}


/*
|--------------------------------------------------------------------------
| CLICK OUTSIDE MODAL
|--------------------------------------------------------------------------
*/

document.getElementById(
    'confirmModal'
).addEventListener(
    'click',
    function(event){

        if(
            event.target === this
        ){
            closeModal();
        }

    }
);


try {
  if(document.readyState==='loading') document.addEventListener('DOMContentLoaded',xtTranslatePlanLabels,{once:true});
  else xtTranslatePlanLabels();
  window.addEventListener('storage',function(e){if(e.key==='xtreme_language') xtTranslatePlanLabels();});
} catch(e) {}
</script>


<script>
(function(){
 function syncStoreTheme(){
   var t=document.documentElement.getAttribute('data-theme')||'premium';
   document.body.setAttribute('data-store-theme',t);
 }
 document.addEventListener('DOMContentLoaded',syncStoreTheme);
 window.addEventListener('xtreme-theme-change',syncStoreTheme);
 window.addEventListener('storage',function(e){if(e.key==='xtreme_theme')syncStoreTheme();});
})();
</script>
<script>
(function(){
  function syncStoreTheme(){
    var t=document.documentElement.getAttribute('data-theme')||'premium';
    document.body.setAttribute('data-store-theme',t);
  }
  document.addEventListener('DOMContentLoaded',syncStoreTheme);
  window.addEventListener('xtreme-theme-change',syncStoreTheme);
  window.addEventListener('storage',function(e){if(e.key==='xtreme_theme')syncStoreTheme();});
})();
</script>
<script src="background-video.js?v=20261018-starfall2"></script>











<!-- XTREME TITAN OFFICIAL floating Live Message launcher -->

<div id="xtLiveChat">
  <div class="xt-chat-bubble" id="xtChatBubble" role="status" aria-live="polite">Need help? Live Chat is here!</div>
  <a class="xt-chat-launch" href="messages.php" aria-label="Open Live Message" title="Live Message">
    <svg viewBox="0 0 24 24" fill="none" aria-hidden="true"><path d="M20.2 11.5a8.1 8.1 0 0 1-8.3 7.9 9 9 0 0 1-3.4-.7L3 20l1.4-4.2a7.5 7.5 0 0 1-1.2-4.1A8.2 8.2 0 0 1 11.6 4a8.3 8.3 0 0 1 8.6 7.5Z" fill="white" fill-opacity=".14" stroke="white" stroke-width="1.7" stroke-linejoin="round"/><path d="M7.5 10.1h9M7.5 13.5h6" stroke="white" stroke-width="1.7" stroke-linecap="round"/></svg>
  </a>
</div>
<script>
(()=>{const bubble=document.getElementById('xtChatBubble');if(!bubble)return;let intervalMs=90000,durationMs=6000,settings=null,timer=null;const language=()=>{try{return (localStorage.getItem('xtreme_language')||document.documentElement.lang||'en').toLowerCase().split('-')[0]}catch(e){return 'en'}};const message=()=>String((settings&&settings.popup_text)||'Need help? Live Chat is here!');const show=()=>{bubble.textContent=message();bubble.classList.add('show');setTimeout(()=>bubble.classList.remove('show'),durationMs)};const start=()=>{if(timer)clearInterval(timer);timer=setInterval(show,intervalMs);setTimeout(show,12000)};window.addEventListener('storage',e=>{if(e.key==='xtreme_language'&&bubble.classList.contains('show'))bubble.textContent=message()});const loadSettings=()=>{const lang=language();fetch('messages.php?action=widget_config&lang='+encodeURIComponent(lang),{cache:'no-store',credentials:'same-origin'}).then(r=>r.json()).then(d=>{if(d.ok&&d.settings){settings=d.settings;intervalMs=Math.max(60000,Math.min(7200000,Number(settings.interval_seconds||90)*1000));durationMs=Math.max(3000,Math.min(15000,Number(settings.duration_seconds||6)*1000));if(bubble.classList.contains('show'))bubble.textContent=settings.popup_text||'Need help? Live Chat is here!'}start()}).catch(()=>{settings={popup_text:'Need help? Live Chat is here!'};start()})};window.addEventListener('storage',e=>{if(e.key==='xtreme_language')loadSettings()});let lastLang=language();setInterval(()=>{const current=language();if(current!==lastLang){lastLang=current;loadSettings()}},2000);loadSettings();})();
</script>
























<script src="assets/xtreme-music.js?v=3" data-enabled="<?=e(site_setting('background_music_enabled','1'))?>" data-src="<?=e(site_setting('background_music_path','uploads/music/xtreme-background.m4a'))?>" defer></script>







<script id="xt-license-order-panel-start-hidden-v11">
(function () {
  function keepLicensePanelClosedOnEntry() {
    var panel = document.getElementById('confirmModal');
    if (!panel) return;
    panel.classList.remove('show');
    panel.setAttribute('aria-hidden', 'true');
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', keepLicensePanelClosedOnEntry, { once: true });
  } else {
    keepLicensePanelClosedOnEntry();
  }
})();
</script>



<script id="xt-product-category-filter-v12">
(function(){
  'use strict';
  function initProductCategoryFilters(){
    var track=document.getElementById('xtProductFilterTrack');
    var list=document.querySelector('main.container');
    if(!track||!list||track.dataset.ready==='1')return;
    track.dataset.ready='1';

    var buttons=Array.prototype.slice.call(track.querySelectorAll('[data-product-filter]'));
    var cards=Array.prototype.slice.call(list.querySelectorAll(':scope > section.product'));
    var empty=document.createElement('div');
    empty.className='xt-product-filter-empty';
    empty.textContent='এই ক্যাটাগরিতে কোনো প্রোডাক্ট পাওয়া যায়নি।';
    empty.setAttribute('role','status');
    list.appendChild(empty);

    function platformsOf(card){
      return String(card.getAttribute('data-platforms')||'ALL')
        .toUpperCase().split(',').map(function(v){return v.trim();}).filter(Boolean);
    }
    function apply(filter){
      var visible=0;
      list.classList.toggle('xt-live-key-filter-active',filter==='LIVE_KEY');
      cards.forEach(function(card){
        var tags=platformsOf(card);
        var hasPlans=card.getAttribute('data-has-plans')==='1';
        // LIVE KEY is a compact product/plan inventory view. Include out-of-stock plans too.
        var match=filter==='ALL'
          || (filter==='LIVE_KEY' && hasPlans)
          || (filter!=='LIVE_KEY' && tags.indexOf(filter)!==-1);
        card.classList.toggle('xt-filtered-out',!match);
        card.classList.toggle('xt-live-key-match',filter==='LIVE_KEY'&&match);
        if(match)visible++;
      });
      empty.classList.toggle('is-visible',visible===0);
      buttons.forEach(function(btn){
        var active=btn.getAttribute('data-product-filter')===filter;
        btn.classList.toggle('is-active',active);
        btn.setAttribute('aria-pressed',active?'true':'false');
      });
    }
    buttons.forEach(function(btn){
      btn.addEventListener('click',function(){
        apply(btn.getAttribute('data-product-filter')||'ALL');
      });
    });
    // Default to All Products so every product remains visible on first entry.
    apply('ALL');
  }
  if(document.readyState==='loading'){
    document.addEventListener('DOMContentLoaded',initProductCategoryFilters,{once:true});
  }else{
    initProductCategoryFilters();
  }
})();
</script>


<script id="xt-product-filter-language-v14">
(function(){
  'use strict';
  var labels={
    bn:{LIVE_KEY:'লাইভ কী',ALL:'সব প্রোডাক্ট',ANDROID_NONROOT:'অ্যান্ড্রয়েড নন রুট',IPHONE:'iOS আইফোন',ANDROID_ROOT:'অ্যান্ড্রয়েড রুট',PC_PANEL_FF:'পিসি প্রোডাক্ট'},
    en:{LIVE_KEY:'LIVE KEY',ALL:'ALL PRODUCTS',ANDROID_NONROOT:'ANDROID NON ROOT',IPHONE:'iOS iPHONE',ANDROID_ROOT:'ANDROID ROOT',PC_PANEL_FF:'PC PRODUCT'},
    it:{LIVE_KEY:'CHIAVI LIVE',ALL:'TUTTI I PRODOTTI',ANDROID_NONROOT:'ANDROID NON ROOT',IPHONE:'iOS iPHONE',ANDROID_ROOT:'ANDROID ROOT',PC_PANEL_FF:'PRODOTTI PC'},
    hi:{LIVE_KEY:'लाइव की',ALL:'सभी प्रोडक्ट',ANDROID_NONROOT:'एंड्रॉइड नॉन रूट',IPHONE:'iOS आईफोन',ANDROID_ROOT:'एंड्रॉइड रूट',PC_PANEL_FF:'पीसी प्रोडक्ट'},
    ne:{LIVE_KEY:'लाइभ की',ALL:'सबै उत्पादन',ANDROID_NONROOT:'एन्ड्रोइड नन रुट',IPHONE:'iOS आईफोन',ANDROID_ROOT:'एन्ड्रोइड रुट',PC_PANEL_FF:'पीसी उत्पादन'},
    vi:{LIVE_KEY:'KEY TRỰC TUYẾN',ALL:'TẤT CẢ SẢN PHẨM',ANDROID_NONROOT:'ANDROID KHÔNG ROOT',IPHONE:'iOS iPHONE',ANDROID_ROOT:'ANDROID ROOT',PC_PANEL_FF:'SẢN PHẨM PC'},
    es:{LIVE_KEY:'CLAVES ACTIVAS',ALL:'TODOS LOS PRODUCTOS',ANDROID_NONROOT:'ANDROID SIN ROOT',IPHONE:'iOS iPHONE',ANDROID_ROOT:'ANDROID ROOT',PC_PANEL_FF:'PRODUCTOS PC'},
    fr:{LIVE_KEY:'CLÉS DISPONIBLES',ALL:'TOUS LES PRODUITS',ANDROID_NONROOT:'ANDROID SANS ROOT',IPHONE:'iOS iPHONE',ANDROID_ROOT:'ANDROID ROOT',PC_PANEL_FF:'PRODUITS PC'},
    ar:{LIVE_KEY:'مفاتيح متاحة',ALL:'كل المنتجات',ANDROID_NONROOT:'أندرويد بدون روت',IPHONE:'آيفون iOS',ANDROID_ROOT:'أندرويد روت',PC_PANEL_FF:'منتجات الكمبيوتر'},
    pt:{LIVE_KEY:'CHAVES ATIVAS',ALL:'TODOS OS PRODUTOS',ANDROID_NONROOT:'ANDROID SEM ROOT',IPHONE:'iOS iPHONE',ANDROID_ROOT:'ANDROID ROOT',PC_PANEL_FF:'PRODUTOS PC'},
    tr:{LIVE_KEY:'AKTİF ANAHTARLAR',ALL:'TÜM ÜRÜNLER',ANDROID_NONROOT:'ANDROID ROOTSUZ',IPHONE:'iOS iPHONE',ANDROID_ROOT:'ANDROID ROOT',PC_PANEL_FF:'PC ÜRÜNLERİ'},
    ru:{LIVE_KEY:'АКТИВНЫЕ КЛЮЧИ',ALL:'ВСЕ ПРОДУКТЫ',ANDROID_NONROOT:'ANDROID БЕЗ ROOT',IPHONE:'iOS iPHONE',ANDROID_ROOT:'ANDROID ROOT',PC_PANEL_FF:'ПРОДУКТЫ ПК'},
    zh:{LIVE_KEY:'可用密钥',ALL:'所有产品',ANDROID_NONROOT:'安卓免ROOT',IPHONE:'iOS iPHONE',ANDROID_ROOT:'安卓ROOT',PC_PANEL_FF:'电脑产品'},
    ja:{LIVE_KEY:'利用可能なキー',ALL:'すべての商品',ANDROID_NONROOT:'Android 非Root',IPHONE:'iOS iPhone',ANDROID_ROOT:'Android Root',PC_PANEL_FF:'PC製品'}
  };
  function currentLanguage(){
    try{return (localStorage.getItem('xtreme_language')||document.documentElement.lang||'en').toLowerCase().split(/[-_]/)[0];}
    catch(e){return (document.documentElement.lang||'en').toLowerCase().split(/[-_]/)[0];}
  }
  var stockWords={
    bn:{available:'স্টক আছে',out:'স্টক নেই'},
    en:{available:'IN STOCK',out:'OUT OF STOCK'},
    it:{available:'DISPONIBILE',out:'NON DISPONIBILE'},
    hi:{available:'स्टॉक उपलब्ध',out:'स्टॉक नहीं'},
    ne:{available:'स्टक छ',out:'स्टक छैन'},
    vi:{available:'CÒN HÀNG',out:'HẾT HÀNG'},
    es:{available:'DISPONIBLE',out:'AGOTADO'},
    fr:{available:'EN STOCK',out:'ÉPUISÉ'},
    ar:{available:'متوفر',out:'غير متوفر'},
    pt:{available:'EM ESTOQUE',out:'ESGOTADO'},
    tr:{available:'STOKTA',out:'STOKTA YOK'},
    ru:{available:'В НАЛИЧИИ',out:'НЕТ В НАЛИЧИИ'},
    zh:{available:'有库存',out:'缺货'},
    ja:{available:'在庫あり',out:'在庫なし'}
  };
  function translateFilterButtons(){
    var lang=currentLanguage(),dict=labels[lang]||labels.en;
    var stockDict=stockWords[lang]||stockWords.en;
    document.querySelectorAll('.xt-live-key-stock-status[data-live-stock-label]').forEach(function(el){
      var state=el.getAttribute('data-live-stock-label')||'out';
      el.textContent=stockDict[state]||stockWords.en[state];
    });
    document.querySelectorAll('#xtProductFilterTrack [data-product-filter]').forEach(function(btn){
      var key=btn.getAttribute('data-product-filter')||'ALL';
      var target=btn.querySelector('b');
      if(target)target.textContent=dict[key]||labels.en[key]||key;
      btn.setAttribute('aria-label',dict[key]||labels.en[key]||key);
    });
  }
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',translateFilterButtons,{once:true});
  else translateFilterButtons();
  window.addEventListener('xtreme-language-change',translateFilterButtons);
  window.addEventListener('storage',function(e){if(!e||e.key==='xtreme_language')translateFilterButtons();});
})();
</script>






<script>
(function(){
  var timers=[];
  function startCountdowns(){
    timers.forEach(function(id){window.clearInterval(id);}); timers=[];
    document.querySelectorAll('.xt-maintenance-countdown,.xt-purchase-countdown').forEach(function(el){
      var start=Number(el.getAttribute('data-countdown-start')||Date.now());
      if(!Number.isFinite(start)||start<=0) start=Date.now();
      function render(){
        var elapsed=Math.max(0,Math.floor((Date.now()-start)/1000));
        var n=3-(elapsed%3);
        el.textContent=String(n);
        el.setAttribute('aria-label','Maintenance countdown '+n);
      }
      render();
      timers.push(window.setInterval(render,250));
    });
  }
  if(document.readyState==='loading') document.addEventListener('DOMContentLoaded',startCountdowns);
  else startCountdowns();
  window.addEventListener('pageshow',startCountdowns);
})();
</script>
</body>
</html>
