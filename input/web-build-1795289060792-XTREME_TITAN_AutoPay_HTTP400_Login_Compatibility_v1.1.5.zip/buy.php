<?php

require_once __DIR__ . '/config.php';
require_once __DIR__ . '/topup-lib.php';
ensure_catalog_product_columns();
ensure_product_plan_type_column();

if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}

/*
|--------------------------------------------------------------------------
| USER LOGIN
|--------------------------------------------------------------------------
*/

$userId = (int)($_SESSION['user_id'] ?? 0);

if ($userId <= 0) {
    header('Location: login.php');
    exit;
}

$pdo = db();
    try { $pdo->exec("ALTER TABLE product_plans ADD COLUMN duration_seconds INT NULL"); } catch (Throwable $ignore) {}
    try { $pdo->exec("UPDATE product_plans SET duration_seconds = CASE WHEN duration_days < 0 THEN ABS(duration_days)*3600 ELSE duration_days*86400 END WHERE duration_seconds IS NULL"); } catch (Throwable $ignore) {}
    try { $pdo->exec("ALTER TABLE user_keys ADD COLUMN duration_seconds INT NULL"); } catch (Throwable $ignore) {}

$message = '';
$error = '';
// Keep the exact server-side BDT values separately from the human-readable flash text.
// The browser can then convert these raw values exactly once for the selected currency.
$warningBalanceBdt = null;
$warningNeedBdt = null;

// Reseller pricing is controlled by Admin > Reseller Control.
$resellerDiscount = 0.0;
$role = current_user_role();
try {
    if ($role === 'reseller') {
        $resellerDiscount = max(0.0, min(90.0, (float)site_setting('reseller_discount_percent', '20')));
    }
} catch (Throwable $ignore) {}

/*
|--------------------------------------------------------------------------
| CSRF
|--------------------------------------------------------------------------
*/

if (empty($_SESSION['buy_csrf'])) {
    $_SESSION['buy_csrf'] = bin2hex(random_bytes(32));
}

$csrf = $_SESSION['buy_csrf'];

/*
|--------------------------------------------------------------------------
| HELPERS
|--------------------------------------------------------------------------
*/

function h($value): string
{
    return htmlspecialchars(
        (string)$value,
        ENT_QUOTES,
        'UTF-8'
    );
}

/*
|--------------------------------------------------------------------------
| PRODUCT
|--------------------------------------------------------------------------
|
| Supports:
| buy.php?product_id=1
|
*/

$productId = (int)(
    $_GET['product_id']
    ?? $_POST['product_id']
    ?? 0
);

if ($productId <= 0) {
    $productId = 1;
}

/*
|--------------------------------------------------------------------------
| PROCESS PURCHASE
|--------------------------------------------------------------------------
*/

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $postedCsrf = (string)($_POST['csrf'] ?? '');

    $postedProductId = (int)(
        $_POST['product_id'] ?? 0
    );

    $planId = (int)(
        $_POST['plan_id'] ?? 0
    );

    $quantity = (int)(
        $_POST['quantity'] ?? 1
    );

    if (
        $postedCsrf === '' ||
        !hash_equals($csrf, $postedCsrf)
    ) {
        $error = 'Security verification failed.';
    }

    elseif ($postedProductId <= 0) {
        $error = 'Invalid product.';
    }

    elseif ($planId <= 0) {
        $error = 'Please select a plan first.';
    }

    elseif ($quantity < 1 || $quantity > 30) {
        $error = 'Invalid quantity.';
    }

    else {

        try {

            $pdo->beginTransaction();

            /*
             * Lock selected plan.
             */
            $stmt = $pdo->prepare("
                SELECT
                    pp.id,
                    pp.plan_type,
                    pp.product_id,
                    pp.duration_days,
                    pp.duration_seconds,
                    pp.duration_label,
                    pp.price,
                    pp.status,
                    cp.reseller_discount_percent
                FROM product_plans pp
                LEFT JOIN catalog_products cp ON cp.id = pp.product_id
                WHERE pp.id = ?
                  AND pp.product_id = ?
                LIMIT 1
                FOR UPDATE
            ");

            $stmt->execute([
                $planId,
                $postedProductId
            ]);

            $plan = $stmt->fetch(
                PDO::FETCH_ASSOC
            );

            if (!$plan) {
                throw new RuntimeException(
                    'Selected plan was not found.'
                );
            }

            if ((int)$plan['status'] !== 1) {
                throw new RuntimeException(
                    'This plan is currently unavailable.'
                );
            }

            $effectiveResellerDiscount = ($role === 'reseller' && array_key_exists('reseller_discount_percent', $plan) && $plan['reseller_discount_percent'] !== null) ? max(0.0, min(90.0, (float)$plan['reseller_discount_percent'])) : $resellerDiscount;
            $unitPrice = (float)$plan['price'] * (1 - $effectiveResellerDiscount / 100);

            $totalAmount =
                $unitPrice * $quantity;

            /*
             * Count available keys for EXACT:
             *
             * product_id + plan_id
             *
             * This prevents a 30-day key being given
             * to a 1-day purchase.
             */
            $stockStmt = $pdo->prepare("
                SELECT COUNT(*)
                FROM user_keys
                WHERE product_id = ?
                  AND plan_id = ?
                  AND user_id IS NULL
            ");

            $stockStmt->execute([
                $postedProductId,
                $planId
            ]);

            $availableKeys = (int)$stockStmt->fetchColumn();

            if ($availableKeys < $quantity) {

                throw new RuntimeException(
                    'Not enough keys available. Only ' .
                    $availableKeys .
                    ' key(s) are available.'
                );
            }

            /*
             * ---------------------------------------------------------
             * BALANCE
             * ---------------------------------------------------------
             *
             * Balance =
             *
             * approved deposits
             * MINUS
             * previous purchases
             *
             * No transactions table is used.
             */

            try { $depCols=$pdo->query('SHOW COLUMNS FROM deposits')->fetchAll(PDO::FETCH_COLUMN); } catch(Throwable $ignore) { $depCols=[]; }
            $depositSumExpr = in_array('amount_bdt',$depCols,true) ? 'SUM(COALESCE(amount_bdt, amount))' : 'SUM(amount)';
            $depositStmt = $pdo->prepare("SELECT COALESCE({$depositSumExpr},0) FROM deposits WHERE user_id = ? AND LOWER(status) = 'approved'");

            $depositStmt->execute([
                $userId
            ]);

            $totalDeposits = (float)(
                $depositStmt->fetchColumn()
                ?: 0
            );

            // Wallet and product prices are held in BDT; convert the approved BDT total to USD-equivalent for the reseller $50 unlock.
            $totalDepositsUsd = $totalDeposits / 122.0;
            if ($role === 'reseller' && $totalDepositsUsd < 50.00) {
                throw new RuntimeException(
                    'Reseller purchases are locked until your approved deposits reach $50.00. Approved so far: $' . number_format($totalDepositsUsd, 2) . '. Please add funds and wait for admin approval.'
                );
            }

            /*
             * Previous purchases.
             */
            $purchaseStmt = $pdo->prepare("
                SELECT
                    COALESCE(
                        SUM(total_amount),
                        0
                    )
                FROM user_purchases
                WHERE user_id = ?
            ");

            $purchaseStmt->execute([
                $userId
            ]);

            $totalPurchases = (float)(
                $purchaseStmt->fetchColumn()
                ?: 0
            );

            $balance =
                $totalDeposits -
                $totalPurchases;

            if ($balance < $totalAmount) {
                $warningBalanceBdt = max(0.0, (float)$balance);
                $warningNeedBdt = max(0.0, (float)$totalAmount);

                throw new RuntimeException(
                    'Insufficient balance. ' .
                    'Your balance is ৳' .
                    number_format(
                        $balance,
                        2
                    ) .
                    ' but you need ৳' .
                    number_format(
                        $totalAmount,
                        2
                    ) .
                    '.'
                );
            }

            /*
             * ---------------------------------------------------------
             * GET EXACT KEYS
             * ---------------------------------------------------------
             *
             * Only keys belonging to the selected:
             *
             * product + plan
             *
             * are selected.
             */

            $keyStmt = $pdo->prepare("
                SELECT
                    id,
                    license_key
                FROM user_keys
                WHERE product_id = ?
                  AND plan_id = ?
                  AND user_id IS NULL
                ORDER BY id ASC
                LIMIT " . $quantity . "
                FOR UPDATE
            ");

            $keyStmt->execute([
                $postedProductId,
                $planId
            ]);

            $keys = $keyStmt->fetchAll(
                PDO::FETCH_ASSOC
            );

            if (count($keys) !== $quantity) {

                throw new RuntimeException(
                    'Unable to reserve the required keys.'
                );
            }

            /*
             * ---------------------------------------------------------
             * PRODUCT NAME
             * ---------------------------------------------------------
             */

            $productStmt = $pdo->prepare("
                SELECT
                    id,
                    name
                FROM catalog_products
                WHERE id = ?
                LIMIT 1
            ");

            $productStmt->execute([
                $postedProductId
            ]);

            $product = $productStmt->fetch(
                PDO::FETCH_ASSOC
            );

            if (!$product) {

                throw new RuntimeException(
                    'Product not found.'
                );
            }

            /*
             * ---------------------------------------------------------
             * CREATE PURCHASE
             * ---------------------------------------------------------
             */

            // Build the purchase row from columns that exist on this installation.
            // Some databases have a UNIQUE order_code column; leaving its default
            // empty string makes the second purchase fail with duplicate entry ''.
            $purchaseCols = $pdo->query("SHOW COLUMNS FROM user_purchases")->fetchAll(PDO::FETCH_COLUMN);
            $purchaseData = [
                'user_id' => $userId,
                'product_id' => $postedProductId,
                'product_name' => $product['name'],
                'plan_name' => $plan['duration_label'],
                'duration_days' => (int)$plan['duration_days'],
                'quantity' => $quantity,
                'unit_price' => $unitPrice,
                'total_amount' => $totalAmount
            ];
            if (in_array('created_at', $purchaseCols, true)) $purchaseData['created_at'] = utc_sql_now();
            if (in_array('order_code', $purchaseCols, true)) {
                $purchaseData['order_code'] = 'XT' . gmdate('ymdHis') . strtoupper(bin2hex(random_bytes(5)));
            }
            $purchaseData = array_intersect_key($purchaseData, array_flip($purchaseCols));
            if (!$purchaseData) throw new RuntimeException('Purchase table is missing required columns.');
            $purchaseColumnSql = implode(',', array_map(static fn($c) => '`' . str_replace('`', '``', $c) . '`', array_keys($purchaseData)));
            $purchasePlaceholders = implode(',', array_fill(0, count($purchaseData), '?'));
            $insertPurchase = $pdo->prepare("INSERT INTO user_purchases ({$purchaseColumnSql}) VALUES ({$purchasePlaceholders})");
            $insertPurchase->execute(array_values($purchaseData));
            $purchaseId = (int)$pdo->lastInsertId();

            /*
             * ---------------------------------------------------------
             * ASSIGN KEYS
             * ---------------------------------------------------------
             *
             * Each purchased key gets the current user_id.
             */

            $updateKey = $pdo->prepare("
                UPDATE user_keys
                SET
                    user_id = ?,
                    price = ?,
                    purchased_at = ?,
                    duration_seconds = ?
                WHERE id = ?
                  AND user_id IS NULL
                LIMIT 1
            ");

            foreach ($keys as $key) {

                $updateKey->execute([
                    $userId,
                    $unitPrice,
                    utc_sql_now(),
                    (int)($plan['duration_seconds'] ?? ((int)$plan['duration_days'] * 86400)),
                    (int)$key['id']
                ]);

                if ($updateKey->rowCount() !== 1) {

                    throw new RuntimeException(
                        'A key could not be assigned.'
                    );
                }
            }

            /*
             * Everything successful.
             */
            $pdo->commit();

            // Notify the customer after the purchase and key assignment are committed.
            try {
                xt_user_notify($userId, 'purchase_completed', 'Purchase completed',
                    'Your purchase #'.$purchaseId.' of '.$product['name'].' — '.$plan['duration_label'].' was successful. Quantity: '.$quantity.'. Total: ৳'.number_format((float)$totalAmount,2).'.',
                    'my-keys.php');
            } catch (Throwable $noticeError) { error_log('XT purchase notification: '.$noticeError->getMessage()); }

            // Stock depletion alert: count the real unassigned keys for this exact plan.
            // This runs after the purchase commits and must never interrupt a successful sale.
            try {
                $pdo->exec("CREATE TABLE IF NOT EXISTS admin_stock_alert_state (
                    plan_id BIGINT UNSIGNED NOT NULL PRIMARY KEY,
                    alerted TINYINT(1) NOT NULL DEFAULT 0,
                    last_stock INT NOT NULL DEFAULT 0,
                    updated_at DATETIME NOT NULL
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
                $remainingStmt = $pdo->prepare("SELECT COUNT(*) FROM user_keys WHERE product_id=? AND plan_id=? AND user_id IS NULL");
                $remainingStmt->execute([$postedProductId, $planId]);
                $remainingStock = (int)$remainingStmt->fetchColumn();
                $stateStmt = $pdo->prepare("SELECT alerted FROM admin_stock_alert_state WHERE plan_id=? LIMIT 1");
                $stateStmt->execute([$planId]);
                $alreadyAlerted = $stateStmt->fetchColumn();
                if ($remainingStock > 0) {
                    $saveState = $pdo->prepare("INSERT INTO admin_stock_alert_state(plan_id,alerted,last_stock,updated_at) VALUES(?,0,?,UTC_TIMESTAMP()) ON DUPLICATE KEY UPDATE alerted=0,last_stock=VALUES(last_stock),updated_at=UTC_TIMESTAMP()");
                    $saveState->execute([$planId, $remainingStock]);
                } else {
                    $saveState = $pdo->prepare("INSERT INTO admin_stock_alert_state(plan_id,alerted,last_stock,updated_at) VALUES(?,1,0,UTC_TIMESTAMP()) ON DUPLICATE KEY UPDATE alerted=1,last_stock=0,updated_at=UTC_TIMESTAMP()");
                    $saveState->execute([$planId]);
                    if ($availableKeys > 0) {
                        $productNameStmt = $pdo->prepare("SELECT name FROM catalog_products WHERE id=? LIMIT 1");
                        $productNameStmt->execute([$postedProductId]);
                        $productName = (string)($productNameStmt->fetchColumn() ?: ('Product #' . $postedProductId));
                        $planLabel = (string)($plan['duration_label'] ?? ($plan['duration_days'] . ' days'));
                        if (function_exists('notify_admin')) {
                            notify_admin('stock_out', 'Product stock finished', $productName . ' — ' . $planLabel . ' (Plan #' . $planId . ') is out of stock.', 'stock-alerts.php');
                        }
                    }
                }
            } catch (Throwable $stockAlertError) {
                error_log('Stock alert check failed: ' . $stockAlertError->getMessage());
            }


            $message =
                'Purchase successful! ' .
                $quantity .
                ' key(s) purchased for ' .
                $plan['duration_label'] .
                '.';

            /*
             * Keep selected product.
             */
            $productId = $postedProductId;

        } catch (Throwable $e) {

            if (
                $pdo instanceof PDO &&
                $pdo->inTransaction()
            ) {
                $pdo->rollBack();
            }

            $error = $e->getMessage();
        }
    }
}

/*
|--------------------------------------------------------------------------
| POST/REDIRECT/GET after successful purchase
|--------------------------------------------------------------------------
| Avoid rendering the stale plan/stock page after a purchase. The purchase
| transaction has already committed, so send the customer to their keys.
*/
if ($_SERVER['REQUEST_METHOD'] === 'POST' && $message !== '' && $error === '') {
    $_SESSION['purchase_flash'] = $message;
    header('Location: my-keys.php?purchase=success', true, 303);
    exit;
}

/* Keep purchase failures on the Store page; never render a standalone error page. */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && $error !== '') {
    $_SESSION['purchase_error_flash'] = $error;
    if (stripos($error, 'Insufficient balance.') === 0 && $warningBalanceBdt !== null && $warningNeedBdt !== null) {
        $_SESSION['purchase_error_amounts'] = ['have_bdt' => $warningBalanceBdt, 'need_bdt' => $warningNeedBdt];
    } else {
        unset($_SESSION['purchase_error_amounts']);
    }
    header('Location: store.php?purchase=failed', true, 303);
    exit;
}

/*
|--------------------------------------------------------------------------
| LOAD PRODUCT
|--------------------------------------------------------------------------
*/

$product = null;

try {

    $stmt = $pdo->prepare("
        SELECT
            id,
            name
        FROM catalog_products
        WHERE id = ?
        LIMIT 1
    ");

    $stmt->execute([
        $productId
    ]);

    $product = $stmt->fetch(
        PDO::FETCH_ASSOC
    );

    if (!$product) {
        throw new RuntimeException(
            'Product not found.'
        );
    }

} catch (Throwable $e) {

    $error = $e->getMessage();
}

/*
|--------------------------------------------------------------------------
| LOAD PLANS + EXACT STOCK
|--------------------------------------------------------------------------
*/

$plans = [];

if ($product) {

    try {

        $stmt = $pdo->prepare("
            SELECT
                pp.id,
                pp.plan_type,
                pp.duration_days,
                pp.duration_label,
                pp.price,
                pp.stock,
                pp.status,
                cp.reseller_discount_percent,

                (
                    SELECT COUNT(*)
                    FROM user_keys uk
                    WHERE uk.product_id = pp.product_id
                      AND uk.plan_id = pp.id
                      AND uk.user_id IS NULL
                ) AS available_keys

            FROM product_plans pp
            LEFT JOIN catalog_products cp ON cp.id = pp.product_id

            WHERE pp.product_id = ?
              AND pp.status = 1

            ORDER BY pp.duration_days ASC
        ");

        $stmt->execute([
            $productId
        ]);

        $plans = $stmt->fetchAll(
            PDO::FETCH_ASSOC
        );

    } catch (Throwable $e) {

        $error =
            'Unable to load plans. ' .
            $e->getMessage();
    }
}

/*
|--------------------------------------------------------------------------
| CURRENT BALANCE
|--------------------------------------------------------------------------
*/

$balance = 0;

try {

    $stmt = $pdo->prepare("
        SELECT
            COALESCE(
                SUM(amount),
                0
            )
        FROM deposits
        WHERE user_id = ?
          AND LOWER(status) = 'approved'
    ");

    $stmt->execute([
        $userId
    ]);

    $depositsTotal = (float)(
        $stmt->fetchColumn()
        ?: 0
    );

    $stmt = $pdo->prepare("
        SELECT
            COALESCE(
                SUM(total_amount),
                0
            )
        FROM user_purchases
        WHERE user_id = ?
    ");

    $stmt->execute([
        $userId
    ]);

    $purchasesTotal = (float)(
        $stmt->fetchColumn()
        ?: 0
    );

    $balance =
        $depositsTotal -
        $purchasesTotal;

} catch (Throwable $e) {
    $balance = 0;
}

?>

<!doctype html>

<html lang="en">

<head>
<link rel="stylesheet" href="theme.php?v=20261022-lightfix3">

<meta charset="utf-8">

<meta
    name="viewport"
    content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no"
>

<title>
    <?= h($product['name'] ?? 'Store') ?>
</title>

<style>

*{
    box-sizing:border-box;
}

html,
body{
    margin:0;
    padding:0;
    background:#06101c;
    color:#eef4ff;
    font-family:Arial,Helvetica,sans-serif;
}

body{
    min-height:100vh;
}

.container{
    width:100%;
    max-width:820px;
    margin:auto;
    padding:22px 15px 100px;
}

.header{
    display:flex;
    align-items:center;
    justify-content:space-between;
    margin-bottom:20px;
}

.title{
    font-size:28px;
    font-weight:900;
}

.balance{
    background:#0d1928;
    border:1px solid #26384e;
    border-radius:12px;
    padding:9px 12px;
    font-size:12px;
    font-weight:900;
    color:#63ff16;
}

.alert{
    padding:13px;
    border-radius:12px;
    margin-bottom:15px;
    font-size:13px;
}

.success{
    background:#15351c;
    border:1px solid #285b32;
    color:#9aff78;
}

.error{
    background:#3b1c24;
    border:1px solid #6b2b38;
    color:#ff9aaa;
}

.card{
    background:#0d1928;
    border:1px solid #1e3147;
    border-radius:20px;
    padding:18px;
}

.product-name{
    font-size:30px;
    font-weight:900;
    margin-bottom:5px;
}

.subtitle{
    color:#8fa0b5;
    margin-bottom:22px;
}

.plans{
    display:flex;
    flex-direction:column;
    gap:12px;
}

.plan{
    position:relative;
}

.plan input{
    position:absolute;
    opacity:0;
    pointer-events:none;
}

.plan-label{
    display:block;
    width:100%;
    background:#091522;
    border:2px solid #1d3045;
    border-radius:16px;
    padding:18px;
    cursor:pointer;
    transition:.15s;
}

.plan-label:active{
    transform:scale(.99);
}

.plan input:checked + .plan-label{
    border-color:#63ff16;
    background:#10251a;
    box-shadow:0 0 0 1px #63ff16;
}

.plan-row{
    display:flex;
    align-items:center;
    justify-content:space-between;
    gap:10px;
}

.plan-name{
    font-size:20px;
    font-weight:900;
}

.plan-price{
    font-size:20px;
    font-weight:900;
    color:#63ff16;
}

.stock{
    margin-top:7px;
    color:#8fa0b5;
    font-size:12px;
}

.stock.available{
    color:#8fe875;
}

.stock.empty{
    color:#ff7186;
}

.controls{
    margin-top:22px;
    padding-top:20px;
    border-top:1px solid #203247;
}

.qty-title{
    color:#8fa0b5;
    font-size:12px;
    font-weight:800;
    text-align:center;
    margin-bottom:9px;
}

.quantity{
    display:flex;
    align-items:center;
    justify-content:center;
    gap:20px;
}

.qty-btn{
    width:60px;
    height:60px;
    border:0;
    border-radius:15px;
    background:#1a2c42;
    color:#eef4ff;
    font-size:30px;
    font-weight:900;
    cursor:pointer;
}

.qty-btn:active{
    transform:scale(.94);
}

.qty-number{
    min-width:40px;
    text-align:center;
    font-size:28px;
    font-weight:900;
}

.total{
    text-align:center;
    margin-top:18px;
    font-size:16px;
    color:#9aa9bf;
}

.total strong{
    color:#eef4ff;
    font-size:25px;
}

.buy-button{
    display:block;
    width:100%;
    margin-top:18px;
    border:0;
    border-radius:14px;
    padding:16px;
    background:#63ff16;
    color:#06101c;
    font-size:17px;
    font-weight:900;
    cursor:pointer;
}

.buy-button:active{
    transform:scale(.99);
}

.buy-button:disabled{
    opacity:.35;
    cursor:not-allowed;
}

.back{
    display:block;
    text-align:center;
    margin-top:18px;
    color:#9aa9bf;
    text-decoration:none;
    font-size:13px;
}

</style>

<link rel="stylesheet" href="reference-theme.css">
<link rel="stylesheet" href="site-polish.css?v=20261022-lightfix3">
<script src="theme-client.js?v=20260928-19" defer></script><link rel="stylesheet" href="premium-global.css?v=20261022-lightfix3"><script src="currency-client.js?v=20261018-fx1" defer></script><link rel="stylesheet" href="responsive-lock.css?v=20260929-28">

<link rel="icon" type="image/png" sizes="48x48" href="/assets/pwa-icon-48.png">
<link rel="apple-touch-icon" sizes="180x180" href="/assets/pwa-icon-180.png">
<link rel="manifest" href="/pwa-manifest.json">
<meta name="apple-mobile-web-app-title" content="XTREME TITAN">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="mobile-web-app-capable" content="yes">
<meta name="theme-color" content="#080a14">
<script src="/admin/admin-action-progress.js?v=20261023-inline-progress25" defer></script>
</head>

<body>

<div class="container">

<div class="header">

    <div class="title">
        Store
    </div>

    <div class="balance">
        Balance:
        <span data-currency-amount="<?=h($balance)?>"><?=h(number_format($balance,2))?></span>
    </div>

</div>


<?php if ($message !== ''): ?>

<div class="alert success">
    <?= h($message) ?>
</div>

<?php endif; ?>


<?php if ($error !== ''): ?>

<div class="alert error">
    <?= h($error) ?>
</div>

<?php endif; ?>


<?php if ($product): ?>

<div class="card">

    <div class="product-name">
        <?= h($product['name']) ?>
    </div>

    <div class="subtitle">
        Premium digital license.
    </div>


    <form
        method="post"
        id="buyForm"
    >

        <input
            type="hidden"
            name="csrf"
            value="<?= h($csrf) ?>"
        >

        <input
            type="hidden"
            name="product_id"
            value="<?= (int)$productId ?>"
        >

        <input
            type="hidden"
            name="quantity"
            id="quantityInput"
            value="1"
        >


        <div class="plans">

        <?php foreach ($plans as $plan): ?>

            <?php
                $available =
                    (int)$plan['available_keys'];

                $disabled =
                    $available <= 0;
                $buyOriginalPrice = (float)$plan['price'];
                $buyProductDiscount = ($role === 'reseller' && isset($plan['reseller_discount_percent']) && $plan['reseller_discount_percent'] !== null) ? max(0.0, min(90.0, (float)$plan['reseller_discount_percent'])) : $resellerDiscount;
                $buyDisplayPrice = $buyOriginalPrice * (1 - $buyProductDiscount / 100);
            ?>

            <div class="plan">

                <input
                    type="radio"
                    name="plan_id"
                    id="plan_<?= (int)$plan['id'] ?>"
                    value="<?= (int)$plan['id'] ?>"
                    data-price="<?= h($buyDisplayPrice) ?>"
                    data-stock="<?= $available ?>"
                    <?= $disabled ? 'disabled' : '' ?>
                >

                <label
                    class="plan-label"
                    for="plan_<?= (int)$plan['id'] ?>"
                >

                    <div class="plan-row">

                        <div class="plan-name">
                            <?= h($plan['duration_label']) ?>
                        </div>

                        <div class="plan-price"><?php if ($role === 'reseller' && $buyProductDiscount > 0): ?><span style="display:block;font-size:11px;color:#94a3b8;text-decoration:line-through"><span data-currency-amount="<?=h($buyOriginalPrice)?>"><?=h(number_format($buyOriginalPrice,2))?></span></span><?php endif; ?><span data-currency-amount="<?= h($buyDisplayPrice) ?>"><?= h(number_format($buyDisplayPrice,2)) ?></span></div>

                    </div>

                    <div
                        class="stock <?= $disabled ? 'empty' : 'available' ?>"
                    >

                        <?php if ($disabled): ?>

                            Out of stock

                        <?php else: ?>

                            <?= $available ?>
                            key(s) available

                        <?php endif; ?>

                    </div>

                </label>

            </div>

        <?php endforeach; ?>

        </div>


        <div class="controls">

            <div class="qty-title">
                Quantity
            </div>

            <div class="quantity">

                <button
                    type="button"
                    class="qty-btn"
                    id="minusBtn"
                >
                    −
                </button>

                <div
                    class="qty-number"
                    id="qtyNumber"
                >
                    1
                </div>

                <button
                    type="button"
                    class="qty-btn"
                    id="plusBtn"
                >
                    +
                </button>

            </div>


            <div class="total">

                Total:

                <strong id="totalText">
                    Select a plan
                </strong>

            </div>


            <button
                type="submit"
                class="buy-button"
                id="buyButton"
            >
                BUY
            </button>

        </div>

    </form>

</div>

<?php endif; ?>


<a
    href="dashboard.php"
    class="back"
>
    ← Back to Store
</a>

</div>


<script>

(function(){

    const form =
        document.getElementById('buyForm');

    if (!form) {
        return;
    }

    const radios =
        document.querySelectorAll(
            'input[name="plan_id"]'
        );

    const quantityInput =
        document.getElementById(
            'quantityInput'
        );

    const qtyNumber =
        document.getElementById(
            'qtyNumber'
        );

    const minusBtn =
        document.getElementById(
            'minusBtn'
        );

    const plusBtn =
        document.getElementById(
            'plusBtn'
        );

    const totalText =
        document.getElementById(
            'totalText'
        );

    const buyButton =
        document.getElementById(
            'buyButton'
        );

    let quantity = 1;


    function selectedPlan(){

        for(
            let i = 0;
            i < radios.length;
            i++
        ){

            if(radios[i].checked){

                return radios[i];
            }
        }

        return null;
    }


    function update(){

        quantityInput.value =
            quantity;

        qtyNumber.textContent =
            quantity;

        const plan =
            selectedPlan();

        if(!plan){

            totalText.textContent =
                'Select a plan';

            buyButton.disabled =
                true;

            return;
        }

        const price =
            parseFloat(
                plan.dataset.price
            ) || 0;

        const stock =
            parseInt(
                plan.dataset.stock,
                10
            ) || 0;

        if(quantity > stock){

            quantity = Math.max(
                1,
                stock
            );

            quantityInput.value =
                quantity;

            qtyNumber.textContent =
                quantity;
        }

        const total =
            price * quantity;

        totalText.textContent =
            '৳' +
            total.toLocaleString(
                'en-BD',
                {
                    minimumFractionDigits:2,
                    maximumFractionDigits:2
                }
            );

        buyButton.disabled =
            stock < 1;
    }


    radios.forEach(function(radio){

        radio.addEventListener(
            'change',
            function(){

                quantity = 1;

                update();
            }
        );

    });


    minusBtn.addEventListener(
        'click',
        function(){

            if(quantity > 1){

                quantity--;

                update();
            }

        }
    );


    plusBtn.addEventListener(
        'click',
        function(){

            const plan =
                selectedPlan();

            if(!plan){

                alert(
                    'Please select a plan first.'
                );

                return;
            }

            const stock =
                parseInt(
                    plan.dataset.stock,
                    10
                ) || 0;

            if(quantity < stock){

                quantity++;

                update();

            } else {

                alert(
                    'No more keys are available for this plan.'
                );
            }

        }
    );


    form.addEventListener(
        'submit',
        function(event){

            const plan =
                selectedPlan();

            if(!plan){

                event.preventDefault();

                alert(
                    'Please select a plan first.'
                );

                return;
            }

            const stock =
                parseInt(
                    plan.dataset.stock,
                    10
                ) || 0;

            if(
                stock < 1 ||
                quantity > stock
            ){

                event.preventDefault();

                alert(
                    'Not enough keys available.'
                );

                return;
            }

            if(
                !confirm(
                    'Confirm this purchase?'
                )
            ){

                event.preventDefault();

            }

        }
    );


    update();

})();

</script>

</body>

</html>