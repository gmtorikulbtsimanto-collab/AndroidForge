XTREME TITAN — Store Language and Google Region Flow Fix

This patch updates language-client.js and auth-region-picker.js, plus cache-busting versions in PHP pages.

Changes:
- Adds translations for store purchase controls, plan selection, product category filters, live-key stock labels, profile key-reset controls and reset instructions in Bangla, Hindi, Nepali, Dzongkha and Vietnamese. Other Country remains English.
- Handles dynamic plan duration strings (for example 1 day / 7 days) and dynamic key availability counts.
- When a country is selected in the Google region chooser, the Google Identity Services prompt is requested after the script loads; the normal Google sign-in button remains available if the browser does not show the prompt.

Important: Test on the live host after uploading. Google account chooser behavior can depend on browser privacy settings and the Google Identity Services SDK; this patch cannot guarantee that a browser always displays the account chooser automatically. Dynamic product names and third-party Google button text are not translated by the site dictionary.
