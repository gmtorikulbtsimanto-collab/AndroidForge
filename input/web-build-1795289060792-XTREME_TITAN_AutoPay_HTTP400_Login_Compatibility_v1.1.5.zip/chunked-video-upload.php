<?php
require_once __DIR__ . '/config.php';
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');
function failUpload(string $msg, int $status=400): never { http_response_code($status); echo json_encode(['ok'=>false,'error'=>$msg]); exit; }
if (empty($_SESSION['admin_id']) && empty($_SESSION['admin_logged_in'])) failUpload('Admin login required.', 403);
$csrf=(string)($_GET['csrf']??'');
if (empty($_SESSION['admin_csrf']) || !hash_equals((string)$_SESSION['admin_csrf'],$csrf)) failUpload('Security verification failed. Refresh Admin Products and try again.',403);
if ($_SERVER['REQUEST_METHOD']!=='POST') failUpload('POST required.',405);
$id=(string)($_GET['id']??''); $idx=filter_var($_GET['index']??null,FILTER_VALIDATE_INT); $count=filter_var($_GET['count']??null,FILTER_VALIDATE_INT); $total=filter_var($_GET['total']??null,FILTER_VALIDATE_INT);
$name=basename((string)($_GET['name']??'video.mp4')); $ext=strtolower(pathinfo($name,PATHINFO_EXTENSION));
if (!preg_match('/^[a-f0-9]{32}$/',$id) || $idx===false || $count===false || $total===false || $idx<0 || $count<1 || $idx>=$count) failUpload('Invalid upload information.');
$imageExts=['jpg','jpeg','png','webp','gif'];
$videoExts=['mp4','webm','ogg','ogv','mov'];
if (!in_array($ext,array_merge($imageExts,$videoExts),true)) failUpload('Only JPG, PNG, WebP, GIF, MP4, WebM, OGG, OGV and MOV are supported.');
$maxBytes=in_array($ext,$imageExts,true)?8*1024*1024:300*1024*1024;
if ($total<1 || $total>$maxBytes) failUpload(in_array($ext,$imageExts,true)?'ছবির সাইজ সর্বোচ্চ 8 MB হতে পারবে।':'ভিডিও সর্বোচ্চ 300 MB হতে পারবে।');
$chunk=file_get_contents('php://input'); if ($chunk===false || strlen($chunk)<1 || strlen($chunk)>2*1024*1024) failUpload('Invalid upload chunk.');
$dir=__DIR__.'/uploads/product-media'; if(!is_dir($dir)&&!mkdir($dir,0755,true)&&!is_dir($dir))failUpload('Could not create media folder.',500);
$tmpDir=$dir.'/.chunks'; if(!is_dir($tmpDir)&&!mkdir($tmpDir,0755,true)&&!is_dir($tmpDir))failUpload('Could not create temporary folder.',500);
$part=$tmpDir.'/'.$id.'.part'; $meta=$tmpDir.'/'.$id.'.json';
if($idx===0){file_put_contents($meta,json_encode(['count'=>$count,'total'=>$total,'ext'=>$ext,'next'=>0]),LOCK_EX);file_put_contents($part,'');}
if(!is_file($meta)||!is_file($part))failUpload('Upload session expired. Please try again.');
$m=json_decode((string)file_get_contents($meta),true); if(!is_array($m)||$m['count']!==$count||$m['total']!==$total||$m['ext']!==$ext||(int)$m['next']!==$idx)failUpload('Upload chunk order mismatch. Please retry.');
$written=file_put_contents($part,$chunk,FILE_APPEND|LOCK_EX); if($written!==strlen($chunk))failUpload('Could not write video data.',500);
$m['next']=$idx+1;file_put_contents($meta,json_encode($m),LOCK_EX);
if($idx+1===$count){clearstatcache(true,$part);if(filesize($part)!==$total){@unlink($part);@unlink($meta);failUpload('Uploaded file size did not match. Please retry.');}$final=$dir.'/product_'.date('Ymd_His').'_'.$id.'.'.$ext;if(!rename($part,$final))failUpload('Could not finalize video file.',500);@unlink($meta);echo json_encode(['ok'=>true,'complete'=>true,'path'=>'uploads/product-media/'.basename($final)]);exit;}
echo json_encode(['ok'=>true,'complete'=>false,'received'=>$idx+1]);
