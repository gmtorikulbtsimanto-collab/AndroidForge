XTREME TITAN — Country, Currency & Deposit Source Fix

Changes:
- Registration country selector: Bangladesh/BDT/Bengali, India/INR/Hindi, Nepal/NPR/Nepali, Bhutan/BTN/Dzongkha, Vietnam/VND/Vietnamese, Other/USD/English.
- Signed-in pages load saved account country/currency/language preferences from preferences.php.
- Deposit records store the original submitted amount and currency, the source role (User Panel or Reseller Panel), country, and a BDT-equivalent amount for wallet accounting.
- Admin Deposit Approvals shows original amount with currency, source panel, country, and wallet credit in BDT.
- Wallet credit uses the BDT-equivalent field. Reseller $50 unlock checks BDT-equivalent deposits converted to USD using the configured approximate BDT/USD rate.

Important: BDT conversion rates are approximate fixed rates in this patch (USD 122 BDT, EUR 133.33 BDT, AED 33.22 BDT, INR/BTN 1.77 BDT, NPR 0.88 BDT, VND 0.0049 BDT, GBP 154 BDT). Update these rates when needed. Historical deposits have no original currency/source metadata and are marked Legacy / Unknown in the admin panel. Test with a small deposit in a staging account before using live.
