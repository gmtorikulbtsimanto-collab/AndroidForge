XTREME TITAN OFFICIAL — Reset / Plan / Key Manager Update

- Profile > Reset Key offers Device Reset and Reset with a New Key.
- Replacement key reset selects an unused inventory key belonging to the same product and plan as the selected user key.
- Admin approval consumes that unused inventory record, updates the user's key shown in My Keys, and restarts the plan countdown from approval time.
- Device Reset clears device binding only and preserves the existing countdown.
- Admin > Key Manager lists unused inventory keys and permits deleting them individually. Assigned user keys are protected from this delete action.
- Plan Manager supports PRO, BASIC, and NORMAL plan types; admins can create only the durations they need, edit plans, and delete plans with no assigned user keys. Deleting a plan also removes its unused inventory keys.
- Product Editor allows assigning the existing product to Android Non Root, Apple iOS, Android Root, PC PANEL FF, LIVE KEYS, or All/Multi-platform. Existing Store buttons/layout are retained.
- Admin POST forms use a processing overlay that shows progress while the server responds. It reports 100% after page response/reload and asks the admin to verify the result message; this is a UI progress indicator, not server-side byte-level progress.

Validation performed: PHP syntax checks passed for all PHP files. The ZIP was not tested against the live InfinityFree database/site; back up and test with a spare user/key first.
