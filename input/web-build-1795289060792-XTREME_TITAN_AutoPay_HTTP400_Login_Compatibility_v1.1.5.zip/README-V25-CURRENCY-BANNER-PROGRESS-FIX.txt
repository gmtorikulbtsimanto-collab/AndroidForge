XTREME TITAN V25 PATCH NOTES

1. Purchase balance warning now carries the exact raw server-side BDT balance and required amount separately from the translated message. This prevents a converted display amount from being converted a second time by the currency/language client.
2. The Add Funds promotional image is rendered above the Add Funds button. Configure it in Admin Panel > Site Settings > Add Funds promotional banner, upload an image, and optionally enter the destination URL.
3. Store dashboard Quick Access buttons (My Keys, Add Funds, History, Profile) have larger tap targets and text.
4. Progress indicator no longer reports 100% just because the browser starts navigating away. Ordinary PHP form processing still cannot provide true server-side percentage without an AJAX/progress endpoint; the inline percentage is an estimate while waiting.
5. Client script cache versions have been bumped so browsers request updated currency/language/progress scripts.

Before deploying, back up the existing website and database. Test purchases with insufficient balance and verify the warning amounts match the displayed balance/currency. Live-host testing was not performed as part of this patch.
