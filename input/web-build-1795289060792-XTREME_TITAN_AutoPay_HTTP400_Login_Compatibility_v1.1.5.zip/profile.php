<?php
require_once __DIR__ . '/config.php';
require_login();
$site = site_settings();
$userId = (int)($_SESSION['user_id'] ?? 0); ensure_account_role_columns(); ensure_key_reset_tables(); $profilePhoto='';
$name = $_SESSION['user_name'] ?? 'User';
$email = $_SESSION['user_email'] ?? '';
$phone = $_SESSION['user_phone'] ?? '';
$initial = strtoupper(mb_substr($name, 0, 1));
$wallet = 0.0; $refBalance = 0.0; $refCount = 0; $totalKeys = 0; $totalDeposit = 0.0; $accountStatus = 'Active';
try {
    $pdo = db();
    $stmt = $pdo->query('SHOW COLUMNS FROM `users`');
    $columns = $stmt->fetchAll(PDO::FETCH_COLUMN);
    $find = function($wanted) use ($columns) { foreach ($columns as $c) if (strcasecmp($c, $wanted) === 0) return $c; return null; };
    $idCol=$find('id'); $nameCol=$find('name'); $emailCol=$find('email'); $phoneCol=$find('phone'); $photoCol=$find('profile_photo'); $statusCol=$find('account_status') ?: $find('status'); $activeCol=$find('is_active');
    if ($idCol) {
        $select=[]; if($nameCol)$select[]='`'.str_replace('`','``',$nameCol).'` AS user_name'; if($emailCol)$select[]='`'.str_replace('`','``',$emailCol).'` AS user_email'; if($phoneCol)$select[]='`'.str_replace('`','``',$phoneCol).'` AS user_phone'; if($photoCol)$select[]='`'.str_replace('`','``',$photoCol).'` AS user_photo'; if($statusCol)$select[]='`'.str_replace('`','``',$statusCol).'` AS account_status'; if($activeCol)$select[]='`'.str_replace('`','``',$activeCol).'` AS account_active';
        if($select){$q=$pdo->prepare('SELECT '.implode(', ',$select).' FROM `users` WHERE `'.str_replace('`','``',$idCol).'`=? LIMIT 1');$q->execute([$userId]);if($u=$q->fetch(PDO::FETCH_ASSOC)){if(!empty($u['user_name']))$name=$u['user_name'];if(isset($u['user_email']))$email=$u['user_email'];if(isset($u['user_phone']))$phone=$u['user_phone'];if(isset($u['user_photo']))$profilePhoto=(string)$u['user_photo']; if(!empty($u['account_status']))$accountStatus=(string)$u['account_status']; elseif(isset($u['account_active']))$accountStatus=((string)$u['account_active']==='1'?'Active':'Inactive'); $initial=strtoupper(mb_substr($name,0,1));}}
    }
    // Wallet balance is calculated from approved deposits minus completed purchases.
    try {$q=$pdo->prepare("SELECT COALESCE(SUM(amount),0) FROM deposits WHERE user_id=? AND LOWER(status)='approved'");$q->execute([$userId]);$wallet+=(float)$q->fetchColumn();}catch(Throwable $e){}
    try {$q=$pdo->prepare("SELECT COALESCE(SUM(total_amount),0) FROM user_purchases WHERE user_id=?");$q->execute([$userId]);$wallet-=(float)$q->fetchColumn();}catch(Throwable $e){}
    $wallet=max(0,$wallet);
    try {$q=$pdo->prepare("SELECT COUNT(*) FROM users WHERE referred_by=?");$q->execute([$userId]);$refCount=(int)$q->fetchColumn();}catch(Throwable $e){
        try {$q=$pdo->prepare("SELECT COUNT(*) FROM users WHERE referrer_id=?");$q->execute([$userId]);$refCount=(int)$q->fetchColumn();}catch(Throwable $e2){}
    }
    // Profile summary metrics: total owned keys and approved deposit total.
    try {$q=$pdo->prepare("SELECT COUNT(*) FROM user_keys WHERE user_id=?");$q->execute([$userId]);$totalKeys=(int)$q->fetchColumn();}catch(Throwable $e){}
    try {$q=$pdo->prepare("SELECT COALESCE(SUM(amount),0) FROM deposits WHERE user_id=? AND LOWER(status)='approved'");$q->execute([$userId]);$totalDeposit=(float)$q->fetchColumn();}catch(Throwable $e){}
    $refBalance=0.0;
} catch(Throwable $e) {}
$prefs = current_user_preferences();
$themeDefault = (string)($site['theme_default'] ?? 'premium');
$telegram = (string)($site['telegram_url'] ?? '');
$rulesUrl = (string)($site['rules_url'] ?? '');
if (empty($_SESSION['reset_key_csrf'])) $_SESSION['reset_key_csrf']=bin2hex(random_bytes(32));
$resetKeyCsrf=$_SESSION['reset_key_csrf'];
$referralUrl = 'referral.php';
$topUrl = 'top-members.php';
function ph($v){return htmlspecialchars((string)$v,ENT_QUOTES,'UTF-8');}
?>
<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no,viewport-fit=cover"><title><?=ph($site['site_title']??'XTREME TITAN')?> — Profile</title><link rel="stylesheet" href="reference-theme.css"><link rel="stylesheet" href="site-polish.css?v=20261022-lightfix3"><link rel="stylesheet" href="theme.php?v=20261022-lightfix3"><style>
.profile-page{max-width:720px;margin:0 auto;padding:18px 13px 96px}.profile-hero{padding:20px;border-radius:26px;background:linear-gradient(145deg,rgba(13,27,45,.96),rgba(6,14,26,.94));border:1px solid rgba(78,105,139,.45);box-shadow:0 25px 70px rgba(0,0,0,.28),inset 0 1px 0 rgba(255,255,255,.04);position:relative;overflow:hidden}.profile-hero:before{content:"";position:absolute;inset:-60px auto auto -50px;width:190px;height:190px;border-radius:50%;background:radial-gradient(circle,rgba(16,217,255,.18),transparent 68%);pointer-events:none}.hero-row{display:flex;align-items:center;gap:14px;position:relative}.big-avatar{width:68px;overflow:hidden;height:68px;border-radius:21px;display:grid;place-items:center;font-size:27px;font-weight:1000;color:#fff;background:linear-gradient(145deg,#18d9ff,#287cff);box-shadow:0 14px 30px rgba(20,135,255,.24)}.big-avatar img{width:100%;height:100%;object-fit:cover}.hero-name{font-size:23px;font-weight:1000;letter-spacing:-.02em}.hero-user{font-size:12px;color:#93a4ba;margin-top:4px}.balance-grid{display:grid;grid-template-columns:1.35fr 1fr 1fr;gap:9px;margin-top:16px}.balance-card{padding:13px;border-radius:17px;background:rgba(3,11,20,.55);border:1px solid rgba(78,105,139,.34)}.balance-card.primary{background:linear-gradient(145deg,rgba(15,105,153,.34),rgba(7,25,42,.7));border-color:rgba(16,217,255,.3)}.b-label{font-size:9px;font-weight:900;color:#8fa0b7;letter-spacing:.08em}.b-value{font-size:19px;font-weight:1000;margin-top:5px}.b-value.green{color:#5fffae}.b-value.cyan{color:#24dcff}.section-title{font-size:11px;font-weight:1000;color:#7f91aa;letter-spacing:.12em;margin:20px 4px 8px;text-transform:uppercase}.profile-list{display:grid;gap:8px}.profile-action{display:flex;align-items:center;gap:12px;text-decoration:none;color:#f2f6ff;padding:14px;border-radius:18px;background:linear-gradient(145deg,rgba(13,27,45,.94),rgba(7,16,29,.91));border:1px solid rgba(78,105,139,.38);box-shadow:0 12px 30px rgba(0,0,0,.16);transition:.18s}.profile-action:hover{transform:translateY(-1px);border-color:rgba(16,217,255,.45)}.pa-icon{width:40px;height:40px;border-radius:13px;display:grid;place-items:center;background:rgba(16,217,255,.09);border:1px solid rgba(16,217,255,.17);font-size:20px}.pa-main{min-width:0;flex:1}.pa-title{font-size:13px;font-weight:1000}.pa-text{font-size:10px;color:#8596ad;margin-top:4px;line-height:1.35}.chev{font-size:20px;color:#71849d}.logout-card{border-color:rgba(255,85,110,.2);background:linear-gradient(145deg,rgba(45,16,25,.7),rgba(18,10,16,.75))}.logout-card .pa-icon{background:rgba(255,85,110,.08);border-color:rgba(255,85,110,.18)}.theme-box{padding:14px;border-radius:20px;background:linear-gradient(145deg,rgba(13,27,45,.94),rgba(7,16,29,.91));border:1px solid rgba(78,105,139,.38)}.theme-switch{display:grid;grid-template-columns:repeat(5,1fr);gap:7px}.theme-btn{border:1px solid rgba(78,105,139,.4);background:#07121f;color:#aab8ca;border-radius:12px;padding:10px 5px;font-size:9px;font-weight:900;cursor:pointer}.theme-btn.active{color:#fff;border-color:rgba(16,217,255,.75);background:linear-gradient(135deg,#13cfff,#277cff);box-shadow:0 8px 20px rgba(25,135,255,.18)}@media(max-width:480px){.balance-grid{grid-template-columns:1fr 1fr}.balance-card.primary{grid-column:1/-1}.theme-switch{grid-template-columns:repeat(2,1fr)}.profile-hero{padding:17px;border-radius:22px}}
.preference-box{padding:14px;border-radius:20px;background:linear-gradient(145deg,rgba(13,27,45,.94),rgba(7,16,29,.91));border:1px solid rgba(78,105,139,.38);box-shadow:0 14px 34px rgba(0,0,0,.16)}.pref-row{display:flex;align-items:center;justify-content:space-between;gap:14px;padding:12px 0;border-bottom:1px solid rgba(148,163,184,.12)}.pref-row:last-of-type{border-bottom:0}.pref-title{font-size:13px;font-weight:1000}.pref-text{font-size:10px;color:#8596ad;margin-top:4px}.pref-select{width:min(210px,45%);min-height:44px;border-radius:12px;padding:8px 10px;font-weight:800}.pref-status{min-height:18px;font-size:11px;color:#34d399;margin-top:7px}@media(max-width:480px){.pref-row{align-items:flex-start;flex-direction:column}.pref-select{width:100%;max-width:none}}
</style><script src="theme-client.js?v=20261022-lightfix2" defer></script><link rel="stylesheet" href="premium-global.css?v=20261022-lightfix3"><script src="currency-client.js?v=20261022-country3" defer></script><script src="language-client.js?v=20261023-full-language-v50" defer></script><script src="preference-sync.js?v=20260928-19" defer></script><link rel="stylesheet" href="responsive-lock.css?v=20260929-28">


<link rel="icon" type="image/png" sizes="48x48" href="/assets/pwa-icon-48.png">
<link rel="apple-touch-icon" sizes="180x180" href="/assets/pwa-icon-180.png">
<link rel="manifest" href="/pwa-manifest.json">
<meta name="apple-mobile-web-app-title" content="XTREME TITAN">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="mobile-web-app-capable" content="yes">
<meta name="theme-color" content="#080a14">
<script src="/admin/admin-action-progress.js?v=20261023-inline-progress25" defer></script>

<style id="xt-global-header-logo-unified-v29">
/* One consistent site-header logo and title scale on every customer page */
header.top, header.topbar {
  box-sizing:border-box!important;
  width:100%!important;
  min-height:0!important;
  height:auto!important;
  padding:14px 14px 16px!important;
  margin:0 auto!important;
  display:flex!important;
  align-items:center!important;
  justify-content:center!important;
  text-align:center!important;
}
header.top .brand-with-logo, header.topbar .brand-with-logo {
  box-sizing:border-box!important;
  width:100%!important;
  max-width:100%!important;
  display:flex!important;
  flex-direction:column!important;
  align-items:center!important;
  justify-content:center!important;
  gap:7px!important;
  margin:0 auto!important;
  text-align:center!important;
}
header.top .header-logo, header.topbar .header-logo {
  display:block!important;
  box-sizing:border-box!important;
  width:46px!important;height:46px!important;
  min-width:46px!important;min-height:46px!important;
  max-width:46px!important;max-height:46px!important;
  flex:0 0 46px!important;
  object-fit:contain!important;object-position:center!important;
  background:transparent!important;
  border:0!important;padding:0!important;margin:0 auto!important;
  border-radius:10px!important;
}
header.top .brand-text, header.topbar .top-title {
  display:block!important;
  max-width:100%!important;
  margin:0 auto!important;padding:0!important;
  text-align:center!important;
  font-size:clamp(17px,4.6vw,25px)!important;
  line-height:1.2!important;
  font-weight:900!important;
  letter-spacing:0!important;
  overflow-wrap:anywhere!important;
}
header.topbar .xt-dashboard-tagline {
  margin:0 auto!important;
  text-align:center!important;
  line-height:1.2!important;
}
@media(max-width:420px) {
  header.top,header.topbar{padding:12px 10px 14px!important}
  header.top .header-logo,header.topbar .header-logo {
    width:46px!important;height:46px!important;min-width:46px!important;min-height:46px!important;
    max-width:46px!important;max-height:46px!important;flex-basis:46px!important;
  }
}
</style>
<link rel="stylesheet" href="assets/xtreme-music.css?v=3">

<link rel="stylesheet" href="assets/xtreme-bottom-nav.css?v=20261117-border-v11">

<style id="xt-profile-premium-summary-v2">
.profile-page{max-width:760px!important;padding:18px 13px 105px!important}
.xt-profile-premium-card{
  padding:22px!important;border-radius:30px!important;
  background:
    radial-gradient(ellipse at 8% 4%,rgba(25,197,255,.16),transparent 38%),
    radial-gradient(ellipse at 95% 12%,rgba(157,72,255,.14),transparent 36%),
    linear-gradient(145deg,#101d34 0%,#091426 58%,#0a1020 100%)!important;
  border:1px solid rgba(84,166,215,.48)!important;
  box-shadow:0 22px 65px rgba(0,0,0,.34),inset 0 1px 0 rgba(255,255,255,.08),0 0 26px rgba(36,173,255,.07)!important;
}
.xt-profile-identity{display:flex;align-items:center;gap:18px;position:relative;z-index:1;min-width:0}
.xt-profile-avatar-wrap{position:relative;display:block;flex:0 0 142px;width:142px;height:142px;text-decoration:none}
.xt-profile-avatar{
  width:142px;height:142px;display:grid;place-items:center;overflow:hidden;border-radius:50%;
  padding:5px;background:conic-gradient(from 20deg,#8d65ff,#26d9ff,#69f3d0,#8d65ff);
  box-shadow:0 0 0 4px rgba(94,128,255,.12),0 12px 35px rgba(48,118,255,.22);
  color:#fff;font-size:46px;font-weight:1000;
}
.xt-profile-avatar img{width:100%;height:100%;object-fit:cover;border-radius:50%;border:4px solid #101a2d}
.xt-profile-camera{
  position:absolute;right:0;bottom:5px;width:42px;height:42px;border-radius:50%;
  display:grid;place-items:center;background:linear-gradient(145deg,#20d9ff,#167de2);
  border:4px solid #0c1729;box-shadow:0 5px 16px rgba(0,0,0,.35);font-size:19px;
}
.xt-profile-details{min-width:0;flex:1}
.xt-profile-name{font-size:clamp(21px,5.5vw,34px);line-height:1.12;font-weight:1000;letter-spacing:-.035em;color:#fff;overflow-wrap:anywhere;text-shadow:0 3px 18px rgba(0,0,0,.25)}
.xt-profile-badges{display:flex;flex-wrap:wrap;gap:8px;margin-top:11px}
.xt-profile-member-badge,.xt-profile-status-badge{
  display:inline-flex;align-items:center;gap:6px;min-height:32px;padding:6px 12px;border-radius:999px;
  font-size:11px;font-weight:950;letter-spacing:.025em;white-space:nowrap
}
.xt-profile-member-badge{color:#fff;background:linear-gradient(110deg,#7438db,#b444ee);box-shadow:0 6px 18px rgba(157,66,245,.24)}
.xt-profile-status-badge{color:#48dafa;background:rgba(14,91,117,.18);border:1px solid rgba(48,204,239,.42)}
.xt-profile-status-badge i{width:7px;height:7px;border-radius:50%;background:#36e9b0;box-shadow:0 0 9px #36e9b0}
.xt-profile-handle{margin-top:12px;color:#4bd8ff;font-size:14px;font-weight:900;overflow-wrap:anywhere}
.xt-profile-email{display:flex;align-items:center;gap:7px;margin-top:8px;color:#aabbd1;font-size:13px;font-weight:650;min-width:0}
.xt-profile-email span{overflow-wrap:anywhere;min-width:0}
.xt-profile-uid{display:inline-flex;align-items:center;gap:6px;margin-top:11px;padding:7px 11px;border-radius:999px;
  color:#66cfff;background:rgba(148,163,184,.12);border:1px solid rgba(148,163,184,.25);font-size:12px;font-weight:950}
.xt-profile-metrics{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:11px;margin-top:25px;position:relative;z-index:1}
.xt-profile-metric{
  min-width:0;min-height:126px;padding:16px 12px 13px;border-radius:23px;
  background:linear-gradient(145deg,rgba(18,29,51,.98),rgba(11,19,36,.98));
  border:1px solid rgba(118,145,181,.25);
  box-shadow:inset 0 1px 0 rgba(255,255,255,.065),0 9px 22px rgba(0,0,0,.2);
  display:flex;flex-direction:column;justify-content:center;align-items:center;text-align:center;
}
.xt-metric-keys{border-color:rgba(43,194,255,.32);background:linear-gradient(145deg,rgba(13,65,101,.42),rgba(13,23,44,.98))}
.xt-metric-deposit{border-color:rgba(166,104,255,.32);background:linear-gradient(145deg,rgba(76,35,108,.34),rgba(13,20,42,.98))}
.xt-metric-status{border-color:rgba(54,224,166,.28);background:linear-gradient(145deg,rgba(12,78,66,.26),rgba(13,20,42,.98))}
.xt-metric-label{display:flex;align-items:center;justify-content:center;gap:7px;color:#b8c7db;font-size:clamp(10px,2.8vw,13px);font-weight:950;line-height:1.2;white-space:normal}
.xt-metric-icon{font-size:20px;line-height:1}
.xt-metric-value{margin-top:12px;color:#fff;font-size:clamp(22px,5vw,31px);line-height:1.05;font-weight:1000;letter-spacing:-.035em;overflow-wrap:anywhere}
.xt-metric-value.is-active{color:#35e6a5;text-shadow:0 0 16px rgba(53,230,165,.18)}
.xt-metric-value.is-inactive{color:#ff8c9d}
.xt-metric-foot{margin-top:7px;color:#8297b4;font-size:9px;font-weight:750;line-height:1.2}
@media(max-width:560px){
 .xt-profile-premium-card{padding:17px!important;border-radius:25px!important}
 .xt-profile-identity{gap:13px}
 .xt-profile-avatar-wrap,.xt-profile-avatar{width:104px;height:104px;flex-basis:104px}
 .xt-profile-avatar{font-size:36px}
 .xt-profile-camera{width:35px;height:35px;font-size:16px;right:-1px;bottom:2px}
 .xt-profile-name{font-size:clamp(18px,5.2vw,25px)}
 .xt-profile-badges{gap:6px;margin-top:8px}
 .xt-profile-member-badge,.xt-profile-status-badge{min-height:27px;padding:5px 9px;font-size:9px}
 .xt-profile-handle{font-size:12px;margin-top:9px}
 .xt-profile-email{font-size:11px;margin-top:6px}
 .xt-profile-uid{font-size:10px;margin-top:8px;padding:6px 9px}
 .xt-profile-metrics{gap:7px;margin-top:20px}
 .xt-profile-metric{min-height:112px;padding:12px 6px;border-radius:18px}
 .xt-metric-icon{font-size:16px}
 .xt-metric-value{font-size:clamp(19px,5.3vw,25px);margin-top:10px}
 .xt-metric-foot{font-size:8px}
}
@media(max-width:365px){
 .xt-profile-identity{gap:9px}
 .xt-profile-avatar-wrap,.xt-profile-avatar{width:88px;height:88px;flex-basis:88px}
 .xt-profile-camera{width:31px;height:31px}
 .xt-profile-metric{padding-left:4px;padding-right:4px}
 .xt-metric-label{font-size:9px;gap:4px}
}
</style>
<script id="xt-profile-summary-i18n-v2">
(function(){
 const words={
  en:{premiumMember:'Premium Member',uid:'UID',totalKeys:'Total Keys',ownedKeys:'Owned licenses',totalDeposit:'Total Deposit',approvedDeposits:'Approved deposits',accountStatus:'Account Status',accountStanding:'Account standing',active:'Active',inactive:'Inactive'},
  bn:{premiumMember:'প্রিমিয়াম সদস্য',uid:'ইউজার আইডি',totalKeys:'মোট কী',ownedKeys:'আপনার লাইসেন্স',totalDeposit:'মোট জমা',approvedDeposits:'অনুমোদিত ডিপোজিট',accountStatus:'অ্যাকাউন্ট স্ট্যাটাস',accountStanding:'অ্যাকাউন্টের অবস্থা',active:'সক্রিয়',inactive:'নিষ্ক্রিয়'},
  hi:{premiumMember:'प्रीमियम सदस्य',uid:'यूज़र आईडी',totalKeys:'कुल की',ownedKeys:'आपके लाइसेंस',totalDeposit:'कुल जमा',approvedDeposits:'स्वीकृत जमा',accountStatus:'अकाउंट स्थिति',accountStanding:'अकाउंट की स्थिति',active:'सक्रिय',inactive:'निष्क्रिय'},
  ne:{premiumMember:'प्रिमियम सदस्य',uid:'प्रयोगकर्ता आईडी',totalKeys:'कुल की',ownedKeys:'तपाईंका लाइसेन्स',totalDeposit:'कुल जम्मा',approvedDeposits:'स्वीकृत जम्मा',accountStatus:'खाता स्थिति',accountStanding:'खाताको अवस्था',active:'सक्रिय',inactive:'निष्क्रिय'},
  it:{premiumMember:'Membro premium',uid:'ID utente',totalKeys:'Chiavi totali',ownedKeys:'Licenze possedute',totalDeposit:'Deposito totale',approvedDeposits:'Depositi approvati',accountStatus:'Stato account',accountStanding:'Condizione account',active:'Attivo',inactive:'Inattivo'},
  ar:{premiumMember:'عضو مميز',uid:'معرّف المستخدم',totalKeys:'إجمالي المفاتيح',ownedKeys:'التراخيص المملوكة',totalDeposit:'إجمالي الإيداع',approvedDeposits:'الإيداعات المعتمدة',accountStatus:'حالة الحساب',accountStanding:'حالة الحساب',active:'نشط',inactive:'غير نشط'},
  vi:{premiumMember:'Thành viên cao cấp',uid:'ID người dùng',totalKeys:'Tổng số key',ownedKeys:'Giấy phép sở hữu',totalDeposit:'Tổng tiền nạp',approvedDeposits:'Tiền nạp đã duyệt',accountStatus:'Trạng thái tài khoản',accountStanding:'Tình trạng tài khoản',active:'Đang hoạt động',inactive:'Không hoạt động'}
 };
 function apply(){
  let lang='en';try{lang=(localStorage.getItem('xtreme_language')||document.documentElement.lang||'en').toLowerCase().split(/[-_]/)[0]}catch(e){}
  const t=words[lang]||words.en;
  document.querySelectorAll('[data-profile-i18n]').forEach(el=>{
    const key=el.getAttribute('data-profile-i18n');
    if(t[key])el.textContent=t[key];
  });
  document.querySelectorAll('[data-profile-status]').forEach(el=>{
    const key=(el.getAttribute('data-profile-status')||'active').toLowerCase()==='active'?'active':'inactive';
    el.textContent=t[key]||words.en[key];
  });
 }
 if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',apply,{once:true});else apply();
 window.addEventListener('xtreme-language-change',apply);
 window.addEventListener('storage',e=>{if(e.key==='xtreme_language')apply()});
 const sel=document.getElementById('profileLanguage');
 if(sel)sel.addEventListener('change',()=>setTimeout(apply,0));
})();
</script>


<style id="xt-profile-premium-crown-v3">
.xt-profile-premium-crown{display:inline-flex;align-items:center;justify-content:center;font-size:14px;line-height:1;filter:drop-shadow(0 0 5px rgba(255,196,64,.42));margin-right:1px}
.xt-profile-status-badge{gap:6px!important}
</style>

<style id="xt-profile-metrics-staggered-v4">
/* Two compact cards on the first row; deposit centered underneath. */
.xt-profile-metrics{
  display:grid!important;
  grid-template-columns:repeat(2,minmax(0,1fr))!important;
  grid-template-areas:"keys status" "deposit deposit"!important;
  align-items:start!important;
  column-gap:16px!important;
  row-gap:13px!important;
}
.xt-profile-metric.xt-metric-keys{grid-area:keys;min-height:112px!important}
.xt-profile-metric.xt-metric-status{grid-area:status;min-height:112px!important}
.xt-profile-metric.xt-metric-deposit{
  grid-area:deposit;
  width:72%!important;
  justify-self:center!important;
  min-height:88px!important;
  padding:10px 14px!important;
}
.xt-profile-metric.xt-metric-deposit .xt-metric-value{margin-top:6px!important}
.xt-profile-metric.xt-metric-deposit .xt-metric-foot{margin-top:4px!important}
@media(max-width:560px){
  .xt-profile-metrics{column-gap:12px!important;row-gap:11px!important}
  .xt-profile-metric.xt-metric-keys,
  .xt-profile-metric.xt-metric-status{min-height:108px!important}
  .xt-profile-metric.xt-metric-deposit{width:72%!important;min-height:82px!important}
}
@media(max-width:365px){
  .xt-profile-metrics{column-gap:9px!important}
  .xt-profile-metric.xt-metric-deposit{width:78%!important}
}
</style>

<style id="xt-profile-metrics-compact-v5">
/* Make only Total Keys and Account Status cards shorter. */
.xt-profile-metric.xt-metric-keys,
.xt-profile-metric.xt-metric-status{
  min-height:86px!important;
  height:86px!important;
  padding:9px 8px!important;
}
.xt-profile-metric.xt-metric-keys .xt-metric-value,
.xt-profile-metric.xt-metric-status .xt-metric-value{
  margin-top:7px!important;
}
.xt-profile-metric.xt-metric-keys .xt-metric-foot,
.xt-profile-metric.xt-metric-status .xt-metric-foot{
  margin-top:4px!important;
}
@media(max-width:560px){
  .xt-profile-metric.xt-metric-keys,
  .xt-profile-metric.xt-metric-status{
    min-height:82px!important;
    height:82px!important;
    padding:8px 6px!important;
  }
}
</style>

<style id="xt-profile-theme-preferences-premium-v6">
/* Compact the two settings panels without shrinking their controls excessively. */
.theme-box{
  padding:10px!important;
  border-radius:17px!important;
  box-shadow:0 10px 26px rgba(0,0,0,.20),inset 0 1px 0 rgba(255,255,255,.07)!important;
}
.theme-switch{
  display:grid!important;
  grid-template-columns:repeat(2,minmax(0,1fr))!important;
  gap:8px!important;
}
.theme-btn{
  position:relative!important;
  isolation:isolate!important;
  overflow:hidden!important;
  min-height:43px!important;
  padding:10px 9px!important;
  border:1px solid rgba(151,174,218,.34)!important;
  border-radius:14px!important;
  background:linear-gradient(145deg,rgba(39,35,67,.98),rgba(18,23,46,.98))!important;
  color:#d8e4f7!important;
  font-size:11px!important;
  font-weight:950!important;
  letter-spacing:.01em!important;
  box-shadow:inset 0 1px 0 rgba(255,255,255,.09),0 5px 13px rgba(0,0,0,.18)!important;
  transition:transform .18s ease,border-color .18s ease,box-shadow .18s ease,background .18s ease!important;
}
.theme-btn:before{
  content:""!important;
  position:absolute!important;
  inset:0!important;
  z-index:-1!important;
  opacity:0!important;
  background:linear-gradient(110deg,rgba(34,211,238,.23),rgba(168,85,247,.28),rgba(244,114,182,.20))!important;
  transition:opacity .18s ease!important;
}
.theme-btn:active{transform:scale(.975)!important}
.theme-btn.active{
  color:#fff!important;
  border-color:rgba(113,224,255,.9)!important;
  background:linear-gradient(120deg,#0aaee7 0%,#6551e8 52%,#c13bd2 100%)!important;
  box-shadow:0 8px 22px rgba(91,83,230,.30),inset 0 1px 0 rgba(255,255,255,.26)!important;
  text-shadow:0 1px 8px rgba(0,0,0,.18)!important;
}
.theme-btn.active:before{opacity:1!important}
.preference-box{
  padding:10px 12px!important;
  border-radius:17px!important;
  box-shadow:0 10px 26px rgba(0,0,0,.18),inset 0 1px 0 rgba(255,255,255,.05)!important;
}
.preference-box .pref-row{
  gap:10px!important;
  padding:9px 0!important;
}
.preference-box .pref-title{font-size:12px!important}
.preference-box .pref-text{font-size:9px!important;line-height:1.35!important}
.preference-box .pref-select{
  min-height:40px!important;
  border-radius:11px!important;
  font-size:12px!important;
}
@media(max-width:480px){
  .theme-box{padding:9px!important}
  .theme-switch{grid-template-columns:repeat(2,minmax(0,1fr))!important;gap:7px!important}
  .theme-btn{min-height:42px!important;padding:9px 7px!important;font-size:10px!important}
  .preference-box{padding:9px 11px!important}
  .preference-box .pref-row{padding:8px 0!important;gap:7px!important}
  .preference-box .pref-select{width:100%!important;max-width:none!important;min-height:39px!important}
}
</style>
</head><body>
<?php $xtHeaderSite = $site; require __DIR__ . '/customer-wallet-header.php'; ?>
<!-- Removed duplicate legacy profile logo/title header; shared account header remains above. -->
<main class="profile-page">
<section class="profile-hero xt-profile-premium-card">
  <div class="xt-profile-identity">
    <a class="xt-profile-avatar-wrap" href="profile-edit.php" aria-label="Edit profile photo">
      <span class="xt-profile-avatar"><?php if($profilePhoto):?><img src="<?=ph($profilePhoto)?>" alt="Profile photo"><?php else:?><?=ph($initial)?><?php endif;?></span>
      <span class="xt-profile-camera" aria-hidden="true">📷</span>
    </a>
    <div class="xt-profile-details">
      <div class="xt-profile-name"><?=ph($name)?></div>
      <div class="xt-profile-badges"><span class="xt-profile-member-badge">✦ XTREME MEMBER</span><span class="xt-profile-status-badge"><i></i><span class="xt-profile-premium-crown" aria-hidden="true">👑</span><span data-profile-i18n="premiumMember">Premium Member</span></span></div>
      <div class="xt-profile-handle"><?=ph($phone ?: ($email ?: 'Account profile'))?></div>
      <div class="xt-profile-email">✉ <span><?=ph($email ?: '—')?></span></div>
      <div class="xt-profile-uid">▣ <span data-profile-i18n="uid">UID</span>: #<?=number_format($userId + 999)?></div>
    </div>
  </div>
  <div class="xt-profile-metrics">
    <article class="xt-profile-metric xt-metric-keys">
      <div class="xt-metric-label"><span class="xt-metric-icon">🔑</span><span data-profile-i18n="totalKeys">Total Keys</span></div>
      <div class="xt-metric-value"><?=number_format($totalKeys)?></div>
      <div class="xt-metric-foot" data-profile-i18n="ownedKeys">Owned licenses</div>
    </article>
    <article class="xt-profile-metric xt-metric-deposit">
      <div class="xt-metric-label"><span class="xt-metric-icon">▣</span><span data-profile-i18n="totalDeposit">Total Deposit</span></div>
      <div class="xt-metric-value"><span data-currency-amount="<?=h($totalDeposit)?>"><?=h(number_format($totalDeposit,2))?></span></div>
      <div class="xt-metric-foot" data-profile-i18n="approvedDeposits">Approved deposits</div>
    </article>
    <article class="xt-profile-metric xt-metric-status">
      <div class="xt-metric-label"><span class="xt-metric-icon">🛡</span><span data-profile-i18n="accountStatus">Account Status</span></div>
      <div class="xt-metric-value" data-profile-status="<?=ph(strtolower($accountStatus))?>" <?=strtolower($accountStatus)==='active'?'is-active':'is-inactive'?>"><?=ph(ucfirst($accountStatus))?></div>
      <div class="xt-metric-foot" data-profile-i18n="accountStanding">Account standing</div>
    </article>
  </div>
</section>
<div class="section-title"><?=ph($site['theme_section_title']??'Theme & Appearance')?></div><section class="theme-box"><div class="theme-switch"><button class="theme-btn" data-theme="black">Black Smooth</button><button class="theme-btn" data-theme="obsidian">Deep Obsidian Dark</button><button class="theme-btn" data-theme="white">White</button><button class="theme-btn" data-theme="premium">Premium</button><button class="theme-btn" data-theme="luxury">Clean Luxury Light</button></div></section>

<div class="section-title">Preferences</div><section class="preference-box profile-language-box"><div class="pref-row"><div><div class="pref-title">Currency</div><div class="pref-text">Product prices are based on BDT and displayed in your selected currency.</div></div><select id="profileCurrency" class="pref-select"><option value="BDT">🇧🇩 BDT — Bangladeshi Taka</option><option value="USD">🇺🇸 USD — US Dollar</option><option value="EUR">🇮🇹 EUR — Euro</option><option value="AED">🇦🇪 AED — UAE Dirham</option><option value="INR">🇮🇳 INR — Indian Rupee</option><option value="NPR">🇳🇵 NPR — Nepalese Rupee</option><option value="VND">🇻🇳 VND — Vietnamese Dong</option><option value="GBP">🇬🇧 GBP — Pound Sterling</option></select></div><div class="pref-row"><div><div class="pref-title">Website Language</div><div class="pref-text">Choose the language used across the website.</div></div><select id="profileLanguage" class="pref-select"><option value="en">English</option><option value="bn">বাংলা</option><option value="hi">हिन्दी</option><option value="ne">नेपाली</option><option value="it">Italiano</option><option value="ar">العربية</option><option value="vi">Tiếng Việt</option></select></div><div id="profileLangStatus" class="pref-status" aria-live="polite"></div><div data-currency-rate-status class="pref-text" style="margin-top:6px">Exchange rate loading…</div></section>

<div class="section-title">Account & Community</div><section class="profile-list"><a class="profile-action" href="profile-edit.php"><span class="pa-icon">✏️</span><span class="pa-main"><span class="pa-title">Edit Profile</span></span><span class="chev">›</span></a>
<a class="profile-action" href="support-ticket.php"><span class="pa-icon">🎧</span><span class="pa-main"><span class="pa-title" data-support-i18n="title">Support Center</span><span class="pa-text" data-support-i18n="subtitle">Create a private support ticket and track replies</span></span><span class="chev">›</span></a>
<a class="profile-action" href="#reset-key"><span class="pa-icon">♻️</span><span class="pa-main"><span class="pa-title">Reset Key</span></span><span class="chev">›</span></a>

<a class="profile-action" href="store.php"><span class="pa-icon">💳</span><span class="pa-main"><span class="pa-title"><?=ph($site['wallet_title']??'My Wallet')?></span><span class="pa-text"><?=ph($site['wallet_text']??'Manage deposits & balance')?></span></span><span class="chev">›</span></a>
<a class="profile-action" href="<?=$referralUrl?>"><span class="pa-icon">🎁</span><span class="pa-main"><span class="pa-title"><?=ph($site['referral_title']??'Referral Hub')?></span><span class="pa-text"><?=ph($site['referral_text']??'Earn rewards & withdraw bonus')?></span></span><span class="chev">›</span></a>
<a class="profile-action" href="<?=$topUrl?>"><span class="pa-icon">🏆</span><span class="pa-main"><span class="pa-title"><?=ph($site['top_members_title']??'Top Members')?></span><span class="pa-text"><?=ph($site['top_members_text']??'Community leaderboard & rankings')?></span></span><span class="chev">›</span></a>
<?php if($telegram!==''): ?><a class="profile-action" href="<?=ph($telegram)?>" target="_blank" rel="noopener"><span class="pa-icon">✈️</span><span class="pa-main"><span class="pa-title"><?=ph($site['telegram_title']??'Telegram Official Channel')?></span><span class="pa-text"><?=ph($site['telegram_text']??'Official announcements & updates')?></span></span><span class="chev">›</span></a><?php endif; ?>
<a class="profile-action" href="<?=ph($rulesUrl ?: 'rules.php')?>"><span class="pa-icon">📜</span><span class="pa-main"><span class="pa-title"><?=ph($site['rules_title']??'Rules & Regulation')?></span><span class="pa-text"><?=ph($site['rules_text']??'Terms of service & platform policies')?></span></span><span class="chev">›</span></a>
<a class="profile-action" href="change-password.php"><span class="pa-icon">🔐</span><span class="pa-main"><span class="pa-title"><?=ph($site['password_title']??'Change Password')?></span><span class="pa-text"><?=ph($site['password_text']??'Security & credentials')?></span></span><span class="chev">›</span></a>
<a class="profile-action logout-card" href="logout.php"><span class="pa-icon">↪</span><span class="pa-main"><span class="pa-title"><?=ph($site['logout_title']??'Logout')?></span><span class="pa-text"><?=ph($site['logout_text']??'Securely exit session')?></span></span><span class="chev">›</span></a>
</section><section id="reset-key" class="preference-box" style="margin-top:14px"><div class="pref-title">Reset Key</div><div class="pref-text">Select one or both actions. Device Reset keeps your current countdown. New Key Reset requires admin approval; the admin will assign a replacement key from Key Manager.</div><form method="post" action="reset-key.php" style="margin-top:12px"><input type="hidden" name="csrf" value="<?=ph($resetKeyCsrf)?>"><select name="key_id" class="pref-select" style="width:100%;max-width:none" required><option value="">Select your key</option><?php try{$rk=db()->prepare("SELECT uk.id,uk.license_key,uk.product_id,uk.plan_id,COALESCE(cp.name,'Key') product_name FROM user_keys uk LEFT JOIN catalog_products cp ON cp.id=uk.product_id WHERE uk.user_id=? ORDER BY uk.id DESC");$rk->execute([$userId]);foreach($rk->fetchAll() as $kk):?><option value="<?=ph($kk['id'])?>" data-product="<?=ph($kk['product_id'])?>" data-plan="<?=ph($kk['plan_id'])?>"><?=ph($kk['product_name'])?> — <?=ph($kk['license_key'])?></option><?php endforeach;}catch(Throwable $ignore){}?></select><label style="display:flex;align-items:center;gap:9px;margin-top:14px"><input type="checkbox" name="request_device" value="1" checked> Device Reset</label><label style="display:flex;align-items:center;gap:9px;margin-top:10px"><input type="checkbox" name="request_replace" value="1" id="requestReplace"> Reset with a New Key</label><div class="pref-text" style="margin-top:8px">If you select both, the admin will reset the device and assign a new key in the same approval.</div><button class="submit" type="submit" style="margin-top:14px">SUBMIT RESET REQUEST</button></form><script>(function(){const form=document.querySelector('#reset-key form'),a=form&&form.querySelector('[name="request_device"]'),b=form&&form.querySelector('[name="request_replace"]');if(form)form.addEventListener('submit',function(e){if(!a.checked&&!b.checked){e.preventDefault();alert('Select Device Reset, Reset with a New Key, or both.');}})})();</script></section></main><nav class="xt-bottom-navigation-card" aria-label="Main navigation">
<a href="store.php" data-nav="store" aria-label="Store"><span class="xt-nav-icon"><img src="assets/nav-icons/store.png" alt="" aria-hidden="true"></span><span class="xt-nav-label">Store</span></a>
<a href="my-keys.php" data-nav="keys" aria-label="My Keys"><span class="xt-nav-icon"><img src="assets/nav-icons/keys.png" alt="" aria-hidden="true"></span><span class="xt-nav-label">My Keys</span></a>
<a href="deposit.php" data-nav="funds" aria-label="Add Funds"><span class="xt-nav-icon"><img src="assets/nav-icons/funds.png" alt="" aria-hidden="true"></span><span class="xt-nav-label">Add Funds</span></a>
<a href="history.php" data-nav="history" aria-label="History"><span class="xt-nav-icon"><img src="assets/nav-icons/history.png" alt="" aria-hidden="true"></span><span class="xt-nav-label">History</span></a>
<a href="profile.php" class="is-active" data-nav="profile" aria-label="Profile"><span class="xt-nav-icon"><img src="assets/nav-icons/profile.png" alt="" aria-hidden="true"></span><span class="xt-nav-label">Profile</span></a>
</nav>
<script>
(function(){const key='xtreme_theme';const fallback=<?=json_encode($themeDefault)?>;const allowed=['black','obsidian','white','premium','luxury'];function apply(t){if(!allowed.includes(t))t=fallback||'premium';document.documentElement.dataset.theme=t;try{localStorage.setItem(key,t)}catch(e){}document.querySelectorAll('.theme-btn').forEach(b=>b.classList.toggle('active',b.dataset.theme===t));window.dispatchEvent(new CustomEvent('xtreme-theme-change',{detail:{theme:t}}));}let t='premium';try{t=localStorage.getItem(key)||fallback||'premium'}catch(e){t=fallback||'premium'}apply(t);document.querySelectorAll('.theme-btn').forEach(b=>b.addEventListener('click',()=>apply(b.dataset.theme)));})();
</script><script>(function(){const lang=document.getElementById('profileLanguage'),cur=document.getElementById('profileCurrency'),status=document.getElementById('profileLangStatus');let currentLang=<?=json_encode((string)($prefs['language']??'en'))?>,currentCur=<?=json_encode((string)($prefs['currency']??'USD'))?>;try{currentLang=localStorage.getItem('xtreme_language')||currentLang;currentCur=localStorage.getItem('xtreme_currency')||currentCur}catch(e){}if(lang)lang.value=currentLang;if(cur)cur.value=currentCur;async function save(){const l=lang?lang.value:currentLang,c=cur?cur.value:currentCur;try{localStorage.setItem('xtreme_language',l);localStorage.setItem('xtreme_currency',c);window.dispatchEvent(new Event('xtreme-language-change'));window.dispatchEvent(new Event('xtreme-currency-change'));const country={BDT:'BD',USD:'US',EUR:'IT',AED:'AE',INR:'IN',NPR:'NP',VND:'VN',GBP:'GB'}[c]||'US';const fd=new FormData();fd.append('language',l);fd.append('currency',c);fd.append('country',country);const r=await fetch('preferences.php',{method:'POST',body:fd,credentials:'same-origin'});const j=await r.json();status.textContent=j.ok?'Saved':'Could not save';}catch(e){status.textContent='Saved on this device';}setTimeout(()=>{if(status)status.textContent=''},1800)}if(lang)lang.addEventListener('change',save);if(cur)cur.addEventListener('change',save);})();</script><script src="background-video.js?v=20261018-starfall2"></script>





































<script src="assets/xtreme-music.js?v=3" data-enabled="<?=e(site_setting('background_music_enabled','1'))?>" data-src="<?=e(site_setting('background_music_path','uploads/music/xtreme-background.m4a'))?>" defer></script>
</body></html>






<style id="xtreme-v21-profile-wallet-balance-icon">
/* V21: Show the same cyan wallet icon beside the Profile wallet balance. */
.profile-page .balance-card.primary .b-value{
  display:flex!important;align-items:center!important;gap:12px!important;
  min-width:0!important;flex-wrap:nowrap!important;
}
.profile-page .balance-card.primary .b-value::before{
  content:""!important;display:inline-block!important;flex:0 0 36px!important;
  width:36px!important;height:32px!important;
  background:url("assets/nav-icons/wallet-cyan-reference.png?v=21") center/contain no-repeat!important;
  filter:drop-shadow(0 0 7px rgba(0,205,255,.32))!important;
}
.profile-page .balance-card.primary .b-value span{
  min-width:0!important;overflow-wrap:anywhere!important;
}
@media(max-width:480px){
  .profile-page .balance-card.primary .b-value::before{
    flex-basis:32px!important;width:32px!important;height:29px!important;
  }
}
</style>

<style id="xtreme-v22-profile-wallet-icon-size">
/* V22: Enlarge the Profile wallet icon while keeping the amount readable. */
.profile-page .balance-card.primary .b-value::before{
  flex:0 0 46px!important;width:46px!important;height:42px!important;
}
@media(max-width:480px){
  .profile-page .balance-card.primary .b-value::before{
    flex:0 0 42px!important;width:42px!important;height:38px!important;
  }
}
</style>

<style id="xtreme-v23-profile-wallet-icon-extra-large">
.profile-page .balance-card.primary .b-value{gap:15px!important}
.profile-page .balance-card.primary .b-value::before{flex:0 0 54px!important;width:54px!important;height:49px!important}
@media(max-width:480px){.profile-page .balance-card.primary .b-value::before{flex:0 0 50px!important;width:50px!important;height:46px!important}}
@media(max-width:360px){.profile-page .balance-card.primary .b-value::before{flex:0 0 44px!important;width:44px!important;height:41px!important}.profile-page .balance-card.primary .b-value{gap:10px!important}}
</style>

<script id="xtreme-support-center-i18n">
(function(){
 const words={
  en:{title:"Support Center",subtitle:"Create a private support ticket and track replies"},
  bn:{title:"সাপোর্ট সেন্টার",subtitle:"ব্যক্তিগত সাপোর্ট টিকিট খুলুন এবং উত্তরের অবস্থা দেখুন"},
  hi:{title:"सपोर्ट सेंटर",subtitle:"निजी सपोर्ट टिकट बनाएँ और जवाबों को ट्रैक करें"},
  ne:{title:"सपोर्ट सेन्टर",subtitle:"निजी सपोर्ट टिकट खोल्नुहोस् र जवाफहरू हेर्नुहोस्"},
  it:{title:"Centro assistenza",subtitle:"Apri un ticket di assistenza privato e segui le risposte"},
  ar:{title:"مركز الدعم",subtitle:"أنشئ تذكرة دعم خاصة وتابع الردود"},
  vi:{title:"Trung tâm hỗ trợ",subtitle:"Tạo yêu cầu hỗ trợ riêng và theo dõi phản hồi"}
 };
 function apply(){
  let lang='en';try{lang=localStorage.getItem('xtreme_language')||'en'}catch(e){}
  const t=words[lang]||words.en;
  document.querySelectorAll('[data-support-i18n="title"]').forEach(el=>el.textContent=t.title);
  document.querySelectorAll('[data-support-i18n="subtitle"]').forEach(el=>el.textContent=t.subtitle);
 }
 apply();
 window.addEventListener('xtreme-language-change',apply);
 document.addEventListener('change',e=>{if(e.target&&e.target.id==='profileLanguage')setTimeout(apply,0)});
 window.addEventListener('storage',e=>{if(e.key==='xtreme_language')apply()});
 document.addEventListener('DOMContentLoaded',apply);
})();
</script>
