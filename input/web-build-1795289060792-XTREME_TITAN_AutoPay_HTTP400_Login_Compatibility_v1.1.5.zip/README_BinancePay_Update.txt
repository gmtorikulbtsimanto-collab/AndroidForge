XTREME TITAN — Binance Pay Deposit Update

Included changes:
- Adds Binance Pay as a deposit method for every supported currency/country.
- Keeps existing currency behavior and existing bKash/Nagad (BDT) and PayPal (non-BDT) options.
- Adds a gold Binance Pay card style with spacing below the existing payment methods.
- Displays the configured Binance UID and optional Binance Receive QR image.
- Adds Admin > Site Settings fields to change the Binance UID, upload/replace the Binance Pay logo, and upload/replace the optional QR image.

Upload:
1. Back up your current website files and database first.
2. Upload deposit.php to the website root, replacing the existing deposit.php.
3. Upload admin/site-settings.php to /admin/, replacing the existing file.
4. Upload config.php to the website root only after backing up the current config.php. This is the supplied config.php with the new Binance setting defaults added; retain your live database credentials if they differ.
5. Upload assets/binance-pay.svg to /assets/.
6. Open Admin > Site Settings. Set the Binance Pay UID and optionally upload your Binance logo and Receive QR image, then Save.

Important:
- The default Binance UID is 1224732977 from the account screenshot you provided. Confirm it is the correct receiving account before accepting deposits.
- Binance Pay is shown for all supported currencies. This update does not introduce a live exchange-rate conversion or automatic Binance payment verification; admins should verify each payment in Binance before approving the deposit.
- The amount and wallet-credit logic remain as in the supplied site files.
