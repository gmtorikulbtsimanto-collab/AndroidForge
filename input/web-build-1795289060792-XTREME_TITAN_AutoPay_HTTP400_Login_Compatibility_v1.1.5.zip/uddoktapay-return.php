<?php
require_once __DIR__.'/config.php';
require_once __DIR__.'/uddoktapay-lib.php';
require_login();
$invoice=trim((string)($_GET['invoice_id']??$_POST['invoice_id']??''));
$depositId=(int)($_GET['deposit_id']??$_POST['deposit_id']??0);
$message='We could not confirm this payment yet. If you completed payment, please refresh your wallet history in a moment.';
$ok=false;
try {
    if ($invoice !== '' && $depositId > 0) {
        xt_uddokta_ensure_deposit_columns();
        $pdo=db();
        $find=$pdo->prepare("SELECT id,user_id,payment_method,uddoktapay_invoice_id,status FROM deposits WHERE id=? AND user_id=? LIMIT 1");
        $find->execute([$depositId,(int)($_SESSION['user_id']??0)]);
        $dep=$find->fetch(PDO::FETCH_ASSOC);
        if (!$dep || strtolower((string)$dep['payment_method'])!=='uddoktapay') {
            throw new RuntimeException('This payment does not belong to your account.');
        }
        if (!empty($dep['uddoktapay_invoice_id']) && !hash_equals((string)$dep['uddoktapay_invoice_id'],$invoice)) {
            throw new RuntimeException('Invoice reference mismatch.');
        }
        $save=$pdo->prepare("UPDATE deposits SET uddoktapay_invoice_id=? WHERE id=? AND user_id=? AND (uddoktapay_invoice_id IS NULL OR uddoktapay_invoice_id='')");
        $save->execute([$invoice,$depositId,(int)$_SESSION['user_id']]);
        $ok=xt_uddokta_complete_invoice($invoice);
        if($ok) $message='Payment verified successfully. Your wallet has been credited.';
        else $message='Payment is not marked COMPLETED by UddoktaPay yet. Please wait and refresh your transaction history.';
    } elseif ($invoice !== '') {
        // Backward-compatible path for an invoice already attached to a deposit.
        $st=db()->prepare('SELECT id,user_id FROM deposits WHERE uddoktapay_invoice_id=? LIMIT 1');
        $st->execute([$invoice]); $dep=$st->fetch(PDO::FETCH_ASSOC);
        if($dep && (int)$dep['user_id']===(int)($_SESSION['user_id']??0)) {
            $ok=xt_uddokta_complete_invoice($invoice);
            if($ok)$message='Payment verified successfully. Your wallet has been credited.';
        }
    }
} catch(Throwable $e) { error_log('UddoktaPay return: '.$e->getMessage()); }
?><!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no"><title>Payment status · XTREME TITAN</title><link rel="stylesheet" href="theme.php"><link rel="stylesheet" href="reference-theme.css"><link rel="stylesheet" href="premium-global.css"><style>body{font-family:system-ui,Arial,sans-serif}.pay-status{width:min(520px,calc(100% - 28px));margin:9vh auto;padding:30px 24px;text-align:center;border-radius:24px;background:linear-gradient(145deg,#10243a,#071321);border:1px solid #1a6377;color:#f4f8ff;box-shadow:0 22px 60px #0008}.pay-status .symbol{font-size:42px}.pay-status h1{font-size:26px}.pay-status p{color:#b8c9dc;line-height:1.6}.pay-status a{display:inline-block;margin:10px;padding:12px 18px;border-radius:12px;background:linear-gradient(90deg,#00cfa8,#169fff);color:#04131d;font-weight:850;text-decoration:none}</style></head><body><main class="pay-status"><div class="symbol"><?= $ok?'✓':'◷' ?></div><h1><?= $ok?'Payment successful':'Payment status' ?></h1><p><?=h($message)?></p><a href="history.php">Transaction History</a><a href="deposit.php">Add Funds</a></main></body></html>
