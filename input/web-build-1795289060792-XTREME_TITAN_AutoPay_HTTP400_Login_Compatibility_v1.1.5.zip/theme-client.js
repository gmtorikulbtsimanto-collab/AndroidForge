(function(){
const key='xtreme_theme', allowed=['black','obsidian','white','premium','luxury'];
function apply(t){if(!allowed.includes(t))t='premium';document.documentElement.dataset.theme=t;document.documentElement.classList.add('theme-ready');try{localStorage.setItem(key,t)}catch(e){}document.querySelectorAll('.theme-btn').forEach(b=>b.classList.toggle('active',b.dataset.theme===t));window.dispatchEvent(new CustomEvent('xtreme-theme-change',{detail:{theme:t}}));}
let t='premium';try{t=localStorage.getItem(key)||'premium'}catch(e){}apply(t);
window.XtremeTheme={set:apply,get:()=>document.documentElement.dataset.theme||'premium'};
document.addEventListener('click',e=>{const b=e.target.closest('.theme-btn');if(b){e.preventDefault();apply(b.dataset.theme)}});
window.addEventListener('storage',e=>{if(e.key===key&&e.newValue)apply(e.newValue)});
})();