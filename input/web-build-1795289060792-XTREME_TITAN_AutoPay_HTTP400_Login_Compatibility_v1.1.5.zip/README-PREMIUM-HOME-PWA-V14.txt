XTREME TITAN PREMIUM HOME + PWA ICONS V14

Changes based on V13: refreshed the public landing page while keeping the existing Login and Register destinations and PHP settings; added site-logo-based favicon, Apple touch icon, and web manifest for Add to Home Screen icons; normalized home-screen title for login/register and reseller entry pages.

Important: iOS may cache old home-screen icons. Remove the old shortcut, clear Safari website data if needed, revisit the site, then use Share > Add to Home Screen again. The visible label below an iOS icon is text and cannot be replaced by an image; the icon itself uses the site logo.

No live hosting test was performed. Existing authentication and payment logic was not intentionally changed.
