STORE BACKGROUND + DASHBOARD FIX

This package makes Store the combined Store + Dashboard landing page.
- Animated background: assets/tanofficial_neon_background.gif
- Small centered XTREME TITAN logo at top of Store
- Dashboard balance/stats/quick access are shown above products
- Bottom navigation has 5 items: Store, My Keys, Deposit, History, Profile
- dashboard.php redirects to store.php by design

Do NOT replace your existing config.php.
After upload, hard refresh Safari or open the site in a Private tab once.
