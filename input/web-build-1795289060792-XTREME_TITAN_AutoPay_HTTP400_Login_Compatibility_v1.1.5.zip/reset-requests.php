<?php
require_once __DIR__.'/../config.php';
if(empty($_SESSION['admin_id'])&&empty($_SESSION['admin_logged_in'])){header('Location: login.php');exit;}
ensure_key_reset_tables();$pdo=db();$msg='';$err='';
/*
 * Reset requests are an event history, not one row per key/status.
 * Remove the legacy unique index that blocked repeat approvals/rejections.
 * Rejected requests are intentionally deleted; approved requests remain in history.
 */
try {
    $idx = $pdo->query("SHOW INDEX FROM key_reset_requests")->fetchAll(PDO::FETCH_ASSOC);
    foreach ($idx as $ix) {
        if ((string)($ix['Key_name'] ?? '') === 'uq_pending_key' && (int)($ix['Non_unique'] ?? 1) === 0) {
            $pdo->exec("ALTER TABLE key_reset_requests DROP INDEX uq_pending_key");
            break;
        }
    }
    $pdo->exec("DELETE FROM key_reset_requests WHERE status='rejected'");
} catch (Throwable $migrationError) {
    $err = 'Database migration failed: ' . $migrationError->getMessage();
}
if(empty($_SESSION['admin_csrf']))$_SESSION['admin_csrf']=bin2hex(random_bytes(32));$csrf=$_SESSION['admin_csrf'];
if($_SERVER['REQUEST_METHOD']==='POST')try{
 if(!hash_equals($csrf,(string)($_POST['csrf']??'')))throw new RuntimeException('Security verification failed.');
 $id=(int)($_POST['id']??0);$action=(string)($_POST['action']??'');$postedInventoryId=(int)($_POST['replacement_key_id']??0);$st=$pdo->prepare('SELECT * FROM key_reset_requests WHERE id=? LIMIT 1');$st->execute([$id]);$r=$st->fetch(PDO::FETCH_ASSOC);if(!$r)throw new RuntimeException('Request not found.');if($r['status']!=='pending')throw new RuntimeException('Request already reviewed.');
 if($action==='approve'){
  $pdo->beginTransaction();
  $uk=$pdo->prepare('SELECT id,license_key,product_id,plan_id FROM user_keys WHERE id=? AND user_id=? FOR UPDATE');$uk->execute([(int)$r['key_id'],(int)$r['user_id']]);$keyRow=$uk->fetch(PDO::FETCH_ASSOC);if(!$keyRow)throw new RuntimeException('Assigned key no longer exists.');
  $type=(string)($r['request_type']??'device');
  if(in_array($type,['replace','both'],true)){
   $inventoryId=$postedInventoryId>0?$postedInventoryId:(int)($r['new_inventory_key_id']??0);if($inventoryId<=0)throw new RuntimeException('Select a replacement key from Key Manager before approving this request.');
   $inv=$pdo->prepare('SELECT id,product_id,plan_id,license_key,price FROM user_keys WHERE id=? AND user_id IS NULL FOR UPDATE');$inv->execute([$inventoryId]);$inventory=$inv->fetch(PDO::FETCH_ASSOC);if(!$inventory)throw new RuntimeException('The selected replacement key is no longer available.');
   if((int)$inventory['product_id']!==(int)$keyRow['product_id'] || (int)$inventory['plan_id']!==(int)$keyRow['plan_id'])throw new RuntimeException('Replacement key must belong to the same product and plan as the selected user key.');
   $duration=0;$ds=$pdo->prepare('SELECT COALESCE(duration_seconds,CASE WHEN duration_days<0 THEN ABS(duration_days)*3600 ELSE duration_days*86400 END,0) FROM product_plans WHERE id=? AND product_id=?');$ds->execute([(int)$inventory['plan_id'],(int)$inventory['product_id']]);$duration=(int)$ds->fetchColumn();
   // The license_key column is UNIQUE. Remove the selected inventory row first,
   // inside this transaction, so assigning its license_key to the user's row does
   // not collide with the still-existing inventory row. If the update fails,
   // rollback restores the inventory row.
   $del=$pdo->prepare('DELETE FROM user_keys WHERE id=? AND user_id IS NULL');
   $del->execute([$inventoryId]);
   if($del->rowCount()!==1) throw new RuntimeException('The selected replacement key is no longer available. Please refresh and choose another key.');
   $upd=$pdo->prepare('UPDATE user_keys SET license_key=?,product_id=?,plan_id=?,price=?,duration_seconds=?,purchased_at=UTC_TIMESTAMP(),device_token=NULL,reset_generation=reset_generation+1 WHERE id=? AND user_id=?');
   $upd->execute([$inventory['license_key'],(int)$inventory['product_id'],(int)$inventory['plan_id'],$inventory['price'],$duration,(int)$r['key_id'],(int)$r['user_id']]);
   if($upd->rowCount()!==1) throw new RuntimeException('Could not assign the replacement key. The transaction was cancelled.');
   $msg=$type==='both'?'Both actions approved. The replacement key is assigned and its countdown starts now; device binding was reset.':'Replacement key approved. It now appears in My Keys and its full plan countdown restarted now.';
  } else{$pdo->prepare('UPDATE user_keys SET device_token=NULL,reset_generation=reset_generation+1 WHERE id=? AND user_id=?')->execute([(int)$r['key_id'],(int)$r['user_id']]);$msg='Device reset approved. Existing countdown was preserved.';}
  $pdo->prepare("UPDATE key_reset_requests SET status='approved',reviewed_at=? WHERE id=?")->execute([utc_sql_now(),$id]);$pdo->commit();
 }elseif($action==='reject'){
  // Rejection means permanently remove only this request row.
  // The user's key and all approved history remain untouched.
  $delReq=$pdo->prepare("DELETE FROM key_reset_requests WHERE id=? AND status='pending'");
  $delReq->execute([$id]);
  if($delReq->rowCount()!==1) throw new RuntimeException('Request could not be rejected. Please refresh and try again.');
  $msg='Request rejected and permanently deleted from database.';
}else throw new RuntimeException('Unknown action.');
}catch(Throwable $e){if($pdo->inTransaction())$pdo->rollBack();$err=$e->getMessage();}
$rows=[];$stockRows=[];try{$rows=$pdo->query("SELECT r.id,r.status,r.request_type,r.new_license_key,r.new_inventory_key_id,r.created_at,r.reviewed_at,u.name,u.email,k.license_key,k.product_id,k.plan_id,k.purchased_at,COALESCE(k.duration_seconds,pp.duration_seconds,CASE WHEN pp.duration_days<0 THEN ABS(pp.duration_days)*3600 ELSE COALESCE(pp.duration_days,0)*86400 END,0) duration_seconds,COALESCE(pp.duration_label,CONCAT(COALESCE(pp.duration_days,0),' Days'),'Plan not set') plan_name,COALESCE(cp.name,'Key') product_name,COALESCE(inv.license_key,r.new_license_key,'—') requested_key FROM key_reset_requests r JOIN users u ON u.id=r.user_id JOIN user_keys k ON k.id=r.key_id LEFT JOIN catalog_products cp ON cp.id=k.product_id LEFT JOIN product_plans pp ON pp.id=k.plan_id AND pp.product_id=k.product_id LEFT JOIN user_keys inv ON inv.id=r.new_inventory_key_id ORDER BY r.id DESC LIMIT 200")->fetchAll(PDO::FETCH_ASSOC);$stockRows=$pdo->query("SELECT id,license_key,product_id,plan_id FROM user_keys WHERE user_id IS NULL AND license_key IS NOT NULL ORDER BY id DESC")->fetchAll(PDO::FETCH_ASSOC);}catch(Throwable $e){}
function ah($v){return htmlspecialchars((string)$v,ENT_QUOTES,'UTF-8');}
function reset_plan_duration_label($seconds): string {
 $seconds=max(0,(int)$seconds);
 if($seconds<=0)return 'Duration not set';
 $days=intdiv($seconds,86400);$hours=intdiv($seconds%86400,3600);
 if($days>0 && $hours>0)return $days.' day'.($days===1?'':'s').' '.$hours.' hour'.($hours===1?'':'s');
 if($days>0)return $days.' day'.($days===1?'':'s');
 $minutes=intdiv($seconds%3600,60);
 return $hours.' hour'.($hours===1?'':'s').($minutes>0?' '.$minutes.' min':'');
}
?><!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no"><title>Reset Requests</title><link rel="stylesheet" href="../theme.php?v=20260929-27"><link rel="stylesheet" href="admin-theme.css"><link rel="stylesheet" href="../responsive-lock.css"><style>
*{box-sizing:border-box}.wrap{width:100%;max-width:1440px;margin:0 auto;padding:clamp(12px,2.5vw,28px);color:#edf4ff}.panel{padding:clamp(14px,2.4vw,28px);border-radius:24px;background:linear-gradient(145deg,rgba(10,20,36,.97),rgba(10,10,27,.96));border:1px solid rgba(53,211,255,.24);box-shadow:0 18px 55px rgba(0,0,0,.32),inset 0 1px rgba(255,255,255,.035);min-width:0;overflow:hidden}.panel h1{margin:0 0 22px;font-size:clamp(25px,3.5vw,38px);line-height:1.15;letter-spacing:-.5px;color:#f4f7ff;text-shadow:0 0 24px rgba(70,170,255,.16)}table{width:100%;border-collapse:separate;border-spacing:0;table-layout:auto}th{padding:14px 11px;text-align:left;font-size:12px;line-height:1.35;font-weight:850;color:#bcd0e8;background:rgba(21,35,58,.92);border-top:1px solid rgba(90,160,220,.18);border-bottom:1px solid rgba(90,160,220,.24);white-space:normal}th:first-child{border-radius:12px 0 0 12px}th:last-child{border-radius:0 12px 12px 0}td{padding:16px 11px;border-bottom:1px solid rgba(155,180,215,.12);text-align:left;font-size:12px;line-height:1.55;vertical-align:top;overflow-wrap:anywhere;color:#e4ecfa}tr:last-child td{border-bottom:0}.time-left{font-weight:900;color:#63ff16;white-space:normal}.time-left.expired{color:#ff7189}.expiry-date{color:#b7c5d8;white-space:normal}.plan-duration{color:#d8b4fe;font-weight:900}.btn{display:inline-flex;align-items:center;justify-content:center;min-height:40px;border:0;border-radius:11px;padding:10px 13px;color:#fff;font-weight:900;font-size:12px;cursor:pointer;box-shadow:0 5px 18px rgba(0,0,0,.18)}.ok{background:linear-gradient(135deg,#059669,#10b981)}.no{background:linear-gradient(135deg,#be123c,#e11d48)}.badge{display:inline-block;padding:5px 9px;border-radius:999px;background:rgba(16,216,255,.11);border:1px solid rgba(16,216,255,.15);color:#10d8ff;font-size:10px;font-weight:900;line-height:1.35;white-space:normal}.small{color:#aebdd2}select{min-height:42px}.panel a{color:#8ddcff;text-decoration:none;font-weight:800}.panel>p:last-child{margin:22px 0 0}.panel form{vertical-align:top}.panel form+form{margin-top:6px}.panel button:active{transform:scale(.98)}
@media(max-width:760px){.wrap{padding:10px}.panel{padding:15px 12px;border-radius:20px}.panel h1{font-size:27px;margin-bottom:18px}table,tbody{display:block;width:100%;min-width:0}table tr:first-child{display:none}table tr{display:block;width:100%;margin:0 0 14px;padding:5px 12px 10px;border:1px solid rgba(75,180,255,.25);border-radius:17px;background:linear-gradient(145deg,rgba(16,27,48,.92),rgba(12,14,32,.94));box-shadow:0 8px 22px rgba(0,0,0,.18);overflow:hidden}table tr:last-child{margin-bottom:0}td{display:grid;grid-template-columns:minmax(104px,34%) minmax(0,1fr);gap:12px;width:100%;padding:11px 0;border-bottom:1px solid rgba(155,180,215,.10);font-size:12px;line-height:1.5;min-width:0}td:last-child{border-bottom:0}td:before{display:block;color:#91a9c6;font-size:10px;font-weight:900;letter-spacing:.45px;text-transform:uppercase;line-height:1.45;content:''}td:nth-child(1):before{content:'User'}td:nth-child(2):before{content:'Current Key'}td:nth-child(3):before{content:'Product'}td:nth-child(4):before{content:'Plan Duration'}td:nth-child(5):before{content:'Time Remaining'}td:nth-child(6):before{content:'Expiry Date / Time'}td:nth-child(7):before{content:'Request Type'}td:nth-child(8):before{content:'Requested New Key'}td:nth-child(9):before{content:'Requested At'}td:nth-child(10):before{content:'Status'}td:nth-child(11):before{content:'Action'}td:nth-child(11){display:block;padding-top:13px}td:nth-child(11):before{margin-bottom:9px}td:nth-child(11) form{display:block!important;width:100%!important;min-width:0!important;margin:0 0 8px!important}td:nth-child(11) form:last-child{margin-bottom:0!important}td:nth-child(11) select{width:100%!important;max-width:none!important;min-height:44px;font-size:13px}td:nth-child(11) button{width:100%;min-height:43px;margin-top:7px!important;font-size:13px}td:nth-child(11) form+form button{margin-top:0!important}.badge{max-width:100%;width:max-content;max-width:100%}.time-left,.expiry-date{word-break:normal}.panel>p:last-child{padding:4px 2px 0}}
@media(min-width:761px) and (max-width:1100px){.wrap{padding:14px}.panel{padding:16px}th,td{padding:10px 7px;font-size:11px}.btn{padding:8px 9px}}
</style><script src="admin-background.js" defer></script><script src="admin-action-progress.js?v=20261023-inline-progress25" defer></script>
<link rel="icon" type="image/png" sizes="48x48" href="/assets/pwa-icon-48.png">
<link rel="apple-touch-icon" sizes="180x180" href="/assets/pwa-icon-180.png">
<link rel="manifest" href="/admin/admin-manifest.json">
<meta name="apple-mobile-web-app-title" content="XTREME TITAN">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="mobile-web-app-capable" content="yes">
<meta name="theme-color" content="#080a14">
<script src="admin-action-progress.js?v=20261023-inline-progress25" defer></script>
</head><body><main class="wrap"><section class="panel"><h1>Key Reset Requests</h1><?php if($msg):?><p style="color:#63ff16;font-weight:900"><?=ah($msg)?></p><?php endif;?><?php if($err):?><p style="color:#ff8da0;font-weight:900"><?=ah($err)?></p><?php endif;?><table><tr><th>User</th><th>Current Key</th><th>Product</th><th>Plan Duration</th><th>Time Remaining</th><th>Expiry Date / Time</th><th>Request Type</th><th>Requested New Key</th><th>Requested</th><th>Status</th><th>Action</th></tr><?php foreach($rows as $r):?><tr><td><?=ah($r['name'])?><br><small><?=ah($r['email'])?></small></td><td><?=ah($r['license_key'])?></td><td><?=ah($r['product_name'])?></td><td><span class="plan-duration"><?=ah(reset_plan_duration_label($r['duration_seconds']??0))?></span><br><small class="small"><?=ah($r['plan_name']??'Plan not set')?></small></td><?php $keyStart=utc_epoch_from_db($r['purchased_at']??'');$keyDuration=(int)($r['duration_seconds']??0);$keyExpiry=($keyStart>0&&$keyDuration>0)?($keyStart+$keyDuration):0; ?><td><?php if($keyExpiry>0):?><span class="time-left" data-expiry="<?= (int)$keyExpiry ?>">Calculating…</span><?php else:?><span class="small">No expiry data</span><?php endif;?></td><td><?php if($keyExpiry>0):?><time class="expiry-date" data-epoch="<?= (int)$keyExpiry ?>"><?=ah(gmdate('Y-m-d H:i:s',$keyExpiry))?> UTC</time><?php else:?>—<?php endif;?></td><td><?php if((string)($r['request_type']??'device')==='both'):?><span class="badge">DEVICE RESET</span><br><span class="badge" style="display:inline-block;margin-top:5px;background:rgba(168,85,247,.16);color:#d8b4fe">NEW KEY</span><br><small class="small">Approve button processes both together.</small><?php elseif((string)($r['request_type']??'device')==='replace'):?><span class="badge" style="background:rgba(168,85,247,.16);color:#d8b4fe">NEW KEY ONLY</span><?php else:?><span class="badge">DEVICE RESET ONLY</span><?php endif;?></td><td><?=ah($r['requested_key']??$r['new_license_key']??'—')?></td><td><?=ah($r['created_at'])?></td><td><span class="badge"><?=ah(strtoupper($r['status']))?></span></td><td><?php if($r['status']==='pending'):?><form method="post" style="display:inline-block;min-width:180px"><input type="hidden" name="csrf" value="<?=ah($csrf)?>"><input type="hidden" name="id" value="<?=ah($r['id'])?>"><?php if(in_array((string)$r['request_type'],['replace','both'],true)):?><label class="small" style="display:block;margin:4px 0">Assign replacement key</label><select name="replacement_key_id" required style="max-width:220px;width:100%;padding:7px;border-radius:8px;background:#0b1524;color:#fff;border:1px solid #53647a"><option value="">Choose key from Key Manager</option><?php foreach($stockRows as $stock):if((int)$stock['product_id']===(int)$r['product_id']&&(int)$stock['plan_id']===(int)$r['plan_id']):?><option value="<?=ah($stock['id'])?>"><?=ah($stock['license_key'])?></option><?php endif;endforeach;?></select><?php endif;?><?php if((string)($r['request_type']??'device')==='both'):?><button class="btn ok" style="margin-top:6px" name="action" value="approve">Approve Both</button><?php elseif((string)($r['request_type']??'device')==='replace'):?><button class="btn ok" style="margin-top:6px" name="action" value="approve">Approve New Key</button><?php else:?><button class="btn ok" style="margin-top:6px" name="action" value="approve">Approve Device Reset</button><?php endif;?></form> <form method="post" style="display:inline-block"><input type="hidden" name="csrf" value="<?=ah($csrf)?>"><input type="hidden" name="id" value="<?=ah($r['id'])?>"><button class="btn no" name="action" value="reject">Reject</button></form><?php else:?>—<?php endif;?></td></tr><?php endforeach;?></table><p><a href="dashboard.php">← Admin Dashboard</a></p></section></main><script>
(function(){
 const fmtDate=new Intl.DateTimeFormat(undefined,{year:'numeric',month:'short',day:'2-digit',hour:'2-digit',minute:'2-digit',second:'2-digit'});
 document.querySelectorAll('.expiry-date[data-epoch]').forEach(el=>{const epoch=Number(el.dataset.epoch);if(epoch>0)el.textContent=fmtDate.format(new Date(epoch*1000));});
 function tick(){const now=Math.floor(Date.now()/1000);document.querySelectorAll('.time-left[data-expiry]').forEach(el=>{let left=Number(el.dataset.expiry)-now;if(left<=0){el.textContent='⛔ Expired';el.classList.add('expired');return;}const d=Math.floor(left/86400);left%=86400;const h=Math.floor(left/3600);left%=3600;const m=Math.floor(left/60);const sec=left%60;el.textContent=(d?d+'d ':'')+(h+'h '+m+'m '+sec+'s');el.classList.remove('expired');});}
 tick();setInterval(tick,1000);
})();
</script></body></html>