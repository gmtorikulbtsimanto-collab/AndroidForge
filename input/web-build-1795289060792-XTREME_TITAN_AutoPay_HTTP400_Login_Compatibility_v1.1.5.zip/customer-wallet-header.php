<?php
/* Shared customer header: site logo, account role, live wallet balance and Add Funds. */
if (!isset($xtHeaderSite) || !is_array($xtHeaderSite)) {
    $xtHeaderSite = function_exists('site_settings') ? site_settings() : [];
}
$xtHeaderUserId = (int)($_SESSION['user_id'] ?? 0);
$xtHeaderRole = function_exists('current_user_role') ? current_user_role() : 'user';
$xtHeaderAccountLabel = ($xtHeaderRole === 'reseller') ? 'Reseller' : 'User';
$xtHeaderBalance = 0.0;
try {
    $xtHeaderPdo = db();
    $xtHeaderDepCols = $xtHeaderPdo->query('SHOW COLUMNS FROM deposits')->fetchAll(PDO::FETCH_COLUMN);
    $xtHeaderDepExpr = in_array('amount_bdt', $xtHeaderDepCols, true)
        ? 'SUM(COALESCE(amount_bdt, amount))' : 'SUM(amount)';
    $xtHeaderStmt = $xtHeaderPdo->prepare("SELECT COALESCE($xtHeaderDepExpr,0) FROM deposits WHERE user_id=? AND LOWER(status)='approved'");
    $xtHeaderStmt->execute([$xtHeaderUserId]);
    $xtHeaderDeposits = (float)$xtHeaderStmt->fetchColumn();
    $xtHeaderStmt = $xtHeaderPdo->prepare('SELECT COALESCE(SUM(total_amount),0) FROM user_purchases WHERE user_id=?');
    $xtHeaderStmt->execute([$xtHeaderUserId]);
    $xtHeaderPurchases = (float)$xtHeaderStmt->fetchColumn();
    $xtHeaderBalance = max(0, $xtHeaderDeposits - $xtHeaderPurchases);
} catch (Throwable $xtHeaderError) {
    error_log('Customer wallet header balance: ' . $xtHeaderError->getMessage());
}
$xtHeaderLogo = trim((string)($xtHeaderSite['logo_path'] ?? ''));
if ($xtHeaderLogo === '') $xtHeaderLogo = 'assets/xtreme-titan-logo.jpg';
$xtHeaderMoney = number_format($xtHeaderBalance, 2);
?>
<style id="xt-shared-customer-wallet-header">
.xt-customer-wallet-header{position:relative;z-index:50;display:grid;grid-template-columns:minmax(0,1fr) auto auto;align-items:center;gap:9px;width:calc(100% - 24px);max-width:none;margin:12px auto 15px;padding:9px 10px;border:1px solid rgba(48,211,231,.34);border-radius:21px;background:linear-gradient(145deg,rgba(10,20,39,.97),rgba(8,13,29,.98));box-shadow:0 9px 28px rgba(0,0,0,.3),inset 0 1px 0 rgba(255,255,255,.07);box-sizing:border-box;color:#f7fbff}
.xt-customer-brand{display:flex;align-items:center;gap:8px;min-width:0;text-decoration:none;color:inherit}
.xt-customer-brand img{display:block;width:42px;height:42px;flex:0 0 42px;object-fit:contain;border-radius:12px;background:rgba(255,255,255,.04)}
.xt-customer-account{display:flex;flex-direction:column;min-width:0;gap:3px}.xt-customer-account strong{font-size:clamp(11px,3vw,14px);font-weight:950;line-height:1.1;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.xt-customer-account small{display:inline-flex;align-items:center;gap:4px;width:max-content;max-width:100%;padding:3px 7px;border:1px solid rgba(36,219,205,.35);border-radius:999px;background:rgba(0,198,190,.12);color:#43e8d0;font-size:9px;font-weight:900;line-height:1}
.xt-customer-balance{display:flex;align-items:center;justify-content:center;gap:7px;min-width:0;padding:10px 11px;border:1px solid rgba(36,222,183,.35);border-radius:999px;background:linear-gradient(120deg,rgba(0,198,164,.13),rgba(10,35,46,.65));color:#36e5b1;font-size:clamp(12px,3.5vw,17px);font-weight:1000;white-space:nowrap;box-shadow:inset 0 0 14px rgba(0,217,178,.06)}
.xt-customer-balance .xt-wallet-symbol{font-size:17px;line-height:1}.xt-customer-balance .xt-wallet-value{min-width:0;overflow:hidden;text-overflow:ellipsis}
.xt-customer-topup{display:inline-flex;align-items:center;justify-content:center;gap:5px;min-height:42px;padding:0 13px;border:1px solid rgba(65,224,255,.5);border-radius:999px;background:linear-gradient(115deg,#05c9ee,#248bff);box-shadow:0 5px 17px rgba(0,173,255,.25);color:#fff!important;text-decoration:none!important;font-size:clamp(10px,2.8vw,13px);font-weight:1000;white-space:nowrap}
@media(max-width:430px){.xt-customer-wallet-header{width:calc(100% - 24px);max-width:none;gap:6px;padding:8px 7px;margin:8px auto 12px}.xt-customer-brand{gap:5px}.xt-customer-brand img{width:34px;height:34px;flex-basis:34px}.xt-customer-account strong{font-size:10px}.xt-customer-account small{font-size:8px;padding:3px 5px}.xt-customer-balance{gap:4px;padding:9px 7px;font-size:clamp(11px,3.4vw,14px)}.xt-customer-balance .xt-wallet-symbol{font-size:14px}.xt-customer-topup{min-height:38px;padding:0 8px;font-size:9px;gap:3px}}
@media(max-width:350px){.xt-customer-account strong{max-width:74px}.xt-customer-brand img{width:30px;height:30px;flex-basis:30px}.xt-customer-topup{padding:0 6px}.xt-customer-balance{padding:8px 5px}}
</style>
<header class="xt-customer-wallet-header" aria-label="Account and wallet">
  <a class="xt-customer-brand" href="profile.php" aria-label="Go to Profile">
    <img src="<?= htmlspecialchars($xtHeaderLogo, ENT_QUOTES, 'UTF-8') ?>" alt="Site logo">
    <span class="xt-customer-account"><strong><?= htmlspecialchars((string)($xtHeaderSite['site_title'] ?? 'TM PANEL SHOP'), ENT_QUOTES, 'UTF-8') ?></strong><small><?= htmlspecialchars($xtHeaderAccountLabel, ENT_QUOTES, 'UTF-8') ?></small></span>
  </a>
  <div class="xt-customer-balance" aria-label="Wallet balance"><span class="xt-wallet-symbol" aria-hidden="true">💳</span><span class="xt-wallet-value" data-currency-amount="<?= htmlspecialchars((string)$xtHeaderBalance, ENT_QUOTES, 'UTF-8') ?>">৳<?= htmlspecialchars($xtHeaderMoney, ENT_QUOTES, 'UTF-8') ?></span></div>
  <a class="xt-customer-topup" href="deposit.php"><span aria-hidden="true">⚡</span> <span>ADD FUNDS</span></a>
</header>
