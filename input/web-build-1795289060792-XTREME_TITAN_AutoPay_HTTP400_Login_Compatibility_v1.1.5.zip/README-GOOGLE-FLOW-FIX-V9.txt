XTREME TITAN — Google country selection auto-prompt patch v10

Changed auth-region-picker.js only:
- Selecting a country now calls Google Identity Services prompt() immediately.
- The extra visible Google button is hidden after region selection.

Important limitation:
Google Identity Services One Tap/prompt is controlled by Google and the browser. On iOS/Safari, Google may suppress the prompt or show no account chooser because of browser/security policy. If that occurs, a guaranteed account chooser requires changing to a server-side OAuth redirect/callback flow and configuring the exact authorized redirect URI in Google Cloud Console. Test on the live host before relying on this patch.
