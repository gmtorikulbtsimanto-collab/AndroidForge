(function(){
  function add(){
    if(document.querySelector('.admin-bg-video')) return;
    var script=document.currentScript;
    var root=script ? new URL('../',script.src).href : new URL('../',location.href).href;
    var source=(getComputedStyle(document.documentElement).getPropertyValue('--xt-site-background').trim()||'').replace(/^url\(["']?|["']?\)$/g,'');
    if(!source) source=root+'assets/tanofficial_neon_background.mp4';
    else if(!/^https?:\/\//i.test(source)) source=root+source.replace(/^\.\//,'');
    var ext=(source.split('?')[0].split('.').pop()||'').toLowerCase();
    var overlay=document.createElement('div'); overlay.className='admin-bg-overlay'; document.body.prepend(overlay);
    if(['mp4','webm','ogv','mov'].includes(ext)){
      var v=document.createElement('video'); v.className='admin-bg-video'; v.autoplay=true; v.muted=true; v.loop=true; v.playsInline=true; v.src=source; document.body.prepend(v);
    }else{
      document.body.style.backgroundImage='url("'+source.replace(/"/g,'\\"')+'")';
      document.body.style.backgroundSize='cover'; document.body.style.backgroundPosition='center'; document.body.style.backgroundAttachment='fixed';
    }
  }
  if(document.readyState==='loading') document.addEventListener('DOMContentLoaded',add); else add();
})();
