XTREME TITAN OFFICIAL — Live Chat Auto Translation V48

Changes:
- Admin Live Messages now has one popup message input only.
- Added a server-side Google Cloud Translation API key field.
- The API key is stored in support_chat_settings and is never returned to the visitor/browser.
- Store widget asks messages.php for the user's selected language and translates the one admin message automatically.
- Translations are cached in support_chat_settings to reduce repeat API calls.
- Popup interval (60–7200 seconds) and visibility (3–15 seconds) remain configurable.

Setup:
1. Upload/replace files while preserving the ZIP's folder structure; keep a backup first.
2. Open Admin > Live Messages.
3. Enter one popup message and timing values.
4. Paste a Google Cloud Translation API key in the API key field and save. To keep an existing key, leave the key field blank.
5. Enable the Cloud Translation API for that Google Cloud project and ensure its billing/quota are configured.
6. Test with the store language set to English, Bengali, and Italian.

If no API key is configured, or the translation service fails, the widget falls back to the original admin message. Translation requests are made server-side; the key is not sent to visitors. API charges/quotas may apply according to Google's current terms.
