XTREME TITAN Background Music Patch

1) ZIP extract করে uploads/music/xtreme-background.m4a ফাইলটি আপনার ওয়েবসাইটের একই path-এ upload/replace করুন।
2) Admin Panel > Site Settings > Background Music থেকে Enable website background music চালু রাখুন।
3) পরবর্তীতে গান বদলাতে Admin Panel > Site Settings > Background Music > Replace music থেকে M4A / MP3 / WAV / OGG ফাইল upload করে Save করুন। সর্বোচ্চ 20 MB।

আপনার দেওয়া অডিও ফাইলটি default background music হিসেবে রাখা হয়েছে। Admin upload handler ও setting field আপনার দেওয়া ZIP-এ আগে থেকেই আছে, তাই এই patch-এ শুধু নতুন audio asset রাখা হয়েছে।

Note: iPhone/Safari এবং কিছু browser প্রথমবার user tap ছাড়া sound autoplay আটকায়। একবার Music button বা page-এ tap করলে browser অনুমতি দিলে গান চালু হবে। সাধারণ page reload/navigation-এর মাঝখানে শতভাগ gapless playback browser policy/বর্তমান multi-page setup-এ guarantee করা যায় না।
