<?php

declare(strict_types=1);

require_once __DIR__ . '/config.php';
ensure_product_plan_type_column();

/*
|--------------------------------------------------------------------------
| ERROR HANDLING
|--------------------------------------------------------------------------
| White screen বন্ধ করার জন্য development error display রাখা হয়েছে।
| কাজ হয়ে গেলে চাইলে display_errors = 0 করতে পারবেন।
|--------------------------------------------------------------------------
*/

error_reporting(E_ALL);
ini_set('display_errors', '1');
ini_set('display_startup_errors', '1');


/*
|--------------------------------------------------------------------------
| SESSION / LOGIN
|--------------------------------------------------------------------------
*/

if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}


/*
|--------------------------------------------------------------------------
| USER ID
|--------------------------------------------------------------------------
| আপনার login system-এ সাধারণত $_SESSION['user_id'] থাকার কথা।
|--------------------------------------------------------------------------
*/

$userId = (int)($_SESSION['user_id'] ?? 0);

if (empty($_SESSION['buy_csrf'])) {
    $_SESSION['buy_csrf'] = bin2hex(random_bytes(32));
}
$buyCsrf = $_SESSION['buy_csrf'];
$purchaseErrorFlash = (string)($_SESSION['purchase_error_flash'] ?? '');
$purchaseErrorAmounts = $_SESSION['purchase_error_amounts'] ?? null;
unset($_SESSION['purchase_error_flash'], $_SESSION['purchase_error_amounts']);
$site = site_settings();
$userRole = current_user_role();
$resellerDiscount = ($userRole === 'reseller') ? max(0.0, min(90.0, (float)site_setting('reseller_discount_percent', '20'))) : 0.0;

if ($userId <= 0) {
    header('Location: login.php');
    exit;
}


/*
|--------------------------------------------------------------------------
| DATABASE
|--------------------------------------------------------------------------
*/

try {
    $pdo = db();

    if (!$pdo instanceof PDO) {
        throw new RuntimeException('Database connection failed.');
    }

} catch (Throwable $e) {

    http_response_code(500);

    echo '<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Store Error</title><style>body{margin:0;padding:28px 16px;background:#07101d;color:#f4f6fb;font:15px Arial,sans-serif}.box{max-width:680px;margin:30px auto;padding:22px;border:1px solid #344155;border-radius:16px;background:#111d2d}h2{margin-top:0;color:#ff8194}pre{white-space:pre-wrap;overflow-wrap:anywhere;color:#ffd2d8;font-size:13px}</style></head><body><main class="box"><h2>Store temporarily unavailable</h2><pre>' . htmlspecialchars($e->getMessage(), ENT_QUOTES, 'UTF-8') . '</pre></main></body></html>';

    exit;
}


/*
|--------------------------------------------------------------------------
| HELPER
|--------------------------------------------------------------------------
*/

function h($value): string
{
    return htmlspecialchars(
        (string)$value,
        ENT_QUOTES,
        'UTF-8'
    );
}

function productLinks(string $description): array
{
    $links = [];
    foreach (preg_split('/\R/', $description) ?: [] as $line) {
        if (preg_match('/^\s*\[(UPDATE|SETUP|LINK|MEDIA|IMAGE|VIDEO|GROUP|SETUP_LABEL|GROUP_LABEL|EXTRA1|EXTRA1_LABEL|EXTRA1_ON|EXTRA2|EXTRA2_LABEL|EXTRA2_ON|FEATURE_ON|FEATURE_OFF|STATUS_TAGS)\]\s*(.*?)\s*$/i', $line, $m)) {
            $type = strtoupper($m[1]);
            $url = trim($m[2]);
            if (in_array($type, ['SETUP_LABEL','GROUP_LABEL','EXTRA1_LABEL','EXTRA1_ON','EXTRA2_LABEL','EXTRA2_ON','STATUS_TAGS'], true)) { $links[$type] = $url; continue; }
            // Stored upload paths are relative in older products. Convert them to site-root paths
            // so media URLs resolve consistently from Store, nested pages, and the inline player.
            if (preg_match('~^/?uploads/product-media/[A-Za-z0-9._/-]+$~', $url)) {
                $url = '/' . ltrim($url, '/');
            }
            if (filter_var($url, FILTER_VALIDATE_URL) || preg_match('#^/(?!/)[A-Za-z0-9._~!$&\'()*+,;=:@%/-]+$#', $url)) $links[] = ['type'=>$type,'url'=>$url];
        }
    }
    return $links;
}


/*
|--------------------------------------------------------------------------
| LOAD PRODUCTS
|--------------------------------------------------------------------------
|
| Expected:
| catalog_products
|   id
|   name
|   status
|
|--------------------------------------------------------------------------
*/

$products = [];
ensure_catalog_product_columns();

try {

    $stmt = $pdo->query("
        SELECT
            id,
            name,
            description,
            category,
            platform,
            live_status,
            reseller_discount_percent
        FROM catalog_products
        WHERE status = 1
        ORDER BY id ASC
    ");

    $products = $stmt->fetchAll(PDO::FETCH_ASSOC);

} catch (Throwable $e) {

    http_response_code(500);

    echo '<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Store Error</title><style>body{margin:0;padding:28px 16px;background:#07101d;color:#f4f6fb;font:15px Arial,sans-serif}.box{max-width:680px;margin:30px auto;padding:22px;border:1px solid #344155;border-radius:16px;background:#111d2d}h2{margin-top:0;color:#ff8194}pre{white-space:pre-wrap;overflow-wrap:anywhere;color:#ffd2d8;font-size:13px}</style></head><body><main class="box"><h2>Store temporarily unavailable</h2><pre>' . htmlspecialchars($e->getMessage(), ENT_QUOTES, 'UTF-8') . '</pre></main></body></html>';

    exit;
}


/*
|--------------------------------------------------------------------------
| LOAD PLANS + REAL KEY STOCK
|--------------------------------------------------------------------------
|
| IMPORTANT:
| Stock is calculated from user_keys.
|
| user_keys:
| id
| user_id
| product_id
| plan_id
| license_key
| price
| purchased_at
|
| user_id IS NULL = available key
|--------------------------------------------------------------------------
*/

$plansByProduct = [];

try {

    $stmt = $pdo->query("
        SELECT
            pp.id,
            pp.product_id,
            pp.plan_type,
            pp.duration_days,
            pp.duration_seconds,
            pp.duration_label,
            pp.price,
            pp.status,
            cp.reseller_discount_percent,

            (
                SELECT COUNT(*)
                FROM user_keys uk
                WHERE uk.product_id = pp.product_id
                  AND uk.plan_id = pp.id
                  AND uk.user_id IS NULL
            ) AS available_keys

        FROM product_plans pp
        LEFT JOIN catalog_products cp ON cp.id = pp.product_id

        WHERE pp.status = 1

        ORDER BY
            pp.product_id ASC,
            FIELD(UPPER(pp.plan_type),'PRO','BASIC','NORMAL'),
            COALESCE(pp.duration_seconds, CASE WHEN pp.duration_days < 0 THEN ABS(pp.duration_days)*3600 ELSE pp.duration_days*86400 END) ASC,
            pp.id ASC
    ");

    $plans = $stmt->fetchAll(PDO::FETCH_ASSOC);

    foreach ($plans as $plan) {

        $productId = (int)$plan['product_id'];

        if (!isset($plansByProduct[$productId])) {
            $plansByProduct[$productId] = [];
        }

        $plansByProduct[$productId][] = $plan;
    }

} catch (Throwable $e) {

    http_response_code(500);

    echo '<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Store Error</title><style>body{margin:0;padding:28px 16px;background:#07101d;color:#f4f6fb;font:15px Arial,sans-serif}.box{max-width:680px;margin:30px auto;padding:22px;border:1px solid #344155;border-radius:16px;background:#111d2d}h2{margin-top:0;color:#ff8194}pre{white-space:pre-wrap;overflow-wrap:anywhere;color:#ffd2d8;font-size:13px}</style></head><body><main class="box"><h2>Store temporarily unavailable</h2><pre>' . htmlspecialchars($e->getMessage(), ENT_QUOTES, 'UTF-8') . '</pre></main></body></html>';

    exit;
}


/*
|--------------------------------------------------------------------------
| STORE DASHBOARD SUMMARY
|--------------------------------------------------------------------------
| The dashboard is intentionally merged into Store. There is no separate
| Home Shop button. Store is the user's shop + dashboard landing page.
|--------------------------------------------------------------------------
*/
$dashBalance = 0.00;
$dashDeposits = 0.00;
$dashPurchases = 0.00;
$dashKeys = 0;
$dashActiveKeys = 0;

try {
    try { $depCols=$pdo->query('SHOW COLUMNS FROM deposits')->fetchAll(PDO::FETCH_COLUMN); } catch(Throwable $ignore) { $depCols=[]; }
    $depExpr = in_array('amount_bdt',$depCols,true) ? 'SUM(COALESCE(amount_bdt, amount))' : 'SUM(amount)';
    $st = $pdo->prepare("SELECT COALESCE({$depExpr},0) FROM deposits WHERE user_id = ? AND LOWER(status) = 'approved'");
    $st->execute([$userId]);
    $dashDeposits = (float)$st->fetchColumn();
} catch (Throwable $e) {}

try {
    $st = $pdo->prepare("SELECT COALESCE(SUM(total_amount),0) FROM user_purchases WHERE user_id = ?");
    $st->execute([$userId]);
    $dashPurchases = (float)$st->fetchColumn();
} catch (Throwable $e) {}

$dashBalance = max(0, $dashDeposits - $dashPurchases);
$dashDepositsUsd = $dashDeposits / 122.0;

try {
    $st = $pdo->prepare("SELECT COUNT(*) FROM user_keys WHERE user_id = ?");
    $st->execute([$userId]);
    $dashKeys = (int)$st->fetchColumn();
} catch (Throwable $e) {}

try {
    // Count only keys that have not expired; zero/unknown duration means no expiry timer.
    $ukCols = []; $planCols = [];
    try { $ukCols = $pdo->query('SHOW COLUMNS FROM user_keys')->fetchAll(PDO::FETCH_COLUMN); } catch (Throwable $ignore) {}
    try { $planCols = $pdo->query('SHOW COLUMNS FROM product_plans')->fetchAll(PDO::FETCH_COLUMN); } catch (Throwable $ignore) {}
    $durationParts = [];
    if (in_array('duration_seconds', $ukCols, true)) $durationParts[] = 'uk.duration_seconds';
    if (in_array('duration_seconds', $planCols, true)) $durationParts[] = 'pp.duration_seconds';
    if (in_array('duration_days', $planCols, true)) $durationParts[] = 'CASE WHEN pp.duration_days < 0 THEN ABS(pp.duration_days)*3600 ELSE COALESCE(pp.duration_days,0)*86400 END';
    $durationExpr = $durationParts ? 'COALESCE(' . implode(',', $durationParts) . ',0)' : '0';
    $activeSql = "SELECT COUNT(*) FROM user_keys uk
        LEFT JOIN product_plans pp ON pp.id=uk.plan_id AND pp.product_id=uk.product_id
        WHERE uk.user_id=? AND uk.purchased_at IS NOT NULL
        AND (" . $durationExpr . " <= 0 OR TIMESTAMPDIFF(SECOND, uk.purchased_at, UTC_TIMESTAMP()) < " . $durationExpr . ")";
    $st = $pdo->prepare($activeSql);
    $st->execute([$userId]);
    $dashActiveKeys = (int)$st->fetchColumn();
} catch (Throwable $e) {}

?>
<!doctype html>

<html lang="en">

<head>

<meta charset="utf-8">

<meta
    name="viewport"
    content="width=device-width,initial-scale=1"
>

<title>Store</title>
<link rel="stylesheet" href="theme.php?v=20261022-lightfix3">
<link rel="stylesheet" href="reference-theme.css?v=20260929-25">
<link rel="stylesheet" href="site-polish.css?v=20261022-lightfix3">
<link rel="stylesheet" href="premium-global.css?v=20261022-lightfix3">
<link rel="stylesheet" href="store-premium.css?v=20260929-25">
<script src="theme-client.js?v=20260929-25" defer></script>
<script src="currency-client.js?v=20261023-warning-balance-v28" defer></script>
<script src="language-client.js?v=20261025-auto-button-translate-v51" defer></script>
<script src="preference-sync.js?v=20260929-25" defer></script>

<style>

*{
    box-sizing:border-box;
}

html,
body{
    margin:0;
    padding:0;
    min-height:100%;
}

body{
    background:#06101c;
    color:#eef4ff;
    font-family:Arial,Helvetica,sans-serif;
    padding-bottom:90px;
    position:relative;
    isolation:isolate;
}

body::before{
    content:"";
    position:fixed;
    inset:0;
    z-index:-2;
    background:url("<?=h($site["background_path"])?>") center center / cover no-repeat;
    opacity:.72;
    pointer-events:none;
}


.site-decoration-wrap{position:fixed;inset:0;pointer-events:none;z-index:0;overflow:hidden}.site-decoration-wrap img{position:absolute;width:72px;height:72px;object-fit:cover;border-radius:18px;opacity:.16;filter:drop-shadow(0 8px 18px rgba(0,0,0,.5))}.site-decoration-wrap img:first-child{left:8px;top:17%}.site-decoration-wrap img:last-child{right:8px;bottom:23%}@media(max-width:600px){.site-decoration-wrap img{width:52px;height:52px}.site-decoration-wrap img:first-child{left:3px}.site-decoration-wrap img:last-child{right:3px}}

body::after{
    content:"";
    position:fixed;
    inset:0;
    z-index:-1;
    background:rgba(3,10,18,.48);
    pointer-events:none;
}


/* -------------------------------------------------------
   TOP
------------------------------------------------------- */

.topbar{
    height:64px;
    display:flex;
    align-items:center;
    justify-content:center;
    background:#071220;
    border-bottom:1px solid #18283c;
    position:sticky;
    top:0;
    z-index:20;
}

.top-title{
    font-size:20px;
    font-weight:900;
}


/* -------------------------------------------------------
   MAIN
------------------------------------------------------- */

.container{
    width:100%;
    max-width:900px;
    margin:0 auto;
    padding:20px 14px 35px;
}


/* -------------------------------------------------------
   PRODUCT
------------------------------------------------------- */

.product{
    background:#0b1827;
    border:1px solid #1d3046;
    border-radius:20px;
    margin-bottom:20px;
    padding:14px;
    overflow:hidden;
}

.product-image{
    width:100%;
    height:210px;
    border-radius:17px;
    background:#172a40;
    display:flex;
    align-items:center;
    justify-content:center;
    font-size:70px;
    margin-bottom:20px;
}

.product-name{
    font-size:29px;
    font-weight:900;
    margin:0 0 7px;
}

.product-links{display:flex;gap:9px;flex-wrap:wrap;margin:12px 0 14px}.product-link{display:inline-flex;align-items:center;justify-content:center;min-height:42px;padding:10px 14px;border-radius:13px;text-decoration:none;font-weight:900;font-size:12px;color:#fff;border:1px solid rgba(16,216,255,.28);background:#0d1c2d}.product-link.update{border-color:rgba(255,63,135,.38);background:rgba(255,63,135,.09)}.product-link.setup{border-color:rgba(16,216,255,.38);background:rgba(16,216,255,.09)}.product-link.link{border-color:rgba(18,229,142,.38);background:rgba(18,229,142,.09)}
.product-media{width:100%;height:100%;display:block;object-fit:cover;border:0;border-radius:17px}.product-video-frame{background:#000;aspect-ratio:16/9}.product-media-link{width:100%;height:100%;display:flex;align-items:center;justify-content:center;text-decoration:none;color:#fff;font-weight:900;font-size:18px;background:linear-gradient(135deg,#111d35,#16304b)}
.product-action-row{display:grid;grid-template-columns:1fr 1fr;gap:10px;margin:12px 0 16px}.product-action{min-width:0;height:44px;display:flex;align-items:center;justify-content:center;padding:0 10px;border-radius:12px;text-decoration:none;font-weight:900;font-size:12px;line-height:1.1;text-align:center;white-space:normal;border:1px solid rgba(16,216,255,.32);background:#0d1c2d;color:#fff}.setup-action{border-color:rgba(16,216,255,.4);background:rgba(16,216,255,.09)}.group-action{border-color:rgba(18,229,142,.4);background:rgba(18,229,142,.09)}.product-action.disabled{opacity:.42;cursor:default}
.product-description{
    color:#91a2b8;
    font-size:15px;
    margin-bottom:20px;
}


/* -------------------------------------------------------
   PLAN
------------------------------------------------------- */

.plan-list{
    display:flex;
    flex-direction:column;
    gap:10px;
}

.plan{
    width:100%;
    background:#0a1624;
    border:1px solid #1e344b;
    border-radius:16px;
    padding:17px;
    cursor:pointer;
    transition:.15s;
    position:relative;
}

.plan:hover{
    border-color:#4e9f35;
}

.plan.selected{
    border:2px solid #63ff16;
    background:#10251a;
}

.plan.out{
    opacity:.55;
    cursor:not-allowed;
}

.plan-row{
    display:flex;
    align-items:center;
    justify-content:space-between;
    gap:15px;
}

.plan-duration{
    font-size:19px;
    font-weight:900;
}

.plan-price{
    color:#63ff16;
    font-size:20px;
    font-weight:900;
    white-space:nowrap;
}

.plan-stock{
    margin-top:8px;
    color:#8192a8;
    font-size:12px;
}

.plan.selected .plan-stock{
    color:#9aff78;
}


/* -------------------------------------------------------
   CONTROLS
------------------------------------------------------- */

.buy-area{
    border-top:1px solid #203247;
    margin-top:18px;
    padding-top:18px;
}

.quantity{
    display:flex;
    justify-content:center;
    align-items:center;
    gap:22px;
}

.qty-btn{
    width:56px;
    height:56px;
    border:0;
    border-radius:15px;
    background:#1a2d44;
    color:#fff;
    font-size:30px;
    font-weight:900;
    cursor:pointer;
}

.qty-btn:active{
    transform:scale(.96);
}

.qty-number{
    min-width:35px;
    text-align:center;
    font-size:25px;
    font-weight:900;
}

.total{
    text-align:center;
    margin-top:17px;
    font-size:17px;
    color:#a7b6ca;
}

.total strong{
    color:#fff;
    font-size:23px;
}


/* -------------------------------------------------------
   BUY
------------------------------------------------------- */

.buy-btn{
    width:100%;
    margin-top:18px;
    border:0;
    border-radius:14px;
    padding:15px;
    background:#63ff16;
    color:#06101c;
    font-size:17px;
    font-weight:900;
    cursor:pointer;
}

.buy-btn:disabled{
    background:#294123;
    color:#78936c;
    cursor:not-allowed;
}


/* -------------------------------------------------------
   EMPTY
------------------------------------------------------- */

.empty{
    background:#0d1928;
    border:1px solid #26384e;
    border-radius:18px;
    padding:45px 20px;
    text-align:center;
    color:#91a2b8;
}

.empty-icon{
    font-size:50px;
    margin-bottom:12px;
}

.empty-title{
    color:#eef4ff;
    font-size:20px;
    font-weight:900;
    margin-bottom:6px;
}


/* -------------------------------------------------------
   NAVIGATION
------------------------------------------------------- */

.bottom-nav{
    position:fixed;
    left:0;
    right:0;
    bottom:0;
    height:78px;
    background:#030d18;
    border-top:1px solid #17283b;
    display:grid;
    grid-template-columns:repeat(5,minmax(0,1fr));
    z-index:100;
}

.nav-item{
    text-decoration:none;
    color:#7f91a7;
    display:flex;
    flex-direction:column;
    align-items:center;
    justify-content:center;
    gap:5px;
    font-size:11px;
    font-weight:800;
}

.nav-icon{
    font-size:24px;
}

.nav-item.active{
    color:#63ff16;
}


/* -------------------------------------------------------
   MODAL
------------------------------------------------------- */

.modal{
    display:none;
    position:fixed!important;
    inset:0!important;
    width:100vw!important;
    height:100vh!important;
    background:rgba(0,0,0,.76);
    z-index:999999!important;
    align-items:flex-start;
    justify-content:center;
    padding:7vh 16px 24px;
    box-sizing:border-box;
    overflow-y:auto;
}

.modal.show{
    display:flex!important;
    visibility:visible!important;
    opacity:1!important;
}

.modal-box{
    position:relative;
    margin:0 auto;
    width:100%;
    max-width:430px;
    background:#102033;
    border:1px solid #30445b;
    border-radius:20px;
    padding:22px;
    box-shadow:0 30px 90px rgba(0,0,0,.55),0 0 35px rgba(16,216,255,.10);
    transform:translateY(0);
}

.modal-title{
    font-size:21px;
    font-weight:900;
    margin-bottom:8px;
}

.modal-text{
    color:#9aa9bf;
    line-height:1.5;
    font-size:14px;
}

.modal-actions{
    display:flex;
    gap:10px;
    margin-top:20px;
}

.modal-btn{
    flex:1;
    border:0;
    border-radius:11px;
    padding:12px;
    font-weight:900;
    cursor:pointer;
}

.close-btn{
    background:#25384d;
    color:#fff;
}

.confirm-btn{
    background:#63ff16;
    color:#06101c;
}


/* -------------------------------------------------------
   MOBILE
------------------------------------------------------- */

@media(max-width:600px){

    .container{
        padding:14px 10px 30px;
    }

    .product{
        border-radius:18px;
        padding:12px;
    }

    .product-image{
        height:180px;
    }

    .product-name{
        font-size:27px;
    }

    .plan-duration{
        font-size:18px;
    }

    .plan-price{
        font-size:18px;
    }

}

</style>


<style id="store-dashboard-ui">
.store-dashboard{width:100%;max-width:900px;margin:0 auto;padding:16px 14px 4px;position:relative;z-index:1}
.dashboard-balance{padding:17px;border:1px solid rgba(55,94,125,.75);border-radius:19px;background:rgba(8,20,34,.82);backdrop-filter:blur(8px);-webkit-backdrop-filter:blur(8px);margin-bottom:10px}
.dashboard-label{color:#9aa9bf;font-size:10px;font-weight:900;letter-spacing:.08em}
.dashboard-balance-value{margin:4px 0 12px;font-size:31px;line-height:1;font-weight:900;color:#eef4ff}
.xt-purchase-warning{margin-top:12px;padding:11px 13px;border:1px solid #fb7185;background:rgba(190,24,93,.16);color:#fecdd3;border-radius:13px;font-size:12px;font-weight:800;line-height:1.45;overflow-wrap:anywhere}
.dashboard-topup{display:inline-flex;align-items:center;justify-content:center;height:39px;padding:0 16px;border-radius:11px;background:#63ff16;color:#06101c;text-decoration:none;font-size:11px;font-weight:900}
.dashboard-stats{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:9px;margin-bottom:10px}
.dashboard-stat{min-width:0;padding:12px;border:1px solid rgba(38,56,78,.9);border-radius:14px;background:rgba(10,22,36,.80);backdrop-filter:blur(7px);-webkit-backdrop-filter:blur(7px)}
.dashboard-stat span{display:block;color:#9aa9bf;font-size:9px;font-weight:900;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.dashboard-stat strong{display:block;margin-top:4px;color:#eef4ff;font-size:17px;font-weight:900;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.dashboard-quick{padding:13px;border:1px solid rgba(38,56,78,.9);border-radius:17px;background:rgba(10,22,36,.80);backdrop-filter:blur(7px);-webkit-backdrop-filter:blur(7px);margin-bottom:17px}
.dashboard-quick-title{font-size:16px;font-weight:900;margin-bottom:9px}
.dashboard-actions{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:8px}
.dashboard-actions a{display:flex;align-items:center;justify-content:center;min-height:62px;padding:15px 12px;border-radius:13px;border:1px solid rgba(34,52,74,.95);background:rgba(17,31,49,.92);color:#eef4ff;text-decoration:none;font-size:14px;font-weight:900;line-height:1.35}
.dashboard-actions a:hover{text-decoration:none}.xt-addfunds-banner{display:block;width:100%;margin:0 0 12px;border-radius:13px;overflow:hidden;line-height:0}.xt-addfunds-banner img{display:block;width:100%;height:auto;max-height:240px;object-fit:cover;border-radius:13px}.xt-addfunds-banner{margin:0 0 12px}.dashboard-topup{margin-bottom:2px}
@media(max-width:600px){.store-dashboard{padding:12px 10px 2px}.dashboard-balance-value{font-size:28px}.dashboard-stat{padding:11px}.dashboard-stat strong{font-size:15px}.dashboard-quick{padding:12px}}
</style>
<style id="store-final-ui">
html,body{width:100%;overflow-x:hidden}
.topbar{height:auto!important;min-height:92px!important;padding:10px 12px 12px!important;display:flex!important;align-items:center!important;justify-content:center!important;position:sticky!important;top:0!important;z-index:100!important;background:#071220!important;border-bottom:1px solid #18283c!important}
.topbar .brand-with-logo{width:100%!important;display:flex!important;flex-direction:column!important;align-items:center!important;justify-content:center!important;gap:5px!important;text-align:center!important}
.topbar .header-logo{display:block!important;width:42px!important;height:42px!important;max-width:42px!important;max-height:42px!important;flex:0 0 42px!important;object-fit:cover!important;border-radius:10px!important;margin:0 auto!important}
.topbar .top-title{display:block!important;margin:0!important;font-size:20px!important;line-height:1.15!important;font-weight:900!important;color:#eef4ff!important;text-align:center!important}
.product-image img[src*="xtreme-titan-logo"],.product-image img[src*="tanofficial_neon_background"]{display:none!important}
.nav{position:fixed!important;left:0!important;right:0!important;bottom:0!important;width:100%!important;height:76px!important;min-height:76px!important;padding:4px 5px!important;margin:0!important;display:grid!important;grid-template-columns:repeat(5,minmax(0,1fr))!important;gap:3px!important;overflow:hidden!important;background:#030b14!important;border-top:1px solid rgba(16,216,255,.24)!important;z-index:99999!important}
.nav>a{min-width:0!important;width:100%!important;height:66px!important;min-height:66px!important;margin:0!important;padding:3px 1px!important;border:1px solid transparent!important;border-radius:13px!important;display:flex!important;flex-direction:column!important;align-items:center!important;justify-content:center!important;gap:2px!important;overflow:hidden!important;white-space:nowrap!important;text-overflow:ellipsis!important;text-decoration:none!important;line-height:1.05!important;font-size:10px!important;font-weight:900!important;color:#9aa9bf!important;background:transparent!important}
.nav>a:visited,.nav>a:hover,.nav>a:focus{text-decoration:none!important}
.nav>a.active{height:66px!important;min-height:66px!important;background:rgba(16,216,255,.08)!important;border:1px solid rgba(16,216,255,.55)!important;color:#10d8ff!important;box-shadow:none!important;transform:none!important}
.nav .emoji{font-size:20px!important;line-height:21px!important;height:22px!important;display:block!important;text-decoration:none!important}
@media(max-width:600px){.topbar{min-height:88px!important;padding:8px 10px 10px!important}.topbar .header-logo{width:40px!important;height:40px!important;max-width:40px!important;max-height:40px!important;flex-basis:40px!important}.topbar .top-title{font-size:19px!important}.nav{height:74px!important;min-height:74px!important}.nav>a,.nav>a.active{height:64px!important;min-height:64px!important;font-size:9px!important}.nav .emoji{font-size:19px!important}}
@media(max-width:380px){.topbar .header-logo{width:38px!important;height:38px!important;max-width:38px!important;max-height:38px!important;flex-basis:38px!important}.topbar .top-title{font-size:18px!important}.nav>a,.nav>a.active{font-size:8px!important}.nav .emoji{font-size:18px!important}}
</style>

<style id="store-dashboard-neon-polish-v29">
/* Dashboard-only polish: preserve compact button dimensions and existing behavior. */
.store-dashboard .dashboard-balance{
  border:1px solid rgba(255,49,174,.72)!important;
  background:linear-gradient(125deg,rgba(9,18,37,.96),rgba(24,12,38,.92))!important;
  box-shadow:0 0 0 1px rgba(76,65,255,.18),0 0 18px rgba(255,35,169,.12),inset 0 0 20px rgba(25,120,255,.06)!important;
}
.store-dashboard .dashboard-topup{
  min-height:38px!important;height:38px!important;padding:0 15px!important;
  border:1px solid rgba(255,255,255,.24)!important;border-radius:12px!important;
  background:linear-gradient(110deg,#10cfff 0%,#665bff 48%,#ff2d9b 100%)!important;
  color:#fff!important;box-shadow:0 0 13px rgba(29,155,240,.2)!important;
}
.store-dashboard .dashboard-stats{gap:8px!important}
.store-dashboard .dashboard-stat{
  padding:11px!important;border-radius:15px!important;
  background:linear-gradient(135deg,rgba(9,19,39,.94),rgba(18,14,42,.92))!important;
  border:1px solid rgba(118,105,255,.48)!important;
  box-shadow:inset 0 0 16px rgba(35,110,255,.06)!important;
}
.store-dashboard .dashboard-stat:nth-child(1){border-color:rgba(20,235,153,.52)!important}
.store-dashboard .dashboard-stat:nth-child(2){border-color:rgba(255,53,156,.5)!important}
.store-dashboard .dashboard-stat:nth-child(3){border-color:rgba(255,190,48,.48)!important}
.store-dashboard .dashboard-stat:nth-child(4){border-color:rgba(174,68,255,.55)!important}
.store-dashboard .dashboard-stat span{font-size:10px!important;letter-spacing:.01em!important;color:#bdc9ff!important}




.store-dashboard .dashboard-quick{
  padding:12px!important;border-radius:18px!important;
  border:1px solid rgba(108,115,255,.48)!important;
  background:linear-gradient(145deg,rgba(7,17,35,.96),rgba(20,12,43,.94))!important;
  box-shadow:0 0 17px rgba(89,64,255,.09)!important;
}
.store-dashboard .dashboard-quick-title{font-size:15px!important;margin-bottom:8px!important}
.store-dashboard .dashboard-actions{gap:7px!important}
.store-dashboard .dashboard-actions a{
  min-height:56px!important;height:auto!important;padding:9px 10px!important;
  gap:7px!important;justify-content:flex-start!important;border-radius:13px!important;
  font-size:12px!important;line-height:1.2!important;
  border:1px solid rgba(95,122,255,.6)!important;
  background:linear-gradient(120deg,rgba(12,36,69,.96),rgba(18,20,58,.96))!important;
  box-shadow:inset 0 0 13px rgba(45,115,255,.08)!important;
}
.store-dashboard .dashboard-actions a:nth-child(1){
  border-color:rgba(17,238,156,.72)!important;
  background:linear-gradient(120deg,rgba(0,108,74,.62),rgba(7,35,51,.96))!important;
  box-shadow:0 0 10px rgba(17,238,156,.10),inset 0 0 12px rgba(17,238,156,.07)!important;
}
.store-dashboard .dashboard-actions a:nth-child(2){
  border-color:rgba(20,166,255,.78)!important;
  background:linear-gradient(120deg,rgba(0,79,172,.65),rgba(9,24,64,.97))!important;
  box-shadow:0 0 10px rgba(20,166,255,.11),inset 0 0 12px rgba(20,166,255,.07)!important;
}
.store-dashboard .dashboard-actions a:nth-child(3){
  border-color:rgba(255,183,45,.75)!important;
  background:linear-gradient(120deg,rgba(133,75,0,.62),rgba(51,25,20,.97))!important;
}
.store-dashboard .dashboard-actions a:nth-child(4){
  border-color:rgba(221,48,255,.75)!important;
  background:linear-gradient(120deg,rgba(103,0,151,.62),rgba(36,12,57,.97))!important;
}
.store-dashboard .dashboard-actions .qa-icon{font-size:24px!important;line-height:1!important;flex:0 0 auto!important;filter:drop-shadow(0 0 5px currentColor)!important}
.store-dashboard .dashboard-actions .qa-label{flex:1 1 auto!important;min-width:0!important}
.store-dashboard .dashboard-actions .qa-arrow{
  width:22px!important;height:22px!important;min-width:22px!important;
  display:inline-flex!important;align-items:center!important;justify-content:center!important;
  border:1px solid currentColor!important;border-radius:50%!important;font-size:20px!important;
  line-height:1!important;opacity:.95!important;
}
@media(max-width:600px){
 .store-dashboard .dashboard-stat{padding:10px!important}
 .store-dashboard .dashboard-actions a{min-height:54px!important;padding:8px!important;font-size:11px!important}
 .store-dashboard .dashboard-actions .qa-icon{font-size:22px!important}
}
</style>




<style id="store-dashboard-reference-icons-v31">
/* Reference-style icon treatment; preserve compact button dimensions and existing actions. */
.store-dashboard .dashboard-balance{
  border-color:rgba(255,48,174,.78)!important;
  background:radial-gradient(ellipse at 92% 0%,rgba(0,180,255,.14),transparent 42%),linear-gradient(135deg,rgba(8,16,36,.97),rgba(28,11,42,.96))!important;
  box-shadow:0 0 0 1px rgba(126,67,255,.2),0 0 17px rgba(255,45,170,.11),inset 0 0 18px rgba(37,119,255,.06)!important;
}
.store-dashboard .dashboard-balance-value{display:flex!important;align-items:center!important;gap:9px!important;flex-wrap:wrap!important}
.store-dashboard .dashboard-balance-value:before{content:"💳";display:inline-flex;align-items:center;justify-content:center;font-size:31px;line-height:1;filter:drop-shadow(0 0 8px rgba(0,190,255,.42))}
.store-dashboard .dashboard-topup{position:relative!important;gap:7px!important;min-height:38px!important;height:38px!important;padding:0 13px!important;border-radius:12px!important;background:linear-gradient(110deg,#10cfff,#665bff 48%,#ff2d9b)!important;border:1px solid rgba(255,255,255,.25)!important;color:#fff!important;font-size:11px!important;box-shadow:0 0 12px rgba(29,155,240,.2)!important}
.store-dashboard .dashboard-topup:before{content:"＋";display:inline-flex;align-items:center;justify-content:center;width:19px;height:19px;border-radius:50%;background:#fff;color:#6553dc;font-size:16px;font-weight:1000;line-height:1}
.store-dashboard .dashboard-stats{gap:9px!important}
.store-dashboard .dashboard-stat{position:relative!important;min-height:78px!important;padding:12px 9px 11px 54px!important;border-radius:16px!important;overflow:hidden!important;background:linear-gradient(135deg,rgba(9,19,39,.95),rgba(22,13,43,.94))!important;border:1px solid rgba(117,104,255,.52)!important;box-shadow:inset 0 0 15px rgba(35,110,255,.07)!important}
.store-dashboard .dashboard-stat:before{content:"";position:absolute;left:10px;top:50%;transform:translateY(-50%);width:34px;height:34px;display:flex;align-items:center;justify-content:center;border-radius:50%;font-size:21px;line-height:1;background:linear-gradient(145deg,rgba(0,255,160,.2),rgba(0,85,255,.22));border:1px solid rgba(70,205,255,.38);filter:drop-shadow(0 0 7px rgba(70,130,255,.2))}
.store-dashboard .dashboard-stat:nth-child(1):before{content:"✓";color:#8affcf;background:linear-gradient(145deg,rgba(0,255,128,.35),rgba(0,145,91,.15));border-color:rgba(0,255,145,.7);font-size:23px;font-weight:1000}
.store-dashboard .dashboard-stat:nth-child(2):before{content:"🛒";background:linear-gradient(145deg,rgba(255,40,190,.3),rgba(98,0,180,.2));border-color:rgba(255,65,194,.65)}
.store-dashboard .dashboard-stat:nth-child(3):before{content:"🔑";background:linear-gradient(145deg,rgba(255,186,40,.3),rgba(154,83,0,.2));border-color:rgba(255,190,67,.65)}
.store-dashboard .dashboard-stat:nth-child(4):before{content:"📦";background:linear-gradient(145deg,rgba(177,64,255,.3),rgba(69,0,180,.2));border-color:rgba(190,80,255,.65)}

.store-dashboard .dashboard-stat strong{display:block!important;margin-top:5px!important;font-size:19px!important;line-height:1.15!important}

.store-dashboard .dashboard-quick{padding:12px!important;border-radius:18px!important;border:1px solid rgba(108,115,255,.5)!important;background:linear-gradient(145deg,rgba(7,17,35,.96),rgba(20,12,43,.94))!important;box-shadow:0 0 17px rgba(89,64,255,.09)!important}


.store-dashboard .dashboard-actions a{min-height:56px!important;height:auto!important;padding:8px 9px!important;gap:7px!important;border-radius:13px!important;font-size:12px!important;line-height:1.2!important;box-shadow:inset 0 0 12px rgba(45,115,255,.08),0 0 8px rgba(70,80,255,.06)!important}
.store-dashboard .dashboard-actions .qa-icon{flex:0 0 27px!important;font-size:24px!important;line-height:1!important;filter:drop-shadow(0 0 6px rgba(255,255,255,.2))!important}
.store-dashboard .dashboard-actions .qa-label{font-size:12px!important;line-height:1.2!important}
.store-dashboard .dashboard-actions .qa-arrow{width:22px!important;height:22px!important;min-width:22px!important;font-size:19px!important}
.store-dashboard .dashboard-actions a:nth-child(1){background:linear-gradient(120deg,rgba(0,108,74,.72),rgba(7,35,51,.96))!important;border-color:rgba(17,238,156,.8)!important}
.store-dashboard .dashboard-actions a:nth-child(2){background:linear-gradient(120deg,rgba(0,79,172,.72),rgba(9,24,64,.97))!important;border-color:rgba(20,166,255,.82)!important}
.store-dashboard .dashboard-actions a:nth-child(3){background:linear-gradient(120deg,rgba(133,75,0,.7),rgba(51,25,20,.97))!important;border-color:rgba(255,183,45,.8)!important}
.store-dashboard .dashboard-actions a:nth-child(4){background:linear-gradient(120deg,rgba(103,0,151,.7),rgba(36,12,57,.97))!important;border-color:rgba(221,48,255,.8)!important}
@media(max-width:600px){
 .store-dashboard .dashboard-stat{min-height:72px!important;padding:10px 6px 10px 47px!important}
 .store-dashboard .dashboard-stat:before{left:7px;width:31px;height:31px;font-size:18px}
 .store-dashboard .dashboard-stat span{font-size:9px!important}
 .store-dashboard .dashboard-stat strong{font-size:17px!important}
 .store-dashboard .dashboard-actions a{min-height:54px!important;padding:8px 7px!important;font-size:11px!important}
 .store-dashboard .dashboard-actions .qa-icon{font-size:22px!important;flex-basis:24px!important}
 .store-dashboard .dashboard-actions .qa-label{font-size:11px!important}
}
</style>

<link rel="icon" type="image/png" sizes="48x48" href="/assets/pwa-icon-48.png">
<link rel="apple-touch-icon" sizes="180x180" href="/assets/pwa-icon-180.png">
<link rel="manifest" href="/pwa-manifest.json">
<meta name="apple-mobile-web-app-title" content="XTREME TITAN">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="mobile-web-app-capable" content="yes">
<meta name="theme-color" content="#080a14">
<style id="store-dashboard-precise-reference-v32">
/* Exact dashboard-only override: vivid reference-style icons/gradients, compact controls. */
html[data-theme] .store-dashboard .dashboard-balance{
  border:1px solid rgba(255,43,171,.82)!important;border-radius:22px!important;
  background:radial-gradient(ellipse at 92% 0%,rgba(22,168,255,.15),transparent 43%),linear-gradient(140deg,#090f22 0%,#17112d 58%,#21102e 100%)!important;
  box-shadow:0 0 0 2px rgba(109,62,255,.13),0 0 18px rgba(255,40,171,.13),inset 0 1px 0 rgba(255,255,255,.08)!important;
}
html[data-theme] .store-dashboard .dashboard-label{color:#aebcff!important;letter-spacing:.12em!important}
html[data-theme] .store-dashboard .dashboard-balance-value{color:#3ff0b6!important;text-shadow:0 0 18px rgba(63,240,182,.22)!important}
html[data-theme] .store-dashboard .dashboard-topup{
 display:inline-flex!important;align-items:center!important;justify-content:center!important;gap:7px!important;
 min-height:38px!important;height:38px!important;padding:0 13px!important;border-radius:12px!important;
 background:linear-gradient(110deg,#13d7ff 0%,#665cff 52%,#ff3b9e 100%)!important;
 border:1px solid rgba(255,255,255,.32)!important;color:#fff!important;font-size:11px!important;
 box-shadow:0 0 14px rgba(28,174,255,.18)!important;
}
html[data-theme] .store-dashboard .dashboard-topup:before{content:"＋"!important;display:inline-flex!important;align-items:center!important;justify-content:center!important;width:19px!important;height:19px!important;border-radius:50%!important;background:#fff!important;color:#6952e8!important;font-size:16px!important;font-weight:1000!important;line-height:1!important}
html[data-theme] .store-dashboard .dashboard-stat{
 position:relative!important;min-height:76px!important;padding:11px 8px 10px 52px!important;border-radius:16px!important;overflow:hidden!important;
 background:linear-gradient(135deg,rgba(10,19,41,.97),rgba(28,13,47,.96))!important;
 border:1px solid rgba(129,113,255,.58)!important;box-shadow:inset 0 0 15px rgba(37,111,255,.07)!important;
}
html[data-theme] .store-dashboard .dashboard-stat:before{position:absolute!important;left:9px!important;top:50%!important;transform:translateY(-50%)!important;width:34px!important;height:34px!important;display:flex!important;align-items:center!important;justify-content:center!important;border-radius:50%!important;font-size:21px!important;line-height:1!important;border:1px solid rgba(70,205,255,.38)!important;filter:drop-shadow(0 0 7px rgba(70,130,255,.2))!important}
html[data-theme] .store-dashboard .dashboard-stat:nth-child(1):before{content:"✓"!important;color:#8affcf!important;background:linear-gradient(145deg,rgba(0,255,128,.35),rgba(0,145,91,.15))!important;border-color:rgba(0,255,145,.7)!important;font-size:23px!important;font-weight:1000!important}
html[data-theme] .store-dashboard .dashboard-stat:nth-child(2):before{content:"🛒"!important;background:linear-gradient(145deg,rgba(255,40,190,.3),rgba(98,0,180,.2))!important;border-color:rgba(255,65,194,.65)!important}
html[data-theme] .store-dashboard .dashboard-stat:nth-child(3):before{content:"🔑"!important;background:linear-gradient(145deg,rgba(255,186,40,.3),rgba(154,83,0,.2))!important;border-color:rgba(255,190,67,.65)!important}
html[data-theme] .store-dashboard .dashboard-stat:nth-child(4):before{content:"📦"!important;background:linear-gradient(145deg,rgba(177,64,255,.3),rgba(69,0,180,.2))!important;border-color:rgba(190,80,255,.65)!important}
html[data-theme] .store-dashboard .dashboard-stat span{font-size:10px!important;line-height:1.3!important;white-space:normal!important;color:#bdc9ff!important}
html[data-theme] .store-dashboard .dashboard-stat strong{display:block!important;margin-top:5px!important;font-size:19px!important;line-height:1.15!important}
html[data-theme] .store-dashboard .dashboard-stat:nth-child(1) strong{color:#38efb0!important}html[data-theme] .store-dashboard .dashboard-stat:nth-child(2) strong{color:#ff6ab3!important}html[data-theme] .store-dashboard .dashboard-stat:nth-child(3) strong{color:#c49bff!important}html[data-theme] .store-dashboard .dashboard-stat:nth-child(4) strong{color:#ffc33d!important}
html[data-theme] .store-dashboard .dashboard-quick{padding:12px!important;border-radius:18px!important;border:1px solid rgba(108,115,255,.55)!important;background:linear-gradient(145deg,rgba(7,17,35,.97),rgba(25,12,44,.96))!important;box-shadow:0 0 17px rgba(89,64,255,.09)!important}
html[data-theme] .store-dashboard .dashboard-quick-title{font-size:15px!important;margin:0 0 8px!important;color:#f5f6ff!important}
html[data-theme] .store-dashboard .dashboard-quick-title:before{content:"ϟ"!important;display:inline-block!important;margin-right:7px!important;color:#ffe84a!important;font-size:22px!important;text-shadow:0 0 12px rgba(255,221,40,.35)!important}
html[data-theme] .store-dashboard .dashboard-actions{gap:7px!important;margin-top:8px!important}
html[data-theme] .store-dashboard .dashboard-actions a{display:flex!important;align-items:center!important;min-height:56px!important;height:auto!important;padding:8px 9px!important;gap:7px!important;border-radius:13px!important;font-size:12px!important;line-height:1.2!important;color:#fff!important;box-shadow:inset 0 0 12px rgba(45,115,255,.08),0 0 8px rgba(70,80,255,.08)!important}
html[data-theme] .store-dashboard .dashboard-actions a:nth-child(1){background:linear-gradient(120deg,rgba(0,170,105,.9),rgba(4,43,51,.98))!important;border:1px solid rgba(17,238,156,.9)!important;box-shadow:0 0 12px rgba(0,225,151,.12),inset 0 0 12px rgba(0,255,163,.08)!important}
html[data-theme] .store-dashboard .dashboard-actions a:nth-child(2){background:linear-gradient(120deg,rgba(0,116,235,.92),rgba(12,28,81,.98))!important;border:1px solid rgba(20,183,255,.9)!important;box-shadow:0 0 12px rgba(20,166,255,.12),inset 0 0 12px rgba(20,166,255,.08)!important}
html[data-theme] .store-dashboard .dashboard-actions a:nth-child(3){background:linear-gradient(120deg,rgba(195,112,0,.92),rgba(67,29,19,.98))!important;border:1px solid rgba(255,190,55,.9)!important;box-shadow:0 0 12px rgba(255,183,45,.12),inset 0 0 12px rgba(255,183,45,.08)!important}
html[data-theme] .store-dashboard .dashboard-actions a:nth-child(4){background:linear-gradient(120deg,rgba(143,0,205,.92),rgba(51,13,77,.98))!important;border:1px solid rgba(225,65,255,.9)!important;box-shadow:0 0 12px rgba(221,48,255,.12),inset 0 0 12px rgba(221,48,255,.08)!important}
html[data-theme] .store-dashboard .dashboard-actions .qa-icon{display:inline-flex!important;align-items:center!important;justify-content:center!important;flex:0 0 27px!important;font-size:24px!important;line-height:1!important;filter:drop-shadow(0 0 6px rgba(255,255,255,.22))!important}
html[data-theme] .store-dashboard .dashboard-actions .qa-label{display:block!important;min-width:0!important;flex:1 1 auto!important;font-size:12px!important;font-weight:950!important;line-height:1.2!important;white-space:normal!important;overflow-wrap:anywhere!important}
html[data-theme] .store-dashboard .dashboard-actions .qa-arrow{display:inline-flex!important;align-items:center!important;justify-content:center!important;flex:0 0 22px!important;width:22px!important;height:22px!important;border:1.5px solid currentColor!important;border-radius:50%!important;font-size:19px!important;line-height:1!important;opacity:.98!important}
html[data-theme] .xt-purchase-warning{border:1px solid #ff4f91!important;border-radius:15px!important;background:linear-gradient(100deg,rgba(104,12,68,.45),rgba(48,12,49,.62))!important;color:#ffe0ef!important;box-shadow:0 0 12px rgba(255,48,145,.1)!important}
@media(max-width:600px){html[data-theme] .store-dashboard .dashboard-stat{min-height:72px!important;padding:10px 6px 10px 47px!important}html[data-theme] .store-dashboard .dashboard-stat:before{left:7px!important;width:31px!important;height:31px!important;font-size:18px!important}html[data-theme] .store-dashboard .dashboard-stat span{font-size:9px!important}html[data-theme] .store-dashboard .dashboard-stat strong{font-size:17px!important}html[data-theme] .store-dashboard .dashboard-actions a{min-height:54px!important;padding:8px 7px!important;font-size:11px!important}html[data-theme] .store-dashboard .dashboard-actions .qa-icon{font-size:22px!important;flex-basis:24px!important}html[data-theme] .store-dashboard .dashboard-actions .qa-label{font-size:11px!important}}
</style>
<style id="xt-dashboard-final-unscoped-v33">
/* Final dashboard-only icon and neon color fix. Deliberately unscoped by theme attribute. */
.store-dashboard .dashboard-balance{border:1px solid rgba(255,45,174,.82)!important;border-radius:22px!important;background:radial-gradient(ellipse at 92% 0%,rgba(22,168,255,.14),transparent 43%),linear-gradient(140deg,#090f22 0%,#17112d 58%,#21102e 100%)!important;box-shadow:0 0 0 2px rgba(109,62,255,.13),0 0 18px rgba(255,40,171,.13),inset 0 1px 0 rgba(255,255,255,.08)!important}
.store-dashboard .dashboard-label{color:#aebcff!important;letter-spacing:.12em!important}
.store-dashboard .dashboard-balance-value{color:#3ff0b6!important;text-shadow:0 0 18px rgba(63,240,182,.22)!important}
.store-dashboard .dashboard-topup{display:inline-flex!important;align-items:center!important;justify-content:center!important;gap:7px!important;min-height:38px!important;height:38px!important;padding:0 13px!important;border-radius:12px!important;background:linear-gradient(110deg,#13d7ff,#665cff 52%,#ff3b9e)!important;border:1px solid rgba(255,255,255,.32)!important;color:#fff!important;font-size:11px!important;box-shadow:0 0 14px rgba(28,174,255,.18)!important}
.store-dashboard .dashboard-topup:before{content:"＋"!important;display:inline-flex!important;align-items:center!important;justify-content:center!important;width:19px!important;height:19px!important;border-radius:50%!important;background:#fff!important;color:#6952e8!important;font-size:16px!important;font-weight:1000!important;line-height:1!important}
.store-dashboard .dashboard-stat{position:relative!important;min-height:76px!important;padding:11px 8px 10px 52px!important;border-radius:16px!important;overflow:hidden!important;background:linear-gradient(135deg,rgba(10,19,41,.97),rgba(28,13,47,.96))!important;border:1px solid rgba(129,113,255,.58)!important;box-shadow:inset 0 0 15px rgba(37,111,255,.07)!important}
.store-dashboard .dashboard-stat:before{position:absolute!important;left:9px!important;top:50%!important;transform:translateY(-50%)!important;width:34px!important;height:34px!important;display:flex!important;align-items:center!important;justify-content:center!important;border-radius:50%!important;font-size:21px!important;line-height:1!important;border:1px solid rgba(70,205,255,.38)!important;filter:drop-shadow(0 0 7px rgba(70,130,255,.2))!important}
.store-dashboard .dashboard-stat:nth-child(1):before{content:"✓"!important;color:#8affcf!important;background:linear-gradient(145deg,rgba(0,255,128,.35),rgba(0,145,91,.15))!important;border-color:rgba(0,255,145,.7)!important;font-size:23px!important;font-weight:1000!important}
.store-dashboard .dashboard-stat:nth-child(2):before{content:"🛒"!important;background:linear-gradient(145deg,rgba(255,40,190,.3),rgba(98,0,180,.2))!important;border-color:rgba(255,65,194,.65)!important}


.store-dashboard .dashboard-stat span{font-size:10px!important;line-height:1.3!important;white-space:normal!important;color:#bdc9ff!important}
.store-dashboard .dashboard-stat strong{display:block!important;margin-top:5px!important;font-size:19px!important;line-height:1.15!important;white-space:normal!important;overflow-wrap:anywhere!important}

.store-dashboard .dashboard-quick{padding:12px!important;border-radius:18px!important;border:1px solid rgba(108,115,255,.55)!important;background:linear-gradient(145deg,rgba(7,17,35,.97),rgba(25,12,44,.96))!important;box-shadow:0 0 17px rgba(89,64,255,.09)!important}
.store-dashboard .dashboard-quick-title{font-size:15px!important;margin:0 0 8px!important;color:#f5f6ff!important}
.store-dashboard .dashboard-quick-title:before{content:"⚡"!important;display:inline-block!important;margin-right:7px!important;color:#ffe84a!important;font-size:20px!important;text-shadow:0 0 12px rgba(255,221,40,.35)!important}
.store-dashboard .dashboard-actions{gap:7px!important;margin-top:8px!important}
.store-dashboard .dashboard-actions a{display:flex!important;align-items:center!important;min-height:56px!important;height:auto!important;padding:8px 9px!important;gap:7px!important;justify-content:flex-start!important;border-radius:13px!important;font-size:12px!important;line-height:1.2!important;color:#fff!important;border:1px solid rgba(95,122,255,.6)!important;background:linear-gradient(120deg,rgba(12,36,69,.96),rgba(18,20,58,.96))!important;box-shadow:inset 0 0 12px rgba(45,115,255,.08),0 0 8px rgba(70,80,255,.08)!important}
.store-dashboard .dashboard-actions a:nth-child(1){background:linear-gradient(120deg,rgba(0,170,105,.9),rgba(4,43,51,.98))!important;border:1px solid rgba(17,238,156,.9)!important;box-shadow:0 0 12px rgba(0,225,151,.12),inset 0 0 12px rgba(0,255,163,.08)!important}
.store-dashboard .dashboard-actions a:nth-child(2){background:linear-gradient(120deg,rgba(0,116,235,.92),rgba(12,28,81,.98))!important;border:1px solid rgba(20,183,255,.9)!important;box-shadow:0 0 12px rgba(20,166,255,.12),inset 0 0 12px rgba(20,166,255,.08)!important}
.store-dashboard .dashboard-actions a:nth-child(3){background:linear-gradient(120deg,rgba(195,112,0,.92),rgba(67,29,19,.98))!important;border:1px solid rgba(255,190,55,.9)!important;box-shadow:0 0 12px rgba(255,183,45,.12),inset 0 0 12px rgba(255,183,45,.08)!important}
.store-dashboard .dashboard-actions a:nth-child(4){background:linear-gradient(120deg,rgba(143,0,205,.92),rgba(51,13,77,.98))!important;border:1px solid rgba(225,65,255,.9)!important;box-shadow:0 0 12px rgba(221,48,255,.12),inset 0 0 12px rgba(221,48,255,.08)!important}
.store-dashboard .dashboard-actions .qa-icon{display:inline-flex!important;align-items:center!important;justify-content:center!important;flex:0 0 27px!important;font-size:24px!important;line-height:1!important;filter:drop-shadow(0 0 6px rgba(255,255,255,.22))!important}
.store-dashboard .dashboard-actions .qa-label{display:block!important;min-width:0!important;flex:1 1 auto!important;font-size:12px!important;font-weight:950!important;line-height:1.2!important;white-space:normal!important;overflow-wrap:anywhere!important}
.store-dashboard .dashboard-actions .qa-arrow{display:inline-flex!important;align-items:center!important;justify-content:center!important;flex:0 0 22px!important;width:22px!important;height:22px!important;border:1.5px solid currentColor!important;border-radius:50%!important;font-size:19px!important;line-height:1!important;opacity:.98!important}
.store-dashboard .xt-purchase-warning{border:1px solid #ff4f91!important;border-radius:15px!important;background:linear-gradient(100deg,rgba(104,12,68,.45),rgba(48,12,49,.62))!important;color:#ffe0ef!important;box-shadow:0 0 12px rgba(255,48,145,.1)!important}
@media(max-width:600px){.store-dashboard .dashboard-stat{min-height:72px!important;padding:10px 6px 10px 47px!important}.store-dashboard .dashboard-stat:before{left:7px!important;width:31px!important;height:31px!important;font-size:18px!important}.store-dashboard .dashboard-stat span{font-size:9px!important}.store-dashboard .dashboard-stat strong{font-size:17px!important}.store-dashboard .dashboard-actions a{min-height:54px!important;padding:8px 7px!important;font-size:11px!important}.store-dashboard .dashboard-actions .qa-icon{font-size:22px!important;flex-basis:24px!important}.store-dashboard .dashboard-actions .qa-label{font-size:11px!important}}
</style>

<style id="xtreme-dashboard-icon-correction-v38">
/* One large wallet icon beside the balance, matching the supplied dashboard reference. */
.store-dashboard .dashboard-balance:before{content:""!important;display:block!important;position:absolute!important;left:25px!important;top:55px!important;width:66px!important;height:56px!important;float:none!important;margin:0!important;background:url("data:image/svg+xml,%3Csvg%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20width%3D%22100%22%20height%3D%2278%22%20viewBox%3D%220%200%20100%2078%22%3E%3Cdefs%3E%3ClinearGradient%20id%3D%22w%22%20x1%3D%220%22%20y1%3D%220%22%20x2%3D%221%22%20y2%3D%221%22%3E%3Cstop%20stop-color%3D%22%2321e6ff%22%2F%3E%3Cstop%20offset%3D%221%22%20stop-color%3D%22%230875ff%22%2F%3E%3C%2FlinearGradient%3E%3ClinearGradient%20id%3D%22c%22%20x1%3D%220%22%20y1%3D%220%22%20x2%3D%220%22%20y2%3D%221%22%3E%3Cstop%20stop-color%3D%22%23ffe86b%22%2F%3E%3Cstop%20offset%3D%221%22%20stop-color%3D%22%23ff9e00%22%2F%3E%3C%2FlinearGradient%3E%3C%2Fdefs%3E%3Cellipse%20cx%3D%2231%22%20cy%3D%2217%22%20rx%3D%2213%22%20ry%3D%2213%22%20fill%3D%22url%28%23c%29%22%20stroke%3D%22%23fff08a%22%20stroke-width%3D%222%22%2F%3E%3Cellipse%20cx%3D%2231%22%20cy%3D%2217%22%20rx%3D%226%22%20ry%3D%226%22%20fill%3D%22%23fff5a6%22%2F%3E%3Cellipse%20cx%3D%2248%22%20cy%3D%2222%22%20rx%3D%2213%22%20ry%3D%2213%22%20fill%3D%22url%28%23c%29%22%20stroke%3D%22%23fff08a%22%20stroke-width%3D%222%22%2F%3E%3Cellipse%20cx%3D%2248%22%20cy%3D%2222%22%20rx%3D%226%22%20ry%3D%226%22%20fill%3D%22%23fff5a6%22%2F%3E%3Cpath%20d%3D%22M12%2026h57a8%208%200%200%201%208%208v34H13a8%208%200%200%201-8-8V34a8%208%200%200%201%207-8z%22%20fill%3D%22url%28%23w%29%22%20stroke%3D%22%2339dfff%22%20stroke-width%3D%222%22%2F%3E%3Cpath%20d%3D%22M62%2039h25a9%209%200%200%201%200%2018H62a9%209%200%200%201%200-18z%22%20fill%3D%22%230875d8%22%20stroke%3D%22%233ce5ff%22%20stroke-width%3D%222%22%2F%3E%3Ccircle%20cx%3D%2278%22%20cy%3D%2248%22%20r%3D%223%22%20fill%3D%22%23b8f7ff%22%2F%3E%3C%2Fsvg%3E") center/contain no-repeat!important;filter:drop-shadow(0 0 9px rgba(0,190,255,.5))!important;z-index:2!important}
.store-dashboard .dashboard-balance-value:before{content:none!important;display:none!important}

/* Replace the unclear purse/card emoji in Quick Access with a clear wallet + icon. */
.store-dashboard .dashboard-actions .xt-wallet-add-icon{font-size:0!important;line-height:0!important;display:inline-flex!important;position:relative!important;flex:0 0 48px!important;width:48px!important;height:42px!important;background:url("data:image/svg+xml,%3Csvg%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20width%3D%22100%22%20height%3D%2278%22%20viewBox%3D%220%200%20100%2078%22%3E%3Cdefs%3E%3ClinearGradient%20id%3D%22w%22%20x1%3D%220%22%20y1%3D%220%22%20x2%3D%221%22%20y2%3D%221%22%3E%3Cstop%20stop-color%3D%22%2322e7ff%22%2F%3E%3Cstop%20offset%3D%221%22%20stop-color%3D%22%230876ff%22%2F%3E%3C%2FlinearGradient%3E%3C%2Fdefs%3E%3Cpath%20d%3D%22M12%2028h57a8%208%200%200%201%208%208v33H13a8%208%200%200%201-8-8V36a8%208%200%200%201%207-8z%22%20fill%3D%22url%28%23w%29%22%20stroke%3D%22%2345e7ff%22%20stroke-width%3D%222%22%2F%3E%3Cpath%20d%3D%22M16%2027%2037%2013h29a6%206%200%200%201%206%206v7H16z%22%20fill%3D%22%2320c9ff%22%20stroke%3D%22%236cecff%22%20stroke-width%3D%222%22%2F%3E%3Cpath%20d%3D%22M62%2039h25a9%209%200%200%201%200%2018H62a9%209%200%200%201%200-18z%22%20fill%3D%22%230875d8%22%20stroke%3D%22%233ce5ff%22%20stroke-width%3D%222%22%2F%3E%3Ccircle%20cx%3D%2278%22%20cy%3D%2248%22%20r%3D%223%22%20fill%3D%22%23b8f7ff%22%2F%3E%3Ccircle%20cx%3D%2276%22%20cy%3D%2219%22%20r%3D%2215%22%20fill%3D%22%23fff%22%20stroke%3D%22%236deaff%22%20stroke-width%3D%223%22%2F%3E%3Cpath%20d%3D%22M76%2010v18M67%2019h18%22%20stroke%3D%22%233d6dff%22%20stroke-width%3D%224%22%20stroke-linecap%3D%22round%22%2F%3E%3C%2Fsvg%3E") center/contain no-repeat!important;filter:drop-shadow(0 0 8px rgba(0,190,255,.42))!important}
.store-dashboard .dashboard-actions .xt-wallet-add-icon .xt-wallet-plus{display:none!important}
@media(max-width:600px){.store-dashboard .dashboard-balance:before{left:15px!important;top:53px!important;width:52px!important;height:45px!important}.store-dashboard .dashboard-balance-value{margin-left:62px!important}.store-dashboard .dashboard-actions .xt-wallet-add-icon{flex-basis:36px!important;width:36px!important;height:34px!important}}
@media(max-width:380px){.store-dashboard .dashboard-balance:before{left:11px!important;top:51px!important;width:43px!important;height:38px!important}.store-dashboard .dashboard-balance-value{margin-left:51px!important}.store-dashboard .dashboard-actions .xt-wallet-add-icon{flex-basis:30px!important;width:30px!important;height:29px!important}}
</style>
<style id="xt-dashboard-icon-redesign-v15">
/* Dashboard-only: visibly replace the Balance and Add Funds icons. */
.store-dashboard .dashboard-balance:before{content:""!important;display:block!important;position:absolute!important;left:24px!important;top:54px!important;width:68px!important;height:58px!important;margin:0!important;float:none!important;font-size:0!important;line-height:0!important;background-image:url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='100' height='82' viewBox='0 0 100 82'%3E%3Cdefs%3E%3ClinearGradient id='coin' x1='0' y1='0' x2='0' y2='1'%3E%3Cstop stop-color='%23fff08a'/%3E%3Cstop offset='.48' stop-color='%23ffc52e'/%3E%3Cstop offset='1' stop-color='%23e88b00'/%3E%3C/linearGradient%3E%3ClinearGradient id='bill' x1='0' y1='0' x2='1' y2='1'%3E%3Cstop stop-color='%233ef5c2'/%3E%3Cstop offset='1' stop-color='%2300a887'/%3E%3C/linearGradient%3E%3C/defs%3E%3Cellipse cx='33' cy='24' rx='18' ry='18' fill='url(%23coin)' stroke='%23fff5ad' stroke-width='2'/%3E%3Cellipse cx='55' cy='20' rx='18' ry='18' fill='url(%23coin)' stroke='%23fff5ad' stroke-width='2'/%3E%3Cellipse cx='45' cy='43' rx='18' ry='18' fill='url(%23coin)' stroke='%23fff5ad' stroke-width='2'/%3E%3Cpath d='M22 43h48a9 9 0 0 1 9 9v18H22a9 9 0 0 1-9-9v-9a9 9 0 0 1 9-9z' fill='url(%23bill)' stroke='%236affd8' stroke-width='2'/%3E%3Ctext x='47' y='62' text-anchor='middle' font-family='Arial,sans-serif' font-size='21' font-weight='bold' fill='%230b4e47'%3E%E0%A7%B3%3C/text%3E%3C/svg%3E")!important;background-position:center!important;background-size:contain!important;background-repeat:no-repeat!important;filter:drop-shadow(0 0 10px rgba(35,244,194,.45))!important;z-index:3!important}
.store-dashboard .dashboard-balance-value{margin-left:84px!important}
.store-dashboard .dashboard-actions a[href*="deposit.php"] .xt-wallet-add-icon,.store-dashboard .dashboard-actions a[href*="deposit.php"] .qa-icon{display:inline-flex!important;position:relative!important;align-items:center!important;justify-content:center!important;flex:0 0 48px!important;width:48px!important;height:48px!important;min-width:48px!important;min-height:48px!important;margin:0!important;padding:0!important;border:0!important;border-radius:0!important;background:none!important;background-image:none!important;box-shadow:none!important;overflow:visible!important;font-size:0!important;line-height:0!important}
.store-dashboard .dashboard-actions a[href*="deposit.php"] .xt-wallet-add-icon img,.store-dashboard .dashboard-actions a[href*="deposit.php"] .qa-icon img{display:none!important;visibility:hidden!important}
.store-dashboard .dashboard-actions a[href*="deposit.php"] .xt-wallet-add-icon:before,.store-dashboard .dashboard-actions a[href*="deposit.php"] .qa-icon:before{content:""!important;display:block!important;width:48px!important;height:44px!important;background-image:url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='100' height='82' viewBox='0 0 100 82'%3E%3Cdefs%3E%3ClinearGradient id='w' x1='0' y1='0' x2='1' y2='1'%3E%3Cstop stop-color='%2345f1ff'/%3E%3Cstop offset='1' stop-color='%23005bff'/%3E%3C/linearGradient%3E%3ClinearGradient id='p' x1='0' y1='0' x2='1' y2='1'%3E%3Cstop stop-color='%23fff'/%3E%3Cstop offset='1' stop-color='%23dce8ff'/%3E%3C/linearGradient%3E%3C/defs%3E%3Cpath d='M12 25h59a8 8 0 0 1 8 8v37H15a8 8 0 0 1-8-8V33a8 8 0 0 1 5-8z' fill='url(%23w)' stroke='%2371f4ff' stroke-width='3'/%3E%3Cpath d='M18 24l17-12h30a6 6 0 0 1 6 6v7z' fill='%2325caff' stroke='%2371f4ff' stroke-width='2'/%3E%3Cpath d='M61 39h26a10 10 0 0 1 0 20H61a10 10 0 0 1 0-20z' fill='%230a3b9d' stroke='%2368eaff' stroke-width='3'/%3E%3Ccircle cx='78' cy='49' r='3.5' fill='%23d9ffff'/%3E%3Ccircle cx='76' cy='17' r='16' fill='url(%23p)' stroke='%2364eaff' stroke-width='3'/%3E%3Cpath d='M76 8v18M67 17h18' stroke='%233a6bff' stroke-width='5' stroke-linecap='round'/%3E%3C/svg%3E")!important;background-position:center!important;background-size:contain!important;background-repeat:no-repeat!important;filter:drop-shadow(0 0 9px rgba(0,207,255,.55))!important}
@media(max-width:600px){.store-dashboard .dashboard-balance:before{left:14px!important;top:51px!important;width:53px!important;height:47px!important}.store-dashboard .dashboard-balance-value{margin-left:64px!important}.store-dashboard .dashboard-actions a[href*="deposit.php"] .xt-wallet-add-icon,.store-dashboard .dashboard-actions a[href*="deposit.php"] .qa-icon{flex-basis:40px!important;width:40px!important;height:40px!important;min-width:40px!important;min-height:40px!important}.store-dashboard .dashboard-actions a[href*="deposit.php"] .xt-wallet-add-icon:before,.store-dashboard .dashboard-actions a[href*="deposit.php"] .qa-icon:before{width:40px!important;height:38px!important}}
</style>

<style id="xtreme-v23-header-announcement-banner">
/* Banner sits in page flow below the fixed brand header and directly above the balance card. */
.xt-header-announcement{
  display:flex!important;flex-direction:column!important;align-items:center!important;justify-content:center!important;
  gap:6px!important;width:min(94%,560px)!important;max-width:560px!important;margin:10px auto 14px!important;
  padding:7px 9px!important;border:1px solid rgba(64,210,255,.55)!important;border-radius:13px!important;
  background:linear-gradient(110deg,rgba(14,36,68,.86),rgba(54,20,75,.88))!important;
  box-shadow:0 0 12px rgba(0,190,255,.12),inset 0 1px 0 rgba(255,255,255,.10)!important;
  color:#eaf7ff!important;text-decoration:none!important;overflow:hidden!important;box-sizing:border-box!important;
}
.xt-header-announcement img{display:block!important;width:100%!important;max-width:100%!important;max-height:125px!important;object-fit:contain!important;border-radius:8px!important}
.xt-header-announcement span{display:block!important;width:100%!important;text-align:center!important;font-size:11px!important;line-height:1.4!important;font-weight:800!important;letter-spacing:.025em!important;overflow-wrap:anywhere!important;color:#dff8ff!important}
@media(max-width:600px){.xt-header-announcement{width:94%!important;margin:8px auto 12px!important;padding:6px 7px!important;border-radius:11px!important}.xt-header-announcement img{max-height:92px!important}.xt-header-announcement span{font-size:10px!important}}
</style>


<style id="xt-global-header-logo-unified-v29">
/* One consistent site-header logo and title scale on every customer page */
header.top, header.topbar {
  box-sizing:border-box!important;
  width:100%!important;
  min-height:0!important;
  height:auto!important;
  padding:14px 14px 16px!important;
  margin:0 auto!important;
  display:flex!important;
  align-items:center!important;
  justify-content:center!important;
  text-align:center!important;
}
header.top .brand-with-logo, header.topbar .brand-with-logo {
  box-sizing:border-box!important;
  width:100%!important;
  max-width:100%!important;
  display:flex!important;
  flex-direction:column!important;
  align-items:center!important;
  justify-content:center!important;
  gap:7px!important;
  margin:0 auto!important;
  text-align:center!important;
}
header.top .header-logo, header.topbar .header-logo {
  display:block!important;
  box-sizing:border-box!important;
  width:46px!important;height:46px!important;
  min-width:46px!important;min-height:46px!important;
  max-width:46px!important;max-height:46px!important;
  flex:0 0 46px!important;
  object-fit:contain!important;object-position:center!important;
  background:transparent!important;
  border:0!important;padding:0!important;margin:0 auto!important;
  border-radius:10px!important;
}
header.top .brand-text, header.topbar .top-title {
  display:block!important;
  max-width:100%!important;
  margin:0 auto!important;padding:0!important;
  text-align:center!important;
  font-size:clamp(17px,4.6vw,25px)!important;
  line-height:1.2!important;
  font-weight:900!important;
  letter-spacing:0!important;
  overflow-wrap:anywhere!important;
}
header.topbar .xt-dashboard-tagline {
  margin:0 auto!important;
  text-align:center!important;
  line-height:1.2!important;
}
@media(max-width:420px) {
  header.top,header.topbar{padding:12px 10px 14px!important}
  header.top .header-logo,header.topbar .header-logo {
    width:46px!important;height:46px!important;min-width:46px!important;min-height:46px!important;
    max-width:46px!important;max-height:46px!important;flex-basis:46px!important;
  }
}
</style>

<style id="xt-dashboard-panel-inset-v29">
/* Keep the large dashboard panel visibly inset from both phone edges.
   The contents stay inside this panel; only its outer spacing changes. */
.store-dashboard {
  box-sizing:border-box!important;
  width:calc(100% - 28px)!important;
  max-width:1000px!important;
  margin:18px auto 20px!important;
  padding:18px!important;
  border-radius:26px!important;
  overflow:hidden!important;
}
.store-dashboard .dashboard-balance,
.store-dashboard .dashboard-stats,
.store-dashboard .dashboard-quick,
.store-dashboard .dashboard-actions-wrap {
  box-sizing:border-box!important;
  max-width:100%!important;
  min-width:0!important;
}
.store-dashboard .dashboard-balance{width:100%!important;margin-left:auto!important;margin-right:auto!important}
.store-dashboard .dashboard-stats {
  width:100%!important;
  display:grid!important;
  grid-template-columns:repeat(2,minmax(0,1fr))!important;
  gap:12px!important;
  margin-left:auto!important;margin-right:auto!important;
}
.store-dashboard .dashboard-stat{box-sizing:border-box!important;min-width:0!important;max-width:100%!important}
.store-dashboard .dashboard-quick {
  width:100%!important;
  margin-left:auto!important;margin-right:auto!important;
}
.store-dashboard .dashboard-actions {
  width:100%!important;
  box-sizing:border-box!important;
  display:grid!important;
  grid-template-columns:repeat(2,minmax(0,1fr))!important;
  gap:10px!important;
}
.store-dashboard .dashboard-actions a {
  box-sizing:border-box!important;
  min-width:0!important;
  max-width:100%!important;
}
@media(max-width:480px) {
  .store-dashboard {
    width:calc(100% - 28px)!important;
    margin:16px auto 18px!important;
    padding:14px!important;
    border-radius:24px!important;
  }
  .store-dashboard .dashboard-stats{gap:10px!important}
  .store-dashboard .dashboard-actions{gap:9px!important}
}
</style>

<style id="xt-banner-dashboard-width-and-image-fit-v30">
/* V30: Make the large dashboard panel match the announcement banner's side margins. */
.xt-header-announcement,
.store-dashboard {
  box-sizing:border-box!important;
  width:94%!important;
  max-width:560px!important;
  margin-left:auto!important;
  margin-right:auto!important;
}
.store-dashboard {
  margin-top:18px!important;
  margin-bottom:20px!important;
  padding:16px!important;
  border-radius:24px!important;
  overflow:hidden!important;
}
.store-dashboard .dashboard-balance,
.store-dashboard .dashboard-stats,
.store-dashboard .dashboard-quick,
.store-dashboard .dashboard-actions-wrap {
  box-sizing:border-box!important;
  width:100%!important;
  max-width:100%!important;
  min-width:0!important;
}
.store-dashboard .dashboard-stats {
  display:grid!important;
  grid-template-columns:repeat(2,minmax(0,1fr))!important;
  gap:10px!important;
  margin-left:0!important;
  margin-right:0!important;
}
.store-dashboard .dashboard-stat {min-width:0!important;max-width:100%!important;box-sizing:border-box!important}
.store-dashboard .dashboard-quick {margin-left:0!important;margin-right:0!important}
.store-dashboard .dashboard-actions {
  display:grid!important;
  grid-template-columns:repeat(2,minmax(0,1fr))!important;
  width:100%!important;
  gap:9px!important;
  box-sizing:border-box!important;
}
.store-dashboard .dashboard-actions a {min-width:0!important;max-width:100%!important;box-sizing:border-box!important}

/* Fill the banner card with the uploaded banner instead of leaving the image tiny
   or letterboxed. The whole image remains responsive on narrow phone screens. */
.xt-header-announcement {
  padding:7px!important;
  gap:0!important;
  overflow:hidden!important;
}
.xt-header-announcement img {
  display:block!important;
  width:100%!important;
  max-width:100%!important;
  height:clamp(105px,25vw,145px)!important;
  max-height:none!important;
  object-fit:cover!important;
  object-position:center!important;
  border-radius:8px!important;
}
@media(max-width:480px) {
  .xt-header-announcement,.store-dashboard {width:94%!important}
  .store-dashboard {padding:13px!important}
  .store-dashboard .dashboard-stats {gap:9px!important}
  .store-dashboard .dashboard-actions {gap:8px!important}
  .xt-header-announcement img {height:clamp(100px,28vw,125px)!important}
}
</style>

<style id="xt-dashboard-sides-match-banner-v31">
/* Match the outer dashboard panel's left/right inset to the banner card. */
html[data-theme] section.store-dashboard,
section.store-dashboard {
  box-sizing:border-box!important;
  width:calc(100% - 48px)!important;
  max-width:560px!important;
  margin-left:auto!important;
  margin-right:auto!important;
  overflow:hidden!important;
}
html[data-theme] .xt-header-announcement,
.xt-header-announcement {
  box-sizing:border-box!important;
  width:calc(100% - 48px)!important;
  max-width:560px!important;
  margin-left:auto!important;
  margin-right:auto!important;
}

@media(max-width:480px) {
  html[data-theme] section.store-dashboard,
  section.store-dashboard,
  html[data-theme] .xt-header-announcement,
  .xt-header-announcement {
    width:calc(100% - 48px)!important;
  }
}
</style>

<style id="xt-dashboard-banner-match-product-card-width-v32">
/* Match the outer dashboard and banner card to the product-card side inset. */
html[data-theme] .xt-header-announcement,
.xt-header-announcement,
html[data-theme] section.store-dashboard,
section.store-dashboard {
  box-sizing:border-box!important;
  width:calc(100% - 20px)!important;
  max-width:900px!important;
  margin-left:auto!important;
  margin-right:auto!important;
}
html[data-theme] section.store-dashboard {
  padding:16px!important;
  border-radius:24px!important;
  overflow:hidden!important;
}
html[data-theme] section.store-dashboard .dashboard-balance,
html[data-theme] section.store-dashboard .dashboard-stats,
html[data-theme] section.store-dashboard .dashboard-quick,
html[data-theme] section.store-dashboard .dashboard-actions,
section.store-dashboard .dashboard-balance,
section.store-dashboard .dashboard-stats,
section.store-dashboard .dashboard-quick,
section.store-dashboard .dashboard-actions {
  box-sizing:border-box!important;
  max-width:100%!important;
  min-width:0!important;
}
@media(max-width:600px) {
  html[data-theme] .xt-header-announcement,
  .xt-header-announcement,
  html[data-theme] section.store-dashboard,
  section.store-dashboard {
    width:calc(100% - 20px)!important;
  }
  html[data-theme] section.store-dashboard,
  section.store-dashboard {padding:13px!important}
}
</style>
<link rel="stylesheet" href="assets/xtreme-music.css?v=3">
</head>

<body>


<div class="site-decoration-wrap" aria-hidden="true"></div>

<header class="topbar">

    <div class="brand-with-logo">
        <img class="header-logo" src="<?=h($site['logo_path'])?>" alt="XTREME TITAN">
        <div class="top-title"><?=h($site['site_title'])?></div>
        <div class="xt-dashboard-tagline">PREMIUM PANEL STORE</div>
    </div>

</header>

        <?php if (trim((string)($site['header_banner_path'] ?? '')) !== '' || trim((string)($site['header_banner_text'] ?? '')) !== ''): ?>
          <?php $headerBannerUrl = trim((string)($site['header_banner_url'] ?? '')); ?>
          <?php if ($headerBannerUrl !== ''): ?><a class="xt-header-announcement" href="<?=h($headerBannerUrl)?>" target="_blank" rel="noopener noreferrer"><?php else: ?><div class="xt-header-announcement"><?php endif; ?>
            <?php if (trim((string)($site['header_banner_path'] ?? '')) !== ''): ?><img src="<?=h($site['header_banner_path'])?>" alt="Shop announcement banner" loading="lazy"><?php endif; ?>
            <?php if (trim((string)($site['header_banner_text'] ?? '')) !== ''): ?><span><?=h($site['header_banner_text'])?></span><?php endif; ?>
          <?php if ($headerBannerUrl !== ''): ?></a><?php else: ?></div><?php endif; ?>
        <?php endif; ?>

<section class="store-dashboard">
    <div class="dashboard-balance">
        <div class="dashboard-label">BALANCE</div>
        <div class="dashboard-balance-value" data-currency-amount="<?=h($dashBalance)?>"><?=h(number_format($dashBalance,2))?></div>
        <?php if ($site['add_funds_banner_path'] !== ''): ?>
          <?php $bannerUrl = trim((string)$site['add_funds_banner_url']); ?>
          <?php if ($bannerUrl !== ''): ?><a class="xt-addfunds-banner" href="<?=h($bannerUrl)?>" target="_blank" rel="noopener noreferrer"><?php else: ?><div class="xt-addfunds-banner"><?php endif; ?>
            <img src="<?=h($site['add_funds_banner_path'])?>" alt="Add Funds promotion" loading="lazy">
          <?php if ($bannerUrl !== ''): ?></a><?php else: ?></div><?php endif; ?>
        <?php endif; ?>
        <a class="dashboard-topup" href="deposit.php">ADD FUNDS</a>
        <?php if ($purchaseErrorFlash !== ''): ?>
          <?php
            // Always source the displayed available balance from the same canonical BDT
            // calculation used by the dashboard. Old flash messages may contain a
            // previously formatted currency amount; parsing that as BDT caused a
            // second conversion (e.g. $2.26 becoming $0.02).
            // Always use the same canonical balance shown in the dashboard.
            // Session-stored values may be stale or were captured before a prior
            // currency conversion, causing e.g. $2.26 in the dashboard but $0.02 here.
            $warnHave = (float)$dashBalance;
            $warnNeed = is_array($purchaseErrorAmounts ?? null) && isset($purchaseErrorAmounts['need_bdt'])
                ? (float)$purchaseErrorAmounts['need_bdt'] : null;
            if ($warnNeed === null && preg_match('/but you need\s*(?:৳|\$|€|£|₹|₫|د\.إ|Nu\.)?\s*([\d,]+\.\d{2})/i', $purchaseErrorFlash, $wm)) {
                // The fallback is only for older sessions without raw numeric values.
                $warnNeed = (float)str_replace(',', '', $wm[1]);
            }
          ?>
          <div class="xt-purchase-warning" role="alert" aria-live="polite" data-raw-message="<?= htmlspecialchars($purchaseErrorFlash, ENT_QUOTES, 'UTF-8') ?>" <?php if($warnNeed!==null): ?>data-balance-bdt="<?=h($warnHave)?>" data-needed-bdt="<?=h($warnNeed)?>"<?php endif; ?>><?= htmlspecialchars($purchaseErrorFlash, ENT_QUOTES, 'UTF-8') ?></div>
        <?php endif; ?>
    </div>

    <div class="dashboard-stats">
        <div class="dashboard-stat"><span>Approved Deposits</span><strong data-currency-amount="<?=h($dashDeposits)?>"><?=h(number_format($dashDeposits,2))?></strong></div>
        <div class="dashboard-stat"><span>Total Purchases</span><strong data-currency-amount="<?=h($dashPurchases)?>"><?=h(number_format($dashPurchases,2))?></strong></div>
        <div class="dashboard-stat"><span>My Keys</span><strong><?= $dashKeys ?></strong></div>
        <div class="dashboard-stat"><span>Active Key</span><strong><?= $dashActiveKeys ?></strong></div>
    </div>

    <div class="dashboard-quick">
        <div class="dashboard-quick-title">Quick Access</div>
        <div class="dashboard-actions">
            <a href="my-keys.php"><span class="qa-icon qa-image-icon" aria-hidden="true"><img src="assets/nav-icons/quick-keys.png" alt=""></span><span class="qa-label">My Keys</span><span class="qa-arrow" aria-hidden="true">›</span></a>
            <a href="deposit.php"><span class="qa-icon qa-image-icon xt-wallet-add-icon" aria-hidden="true"><img src="assets/nav-icons/quick-funds.png" alt=""></span><span class="qa-label">Add Funds</span><span class="qa-arrow" aria-hidden="true">›</span></a>
            <a href="history.php"><span class="qa-icon qa-image-icon" aria-hidden="true"><img src="assets/nav-icons/quick-history.png" alt=""></span><span class="qa-label">History</span><span class="qa-arrow" aria-hidden="true">›</span></a>
            <a href="profile.php"><span class="qa-icon qa-image-icon" aria-hidden="true"><img src="assets/nav-icons/quick-profile.png" alt=""></span><span class="qa-label">Profile</span><span class="qa-arrow" aria-hidden="true">›</span></a>
        </div>
    </div>
    <?php if ($userRole === 'reseller'): ?>
      <div class="reseller-access-panel" style="margin-top:12px;padding:14px 16px;border-radius:18px;border:1px solid rgba(16,216,255,.28);background:linear-gradient(135deg,rgba(16,216,255,.10),rgba(139,92,246,.12));color:var(--xt-text)">
        <strong style="display:block;font-size:14px">RESELLER PRICING · PRODUCT-WISE DISCOUNTS</strong>
        <?php if ($dashDepositsUsd < 50): ?>
          <p style="margin:7px 0;color:var(--xt-muted);font-size:12px;line-height:1.5">Purchases are locked until your approved deposits reach $50. Approved deposits: $<?=h(number_format($dashDepositsUsd,2))?> / $50.00.</p>
          <div style="height:8px;background:rgba(100,116,139,.22);border-radius:999px;overflow:hidden"><div style="height:100%;width:<?=h((string)max(0,min(100,($dashDeposits/50)*100)))?>%;background:linear-gradient(90deg,#06b6d4,#8b5cf6);border-radius:999px"></div></div>
          <a href="deposit.php" style="display:inline-block;margin-top:10px;padding:9px 13px;border-radius:11px;background:linear-gradient(135deg,#06b6d4,#7c3aed);color:#fff;text-decoration:none;font-weight:900;font-size:12px">ADD FUNDS TO UNLOCK</a>
        <?php else: ?>
          <p style="margin:7px 0;color:var(--xt-money);font-size:12px">✓ $50 deposit requirement met. Reseller purchases are unlocked.</p>
        <?php endif; ?>
      </div>
    <?php endif; ?>
</section>

<section class="store-filters" aria-label="Product filters">
  <button type="button" class="store-filter" data-filter="live">LIVE KEYS <b id="count-live">0</b></button>
  <button type="button" class="store-filter active" data-filter="all">All Products <b id="count-all">0</b></button>
  <button type="button" class="store-filter" data-filter="ANDROID_NONROOT">Android Non Root <b id="count-anr">0</b></button>
  <button type="button" class="store-filter" data-filter="IPHONE">Apple iOS Product <b id="count-ios">0</b></button>
  <button type="button" class="store-filter" data-filter="ANDROID_ROOT">Android Root <b id="count-ar">0</b></button>
  <button type="button" class="store-filter" data-filter="PC_PANEL_FF">PC PANEL FF <b id="count-pc">0</b></button>
</section>

<main class="container">

<?php if (!$products): ?>

    <div class="empty">

        <div class="empty-icon">
            🛒
        </div>

        <div class="empty-title">
            No Products Available
        </div>

        <div>
            Products will appear here when they are added.
        </div>

    </div>

<?php else: ?>


<?php foreach ($products as $product): ?>

<?php

$productId = (int)$product['id'];
$productDescription = trim((string)($product['description'] ?? ''));
$productLinks = productLinks($productDescription);

$productPlans =
    $plansByProduct[$productId] ?? [];
$productResellerDiscount = ($userRole === 'reseller') ? (isset($product['reseller_discount_percent']) && $product['reseller_discount_percent'] !== null ? max(0.0, min(90.0, (float)$product['reseller_discount_percent'])) : $resellerDiscount) : 0.0;
$productAvailableTotal = 0;
foreach ($productPlans as $pp0) { $productAvailableTotal += (int)($pp0['available_keys'] ?? 0); }

?>

<section
    class="product"
    data-product-id="<?= $productId ?>"
    data-platforms="<?= h((function($raw,$n){$parts=array_map('trim',explode(',',strtoupper((string)$raw)));$out=[];foreach($parts as $p){if($p==='ALL'||$p==='')continue;if(in_array($p,['IOS','APPLE','APPLE_IOS','APPLE_IOS_PRODUCT','IPHONE_PRODUCT'],true))$p='IPHONE';if(in_array($p,['ANDROID_NON_ROOT','ANDROID_NONROOTED','ANDROID_NONROOT_PRODUCT'],true))$p='ANDROID_NONROOT';if(in_array($p,['PC','PC_PANEL','PC_FF'],true))$p='PC_PANEL_FF';if(in_array($p,['ANDROID_NONROOT','IPHONE','ANDROID_ROOT','PC_PANEL_FF'],true)&&!in_array($p,$out,true))$out[]=$p;}if(!$out){$n=strtoupper((string)$n);if(str_contains($n,'PC PANEL FF'))$out[]='PC_PANEL_FF';if(str_contains($n,'ANDROID ROOT')&&!str_contains($n,'NON ROOT'))$out[]='ANDROID_ROOT';if(str_contains($n,'ANDROID NON ROOT')||str_contains($n,'ANDROID NONROOT'))$out[]='ANDROID_NONROOT';if(str_contains($n,'APPLE IOS')||str_contains($n,'IOS PRODUCT')||str_contains($n,'IPHONE'))$out[]='IPHONE';}return implode(',', $out ?: $parts);})($product['platform'] ?? 'ALL',$product['name'] ?? '')) ?>"
    data-platform="<?= h((function($raw,$n){$v=explode(',',(string)$raw)[0]??'ALL';return strtoupper(trim($v));})($product['platform'] ?? 'ALL',$product['name'] ?? '')) ?>"
    data-live="<?= ((int)($product['live_status'] ?? 1) === 1 ? '1' : '0') ?>"
    data-available="<?= $productAvailableTotal ?>"
>


    <?php
    $mediaUrl = '';
    $imageUrl = '';
    $videoUrl = '';
    foreach ($productLinks as $pl) {
        if (!is_array($pl)) continue;
        $candidate = trim((string)($pl['url'] ?? ''));
        if (($pl['type'] ?? '') === 'IMAGE' && $candidate !== '') $imageUrl = $candidate;
        if (($pl['type'] ?? '') === 'VIDEO' && $candidate !== '') $videoUrl = $candidate;
    }
    foreach ($productLinks as $pl) {
        if (!is_array($pl) || ($pl['type'] ?? '') !== 'MEDIA') continue;
        $candidateMedia = trim((string)($pl['url'] ?? ''));
        // The XTREME TITAN logo is branding only; never render it as a giant product poster.
        if (preg_match('~(?:^|/)(?:xtreme-titan-logo\.jpg|tanofficial_neon_background\.(?:gif|mp4)|payment-(?:paypal|bkash|nagad)\.svg)(?:$|\?)~i', $candidateMedia)) continue;
        $mediaUrl = $candidateMedia;
        break;
    }
    if ($mediaUrl === '') {
        foreach ($productLinks as $pl) {
            if (!is_array($pl) || ($pl['type'] ?? '') !== 'SETUP') continue;
            $candidateMedia = trim((string)($pl['url'] ?? ''));
            if (preg_match('~(?:^|/)(?:xtreme-titan-logo\.jpg|tanofficial_neon_background\.(?:gif|mp4)|payment-(?:paypal|bkash|nagad)\.svg)(?:$|\?)~i', $candidateMedia)) continue;
            $mediaUrl = $candidateMedia;
            break;
        }
    }
    if ($imageUrl !== '') $mediaUrl = $imageUrl;
    elseif ($videoUrl !== '') $mediaUrl = $videoUrl;
    ?>
    <div class="product-image xt-inline-media" data-inline-media>
        <?php
        $lowerMedia = strtolower(parse_url($mediaUrl, PHP_URL_PATH) ?? '');
        $isDirectVideo = (bool)preg_match('/\.(mp4|webm|ogg|mov)$/i', $lowerMedia);
        $isYoutube = (bool)preg_match('/(?:youtube\.com\/(?:watch\?v=|shorts\/|embed\/)|youtu\.be\/)/i', $mediaUrl);
        $isVimeo = (bool)preg_match('/vimeo\.com\//i', $mediaUrl);
        $videoEmbed = '';
        if ($isYoutube) {
            if (preg_match('~youtu\.be/([A-Za-z0-9_-]{6,})~', $mediaUrl, $ym)) $videoEmbed = 'https://www.youtube-nocookie.com/embed/'.$ym[1].'?autoplay=1';
            elseif (preg_match('~youtube\.com/(?:watch\?v=|shorts/|embed/)([A-Za-z0-9_-]{6,})~', $mediaUrl, $ym)) $videoEmbed = 'https://www.youtube-nocookie.com/embed/'.$ym[1].'?autoplay=1';
        } elseif ($isVimeo && preg_match('~vimeo\.com/(?:video/)?([0-9]+)~', $mediaUrl, $vm)) {
            $videoEmbed = 'https://player.vimeo.com/video/'.$vm[1].'?autoplay=1';
        }
        $inlineVideo = $videoUrl !== '' ? $videoUrl : (($isDirectVideo || $isYoutube || $isVimeo) ? $mediaUrl : '');
        $inlineIsDirect = $inlineVideo !== '' && (bool)preg_match('/\.(mp4|webm|ogg|mov)$/i', strtolower(parse_url($inlineVideo, PHP_URL_PATH) ?? ''));
        $inlineEmbed = '';
        if ($inlineVideo !== '' && !$inlineIsDirect) {
            if (preg_match('~(?:youtube\.com/(?:watch\?v=|shorts/|embed/)|youtu\.be/)~i', $inlineVideo)) {
                if (preg_match('~youtu\.be/([A-Za-z0-9_-]{6,})~', $inlineVideo, $ym)) $inlineEmbed = 'https://www.youtube-nocookie.com/embed/'.$ym[1].'?autoplay=1';
                elseif (preg_match('~youtube\.com/(?:watch\?v=|shorts/|embed/)([A-Za-z0-9_-]{6,})~', $inlineVideo, $ym)) $inlineEmbed = 'https://www.youtube-nocookie.com/embed/'.$ym[1].'?autoplay=1';
            } elseif (preg_match('~vimeo\.com/(?:video/)?([0-9]+)~', $inlineVideo, $vm)) $inlineEmbed = 'https://player.vimeo.com/video/'.$vm[1].'?autoplay=1';
        }
        $posterUrl = $imageUrl !== '' ? $imageUrl : (($inlineVideo === '' ? $mediaUrl : ''));
        ?>
        <?php if ($posterUrl !== ''): ?>
            <img class="product-media xt-inline-poster" src="<?= h($posterUrl) ?>" alt="<?= h($product['name']) ?>" loading="lazy">
        <?php else: ?>
            <div class="product-media-link">🔑</div>
        <?php endif; ?>
        <?php if ($inlineVideo !== ''): ?>
            <button type="button" class="xt-inline-play" aria-label="Play <?= h($product['name']) ?> video" data-video="<?= h($inlineVideo) ?>" data-embed="<?= h($inlineEmbed) ?>">▶</button>
        <?php endif; ?>
        <?php $topLeftTags = array_values(array_intersect(['SAFE','RISK','UPDATING','TESTING'], array_map('strtoupper', array_filter(array_map('trim', explode(',', (string)($productLinks['STATUS_TAGS'] ?? ''))))))); ?>
        <?php if ($topLeftTags): ?><div class="xt-product-tags" aria-label="Product status badges"><?php foreach ($topLeftTags as $tag): ?><span class="xt-product-tag tag-<?= strtolower(h($tag)) ?>"><?= h($tag) ?></span><?php endforeach; ?></div><?php endif; ?>
        <div class="xt-product-status <?= ((int)($product['live_status'] ?? 1) === 1) ? 'is-online' : 'is-maintenance' ?>" aria-label="<?= ((int)($product['live_status'] ?? 1) === 1) ? 'Online' : 'Maintenance' ?>">
          <span class="xt-status-dot"></span>
          <span><?= ((int)($product['live_status'] ?? 1) === 1) ? 'ONLINE' : 'MAINTENANCE' ?></span>
          <?php if ((int)($product['live_status'] ?? 1) !== 1): ?><span class="xt-maintenance-countdown" aria-label="Maintenance countdown" data-countdown-start="<?= (int)(microtime(true) * 1000) ?>">3</span><?php endif; ?>
        </div>
    </div>
    <style>
      .xt-inline-media{position:relative;overflow:hidden;aspect-ratio:16/9;background:#000}
      .xt-inline-media .xt-inline-poster{width:100%;height:100%;object-fit:cover;display:block}
      .xt-inline-play{position:absolute;left:50%;top:50%;transform:translate(-50%,-50%);width:64px;height:64px;border-radius:50%;border:2px solid rgba(255,255,255,.9);background:rgba(0,0,0,.68);color:#fff;font-size:27px;display:flex;align-items:center;justify-content:center;cursor:pointer;box-shadow:0 0 24px rgba(0,220,255,.45)}
      .xt-inline-media video,.xt-inline-media iframe{position:absolute;inset:0;width:100%;height:100%;border:0;display:block;object-fit:contain;background:#000}
    </style>
    <script>
    document.addEventListener('click', function(ev){
      const btn = ev.target.closest('.xt-inline-play');
      if(!btn) return;
      const wrap = btn.closest('[data-inline-media]');
      if(!wrap || wrap.dataset.playing === '1') return;
      const url = btn.getAttribute('data-video') || '';
      const embed = btn.getAttribute('data-embed') || '';
      if(!url) return;
      wrap.dataset.playing = '1';
      const media = embed ? document.createElement('iframe') : document.createElement('video');
      if(embed){ media.src = embed; media.allow='autoplay; fullscreen; picture-in-picture'; media.allowFullscreen=true; media.title='Product video'; }
      else { media.src=url; media.controls=true; media.playsInline=true; media.preload='metadata'; media.autoplay=true; }
      media.setAttribute('aria-label','Product video');
      wrap.querySelector('.xt-inline-poster')?.remove();
      btn.remove();
      wrap.appendChild(media);
      if(!embed){ const p=media.play(); if(p && p.catch) p.catch(()=>{media.controls=true;}); }
    });
    </script>

    <h2 class="product-name">
        <?= h($product['name']) ?>
    </h2>
    <div class="product-badges">
        <span class="product-badge type-badge"><?= h(strtoupper((string)($product['category'] ?? 'PRO'))) ?></span>
        <?php if (strtoupper((string)($product['platform'] ?? 'ALL')) !== 'ALL'): ?>
            <span class="product-badge platform-badge"><?= h((function($v){$m=['ANDROID_NONROOT'=>'Android Non Root','IPHONE'=>'Apple iOS Product','ANDROID_ROOT'=>'Android Root','PC_PANEL_FF'=>'PC PANEL FF','LIVE_KEY'=>'LIVE KEYS'];$parts=array_map('trim',explode(',',strtoupper((string)$v)));return implode(' + ',array_map(static fn($p)=>$m[$p]??$p,$parts));})(strtoupper((string)$product['platform'])) ) ?></span>
        <?php endif; ?>
        <?php if ((int)($product['live_status'] ?? 1) === 1): ?>
            <span class="product-badge live-badge">● LIVE</span>
        <?php endif; ?>
    </div>


        <?php
      $featureCards = [];
      foreach (preg_split('/\R/', $productDescription) ?: [] as $featureLine) {
        if (preg_match('/^\s*\[FEATURE_ON\]\s*(.*?)\s*$/i', $featureLine, $fm) && trim($fm[1]) !== '') $featureCards[] = trim($fm[1]);
      }
      $visibleDescription = trim((string)preg_replace('/^\s*\[(UPDATE|SETUP|LINK|MEDIA|IMAGE|VIDEO|GROUP|SETUP_LABEL|GROUP_LABEL|EXTRA1|EXTRA1_LABEL|EXTRA1_ON|EXTRA2|EXTRA2_LABEL|EXTRA2_ON|FEATURE_ON|FEATURE_OFF|STATUS_TAGS)\]\s*.*?\s*$/im', '', $productDescription));
    ?>
    <?php if ($featureCards): ?>
      <div class="xt-feature-cards"><?php foreach ($featureCards as $featureText): ?><span class="xt-feature-card"><?= h($featureText) ?></span><?php endforeach; ?></div>
    <?php endif; ?>
    <?php if ($visibleDescription !== ''): ?><div class="product-description"><?= h($visibleDescription) ?></div><?php endif; ?>
    <style>.xt-feature-cards{display:flex;flex-wrap:wrap;gap:8px;justify-content:center;margin:12px 0 15px}.xt-feature-card{display:inline-flex;align-items:center;justify-content:center;padding:9px 13px;border-radius:12px;border:1px solid rgba(34,211,238,.28);background:linear-gradient(135deg,rgba(8,45,61,.94),rgba(17,35,54,.96));color:#50c9ff;font-weight:800;font-size:13px;text-align:center;max-width:100%;overflow-wrap:anywhere;box-shadow:inset 0 1px rgba(255,255,255,.05)}</style>
    <?php
    $setupUrl = ''; $groupUrl = ''; $setupLabel = '🎥 Setup Video'; $groupLabel = '👥 Join Product Group';
    foreach ($productLinks as $pl) {
        if (!is_array($pl)) continue;
        if (($pl['type'] ?? '') === 'SETUP' && $setupUrl === '') $setupUrl = $pl['url'];
        if (($pl['type'] ?? '') === 'MEDIA' && $setupUrl === '') $setupUrl = $pl['url'];
        if (($pl['type'] ?? '') === 'GROUP') $groupUrl = $pl['url'];
    }
    $setupLabel = !empty($productLinks['SETUP_LABEL']) ? $productLinks['SETUP_LABEL'] : $setupLabel;
    $groupLabel = !empty($productLinks['GROUP_LABEL']) ? $productLinks['GROUP_LABEL'] : $groupLabel;
    $extra1Url = ''; $extra2Url = '';
    foreach ($productLinks as $pl) { if (is_array($pl) && ($pl['type'] ?? '') === 'EXTRA1') $extra1Url = $pl['url']; if (is_array($pl) && ($pl['type'] ?? '') === 'EXTRA2') $extra2Url = $pl['url']; }
    $extra1Label = !empty($productLinks['EXTRA1_LABEL']) ? $productLinks['EXTRA1_LABEL'] : '📁 Download File';
    $extra2Label = !empty($productLinks['EXTRA2_LABEL']) ? $productLinks['EXTRA2_LABEL'] : '🔗 More Info';
    $extra1On = (($productLinks['EXTRA1_ON'] ?? '0') === '1');
    $extra2On = (($productLinks['EXTRA2_ON'] ?? '0') === '1');
    ?>
    <div class="product-action-row">
        <?php if ($setupUrl !== ''): ?><a class="product-action setup-action" href="<?= h($setupUrl) ?>" target="_blank" rel="noopener noreferrer" data-auto-button-label="1" data-original-button-label="<?= h($setupLabel) ?>"><?= h($setupLabel) ?></a><?php else: ?><span class="product-action setup-action disabled" data-auto-button-label="1" data-original-button-label="<?= h($setupLabel) ?>"><?= h($setupLabel) ?></span><?php endif; ?>
        <?php if ($groupUrl !== ''): ?><a class="product-action group-action" href="<?= h($groupUrl) ?>" target="_blank" rel="noopener noreferrer" data-auto-button-label="1" data-original-button-label="<?= h($groupLabel) ?>"><?= h($groupLabel) ?></a><?php else: ?><span class="product-action group-action disabled" data-auto-button-label="1" data-original-button-label="<?= h($groupLabel) ?>"><?= h($groupLabel) ?></span><?php endif; ?>
        <?php if ($extra1On): ?><?php if ($extra1Url !== ''): ?><a class="product-action extra1-action" href="<?= h($extra1Url) ?>" target="_blank" rel="noopener noreferrer" data-auto-button-label="1" data-original-button-label="<?= h($extra1Label) ?>"><?= h($extra1Label) ?></a><?php else: ?><span class="product-action extra1-action disabled" title="Add a link in Admin Product Editor" data-auto-button-label="1" data-original-button-label="<?= h($extra1Label) ?>"><?= h($extra1Label) ?></span><?php endif; ?><?php endif; ?>
        <?php if ($extra2On): ?><?php if ($extra2Url !== ''): ?><a class="product-action extra2-action" href="<?= h($extra2Url) ?>" target="_blank" rel="noopener noreferrer" data-auto-button-label="1" data-original-button-label="<?= h($extra2Label) ?>"><?= h($extra2Label) ?></a><?php else: ?><span class="product-action extra2-action disabled" title="Add a link in Admin Product Editor" data-auto-button-label="1" data-original-button-label="<?= h($extra2Label) ?>"><?= h($extra2Label) ?></span><?php endif; ?><?php endif; ?>
    </div>


    <?php if (!$productPlans): ?>

        <div class="empty">

            <div class="empty-title">
                No plans available
            </div>

        </div>

    <?php else: ?>

    <button type="button" class="xt-purchase-toggle <?= ((int)($product['live_status'] ?? 1) !== 1) ? 'is-maintenance-purchase' : '' ?>" aria-expanded="false" data-maintenance="<?= ((int)($product['live_status'] ?? 1) !== 1) ? '1' : '0' ?>" onclick="requestProductPurchase(this)"><?php if ((int)($product['live_status'] ?? 1) !== 1): ?><span>MAINTENANCE</span><?php else: ?>PURCHASE KEY 🔑<?php endif; ?></button>

    <div class="plan-list" hidden>


    <?php foreach ($productPlans as $plan): ?>

    <?php

    $planId =
        (int)$plan['id'];

    $duration =
        (int)$plan['duration_days'];

    $label =
        trim((string)$plan['duration_label']);

    if ($label === '') {
        $label = $duration . ' Days';
    }

    $originalPrice = (float)$plan['price'];
    $price = $originalPrice * (1 - $productResellerDiscount / 100);

    $available =
        (int)$plan['available_keys'];

    $hasStock =
        $available > 0;

    ?>

    <div
        class="plan <?= $hasStock ? '' : 'out' ?>"
        data-plan-type="<?= h(strtoupper((string)($plan['plan_type'] ?? 'PRO'))) ?>"
        data-plan-id="<?= $planId ?>"
        data-price="<?= h($price) ?>"
        data-stock="<?= $available ?>"
        role="button" tabindex="0" onclick="selectPlan(this); event.stopPropagation();" onkeydown="if(event.key==='Enter'||event.key===' '){event.preventDefault();selectPlan(this);}"
    >

        <div class="plan-row">
            <div class="plan-type-pill <?= strtolower((string)($plan['plan_type'] ?? 'PRO'))==='basic'?'basic':(strtolower((string)($plan['plan_type'] ?? 'PRO'))==='normal'?'normal':'pro') ?>"><?= h(strtoupper((string)($plan['plan_type'] ?? 'PRO'))) ?></div>
            <div class="plan-duration">
                <?= h($label) ?>
            </div>

            <div class="plan-price">
                <?php if ($userRole === 'reseller' && $productResellerDiscount > 0): ?><span style="display:block;font-size:11px;color:var(--xt-muted);text-decoration:line-through;font-weight:700"><span data-currency-amount="<?=h($originalPrice)?>"><?=h(number_format($originalPrice,2))?></span></span><?php endif; ?>
                <span data-currency-amount="<?=h($price)?>"><?=h(number_format($price,2))?></span>
            </div>

        </div>


        <div class="plan-stock">

        <?php if ($hasStock): ?>

            <?= $available ?> key(s) available

        <?php else: ?>

            Out of stock

        <?php endif; ?>

        </div>

    </div>

    <?php endforeach; ?>


    </div>


    <div class="buy-area" hidden>


        <div class="quantity">

            <button
                type="button"
                class="qty-btn"
                onclick="event.stopPropagation(); changeQty(this, -1)"
            >
                −
            </button>


            <div class="qty-number">
                1
            </div>


            <button
                type="button"
                class="qty-btn"
                onclick="event.stopPropagation(); changeQty(this, 1)"
            >
                +
            </button>

        </div>


        <div class="total">

            Total:
            <strong class="total-value">
                Select a plan
            </strong>

        </div>


        <button
            type="button"
            class="buy-btn"
            onclick="event.stopPropagation(); buyProduct(this)"
        >
            BUY / CONFIRM
        </button>


    </div>


    <?php endif; ?>


</section>

<?php endforeach; ?>


<?php endif; ?>


</main>


<!-- -------------------------------------------------------
     CONFIRM MODAL
-------------------------------------------------------- -->

<div
    class="modal"
    id="confirmModal"
>

    <div class="modal-box">

        <div class="modal-title">
            Confirm Purchase
        </div>

        <div
            class="modal-text"
            id="confirmText"
            aria-live="polite"
        ></div>


        <div class="modal-actions">

            <button
                type="button"
                class="modal-btn close-btn"
                onclick="closeModal()"
            >
                Cancel
            </button>

            <button
                type="button"
                class="modal-btn confirm-btn"
                id="confirmBuy"
            >
                Confirm
            </button>

        </div>

    </div>

</div>


<!-- -------------------------------------------------------
     BOTTOM NAV
-------------------------------------------------------- -->

<nav class="nav"><a href="store.php" class="active"><span class="nav-ico nav-svg-icon"><img class="xt-nav-image" src="assets/nav-icons/store.png" alt="" aria-hidden="true"></span><span>Store</span></a><a href="my-keys.php"><span class="nav-ico nav-svg-icon"><img class="xt-nav-image" src="assets/nav-icons/keys.png" alt="" aria-hidden="true"></span><span>My Keys</span></a><a href="deposit.php"><span class="nav-ico nav-svg-icon"><img class="xt-nav-image" src="assets/nav-icons/funds.png" alt="" aria-hidden="true"></span><span>Add Funds</span></a><a href="history.php"><span class="nav-ico nav-svg-icon"><img class="xt-nav-image" src="assets/nav-icons/history.png" alt="" aria-hidden="true"></span><span>History</span></a><a href="profile.php"><span class="nav-ico nav-svg-icon"><img class="xt-nav-image" src="assets/nav-icons/profile.png" alt="" aria-hidden="true"></span><span>Profile</span></a></nav>




<script>


function requestProductPurchase(button){
    if(button.dataset.maintenance !== '1'){
        toggleProductPlans(button);
        return;
    }
    let modal=document.getElementById('xt-maintenance-confirm');
    if(!modal){
        modal=document.createElement('div');
        modal.id='xt-maintenance-confirm';
        modal.className='xt-maintenance-overlay';
        modal.innerHTML='<section class="xt-maintenance-dialog" role="dialog" aria-modal="true" aria-labelledby="xt-maintenance-title"><div class="xt-maintenance-icon"><span class="xt-status-dot"></span></div><h2 id="xt-maintenance-title">Product Maintenance</h2><p>This product is currently under maintenance. Do you still want to continue with the purchase?</p><div class="xt-maintenance-actions"><button type="button" class="xt-maintenance-cancel">Cancel</button><button type="button" class="xt-maintenance-continue">Continue</button></div></section>';
        document.body.appendChild(modal);
        modal.addEventListener('click',function(ev){
            if(ev.target===modal || ev.target.closest('.xt-maintenance-cancel')) modal.remove();
            if(ev.target.closest('.xt-maintenance-continue')){
                const target=modal._purchaseButton;
                modal.remove();
                if(target) toggleProductPlans(target);
            }
        });
        document.addEventListener('keydown',function(ev){if(ev.key==='Escape'){const m=document.getElementById('xt-maintenance-confirm');if(m)m.remove();}});
    }
    modal._purchaseButton=button;
    modal.style.display='flex';
}

function toggleProductPlans(button){
    const product = button.closest('.product');
    if(!product) return;
    const list = product.querySelector('.plan-list');
    const buyArea = product.querySelector('.buy-area');
    const opening = !!(list && list.hidden);
    if(list) list.hidden = !opening;
    if(buyArea) buyArea.hidden = !opening;
    button.setAttribute('aria-expanded', opening ? 'true' : 'false');
    button.textContent = opening ? 'HIDE PLANS ▲' : 'PURCHASE KEY 🔑';
    if(opening && list) list.scrollIntoView({behavior:'smooth', block:'nearest'});
}

let selectedPlan = null;
let selectedProduct = null;
let selectedQuantity = 1;


/*
|--------------------------------------------------------------------------
| SELECT PLAN
|--------------------------------------------------------------------------
*/

function selectPlan(planElement){

    if(!planElement){
        return;
    }

    const stock =
        parseInt(
            planElement.dataset.stock || '0',
            10
        );

    if(stock <= 0){
        return;
    }

    const product =
        planElement.closest('.product');

    if(!product){
        return;
    }


    /*
     * Remove selection from ONLY this product.
     */
    product
        .querySelectorAll('.plan')
        .forEach(function(item){

            item.classList.remove('selected');

        });


    planElement.classList.add('selected');


    selectedPlan = {
        id: parseInt(
            planElement.dataset.planId,
            10
        ),

        price: parseFloat(
            planElement.dataset.price
        ),

        stock: stock
    };


    selectedProduct =
        parseInt(
            product.dataset.productId,
            10
        );


    selectedQuantity = 1;


    const quantityElement =
        product.querySelector('.qty-number');

    if(quantityElement){
        quantityElement.textContent = '1';
    }


    updateTotal(product);
}


/*
|--------------------------------------------------------------------------
| QUANTITY
|--------------------------------------------------------------------------
*/

function changeQty(button, amount){

    if(!button){
        return;
    }

    const product =
        button.closest('.product');

    if(!product){
        return;
    }


    const selected =
        product.querySelector('.plan.selected');

    if(!selected){
        return;
    }


    const stock =
        parseInt(
            selected.dataset.stock || '0',
            10
        );


    let current =
        parseInt(
            product
                .querySelector('.qty-number')
                .textContent || '1',
            10
        );


    current += amount;


    if(current < 1){
        current = 1;
    }


    if(stock > 0 && current > stock){
        current = stock;
    }


    product
        .querySelector('.qty-number')
        .textContent = current;


    selectedQuantity = current;


    updateTotal(product);
}


/*
|--------------------------------------------------------------------------
| TOTAL
|--------------------------------------------------------------------------
*/

function updateTotal(product){

    const total =
        product.querySelector('.total-value');

    const selected =
        product.querySelector('.plan.selected');

    if(!selected){

        total.textContent =
            'Select a plan';

        return;
    }


    const price =
        parseFloat(
            selected.dataset.price || '0'
        );


    const quantity =
        parseInt(
            product
                .querySelector('.qty-number')
                .textContent || '1',
            10
        );


    const amount =
        price * quantity;


    total.textContent = window.XtremeCurrency ? window.XtremeCurrency.format(amount) : ('৳' + amount.toFixed(2));
}


/*
|--------------------------------------------------------------------------
| BUY
|--------------------------------------------------------------------------
*/

function buyProduct(button){

    const product =
        button.closest('.product');

    if(!product){
        return;
    }


    const selected =
        product.querySelector('.plan.selected');


    /*
     * THIS fixes:
     * "Please select a plan first"
     */

    if(!selected){

        showModal(
            'Please select a plan first.'
        );

        return;
    }


    const stock =
        parseInt(
            selected.dataset.stock || '0',
            10
        );


    if(stock <= 0){

        showModal(
            'This plan is out of stock.'
        );

        return;
    }


    const planId =
        parseInt(
            selected.dataset.planId,
            10
        );


    const productId =
        parseInt(
            product.dataset.productId,
            10
        );


    const price =
        parseFloat(
            selected.dataset.price || '0'
        );


    const quantity =
        parseInt(
            product
                .querySelector('.qty-number')
                .textContent || '1',
            10
        );


    const total =
        price * quantity;


    selectedProduct =
        productId;

    selectedPlan = {
        id: planId,
        price: price,
        stock: stock
    };

    selectedQuantity =
        quantity;


    const formattedTotal = window.XtremeCurrency ? window.XtremeCurrency.format(total) : ('৳' + total.toLocaleString('en-BD',{minimumFractionDigits:2,maximumFractionDigits:2}));
    const text =
        'You selected ' + quantity + ' license key(s).<br><br>Total: <strong>' + formattedTotal + '</strong>';


    document.getElementById(
        'confirmText'
    ).innerHTML = text;


    document.getElementById(
        'confirmBuy'
    ).onclick = function(){

        /*
         * Send purchase to buy.php
         *
         * product_id
         * plan_id
         * quantity
         */

        const form =
            document.createElement('form');

        form.method =
            'POST';

        form.action =
            'buy.php';


        const fields = {
            csrf: <?= json_encode($buyCsrf) ?>,
            product_id: selectedProduct,
            plan_id: selectedPlan.id,
            quantity: selectedQuantity
        };


        Object.keys(fields).forEach(
            function(name){

                const input =
                    document.createElement(
                        'input'
                    );

                input.type =
                    'hidden';

                input.name =
                    name;

                input.value =
                    fields[name];

                form.appendChild(
                    input
                );
            }
        );


        document.body.appendChild(
            form
        );

        form.submit();
    };


    document.getElementById(
        'confirmModal'
    ).classList.add('show');
}


/*
|--------------------------------------------------------------------------
| MODAL
|--------------------------------------------------------------------------
*/

function showModal(message){

    document.getElementById(
        'confirmText'
    ).textContent = message;


    document.getElementById(
        'confirmBuy'
    ).style.display = 'none';


    document.getElementById(
        'confirmModal'
    ).classList.add('show');
}


function closeModal(){

    document.getElementById(
        'confirmModal'
    ).classList.remove('show');


    document.getElementById(
        'confirmBuy'
    ).style.display = '';
}


/*
|--------------------------------------------------------------------------
| CLICK OUTSIDE MODAL
|--------------------------------------------------------------------------
*/

document.getElementById(
    'confirmModal'
).addEventListener(
    'click',
    function(event){

        if(
            event.target === this
        ){
            closeModal();
        }

    }
);

</script>


<script>
(function(){
 function syncStoreTheme(){
   var t=document.documentElement.getAttribute('data-theme')||'premium';
   document.body.setAttribute('data-store-theme',t);
 }
 document.addEventListener('DOMContentLoaded',syncStoreTheme);
 window.addEventListener('xtreme-theme-change',syncStoreTheme);
 window.addEventListener('storage',function(e){if(e.key==='xtreme_theme')syncStoreTheme();});
})();
</script>
<script>
(function(){
  function syncStoreTheme(){
    var t=document.documentElement.getAttribute('data-theme')||'premium';
    document.body.setAttribute('data-store-theme',t);
  }
  document.addEventListener('DOMContentLoaded',syncStoreTheme);
  window.addEventListener('xtreme-theme-change',syncStoreTheme);
  window.addEventListener('storage',function(e){if(e.key==='xtreme_theme')syncStoreTheme();});
})();
</script>
<script src="background-video.js?v=20261018-starfall2"></script><script id="store-category-filter-js">
(function () {
  'use strict';
  function initStoreCategoryFilters() {
    var buttons = Array.prototype.slice.call(document.querySelectorAll('.store-filters .store-filter[data-filter]'));
    var cards = Array.prototype.slice.call(document.querySelectorAll('.product[data-product-id]'));
    if (!buttons.length || !cards.length) return;

    function canonical(value) {
      var p = String(value || '').trim().toUpperCase().replace(/[\s-]+/g, '_');
      if (['IOS','APPLE','APPLE_IOS','APPLE_IOS_PRODUCT','IPHONE_PRODUCT'].indexOf(p) !== -1) return 'IPHONE';
      if (['ANDROID_NON_ROOT','ANDROID_NONROOTED','ANDROID_NONROOT_PRODUCT'].indexOf(p) !== -1) return 'ANDROID_NONROOT';
      if (['PC','PC_PANEL','PC_FF','PC_PANEL_FF'].indexOf(p) !== -1) return 'PC_PANEL_FF';
      return p;
    }
    function categories(card) {
      var raw = String(card.getAttribute('data-platforms') || card.getAttribute('data-platform') || '').split(',');
      var out = [];
      raw.forEach(function (value) {
        var p = canonical(value);
        if (['ANDROID_NONROOT','IPHONE','ANDROID_ROOT','PC_PANEL_FF'].indexOf(p) !== -1 && out.indexOf(p) === -1) out.push(p);
      });
      if (out.length) return out;
      var text = ((card.querySelector('.product-name') || {}).textContent || '') + ' ' + ((card.querySelector('.platform-badge') || {}).textContent || '');
      text = canonical(text);
      if (/PC[\s_-]*PANEL[\s_-]*FF|PC[\s_-]*PANEL|\bPC\b/.test(text)) out.push('PC_PANEL_FF');
      if (/ANDROID[\s_-]*ROOT/.test(text) && !/NON[\s_-]*ROOT/.test(text)) out.push('ANDROID_ROOT');
      if (/ANDROID[\s_-]*NON[\s_-]*ROOT/.test(text)) out.push('ANDROID_NONROOT');
      if (/APPLE[\s_-]*IOS|IOS[\s_-]*PRODUCT|IPHONE/.test(text)) out.push('IPHONE');
      return out.length ? out : [canonical(card.getAttribute('data-platform'))];
    }
    function hasAvailableKeys(card) {
      return Number(card.getAttribute('data-available') || 0) > 0;
    }
    function escapeStockText(value) {
      return String(value || '').replace(/[&<>"']/g, function(ch) {
        return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[ch];
      });
    }
    function updateCounts() {
      var counts = {
        live: cards.filter(hasAvailableKeys).reduce(function (total, card) { return total + Number(card.getAttribute('data-available') || 0); }, 0),
        all: cards.length,
        ANDROID_NONROOT: cards.filter(function (card) { return categories(card).indexOf('ANDROID_NONROOT') !== -1; }).length,
        IPHONE: cards.filter(function (card) { return categories(card).indexOf('IPHONE') !== -1; }).length,
        ANDROID_ROOT: cards.filter(function (card) { return categories(card).indexOf('ANDROID_ROOT') !== -1; }).length,
        PC_PANEL_FF: cards.filter(function (card) { return categories(card).indexOf('PC_PANEL_FF') !== -1; }).length
      };
      var targets = {
        live: 'count-live', all: 'count-all', ANDROID_NONROOT: 'count-anr',
        IPHONE: 'count-ios', ANDROID_ROOT: 'count-ar', PC_PANEL_FF: 'count-pc'
      };
      Object.keys(targets).forEach(function (key) {
        var target = document.getElementById(targets[key]);
        if (target) target.textContent = String(counts[key] || 0);
      });
    }
    function apply(filter) {
      filter = String(filter || 'all').toLowerCase();
      buttons.forEach(function (button) {
        button.classList.toggle('active', String(button.getAttribute('data-filter')).toLowerCase() === filter);
        button.setAttribute('aria-pressed', String(String(button.getAttribute('data-filter')).toLowerCase() === filter));
      });
      cards.forEach(function (card) {
        var show = filter === 'live'
          ? hasAvailableKeys(card)
          : (filter === 'all' || categories(card).indexOf(canonical(filter)) !== -1);
        card.classList.toggle('filter-hidden', !show);
        card.hidden = !show;
      });
      var stockPanel = document.getElementById('live-key-stock-summary');
      if (filter === 'live') {
        if (!stockPanel) {
          stockPanel = document.createElement('div');
          stockPanel.id = 'live-key-stock-summary';
          stockPanel.style.cssText = 'margin:18px 14px;padding:24px 18px;border:1px solid rgba(74,222,128,.55);border-radius:20px;background:linear-gradient(145deg,rgba(10,45,35,.92),rgba(12,20,34,.96));color:#eafff4;text-align:left;font-weight:900;box-shadow:0 12px 30px rgba(0,0,0,.22)';
          var main = document.querySelector('main.container');
          if (main) main.insertBefore(stockPanel, main.firstChild);
        }
        var stockCards = cards.filter(hasAvailableKeys);
        var liveKeys = stockCards.reduce(function(total, card) {
          return total + Number(card.getAttribute('data-available') || 0);
        }, 0);
        var rows = stockCards.map(function(card) {
          var nameNode = card.querySelector('.product-name');
          var name = (nameNode ? nameNode.textContent : 'Product').trim();
          var amount = Number(card.getAttribute('data-available') || 0);
          var maintenance = card.getAttribute('data-live') !== '1';
          return '<div style="display:flex;justify-content:space-between;align-items:center;gap:12px;padding:11px 0;border-top:1px solid rgba(134,239,172,.18)"><span style="min-width:0;overflow-wrap:anywhere">' + escapeStockText(name) + (maintenance ? ' <small style="color:#fca5a5">(MAINTENANCE)</small>' : '') + '</span><strong style="white-space:nowrap;color:#86efac">' + amount + ' keys</strong></div>';
        }).join('');
        stockPanel.innerHTML = '<div style="font-size:20px;color:#86efac;margin-bottom:8px;text-align:center">⚡ LIVE KEYS STOCK</div><div style="font-size:32px;line-height:1.2;text-align:center">' + liveKeys + '</div><div style="font-size:12px;color:#b7d8ca;margin:6px 0 14px;text-align:center">available keys by product, including maintenance products</div>' + (rows || '<div style="text-align:center;color:#b7d8ca">No keys currently available</div>');
        stockPanel.hidden = false;
      } else if (stockPanel) {
        stockPanel.hidden = true;
      }
    }
    buttons.forEach(function (button) {
      button.addEventListener('click', function (event) {
        event.preventDefault();
        event.stopPropagation();
        apply(button.getAttribute('data-filter'));
      });
    });
    var style = document.getElementById('store-category-filter-fix-style');
    if (!style) {
      style = document.createElement('style');
      style.id = 'store-category-filter-fix-style';
      style.textContent = '.product.filter-hidden,.product[hidden]{display:none!important}';
      document.head.appendChild(style);
    }
    updateCounts();
    var active = document.querySelector('.store-filters .store-filter.active[data-filter]');
    apply(active ? active.getAttribute('data-filter') : 'all');
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', initStoreCategoryFilters, { once: true });
  else initStoreCategoryFilters();
})();
</script>
<style id="consolidated-mobile-repair">html{max-width:100%;overflow-x:clip}body{max-width:100%;overflow-x:clip}*,*::before,*::after{box-sizing:border-box}img,video,iframe,canvas,svg{max-width:100%}input,select,textarea,button{max-width:100%;font:inherit}.container,.wrap,.panel,.card,.product,.product-card,.payment-box,.payment-methods,.premium-methods{min-width:0;max-width:100%}.product,.product-card{overflow-wrap:anywhere}.product img,.product-media{object-fit:contain;max-width:100%}.store-filters{max-width:100%;overflow-x:auto;overscroll-behavior-x:contain;scrollbar-width:thin}.store-filter{white-space:normal;line-height:1.25;max-width:82vw;min-width:max-content}.premium-methods .premium-method{grid-template-columns:minmax(46px,58px) minmax(0,1fr)!important;grid-template-rows:auto auto!important;min-height:82px!important;overflow:visible!important}.premium-method .payment-logo{grid-column:1;grid-row:1/3;width:48px!important;height:42px!important;object-fit:cover!important}.premium-method .method-name,.premium-method .method-note{min-width:0;white-space:normal!important;overflow-wrap:anywhere}@media(max-width:420px){.premium-methods .premium-method{padding:10px!important;gap:5px 8px!important}.premium-method .method-name{font-size:13px!important}.premium-method .method-note{font-size:10px!important}.container,.wrap{padding-left:10px!important;padding-right:10px!important}.store-filters{padding-left:10px!important;padding-right:10px!important}}</style>

<style id="xt-premium-product-presentation">
/* XTREME TITAN product presentation: neon poster, readable details, clean plan selection. */
.product{position:relative!important;isolation:isolate!important;overflow:hidden!important;border:1px solid rgba(76,213,255,.24)!important;border-radius:25px!important;padding:14px!important;margin:18px 0!important;background:linear-gradient(145deg,rgba(11,18,33,.98),rgba(8,12,24,.98))!important;box-shadow:0 16px 46px rgba(0,0,0,.28),inset 0 1px 0 rgba(255,255,255,.045)!important}
.product:before{content:"";position:absolute;inset:0 0 auto;height:3px;background:linear-gradient(90deg,#12d8ff,#a855f7,#ff35d3,#12d8ff);background-size:220% 100%;animation:xt-product-edge 7s linear infinite;pointer-events:none;z-index:0}
.product>*{position:relative;z-index:1;min-width:0}
.product-image{width:100%!important;max-width:100%!important;aspect-ratio:16/9!important;min-height:0!important;max-height:none!important;display:flex!important;align-items:center!important;justify-content:center!important;overflow:hidden!important;border-radius:18px!important;background:radial-gradient(circle at 50% 0%,rgba(136,40,255,.18),transparent 55%),#080b15!important;border:1px solid rgba(190,100,255,.28)!important;box-shadow:0 0 24px rgba(124,58,237,.12)!important}
.product-image .product-media,.product-image img,.product-image video,.product-image iframe{display:block!important;width:100%!important;height:100%!important;max-width:100%!important;max-height:100%!important;aspect-ratio:16/9!important;object-fit:cover!important;border:0!important;border-radius:0!important}
.product-name{font-size:clamp(20px,5vw,28px)!important;line-height:1.18!important;font-weight:950!important;letter-spacing:.025em!important;overflow-wrap:anywhere!important;margin:18px 2px 10px!important;color:#f7f9ff!important;text-shadow:0 0 18px rgba(147,51,234,.22)!important}
.product-badges{display:flex!important;flex-wrap:wrap!important;gap:7px!important;margin:8px 0 13px!important}
.product-badge{max-width:100%!important;border-radius:999px!important;padding:6px 10px!important;font-size:10px!important;line-height:1.2!important;font-weight:900!important;letter-spacing:.06em!important;overflow-wrap:anywhere!important}
.product-description{white-space:pre-line!important;overflow-wrap:anywhere!important;line-height:1.65!important;color:#d5dfef!important;font-size:14px!important;background:linear-gradient(135deg,rgba(12,28,45,.85),rgba(15,18,36,.75))!important;border:1px solid rgba(34,211,238,.18)!important;border-radius:16px!important;padding:14px!important;margin:12px 0 15px!important}
.product-action-row{display:grid!important;grid-template-columns:repeat(2,minmax(0,1fr))!important;gap:9px!important;margin:12px 0 16px!important}
.product-action-row .product-action{width:100%!important;min-width:0!important;min-height:44px!important;padding:10px 8px!important;text-align:center!important;white-space:normal!important;overflow-wrap:anywhere!important;border-radius:13px!important;border:1px solid rgba(34,211,238,.25)!important;background:rgba(8,31,47,.8)!important;color:#67d8ff!important;font-size:12px!important;font-weight:850!important;line-height:1.3!important}
.product-action-row .product-action.disabled{opacity:.55!important}
.product-extra-video{margin:12px 0!important;border:1px solid rgba(168,85,247,.35)!important;box-shadow:0 8px 25px rgba(0,0,0,.22)!important}
.product-extra-video video,.product-extra-video iframe{width:100%!important;max-width:100%!important;aspect-ratio:16/9!important;max-height:320px!important;object-fit:cover!important;border:0!important}
.plan-list{display:grid!important;grid-template-columns:minmax(0,1fr)!important;gap:10px!important;margin:14px 0!important}
.plan{min-width:0!important;border:1px solid rgba(66,190,255,.25)!important;border-radius:16px!important;background:linear-gradient(110deg,rgba(11,29,47,.98),rgba(21,17,40,.98))!important;padding:13px!important;transition:border-color .18s ease,box-shadow .18s ease,transform .18s ease!important}
.plan:focus,.plan:hover,.plan.selected{border-color:#20d9ff!important;box-shadow:0 0 0 2px rgba(32,217,255,.12),0 10px 28px rgba(0,0,0,.2)!important;outline:none!important}
.plan-row{display:grid!important;grid-template-columns:auto minmax(0,1fr) auto!important;align-items:center!important;gap:9px!important}
.plan-duration{min-width:0!important;overflow-wrap:anywhere!important;font-weight:850!important;color:#f4f7ff!important}
.plan-price{font-size:clamp(16px,4vw,21px)!important;font-weight:950!important;color:#55e7b0!important;white-space:nowrap!important}
.plan-stock{margin-top:7px!important;color:#9caec5!important;font-size:12px!important;line-height:1.45!important}
.product .buy-btn,.product .product-action.buy-btn{width:100%!important;min-height:58px!important;margin-top:12px!important;border-radius:16px!important;background:linear-gradient(100deg,#08b9ec,#377cf5,#13c9a2)!important;color:#fff!important;font-size:17px!important;letter-spacing:.06em!important;font-weight:950!important;box-shadow:0 12px 30px rgba(13,174,226,.22)!important}
@keyframes xt-product-edge{from{background-position:0 0}to{background-position:220% 0}}
@media(max-width:480px){.product{padding:10px!important;border-radius:21px!important}.product-image{border-radius:15px!important}.product-description{font-size:13px!important;padding:12px!important}.product-action-row{gap:7px!important}.product-action-row .product-action{font-size:11px!important}.plan{padding:11px!important}.plan-row{grid-template-columns:auto minmax(0,1fr) auto!important;gap:7px!important}}
@media(prefers-reduced-motion:reduce){.product:before{animation:none!important}}
</style>


<style id="xt-dashboard-neon-final-v34">
/* Dashboard visual-only corrections: preserve links, balance and warning logic. */
.store-dashboard{max-width:920px!important;margin:0 auto!important;padding:12px 10px 100px!important;color:#f5f4ff!important}
.store-dashboard .dashboard-balance{position:relative!important;overflow:hidden!important;padding:18px 16px 16px!important;border:1.5px solid rgba(255,49,177,.82)!important;border-radius:23px!important;background:radial-gradient(ellipse at 92% 12%,rgba(30,87,255,.16),transparent 43%),linear-gradient(145deg,rgba(11,16,42,.98),rgba(29,13,45,.98))!important;box-shadow:0 0 0 1px rgba(255,42,172,.12),0 0 24px rgba(239,40,180,.14),inset 0 1px 0 rgba(255,255,255,.07)!important}
.store-dashboard .dashboard-balance:before{content:""!important;float:left!important;font-size:44px!important;line-height:1.15!important;margin:22px 14px 8px 0!important;filter:drop-shadow(0 0 11px rgba(0,190,255,.48))!important}
.store-dashboard .dashboard-label{color:#b9c5ff!important;font-size:12px!important;letter-spacing:.14em!important;font-weight:900!important}
.store-dashboard .dashboard-balance-value{color:#43f2bd!important;font-size:clamp(32px,8vw,46px)!important;font-weight:1000!important;line-height:1.12!important;text-shadow:0 0 22px rgba(57,229,177,.25)!important;margin:8px 0 14px!important}
.store-dashboard .dashboard-topup{display:inline-flex!important;align-items:center!important;justify-content:center!important;min-height:44px!important;height:auto!important;padding:0 18px!important;border-radius:15px!important;border:1px solid rgba(79,231,255,.85)!important;background:linear-gradient(105deg,#13c8f4 0%,#526bff 52%,#f22b9e 100%)!important;color:#fff!important;font-size:13px!important;font-weight:950!important;box-shadow:0 7px 22px rgba(20,160,255,.2)!important}
.store-dashboard .xt-purchase-warning{clear:both!important;display:block!important;margin-top:14px!important;padding:12px 14px!important;border:1.5px solid #ff438d!important;border-radius:17px!important;background:linear-gradient(110deg,rgba(103,12,52,.55),rgba(50,10,47,.62))!important;color:#ffe6f0!important;font-size:13px!important;font-weight:850!important;line-height:1.5!important;box-shadow:0 0 15px rgba(255,45,137,.1)!important}
.store-dashboard .dashboard-stats{display:grid!important;grid-template-columns:repeat(2,minmax(0,1fr))!important;gap:10px!important;margin:14px 0!important}
.store-dashboard .dashboard-stat{position:relative!important;min-width:0!important;min-height:86px!important;box-sizing:border-box!important;padding:14px 10px 12px 52px!important;border-radius:19px!important;border:1px solid rgba(119,112,255,.58)!important;background:linear-gradient(145deg,rgba(15,20,49,.98),rgba(28,17,49,.96))!important;box-shadow:inset 0 1px 0 rgba(255,255,255,.04)!important;overflow:hidden!important}
.store-dashboard .dashboard-stat:before{left:10px!important;width:34px!important;height:34px!important;border-radius:50%!important;box-shadow:0 0 12px rgba(90,90,255,.12)!important}
.store-dashboard .dashboard-stat:nth-child(1){border-color:rgba(22,211,154,.48)!important}.store-dashboard .dashboard-stat:nth-child(1):before{content:"✓"!important;color:#8affcf!important;background:linear-gradient(145deg,rgba(0,255,128,.35),rgba(0,145,91,.15))!important;border-color:rgba(0,255,145,.7)!important}
.store-dashboard .dashboard-stat:nth-child(2){border-color:rgba(238,65,197,.5)!important}.store-dashboard .dashboard-stat:nth-child(2):before{content:"🛒"!important;color:#fff!important;background:linear-gradient(145deg,rgba(255,40,190,.3),rgba(98,0,180,.2))!important;border-color:rgba(255,65,194,.65)!important}
.store-dashboard .dashboard-stat:nth-child(3){border-color:rgba(245,180,50,.48)!important}.store-dashboard .dashboard-stat:nth-child(3):before{content:"🔑"!important;background:linear-gradient(145deg,rgba(255,186,40,.3),rgba(154,83,0,.2))!important;border-color:rgba(255,190,67,.65)!important}
.store-dashboard .dashboard-stat:nth-child(4){border-color:rgba(183,80,255,.52)!important}.store-dashboard .dashboard-stat:nth-child(4):before{content:"📦"!important;background:linear-gradient(145deg,rgba(177,64,255,.3),rgba(69,0,180,.2))!important;border-color:rgba(190,80,255,.65)!important}
.store-dashboard .dashboard-stat span{display:block!important;font-size:10px!important;line-height:1.35!important;color:#c2cbff!important;font-weight:850!important}
.store-dashboard .dashboard-stat strong{display:block!important;margin-top:4px!important;font-size:20px!important;line-height:1.15!important;font-weight:1000!important;white-space:normal!important;overflow-wrap:anywhere!important}
.store-dashboard .dashboard-stat:nth-child(1) strong{color:#35eab0!important}.store-dashboard .dashboard-stat:nth-child(2) strong{color:#ff6da9!important}.store-dashboard .dashboard-stat:nth-child(3) strong{color:#c29aff!important}
.store-dashboard .dashboard-quick{padding:12px!important;margin:14px 0!important;border:1px solid rgba(111,114,255,.6)!important;border-radius:20px!important;background:linear-gradient(145deg,rgba(9,18,43,.98),rgba(27,14,48,.98))!important;box-shadow:inset 0 1px 0 rgba(255,255,255,.05)!important}
.store-dashboard .dashboard-quick-title{font-size:16px!important;line-height:1.25!important;margin:0 0 9px!important;color:#f5f5ff!important;font-weight:1000!important}
.store-dashboard .dashboard-actions{display:grid!important;grid-template-columns:repeat(2,minmax(0,1fr))!important;gap:7px!important;margin-top:8px!important}
.store-dashboard .dashboard-actions a{display:flex!important;align-items:center!important;justify-content:flex-start!important;gap:8px!important;min-width:0!important;min-height:58px!important;height:auto!important;box-sizing:border-box!important;padding:9px 9px!important;border-radius:15px!important;color:#fff!important;font-size:13px!important;font-weight:950!important;line-height:1.15!important;text-decoration:none!important;box-shadow:inset 0 1px 0 rgba(255,255,255,.12)!important;overflow:hidden!important}
.store-dashboard .dashboard-actions a:nth-child(1){background:linear-gradient(120deg,rgba(0,156,99,.96),rgba(0,55,60,.98))!important;border:1px solid #00e4a2!important;box-shadow:0 0 13px rgba(0,225,160,.13)!important}
.store-dashboard .dashboard-actions a:nth-child(2){background:linear-gradient(120deg,rgba(0,117,230,.96),rgba(13,33,91,.98))!important;border:1px solid #18bfff!important;box-shadow:0 0 13px rgba(24,191,255,.13)!important}
.store-dashboard .dashboard-actions a:nth-child(3){background:linear-gradient(120deg,rgba(183,105,0,.96),rgba(78,34,16,.98))!important;border:1px solid #ffbd43!important;box-shadow:0 0 13px rgba(255,189,67,.11)!important}
.store-dashboard .dashboard-actions a:nth-child(4){background:linear-gradient(120deg,rgba(128,0,196,.96),rgba(60,13,94,.98))!important;border:1px solid #e34dff!important;box-shadow:0 0 13px rgba(227,77,255,.12)!important}
.store-dashboard .dashboard-actions .qa-icon{flex:0 0 28px!important;width:28px!important;font-size:26px!important;line-height:1!important;text-align:center!important;filter:drop-shadow(0 0 6px rgba(255,255,255,.18))!important}
.store-dashboard .dashboard-actions .qa-label{flex:1 1 auto!important;min-width:0!important;font-size:12px!important;white-space:normal!important;overflow-wrap:anywhere!important}
.store-dashboard .dashboard-actions .qa-arrow{flex:0 0 24px!important;width:24px!important;height:24px!important;display:inline-flex!important;align-items:center!important;justify-content:center!important;border:1.5px solid rgba(255,255,255,.92)!important;border-radius:50%!important;font-size:21px!important;line-height:1!important;color:#fff!important}
/* The five-item bottom navigation remains fixed, with a compact neon active tile. */
.nav{position:fixed!important;left:0!important;right:0!important;bottom:0!important;width:100%!important;height:78px!important;min-height:78px!important;box-sizing:border-box!important;padding:5px 7px!important;margin:0!important;display:grid!important;grid-template-columns:repeat(5,minmax(0,1fr))!important;gap:4px!important;overflow:hidden!important;background:linear-gradient(180deg,rgba(16,12,35,.98),rgba(7,7,22,.99))!important;border:1px solid rgba(153,87,201,.45)!important;border-bottom:0!important;border-radius:20px 20px 0 0!important;box-shadow:0 -8px 30px rgba(0,0,0,.32),0 0 20px rgba(160,65,255,.08)!important;z-index:99999!important}
.nav>a,.nav>a.active{display:flex!important;min-width:0!important;width:100%!important;height:66px!important;min-height:66px!important;box-sizing:border-box!important;margin:0!important;padding:3px 1px!important;flex-direction:column!important;align-items:center!important;justify-content:center!important;gap:2px!important;border:1px solid transparent!important;border-radius:14px!important;background:transparent!important;color:#b5b8e9!important;text-decoration:none!important;font-size:10px!important;font-weight:900!important;line-height:1.05!important;white-space:nowrap!important;overflow:hidden!important}
.nav .emoji{display:block!important;height:29px!important;font-size:26px!important;line-height:29px!important;filter:drop-shadow(0 0 6px rgba(55,174,255,.2))!important}
.nav>a:nth-child(1) .emoji{filter:drop-shadow(0 0 7px rgba(255,60,205,.35))!important}.nav>a:nth-child(2) .emoji{filter:drop-shadow(0 0 7px rgba(255,190,55,.35))!important}.nav>a:nth-child(3) .emoji{filter:drop-shadow(0 0 7px rgba(20,190,255,.35))!important}.nav>a:nth-child(4) .emoji{filter:drop-shadow(0 0 7px rgba(255,183,45,.35))!important}.nav>a:nth-child(5) .emoji{filter:drop-shadow(0 0 7px rgba(166,78,255,.35))!important}
.nav>a.active{background:linear-gradient(145deg,rgba(235,0,146,.23),rgba(85,30,122,.22))!important;border-color:rgba(242,56,202,.68)!important;color:#ff75db!important;box-shadow:0 0 18px rgba(226,42,190,.13),inset 0 1px 0 rgba(255,255,255,.06)!important}
@media(max-width:390px){.store-dashboard .dashboard-balance{padding:16px 12px!important}.store-dashboard .dashboard-stat{padding-left:48px!important;min-height:82px!important}.store-dashboard .dashboard-stat:before{left:8px!important;width:31px!important;height:31px!important}.store-dashboard .dashboard-actions a{gap:6px!important;padding:8px 7px!important;min-height:54px!important}.store-dashboard .dashboard-actions .qa-icon{flex-basis:25px!important;width:25px!important;font-size:23px!important}.store-dashboard .dashboard-actions .qa-label{font-size:11px!important}.store-dashboard .dashboard-actions .qa-arrow{flex-basis:22px!important;width:22px!important;height:22px!important;font-size:19px!important}}
</style>


<style id="xt-dashboard-reference-match-v36">
/* Dashboard layout tuned to the supplied neon mobile reference; links/data remain unchanged. */
.store-dashboard{width:100%!important;max-width:940px!important;margin:0 auto!important;padding:16px 14px 8px!important;box-sizing:border-box!important}
.store-dashboard .dashboard-balance{display:grid!important;grid-template-columns:minmax(0,1fr) auto!important;align-items:center!important;column-gap:14px!important;row-gap:8px!important;position:relative!important;overflow:hidden!important;min-width:0!important;padding:20px 18px 17px 30px!important;margin-bottom:14px!important;border:1.5px solid rgba(255,48,174,.88)!important;border-radius:25px!important;background:radial-gradient(ellipse at 90% 10%,rgba(18,174,255,.16),transparent 42%),linear-gradient(145deg,#080f22 0%,#10102a 55%,#160d2b 100%)!important;box-shadow:0 0 0 2px rgba(65,105,255,.12),0 0 24px rgba(255,35,169,.14),inset 0 1px 0 rgba(255,255,255,.08)!important}
.store-dashboard .dashboard-label{grid-column:1/-1!important;font-size:12px!important;letter-spacing:.16em!important;color:#aab9e8!important;margin:0!important}
.store-dashboard .dashboard-balance:before{content:""!important;position:absolute!important;left:27px!important;top:55px!important;float:none!important;margin:0!important;font-size:42px!important;line-height:1.15!important;filter:drop-shadow(0 0 12px rgba(0,190,255,.45))!important}
.store-dashboard .dashboard-balance-value{grid-column:1!important;grid-row:auto!important;min-width:0!important;margin:0 0 0 82px!important;font-size:clamp(32px,8vw,46px)!important;line-height:1.1!important;font-weight:1000!important;color:#43f2bd!important;text-shadow:0 0 22px rgba(57,229,177,.25)!important;overflow-wrap:anywhere!important}
.store-dashboard .dashboard-topup{grid-column:2!important;grid-row:2!important;align-self:center!important;min-height:52px!important;height:auto!important;padding:0 22px!important;border:1px solid rgba(255,255,255,.24)!important;border-radius:17px!important;background:linear-gradient(105deg,#09c7f4,#6d66ff 55%,#f329a5)!important;color:#fff!important;font-size:clamp(12px,3.2vw,16px)!important;font-weight:950!important;letter-spacing:.04em!important;white-space:nowrap!important;box-shadow:0 7px 22px rgba(20,160,255,.22)!important}
.store-dashboard .xt-addfunds-banner{grid-column:1/-1!important;grid-row:auto!important;margin:4px 0!important}
.store-dashboard .xt-purchase-warning{grid-column:1/-1!important;grid-row:auto!important;clear:none!important;margin:8px 0 0!important;padding:15px 16px!important;border:1.5px solid #ff3d88!important;border-radius:18px!important;background:linear-gradient(110deg,rgba(103,12,52,.55),rgba(50,10,47,.55))!important;color:#ffe0ec!important;font-size:clamp(12px,3.2vw,15px)!important;font-weight:850!important;line-height:1.5!important;box-shadow:inset 0 1px 0 rgba(255,255,255,.04),0 0 18px rgba(255,45,130,.08)!important}
.store-dashboard .dashboard-stats{display:grid!important;grid-template-columns:repeat(2,minmax(0,1fr))!important;gap:12px!important;margin:14px 0 18px!important}
.store-dashboard .dashboard-stat{position:relative!important;min-width:0!important;min-height:108px!important;padding:18px 12px 14px 76px!important;border:1px solid rgba(100,120,255,.58)!important;border-radius:22px!important;background:radial-gradient(circle at 100% 100%,rgba(68,49,255,.15),transparent 48%),linear-gradient(145deg,rgba(10,20,43,.97),rgba(20,15,42,.97))!important;box-shadow:inset 0 1px 0 rgba(255,255,255,.05),0 10px 25px rgba(0,0,0,.14)!important}
.store-dashboard .dashboard-stat:before{position:absolute!important;left:17px!important;top:50%!important;transform:translateY(-50%)!important;display:grid!important;place-items:center!important;width:48px!important;height:48px!important;border-radius:50%!important;font-size:27px!important;line-height:1!important;background:rgba(40,90,170,.2)!important;border:1px solid rgba(100,150,255,.5)!important;box-shadow:0 0 14px rgba(65,120,255,.14)!important}
.store-dashboard .dashboard-stat:nth-child(1):before{content:"✓"!important;color:#a7ffdc!important;background:linear-gradient(145deg,#00b86a,#005c4b)!important;border-color:#00e99a!important}
.store-dashboard .dashboard-stat:nth-child(2):before{content:"🛒"!important;color:#ffc0f0!important;background:linear-gradient(145deg,#6d1c8b,#28134e)!important;border-color:#e34dff!important}
.store-dashboard .dashboard-stat:nth-child(3):before{content:"🔑"!important;color:#ffe78a!important;background:linear-gradient(145deg,#8c5916,#39200d)!important;border-color:#ffc04d!important}
.store-dashboard .dashboard-stat:nth-child(4):before{content:"⬡"!important;color:#e8c6ff!important;background:linear-gradient(145deg,#7623d7,#32116f)!important;border-color:#bd6cff!important}
.store-dashboard .dashboard-stat span{display:block!important;font-size:clamp(10px,2.8vw,14px)!important;letter-spacing:.01em!important;color:#bdc9ff!important;white-space:normal!important;overflow:visible!important;text-overflow:clip!important;line-height:1.3!important}
.store-dashboard .dashboard-stat strong{display:block!important;margin-top:5px!important;font-size:clamp(20px,5vw,27px)!important;font-weight:1000!important;line-height:1.1!important;white-space:normal!important;overflow-wrap:anywhere!important;text-overflow:clip!important;color:#43f2bd!important}
.store-dashboard .dashboard-stat:nth-child(1) strong{color:#38efb0!important}.store-dashboard .dashboard-stat:nth-child(2) strong{color:#ff6ab3!important}.store-dashboard .dashboard-stat:nth-child(3) strong{color:#c49bff!important}.store-dashboard .dashboard-stat:nth-child(4) strong{color:#ffc33d!important}
.store-dashboard .dashboard-quick{padding:16px!important;margin:14px 0 18px!important;border:1px solid rgba(108,115,255,.58)!important;border-radius:24px!important;background:radial-gradient(ellipse at 100% 0%,rgba(75,49,255,.16),transparent 45%),linear-gradient(145deg,rgba(8,16,36,.98),rgba(20,13,39,.98))!important;box-shadow:inset 0 1px 0 rgba(255,255,255,.05)!important}
.store-dashboard .dashboard-quick-title{font-size:clamp(19px,5vw,25px)!important;line-height:1.25!important;margin:0 0 5px!important;color:#f5f5ff!important;font-weight:1000!important}
.store-dashboard .dashboard-actions{display:grid!important;grid-template-columns:repeat(2,minmax(0,1fr))!important;gap:11px!important;margin-top:14px!important}
.store-dashboard .dashboard-actions a{display:flex!important;align-items:center!important;justify-content:flex-start!important;gap:9px!important;min-width:0!important;min-height:94px!important;height:auto!important;box-sizing:border-box!important;padding:13px 12px!important;border-radius:21px!important;color:#fff!important;font-size:15px!important;font-weight:950!important;line-height:1.2!important;text-decoration:none!important;box-shadow:inset 0 1px 0 rgba(255,255,255,.12)!important;overflow:hidden!important}
.store-dashboard .dashboard-actions a:nth-child(1){background:linear-gradient(120deg,rgba(0,156,99,.96),rgba(0,55,60,.98))!important;border:1.5px solid #00e4a2!important;box-shadow:0 0 13px rgba(0,225,160,.13)!important}
.store-dashboard .dashboard-actions a:nth-child(2){background:linear-gradient(120deg,rgba(0,117,230,.96),rgba(13,33,91,.98))!important;border:1.5px solid #18bfff!important;box-shadow:0 0 13px rgba(24,191,255,.13)!important}
.store-dashboard .dashboard-actions a:nth-child(3){background:linear-gradient(120deg,rgba(183,105,0,.96),rgba(78,34,16,.98))!important;border:1.5px solid #ffbd43!important;box-shadow:0 0 13px rgba(255,189,67,.11)!important}
.store-dashboard .dashboard-actions a:nth-child(4){background:linear-gradient(120deg,rgba(128,0,196,.96),rgba(60,13,94,.98))!important;border:1.5px solid #e34dff!important;box-shadow:0 0 13px rgba(227,77,255,.12)!important}
.store-dashboard .dashboard-actions .qa-icon{flex:0 0 38px!important;width:38px!important;font-size:34px!important;line-height:1!important;text-align:center!important;filter:drop-shadow(0 0 6px rgba(255,255,255,.18))!important}
.store-dashboard .dashboard-actions .qa-label{flex:1 1 auto!important;min-width:0!important;font-size:clamp(12px,3.4vw,17px)!important;white-space:normal!important;overflow-wrap:anywhere!important}
.store-dashboard .dashboard-actions .qa-arrow{flex:0 0 30px!important;width:30px!important;height:30px!important;display:inline-flex!important;align-items:center!important;justify-content:center!important;border:1.5px solid rgba(255,255,255,.92)!important;border-radius:50%!important;font-size:25px!important;line-height:1!important;color:#fff!important}
@media(max-width:600px){.store-dashboard{padding:12px 10px 8px!important}.store-dashboard .dashboard-balance{padding:18px 12px 15px 17px!important;column-gap:5px!important}.store-dashboard .dashboard-balance:before{left:15px!important;top:53px!important;font-size:34px!important}.store-dashboard .dashboard-balance-value{margin-left:62px!important;font-size:clamp(30px,8vw,42px)!important}.store-dashboard .dashboard-topup{min-height:48px!important;padding:0 13px!important;border-radius:15px!important;font-size:12px!important}.store-dashboard .dashboard-stat{min-height:100px!important;padding:15px 8px 12px 60px!important}.store-dashboard .dashboard-stat:before{left:9px!important;width:40px!important;height:40px!important;font-size:22px!important}.store-dashboard .dashboard-stat span{font-size:10px!important}.store-dashboard .dashboard-stat strong{font-size:clamp(18px,5vw,25px)!important}.store-dashboard .dashboard-quick{padding:13px!important}.store-dashboard .dashboard-actions{gap:9px!important}.store-dashboard .dashboard-actions a{min-height:84px!important;padding:11px 8px!important;gap:6px!important}.store-dashboard .dashboard-actions .qa-icon{font-size:29px!important;flex-basis:30px!important;width:30px!important}.store-dashboard .dashboard-actions .qa-arrow{flex-basis:25px!important;width:25px!important;height:25px!important;font-size:22px!important}.store-dashboard .dashboard-actions .qa-label{font-size:12px!important}}
@media(max-width:380px){.store-dashboard .dashboard-balance{grid-template-columns:minmax(0,1fr) auto!important;padding-left:12px!important}.store-dashboard .dashboard-balance:before{left:11px!important;font-size:30px!important}.store-dashboard .dashboard-balance-value{margin-left:48px!important;font-size:29px!important}.store-dashboard .dashboard-topup{padding:0 9px!important;font-size:10px!important}.store-dashboard .dashboard-stat{padding-left:52px!important}.store-dashboard .dashboard-stat:before{left:7px!important;width:35px!important;height:35px!important;font-size:19px!important}.store-dashboard .dashboard-actions a{min-height:75px!important;padding:9px 6px!important}.store-dashboard .dashboard-actions .qa-icon{font-size:25px!important;flex-basis:25px!important;width:25px!important}.store-dashboard .dashboard-actions .qa-arrow{display:none!important}}
</style>


<!-- XTREME TITAN OFFICIAL floating Live Message launcher -->
<style id="xt-live-chat-widget-css">
#xtLiveChat{position:fixed;right:16px;bottom:96px;z-index:99999;font-family:Arial,Helvetica,sans-serif}
#xtLiveChat .xt-chat-launch{width:58px;height:58px;border:1px solid rgba(99,255,22,.85);border-radius:50%;display:flex;align-items:center;justify-content:center;background:radial-gradient(circle at 30% 25%,#1bff9a,#087c70 48%,#052c3b);box-shadow:0 0 0 5px rgba(99,255,22,.10),0 0 22px rgba(16,216,255,.42);color:#fff;text-decoration:none;animation:xtChatPulse 1.8s ease-in-out infinite;position:relative}
#xtLiveChat .xt-chat-launch svg{width:29px;height:29px;filter:drop-shadow(0 1px 3px #003)}
#xtLiveChat .xt-chat-launch:after{content:"";position:absolute;inset:-5px;border:2px solid rgba(99,255,22,.48);border-radius:50%;animation:xtChatRing 2.2s ease-out infinite}
#xtLiveChat .xt-chat-bubble{position:absolute;right:0;bottom:70px;max-width:235px;min-width:155px;padding:11px 14px;border:1px solid rgba(99,255,22,.6);border-radius:14px 14px 14px 4px;background:rgba(4,13,25,.97);color:#f3fff7;font-size:12px;font-weight:800;line-height:1.45;box-shadow:0 8px 28px #0009,0 0 18px #10d8ff26;opacity:0;visibility:hidden;transform:translateY(7px) scale(.97);transition:opacity .22s,transform .22s,visibility .22s;pointer-events:none}
#xtLiveChat .xt-chat-bubble.show{opacity:1;visibility:visible;transform:translateY(0) scale(1)}
#xtLiveChat .xt-chat-bubble:after{content:"";position:absolute;right:15px;bottom:-7px;width:12px;height:12px;transform:rotate(45deg);background:#040d19;border-right:1px solid rgba(99,255,22,.5);border-bottom:1px solid rgba(99,255,22,.5)}
#xtLiveChat .xt-chat-caption{position:absolute;right:0;bottom:68px;padding:7px 11px;border-radius:9px;background:linear-gradient(135deg,#06121f,#102b35);color:#8cff72;border:1px solid #63ff1680;font-size:10px;font-weight:900;letter-spacing:.6px;white-space:nowrap;box-shadow:0 0 14px #10d8ff22}
@keyframes xtChatPulse{0%,100%{transform:scale(1)}50%{transform:scale(1.07)}}
@keyframes xtChatRing{0%{transform:scale(.9);opacity:.8}100%{transform:scale(1.45);opacity:0}}
@media(max-width:480px){#xtLiveChat{right:12px;bottom:92px}#xtLiveChat .xt-chat-launch{width:52px;height:52px}#xtLiveChat .xt-chat-caption{right:0;bottom:62px}#xtLiveChat .xt-chat-bubble{max-width:min(235px,calc(100vw - 90px))}}
@media(prefers-reduced-motion:reduce){#xtLiveChat .xt-chat-launch,#xtLiveChat .xt-chat-launch:after{animation:none!important}}
</style>
<div id="xtLiveChat">
  <div class="xt-chat-bubble" id="xtChatBubble" role="status" aria-live="polite">Need help? Live Chat is here!</div>
  <a class="xt-chat-launch" href="messages.php" aria-label="Open Live Message" title="Live Message">
    <svg viewBox="0 0 24 24" fill="none" aria-hidden="true"><path d="M20.2 11.5a8.1 8.1 0 0 1-8.3 7.9 9 9 0 0 1-3.4-.7L3 20l1.4-4.2a7.5 7.5 0 0 1-1.2-4.1A8.2 8.2 0 0 1 11.6 4a8.3 8.3 0 0 1 8.6 7.5Z" fill="white" fill-opacity=".14" stroke="white" stroke-width="1.7" stroke-linejoin="round"/><path d="M7.5 10.1h9M7.5 13.5h6" stroke="white" stroke-width="1.7" stroke-linecap="round"/></svg>
  </a>
</div>
<script>
(()=>{const bubble=document.getElementById('xtChatBubble');if(!bubble)return;let intervalMs=90000,durationMs=6000,settings=null,timer=null;const language=()=>{try{return (localStorage.getItem('xtreme_language')||document.documentElement.lang||'en').toLowerCase().split('-')[0]}catch(e){return 'en'}};const message=()=>String((settings&&settings.popup_text)||'Need help? Live Chat is here!');const show=()=>{bubble.textContent=message();bubble.classList.add('show');setTimeout(()=>bubble.classList.remove('show'),durationMs)};const start=()=>{if(timer)clearInterval(timer);timer=setInterval(show,intervalMs);setTimeout(show,12000)};window.addEventListener('storage',e=>{if(e.key==='xtreme_language'&&bubble.classList.contains('show'))bubble.textContent=message()});const loadSettings=()=>{const lang=language();fetch('messages.php?action=widget_config&lang='+encodeURIComponent(lang),{cache:'no-store',credentials:'same-origin'}).then(r=>r.json()).then(d=>{if(d.ok&&d.settings){settings=d.settings;intervalMs=Math.max(60000,Math.min(7200000,Number(settings.interval_seconds||90)*1000));durationMs=Math.max(3000,Math.min(15000,Number(settings.duration_seconds||6)*1000));if(bubble.classList.contains('show'))bubble.textContent=settings.popup_text||'Need help? Live Chat is here!'}start()}).catch(()=>{settings={popup_text:'Need help? Live Chat is here!'};start()})};window.addEventListener('storage',e=>{if(e.key==='xtreme_language')loadSettings()});let lastLang=language();setInterval(()=>{const current=language();if(current!==lastLang){lastLang=current;loadSettings()}},2000);loadSettings();})();
</script>




















<style id="xtreme-dashboard-quick-access-final-v14">
/* V14 dashboard-only Quick Access correction: fixed columns prevent icon/arrow stretching. */
.store-dashboard .dashboard-actions{display:grid!important;grid-template-columns:repeat(2,minmax(0,1fr))!important;gap:12px!important;align-items:stretch!important}
.store-dashboard .dashboard-actions>a{display:grid!important;grid-template-columns:44px minmax(0,1fr) 36px!important;align-items:center!important;justify-content:initial!important;column-gap:10px!important;min-width:0!important;min-height:94px!important;padding:14px 14px!important;box-sizing:border-box!important;text-align:left!important;overflow:hidden!important}
.store-dashboard .dashboard-actions .qa-image-icon,.store-dashboard .dashboard-actions .xt-wallet-add-icon{display:flex!important;align-items:center!important;justify-content:center!important;position:relative!important;inset:auto!important;float:none!important;flex:none!important;width:44px!important;height:44px!important;min-width:44px!important;min-height:44px!important;margin:0!important;padding:0!important;border:0!important;border-radius:0!important;background:none!important;background-image:none!important;box-shadow:none!important;filter:drop-shadow(0 2px 5px rgba(0,0,0,.2))!important;overflow:visible!important}
.store-dashboard .dashboard-actions .qa-image-icon img,.store-dashboard .dashboard-actions .xt-wallet-add-icon img{display:block!important;position:static!important;width:44px!important;height:44px!important;min-width:44px!important;min-height:44px!important;max-width:44px!important;max-height:44px!important;object-fit:contain!important;object-position:center!important;margin:0!important;padding:0!important;border:0!important;border-radius:0!important;background:none!important;filter:none!important}
.store-dashboard .dashboard-actions .qa-label{display:block!important;min-width:0!important;margin:0!important;padding:0!important;align-self:center!important;justify-self:stretch!important;font-size:clamp(13px,3.3vw,17px)!important;font-weight:950!important;line-height:1.2!important;white-space:normal!important;overflow-wrap:anywhere!important;text-align:left!important;transform:none!important}
.store-dashboard .dashboard-actions .qa-arrow{display:flex!important;align-items:center!important;justify-content:center!important;justify-self:end!important;align-self:center!important;flex:none!important;width:36px!important;height:36px!important;min-width:36px!important;min-height:36px!important;max-width:36px!important;box-sizing:border-box!important;margin:0!important;padding:0!important;border:2px solid rgba(255,255,255,.95)!important;border-radius:50%!important;background:rgba(0,0,0,.12)!important;color:#fff!important;font-size:27px!important;line-height:1!important;white-space:nowrap!important;transform:none!important}
.store-dashboard .dashboard-actions a[href*="my-keys"]{background:linear-gradient(115deg,#00b982,#064d4d)!important;border-color:#35ffc1!important}
.store-dashboard .dashboard-actions a[href*="deposit.php"]{background:linear-gradient(115deg,#079eff,#153aa0)!important;border-color:#38d8ff!important}
.store-dashboard .dashboard-actions a[href*="history.php"]{background:linear-gradient(115deg,#c98212,#743514)!important;border-color:#ffd05a!important}
.store-dashboard .dashboard-actions a[href*="profile.php"]{background:linear-gradient(115deg,#a000cf,#59158b)!important;border-color:#ed62ff!important}
@media(max-width:600px){.store-dashboard .dashboard-actions{gap:10px!important}.store-dashboard .dashboard-actions>a{grid-template-columns:38px minmax(0,1fr) 32px!important;column-gap:7px!important;min-height:78px!important;padding:10px 9px!important}.store-dashboard .dashboard-actions .qa-image-icon,.store-dashboard .dashboard-actions .xt-wallet-add-icon,.store-dashboard .dashboard-actions .qa-image-icon img,.store-dashboard .dashboard-actions .xt-wallet-add-icon img{width:38px!important;height:38px!important;min-width:38px!important;min-height:38px!important;max-width:38px!important;max-height:38px!important}.store-dashboard .dashboard-actions .qa-arrow{width:32px!important;height:32px!important;min-width:32px!important;min-height:32px!important;max-width:32px!important;font-size:24px!important}.store-dashboard .dashboard-actions .qa-label{font-size:clamp(12px,3.3vw,16px)!important}}
@media(max-width:380px){.store-dashboard .dashboard-actions>a{grid-template-columns:32px minmax(0,1fr) 28px!important;column-gap:5px!important;padding:9px 7px!important}.store-dashboard .dashboard-actions .qa-image-icon,.store-dashboard .dashboard-actions .xt-wallet-add-icon,.store-dashboard .dashboard-actions .qa-image-icon img,.store-dashboard .dashboard-actions .xt-wallet-add-icon img{width:32px!important;height:32px!important;min-width:32px!important;min-height:32px!important;max-width:32px!important;max-height:32px!important}.store-dashboard .dashboard-actions .qa-arrow{width:28px!important;height:28px!important;min-width:28px!important;min-height:28px!important;max-width:28px!important;font-size:21px!important}}
</style>

<style id="xtreme-dashboard-wallet-icon-final-v17">
/* Use the exact supplied cyan wallet icon for the dashboard Balance and Add Funds. */
.store-dashboard .dashboard-balance:before{
 content:""!important;display:block!important;position:absolute!important;
 left:25px!important;top:55px!important;width:66px!important;height:56px!important;
 margin:0!important;float:none!important;font-size:0!important;line-height:0!important;
 background:url("assets/nav-icons/wallet-cyan-reference.png") center/contain no-repeat!important;
 filter:drop-shadow(0 0 7px rgba(34,215,255,.30))!important;z-index:3!important;
}

/* Quick Access > Add Funds */
.store-dashboard .dashboard-actions a[href*="deposit.php"] .xt-wallet-add-icon,
.store-dashboard .dashboard-actions a[href*="deposit.php"] .qa-icon{
 background:transparent!important;background-image:none!important;
}
.store-dashboard .dashboard-actions a[href*="deposit.php"] .xt-wallet-add-icon:before,
.store-dashboard .dashboard-actions a[href*="deposit.php"] .qa-icon:before{
 content:""!important;display:block!important;width:48px!important;height:48px!important;
 background:url("assets/nav-icons/wallet-cyan-reference.png") center/contain no-repeat!important;
 filter:drop-shadow(0 0 6px rgba(34,215,255,.30))!important;
}
/* Main Add Funds button */
.store-dashboard .dashboard-topup:before{
 content:""!important;display:inline-block!important;width:30px!important;height:30px!important;
 background:url("assets/nav-icons/wallet-cyan-reference.png") center/contain no-repeat!important;
 border-radius:0!important;filter:drop-shadow(0 0 5px rgba(34,215,255,.30))!important;
}
@media(max-width:600px){
 .store-dashboard .dashboard-topup:before{width:26px!important;height:26px!important}
}
</style>

<script src="assets/xtreme-music.js?v=3" data-enabled="<?=e(site_setting('background_music_enabled','1'))?>" data-src="<?=e(site_setting('background_music_path','uploads/music/xtreme-background.m4a'))?>" defer></script>
</body>
</html>
<style id="store-filters-v33">
html[data-theme] .store-filters{padding:6px 14px 16px!important;gap:8px!important}
html[data-theme] .store-filter{min-height:50px!important;padding:9px 13px!important;border-radius:16px!important;font-size:10px!important;font-weight:1000!important;letter-spacing:.1px!important;display:inline-flex!important;align-items:center!important;justify-content:center!important;gap:4px!important;transition:all .18s ease!important}
html[data-theme="luxury"] .store-filter{background:linear-gradient(145deg,#fffdf8,#eee5d5)!important;color:#5b4630!important;border-color:#d9c9ad!important;box-shadow:0 8px 22px rgba(87,68,43,.10)!important}
html[data-theme="luxury"] .store-filter.active{background:linear-gradient(135deg,#a16207,#b45309)!important;color:#fff!important;border-color:#a16207!important}
html[data-theme="white"] .store-filter{background:#fff!important;color:#334155!important;border-color:#d7deea!important}
.store-filter[data-filter="live"] b{background:linear-gradient(135deg,#22c55e,#0f766e)!important;color:#fff!important}
.store-filter[data-filter="ANDROID_NONROOT"] b{background:linear-gradient(135deg,#3b82f6,#06b6d4)!important;color:#fff!important}
.store-filter[data-filter="IPHONE"] b{background:linear-gradient(135deg,#8b5cf6,#ec4899)!important;color:#fff!important}
.store-filter[data-filter="ANDROID_ROOT"] b{background:linear-gradient(135deg,#f59e0b,#ef4444)!important;color:#fff!important}
.store-filter[data-filter="PC_PANEL_FF"] b{background:linear-gradient(135deg,#f43f5e,#7c3aed)!important;color:#fff!important}
</style>
<style id="store-filters-premium-v34">
.store-filters{display:flex!important;align-items:stretch!important;gap:10px!important;padding:8px 14px 18px!important;overflow-x:auto!important;scroll-snap-type:x proximity!important}
.store-filter{position:relative!important;display:inline-flex!important;align-items:center!important;justify-content:center!important;gap:7px!important;min-height:56px!important;padding:9px 13px!important;border-radius:19px!important;flex:0 0 auto!important;overflow:hidden!important;isolation:isolate!important;border:1px solid rgba(255,255,255,.12)!important;background:linear-gradient(145deg,rgba(24,35,55,.98),rgba(6,13,25,.99))!important;color:#eef6ff!important;font-size:10px!important;font-weight:1000!important;letter-spacing:.25px!important;text-transform:uppercase!important;box-shadow:0 14px 30px rgba(0,0,0,.28),inset 0 1px 0 rgba(255,255,255,.08)!important;transition:transform .18s ease,box-shadow .18s ease,border-color .18s ease,filter .18s ease!important}
.store-filter:before{content:""!important;width:30px!important;height:30px!important;flex:0 0 30px!important;display:grid!important;place-items:center!important;border-radius:10px!important;background:rgba(255,255,255,.07)!important;border:1px solid rgba(255,255,255,.10)!important;font-size:15px!important;line-height:1!important;box-shadow:inset 0 1px 0 rgba(255,255,255,.08)!important}
.store-filter[data-filter="live"]:before{content:"⚡"!important}.store-filter[data-filter="all"]:before{content:"♻"!important}.store-filter[data-filter="ANDROID_NONROOT"]:before{content:"🤖"!important}.store-filter[data-filter="IPHONE"]:before{content:""!important;font-family:Arial,sans-serif!important}.store-filter[data-filter="ANDROID_ROOT"]:before{content:"⚙"!important}.store-filter[data-filter="PC_PANEL_FF"]:before{content:"⌨"!important}
.store-filter b{position:relative!important;z-index:2!important;min-width:28px!important;height:28px!important;margin-left:2px!important;padding:0 7px!important;display:inline-grid!important;place-items:center!important;border-radius:10px!important;background:linear-gradient(135deg,rgba(255,255,255,.16),rgba(255,255,255,.05))!important;color:#fff!important;border:1px solid rgba(255,255,255,.12)!important;font-size:10px!important;font-weight:1000!important;box-shadow:inset 0 1px 0 rgba(255,255,255,.10)!important}
.store-filter:after{content:""!important;position:absolute!important;inset:-30% auto auto -10%!important;width:80px!important;height:120px!important;background:linear-gradient(90deg,transparent,rgba(255,255,255,.08),transparent)!important;transform:rotate(18deg)!important;pointer-events:none!important;z-index:-1!important}
.store-filter:hover{transform:translateY(-3px)!important;filter:brightness(1.08)!important;border-color:rgba(125,211,252,.55)!important;box-shadow:0 20px 40px rgba(0,0,0,.32),0 0 25px rgba(56,189,248,.08),inset 0 1px 0 rgba(255,255,255,.10)!important}
.store-filter.active{transform:translateY(-1px)!important;color:#fff!important;border-color:rgba(125,211,252,.95)!important;background:linear-gradient(135deg,rgba(14,165,233,.38),rgba(124,58,237,.34),rgba(15,23,42,.98))!important;box-shadow:0 0 0 1px rgba(56,189,248,.16),0 18px 42px rgba(14,165,233,.18),inset 0 1px 0 rgba(255,255,255,.14)!important}
.store-filter.active:before{background:linear-gradient(135deg,rgba(34,211,238,.35),rgba(139,92,246,.32))!important;border-color:rgba(125,211,252,.38)!important;box-shadow:0 0 18px rgba(56,189,248,.16),inset 0 1px 0 rgba(255,255,255,.14)!important}
.store-filter[data-filter="live"]{border-color:rgba(74,222,128,.42)!important}.store-filter[data-filter="live"]:before{background:linear-gradient(135deg,rgba(34,197,94,.24),rgba(16,185,129,.10))!important}.store-filter[data-filter="live"].active{background:linear-gradient(135deg,rgba(22,163,74,.34),rgba(6,95,70,.30),rgba(15,23,42,.98))!important;border-color:rgba(74,222,128,.95)!important;box-shadow:0 0 0 1px rgba(74,222,128,.16),0 18px 42px rgba(34,197,94,.16)!important}
.store-filter[data-filter="ANDROID_NONROOT"]:before{background:linear-gradient(135deg,rgba(59,130,246,.24),rgba(6,182,212,.12))!important}.store-filter[data-filter="IPHONE"]:before{background:linear-gradient(135deg,rgba(139,92,246,.25),rgba(236,72,153,.12))!important}.store-filter[data-filter="ANDROID_ROOT"]:before{background:linear-gradient(135deg,rgba(245,158,11,.24),rgba(239,68,68,.12))!important}.store-filter[data-filter="PC_PANEL_FF"]:before{background:linear-gradient(135deg,rgba(244,63,94,.24),rgba(124,58,237,.12))!important}
html[data-theme="white"] .store-filter{background:linear-gradient(145deg,#ffffff,#f3f6fb)!important;color:#243247!important;border-color:#d6deea!important;box-shadow:0 12px 28px rgba(15,23,42,.09),inset 0 1px 0 #fff!important}.store-filter b{color:#fff!important}
html[data-theme="luxury"] .store-filter{background:linear-gradient(145deg,#fffdf8,#f1e8d9)!important;color:#4b3a28!important;border-color:#d7c5a7!important;box-shadow:0 14px 30px rgba(87,68,43,.12),inset 0 1px 0 #fff!important}.store-filter[data-filter="live"]{border-color:rgba(21,128,61,.35)!important}html[data-theme="luxury"] .store-filter.active{background:linear-gradient(135deg,#a16207,#b45309,#7c2d12)!important;color:#fff!important;border-color:#a16207!important;box-shadow:0 0 0 1px rgba(161,98,7,.12),0 18px 38px rgba(120,82,30,.18)!important}html[data-theme="luxury"] .store-filter:before{background:linear-gradient(145deg,#fffaf0,#eadcc4)!important;border-color:#d6c3a3!important;color:#8a5a12!important}
@media(max-width:600px){.store-filters{gap:8px!important;padding-left:12px!important;padding-right:12px!important}.store-filter{min-height:54px!important;padding:8px 10px!important;border-radius:17px!important;font-size:9px!important}.store-filter:before{width:28px!important;height:28px!important;flex-basis:28px!important;font-size:14px!important}.store-filter b{min-width:26px!important;height:26px!important}}
</style>


<style id="xt-product-status-purchase-ui">
.product-image.xt-inline-media{position:relative!important}
.xt-product-status{position:absolute;z-index:5;top:12px;right:12px;display:inline-flex;align-items:center;gap:8px;padding:9px 14px;border-radius:999px;font-size:clamp(11px,2.8vw,15px);font-weight:950;letter-spacing:.06em;line-height:1.1;box-shadow:0 4px 18px rgba(0,0,0,.35);backdrop-filter:blur(8px);-webkit-backdrop-filter:blur(8px);animation:xt-status-breathe 1.8s ease-in-out infinite}
.xt-product-tags{position:absolute;z-index:6;top:12px;left:12px;display:flex;flex-direction:column;align-items:flex-start;gap:6px;max-width:55%;pointer-events:none}.xt-product-tag{display:inline-flex;align-items:center;padding:6px 10px;border-radius:999px;color:#fff;font-size:clamp(10px,2.4vw,13px);font-weight:950;letter-spacing:.05em;line-height:1.1;border:1px solid rgba(255,255,255,.4);box-shadow:0 3px 12px rgba(0,0,0,.32);backdrop-filter:blur(7px);-webkit-backdrop-filter:blur(7px);overflow-wrap:anywhere}.xt-product-tag.tag-safe{background:rgba(5,120,75,.92);border-color:#34d399}.xt-product-tag.tag-risk{background:rgba(185,28,28,.94);border-color:#fb4545}.xt-product-tag.tag-updating{background:rgba(180,83,9,.94);border-color:#fbbf24}.xt-product-tag.tag-testing{background:rgba(91,33,182,.94);border-color:#c4b5fd}
.xt-product-tag{position:relative;padding-left:19px!important}
.xt-product-tag:before{content:"";position:absolute;left:7px;top:50%;width:6px;height:6px;border-radius:50%;transform:translateY(-50%);background:currentColor;box-shadow:0 0 7px currentColor;animation:xt-dot-pulse 1.15s ease-in-out infinite}
.xt-maintenance-overlay{position:fixed;inset:0;z-index:99999;display:flex;align-items:center;justify-content:center;padding:20px;background:rgba(1,5,13,.78);backdrop-filter:blur(9px);-webkit-backdrop-filter:blur(9px)}
.xt-maintenance-dialog{width:min(100%,420px);padding:25px 22px;border:1px solid rgba(54,210,255,.5);border-radius:22px;background:linear-gradient(145deg,#101e32,#171329);box-shadow:0 20px 70px rgba(0,0,0,.6),0 0 28px rgba(0,200,255,.12);color:#f5f8ff;text-align:center}
.xt-maintenance-icon{margin:0 auto 12px;width:48px;height:48px;display:grid;place-items:center;border-radius:50%;background:rgba(255,58,68,.15);border:1px solid rgba(255,58,68,.55)}
.xt-maintenance-icon .xt-status-dot{width:12px;height:12px;flex-basis:12px;background:#ff414d;box-shadow:0 0 14px #ff414d}
.xt-maintenance-dialog h2{margin:4px 0 10px;font-size:22px;font-weight:900}
.xt-maintenance-dialog p{margin:0 0 22px;color:#bdc9da;line-height:1.55;font-size:15px}
.xt-maintenance-actions{display:grid;grid-template-columns:1fr 1fr;gap:11px}
.xt-maintenance-actions button{min-height:48px;border-radius:12px;font-weight:900;font-size:15px;cursor:pointer}
.xt-maintenance-cancel{background:#202b3b;border:1px solid #45536a;color:#e8edf5}
.xt-maintenance-continue{background:linear-gradient(100deg,#06b9ee,#10c79b);border:0;color:#04111a}

.xt-product-status.is-online{color:#a7ffdc;background:rgba(5,100,72,.88);border:2px solid #34d399}
.xt-product-status.is-maintenance{color:#fff;background:rgba(153,27,27,.94);border:2px solid #fb4545}
.xt-status-dot{width:10px;height:10px;flex:0 0 10px;border-radius:50%;display:inline-block;animation:xt-dot-pulse 1.15s ease-in-out infinite}
.is-online .xt-status-dot{background:#4dffb0;box-shadow:0 0 12px #34d399}
.is-maintenance .xt-status-dot{background:#ff3838;box-shadow:0 0 12px #ff3838}
.xt-maintenance-countdown{display:inline-grid;place-items:center;min-width:19px;height:19px;padding:0 4px;border-radius:50%;font-size:11px;font-weight:1000;color:#fff;background:#b91c1c;border:1px solid #fca5a5;animation:xt-status-breathe .8s ease-in-out infinite}
.xt-product-tag{position:relative}.xt-product-tag:before{content:"";display:inline-block;width:7px;height:7px;flex:0 0 7px;border-radius:50%;margin-right:6px;background:currentColor;box-shadow:0 0 8px currentColor;animation:xt-dot-pulse 1.15s ease-in-out infinite}
@keyframes xt-status-breathe{0%,100%{transform:scale(1);filter:brightness(1)}50%{transform:scale(1.045);filter:brightness(1.18)}}
@keyframes xt-dot-pulse{0%,100%{opacity:1;transform:scale(1)}50%{opacity:.45;transform:scale(.72)}}
.xt-purchase-toggle{display:block;width:100%;min-height:62px;margin:18px 0 14px;padding:14px 18px;border:0;border-radius:17px;background:linear-gradient(105deg,#09b9e7,#397cff,#10c69a);color:#fff;font-size:clamp(17px,4vw,23px);font-weight:950;letter-spacing:.06em;box-shadow:0 10px 28px rgba(0,190,230,.25);cursor:pointer}
.xt-purchase-toggle:active{transform:scale(.99)}n.xt-purchase-toggle.is-maintenance-purchase{background:linear-gradient(105deg,#7f1d1d,#b91c1c,#7f1d1d);border:1px solid #fb4545;color:#fff;box-shadow:0 10px 28px rgba(239,68,68,.22)}n.xt-purchase-countdown{display:inline-grid;place-items:center;min-width:25px;height:25px;margin-left:10px;padding:0 5px;border-radius:50%;background:#fff;color:#991b1b;font-weight:1000;animation:xt-status-breathe .8s ease-in-out infinite}.xt-purchase-toggle.is-maintenance-purchase{display:flex;align-items:center;justify-content:center;gap:3px}
.product .plan-list[hidden],.product .buy-area[hidden]{display:none!important}
.product-action-row .product-action{border-radius:12px!important}
@media(max-width:480px){.xt-product-tags{top:8px;left:8px;gap:4px}.xt-product-tag{padding:5px 7px;font-size:10px}.xt-product-status{top:8px;right:8px;padding:7px 10px;gap:6px}.xt-status-dot{width:8px;height:8px;flex-basis:8px}.xt-purchase-toggle{min-height:56px}}
</style>
<script>
(function(){
  var timers=[];
  function startCountdowns(){
    timers.forEach(function(id){window.clearInterval(id);}); timers=[];
    document.querySelectorAll('.xt-maintenance-countdown,.xt-purchase-countdown').forEach(function(el){
      var start=Number(el.getAttribute('data-countdown-start')||Date.now());
      if(!Number.isFinite(start)||start<=0) start=Date.now();
      function render(){
        var elapsed=Math.max(0,Math.floor((Date.now()-start)/1000));
        var n=3-(elapsed%3);
        el.textContent=String(n);
        el.setAttribute('aria-label','Maintenance countdown '+n);
      }
      render();
      timers.push(window.setInterval(render,250));
    });
  }
  if(document.readyState==='loading') document.addEventListener('DOMContentLoaded',startCountdowns);
  else startCountdowns();
  window.addEventListener('pageshow',startCountdowns);
})();
</script>


<style id="xt-dashboard-wallet-icons-final-v39">
/* Final icon override: exactly one wallet in balance and one wallet-plus in Quick Access. */
.store-dashboard .dashboard-balance:before{content:""!important;display:block!important;position:absolute!important;left:25px!important;top:55px!important;width:66px!important;height:56px!important;float:none!important;margin:0!important;font-size:0!important;line-height:0!important;background-image:url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='100' height='78' viewBox='0 0 100 78'%3E%3Cdefs%3E%3ClinearGradient id='w' x1='0' y1='0' x2='1' y2='1'%3E%3Cstop stop-color='%2321e6ff'/%3E%3Cstop offset='1' stop-color='%230875ff'/%3E%3C/linearGradient%3E%3ClinearGradient id='c' x1='0' y1='0' x2='0' y2='1'%3E%3Cstop stop-color='%23ffe86b'/%3E%3Cstop offset='1' stop-color='%23ff9e00'/%3E%3C/linearGradient%3E%3C/defs%3E%3Cellipse cx='31' cy='17' rx='13' ry='13' fill='url(%23c)' stroke='%23fff08a' stroke-width='2'/%3E%3Cellipse cx='48' cy='22' rx='13' ry='13' fill='url(%23c)' stroke='%23fff08a' stroke-width='2'/%3E%3Cpath d='M12 26h57a8 8 0 0 1 8 8v34H13a8 8 0 0 1-8-8V34a8 8 0 0 1 7-8z' fill='url(%23w)' stroke='%2339dfff' stroke-width='2'/%3E%3Cpath d='M62 39h25a9 9 0 0 1 0 18H62a9 9 0 0 1 0-18z' fill='%230875d8' stroke='%233ce5ff' stroke-width='2'/%3E%3Ccircle cx='78' cy='48' r='3' fill='%23b8f7ff'/%3E%3C/svg%3E")!important;background-position:center!important;background-size:contain!important;background-repeat:no-repeat!important;filter:drop-shadow(0 0 9px rgba(0,190,255,.5))!important;z-index:2!important}
.store-dashboard .dashboard-balance-value:before,.store-dashboard .dashboard-balance-value:after{content:none!important;display:none!important}
.store-dashboard .dashboard-balance-value{margin-left:82px!important;position:relative!important;z-index:1!important}
.store-dashboard .dashboard-actions a[href*="deposit.php"] .qa-icon{font-size:0!important;line-height:0!important;display:inline-flex!important;position:relative!important;flex:0 0 48px!important;width:48px!important;height:42px!important;background-image:url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='100' height='78' viewBox='0 0 100 78'%3E%3Cdefs%3E%3ClinearGradient id='w' x1='0' y1='0' x2='1' y2='1'%3E%3Cstop stop-color='%2322e7ff'/%3E%3Cstop offset='1' stop-color='%230876ff'/%3E%3C/linearGradient%3E%3C/defs%3E%3Cpath d='M12 28h57a8 8 0 0 1 8 8v33H13a8 8 0 0 1-8-8V36a8 8 0 0 1 7-8z' fill='url(%23w)' stroke='%2345e7ff' stroke-width='2'/%3E%3Cpath d='M16 27 37 13h29a6 6 0 0 1 6 6v7H16z' fill='%2320c9ff' stroke='%236cecff' stroke-width='2'/%3E%3Cpath d='M62 39h25a9 9 0 0 1 0 18H62a9 9 0 0 1 0-18z' fill='%230875d8' stroke='%233ce5ff' stroke-width='2'/%3E%3Ccircle cx='78' cy='48' r='3' fill='%23b8f7ff'/%3E%3Ccircle cx='76' cy='19' r='15' fill='%23fff' stroke='%236deaff' stroke-width='3'/%3E%3Cpath d='M76 10v18M67 19h18' stroke='%233d6dff' stroke-width='4' stroke-linecap='round'/%3E%3C/svg%3E")!important;background-position:center!important;background-size:contain!important;background-repeat:no-repeat!important;filter:drop-shadow(0 0 8px rgba(0,190,255,.42))!important}
.store-dashboard .dashboard-actions a[href*="deposit.php"] .qa-icon .xt-wallet-plus{display:none!important}
@media(max-width:600px){.store-dashboard .dashboard-balance:before{left:15px!important;top:53px!important;width:52px!important;height:45px!important}.store-dashboard .dashboard-balance-value{margin-left:62px!important}.store-dashboard .dashboard-actions a[href*="deposit.php"] .qa-icon{flex-basis:36px!important;width:36px!important;height:34px!important}}
@media(max-width:380px){.store-dashboard .dashboard-balance:before{left:11px!important;top:51px!important;width:43px!important;height:38px!important}.store-dashboard .dashboard-balance-value{margin-left:51px!important}.store-dashboard .dashboard-actions a[href*="deposit.php"] .qa-icon{flex-basis:30px!important;width:30px!important;height:29px!important}}
</style>

<style id="xtreme-bottom-nav-single-source-fix">
/* Single source of truth: five equal tabs; active state changes appearance only. */
html body nav.nav{
 position:fixed!important;left:0!important;right:0!important;bottom:0!important;
 z-index:999999!important;display:grid!important;
 grid-template-columns:repeat(5,minmax(0,1fr))!important;
 gap:0!important;align-items:stretch!important;justify-items:stretch!important;
 width:100%!important;height:calc(76px + env(safe-area-inset-bottom,0px))!important;
 min-height:calc(76px + env(safe-area-inset-bottom,0px))!important;
 max-height:calc(76px + env(safe-area-inset-bottom,0px))!important;
 margin:0!important;padding:4px 3px env(safe-area-inset-bottom,0px)!important;
 box-sizing:border-box!important;overflow:visible!important;
}
html body nav.nav>a,
html body nav.nav>a.active,
html body nav.nav>a:active,
html body nav.nav>a:focus{
 display:flex!important;flex-direction:column!important;
 align-items:center!important;justify-content:center!important;
 justify-self:stretch!important;align-self:stretch!important;
 width:100%!important;min-width:0!important;max-width:100%!important;
 height:100%!important;min-height:0!important;max-height:100%!important;
 margin:0!important;padding:4px 0 2px!important;gap:2px!important;
 box-sizing:border-box!important;flex:none!important;
 border:1px solid transparent!important;border-radius:14px!important;
 background:transparent!important;box-shadow:none!important;
 color:#aeb0c9!important;text-decoration:none!important;
 transform:none!important;scale:1!important;translate:none!important;
 position:relative!important;inset:auto!important;
 font-size:10px!important;font-weight:800!important;line-height:1.1!important;
 letter-spacing:0!important;text-align:center!important;
 white-space:nowrap!important;overflow:hidden!important;
}
html body nav.nav>a.active{
 background:rgba(222,54,193,.13)!important;
 border-color:rgba(242,95,215,.38)!important;
 color:#f16bd7!important;box-shadow:none!important;
}
html body nav.nav>a .nav-ico,
html body nav.nav>a .nav-svg-icon{
 display:flex!important;flex:0 0 62px!important;
 align-items:center!important;justify-content:center!important;
 width:62px!important;min-width:62px!important;max-width:62px!important;
 height:62px!important;min-height:62px!important;max-height:62px!important;
 margin:0!important;padding:0!important;box-sizing:border-box!important;
 border:0!important;border-radius:0!important;background:transparent!important;
 box-shadow:none!important;position:absolute!important;top:-12px!important;left:50%!important;
 transform:translateX(-50%)!important;font-size:0!important;line-height:0!important;
}
html body nav.nav>a img.xt-nav-image,
html body nav.nav>a .nav-ico img,
html body nav.nav>a .nav-svg-icon img{
 display:block!important;flex:none!important;
 width:60px!important;min-width:60px!important;max-width:60px!important;
 height:60px!important;min-height:60px!important;max-height:60px!important;
 object-fit:contain!important;object-position:center!important;
 margin:0!important;padding:0!important;border:0!important;border-radius:0!important;
 background:transparent!important;box-shadow:none!important;
 transform:none!important;filter:none!important;
}
html body nav.nav>a>span:last-child{
 display:block!important;flex:0 0 auto!important;
 position:absolute!important;left:0!important;right:0!important;bottom:4px!important;inset-inline:0!important;
 float:none!important;width:100%!important;min-width:0!important;max-width:100%!important;
 height:14px!important;min-height:14px!important;max-height:14px!important;
 margin:0!important;padding:0 1px!important;box-sizing:border-box!important;
 overflow:visible!important;text-overflow:clip!important;
 color:inherit!important;font-size:10px!important;font-weight:800!important;
 line-height:14px!important;letter-spacing:0!important;text-align:center!important;
 white-space:nowrap!important;transform:none!important;opacity:1!important;
 visibility:visible!important;background:transparent!important;border:0!important;
}
html body{padding-bottom:calc(82px + env(safe-area-inset-bottom,0px))!important}
@media(max-width:390px){
 html body nav.nav{padding-left:1px!important;padding-right:1px!important}
 html body nav.nav>a,html body nav.nav>a.active{border-radius:12px!important}
 html body nav.nav>a .nav-ico,html body nav.nav>a .nav-svg-icon{
  flex-basis:44px!important;width:62px!important;min-width:62px!important;max-width:62px!important;
  height:62px!important;min-height:62px!important;max-height:62px!important;top:-12px!important
 }
 html body nav.nav>a img.xt-nav-image,html body nav.nav>a .nav-ico img,html body nav.nav>a .nav-svg-icon img{
  width:60px!important;min-width:60px!important;max-width:60px!important;
  height:60px!important;min-height:60px!important;max-height:60px!important
 }
 html body nav.nav>a>span:last-child{font-size:9px!important;line-height:13px!important;height:13px!important;min-height:13px!important;max-height:13px!important;bottom:4px!important}
}

/* Match the slight downward label shift on the active Add Funds and Profile tabs.
   Only the active label moves; tab names and layout remain unchanged. */
html body nav.nav>a.active[href="deposit.php"]>span:last-child,
html body nav.nav>a.active[href="profile.php"]>span:last-child{
 transform:translateY(3px)!important;
}

/* XTREME TITAN V12 — unified premium neon dashboard + consistent icon artwork */
.store-dashboard .dashboard-balance{
 background:radial-gradient(ellipse at 15% 0%,rgba(32,224,255,.12),transparent 55%),linear-gradient(135deg,rgba(20,24,58,.98),rgba(30,12,42,.98))!important;
 border:1px solid rgba(238,73,210,.72)!important;
 box-shadow:inset 0 0 0 1px rgba(255,255,255,.035),0 0 22px rgba(231,52,204,.12)!important;
}
.store-dashboard .dashboard-stat,
.store-dashboard .stat-card,
.store-dashboard .dashboard-card{
 background:linear-gradient(145deg,rgba(22,25,58,.97),rgba(24,13,39,.97))!important;
 border-color:rgba(116,105,255,.58)!important;
 box-shadow:inset 0 1px 0 rgba(255,255,255,.045),0 8px 22px rgba(0,0,0,.14)!important;
}
.store-dashboard .dashboard-quick,
.store-dashboard .dashboard-actions-wrap{
 background:radial-gradient(ellipse at 10% 0%,rgba(18,216,255,.08),transparent 55%),linear-gradient(145deg,rgba(13,18,44,.98),rgba(25,11,39,.98))!important;
 border:1px solid rgba(94,115,255,.6)!important;
 box-shadow:inset 0 1px 0 rgba(255,255,255,.04),0 10px 30px rgba(0,0,0,.2)!important;
}
.store-dashboard .dashboard-actions a{
 border-width:1px!important;border-style:solid!important;border-radius:19px!important;
 box-shadow:inset 0 1px 0 rgba(255,255,255,.13),0 7px 16px rgba(0,0,0,.16)!important;
 transition:filter .16s ease,transform .16s ease!important;
}
.store-dashboard .dashboard-actions a[href*="my-keys"]{
 background:linear-gradient(115deg,rgba(0,179,123,.96),rgba(0,83,81,.98))!important;border-color:rgba(51,255,190,.86)!important;
}
.store-dashboard .dashboard-actions a[href*="deposit.php"]{
 background:linear-gradient(115deg,rgba(0,159,255,.98),rgba(29,56,172,.98))!important;border-color:rgba(51,216,255,.9)!important;
}
.store-dashboard .dashboard-actions a[href*="history.php"]{
 background:linear-gradient(115deg,rgba(189,111,0,.98),rgba(104,48,17,.98))!important;border-color:rgba(255,190,62,.9)!important;
}
.store-dashboard .dashboard-actions a[href*="profile.php"]{
 background:linear-gradient(115deg,rgba(143,0,205,.98),rgba(83,24,151,.98))!important;border-color:rgba(238,91,255,.86)!important;
}
/* All four Quick Access icons use the actual matching PNG artwork, at a uniform readable size. */
.store-dashboard .dashboard-actions .qa-image-icon,
.store-dashboard .dashboard-actions .xt-wallet-add-icon{
 display:inline-flex!important;align-items:center!important;justify-content:center!important;
 flex:0 0 44px!important;width:44px!important;height:44px!important;min-width:44px!important;min-height:44px!important;
 padding:0!important;margin:0!important;background:none!important;background-image:none!important;
 border:0!important;border-radius:0!important;filter:drop-shadow(0 2px 7px rgba(0,0,0,.22))!important;overflow:visible!important;
}
.store-dashboard .dashboard-actions .qa-image-icon img,
.store-dashboard .dashboard-actions .xt-wallet-add-icon img{
 display:block!important;visibility:visible!important;opacity:1!important;
 width:42px!important;height:42px!important;max-width:42px!important;max-height:42px!important;
 object-fit:contain!important;object-position:center!important;background:transparent!important;
 border:0!important;border-radius:0!important;margin:0!important;padding:0!important;filter:none!important;
}
.store-dashboard .dashboard-actions .qa-label{font-weight:900!important;letter-spacing:.15px!important;text-shadow:0 1px 5px rgba(0,0,0,.22)!important}
.store-dashboard .dashboard-actions .qa-arrow{background:rgba(5,12,31,.18)!important;box-shadow:inset 0 0 0 1px rgba(255,255,255,.1)!important}
@media(max-width:600px){
 .store-dashboard .dashboard-actions .qa-image-icon,.store-dashboard .dashboard-actions .xt-wallet-add-icon{flex-basis:38px!important;width:38px!important;height:38px!important;min-width:38px!important;min-height:38px!important}
 .store-dashboard .dashboard-actions .qa-image-icon img,.store-dashboard .dashboard-actions .xt-wallet-add-icon img{width:37px!important;height:37px!important;max-width:37px!important;max-height:37px!important}
 .store-dashboard .dashboard-actions a{border-radius:17px!important}
}
@media(max-width:380px){
 .store-dashboard .dashboard-actions .qa-image-icon,.store-dashboard .dashboard-actions .xt-wallet-add-icon{flex-basis:32px!important;width:32px!important;height:32px!important;min-width:32px!important;min-height:32px!important}
 .store-dashboard .dashboard-actions .qa-image-icon img,.store-dashboard .dashboard-actions .xt-wallet-add-icon img{width:31px!important;height:31px!important;max-width:31px!important;max-height:31px!important}
}

</style>


<style id="xtreme-dashboard-only-finish-v13">
/* V13: apply the requested premium treatment to the actual dashboard panel only.
   Product listing cards and other pages are deliberately not targeted. */
.store-dashboard .dashboard-balance{
  background:radial-gradient(circle at 8% 100%,rgba(16,216,255,.12),transparent 38%),linear-gradient(135deg,#10142e 0%,#21102f 58%,#10152f 100%)!important;
  border:2px solid rgba(255,64,205,.86)!important;
  box-shadow:0 0 0 1px rgba(44,220,255,.14),0 0 26px rgba(255,45,198,.16),inset 0 0 22px rgba(98,76,180,.16)!important;
}
.store-dashboard .dashboard-stat:nth-child(1){background:linear-gradient(135deg,rgba(4,75,69,.62),rgba(19,17,47,.97))!important;border:1px solid rgba(40,238,178,.62)!important}
.store-dashboard .dashboard-stat:nth-child(2){background:linear-gradient(135deg,rgba(78,22,78,.56),rgba(19,17,47,.97))!important;border:1px solid rgba(239,76,198,.58)!important}
.store-dashboard .dashboard-stat:nth-child(3){background:linear-gradient(135deg,rgba(83,59,18,.5),rgba(19,17,47,.97))!important;border:1px solid rgba(255,194,69,.58)!important}
.store-dashboard .dashboard-stat:nth-child(4){background:linear-gradient(135deg,rgba(73,28,104,.52),rgba(19,17,47,.97))!important;border:1px solid rgba(182,90,255,.62)!important}
.store-dashboard .dashboard-quick{background:radial-gradient(ellipse at 0% 0%,rgba(25,204,255,.08),transparent 48%),linear-gradient(145deg,rgba(16,19,47,.98),rgba(24,10,38,.98))!important;border:1px solid rgba(111,115,255,.72)!important;box-shadow:0 0 24px rgba(100,74,255,.1),inset 0 1px 0 rgba(255,255,255,.05)!important}
.store-dashboard .dashboard-actions a[href="my-keys.php"]{background:linear-gradient(115deg,#00a878,#064f4d)!important;border-color:#35f2b7!important}
.store-dashboard .dashboard-actions a[href="deposit.php"]{background:linear-gradient(115deg,#078fe9,#183c9c)!important;border-color:#35d8ff!important}
.store-dashboard .dashboard-actions a[href="history.php"]{background:linear-gradient(115deg,#b87912,#71330f)!important;border-color:#ffc24e!important}
.store-dashboard .dashboard-actions a[href="profile.php"]{background:linear-gradient(115deg,#a000cf,#59158b)!important;border-color:#ed62ff!important}
.store-dashboard .dashboard-actions .qa-image-icon,
.store-dashboard .dashboard-actions .xt-wallet-add-icon{width:46px!important;height:46px!important;min-width:46px!important;min-height:46px!important;flex-basis:46px!important;display:inline-flex!important;align-items:center!important;justify-content:center!important}
.store-dashboard .dashboard-actions .qa-image-icon img,
.store-dashboard .dashboard-actions .xt-wallet-add-icon img{width:44px!important;height:44px!important;max-width:44px!important;max-height:44px!important;object-fit:contain!important;display:block!important;visibility:visible!important;opacity:1!important}
.store-dashboard .dashboard-actions .qa-label{font-size:clamp(13px,3.6vw,17px)!important;font-weight:950!important;line-height:1.22!important}
.store-dashboard .dashboard-actions .qa-arrow{width:31px!important;height:31px!important;min-width:31px!important;border:2px solid rgba(255,255,255,.94)!important;border-radius:50%!important;display:inline-flex!important;align-items:center!important;justify-content:center!important;color:#fff!important}
@media(max-width:600px){.store-dashboard .dashboard-actions .qa-image-icon,.store-dashboard .dashboard-actions .xt-wallet-add-icon{width:40px!important;height:40px!important;min-width:40px!important;min-height:40px!important;flex-basis:40px!important}.store-dashboard .dashboard-actions .qa-image-icon img,.store-dashboard .dashboard-actions .xt-wallet-add-icon img{width:39px!important;height:39px!important;max-width:39px!important;max-height:39px!important}}

/* V16 true fix: target the actual dashboard balance and top-up pseudo-icons, after all legacy CSS. */
.store-dashboard .dashboard-balance{position:relative!important;padding-left:24px!important;}
.store-dashboard .dashboard-balance:before{content:""!important;display:block!important;position:absolute!important;left:24px!important;top:72px!important;width:76px!important;height:62px!important;margin:0!important;float:none!important;font-size:0!important;line-height:0!important;background-image:url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='100' height='82' viewBox='0 0 100 82'%3E%3Cdefs%3E%3ClinearGradient id='c' x1='0' y1='0' x2='0' y2='1'%3E%3Cstop stop-color='%23fff18b'/%3E%3Cstop offset='1' stop-color='%23f4a900'/%3E%3C/linearGradient%3E%3ClinearGradient id='b' x1='0' y1='0' x2='1' y2='1'%3E%3Cstop stop-color='%2300e6ff'/%3E%3Cstop offset='1' stop-color='%23005cff'/%3E%3C/linearGradient%3E%3C/defs%3E%3Ccircle cx='31' cy='23' r='17' fill='url(%23c)' stroke='%23fff19a' stroke-width='2'/%3E%3Ccircle cx='52' cy='25' r='17' fill='url(%23c)' stroke='%23ffd84a' stroke-width='2'/%3E%3Cpath d='M10 37 Q10 32 16 32 H67 Q73 32 73 38 V43 H83 Q91 43 91 51 V61 Q91 68 83 68 H72 V74 H17 Q10 74 10 67 Z' fill='url(%23b)' stroke='%2349eaff' stroke-width='3'/%3E%3Cpath d='M72 46 H84 Q91 46 91 53 V59 Q91 65 84 65 H72' fill='%230b8cff' stroke='%2349eaff' stroke-width='3'/%3E%3Ccircle cx='81' cy='55' r='3' fill='%23b7ffff'/%3E%3C/svg%3E")!important;background-position:center!important;background-size:contain!important;background-repeat:no-repeat!important;filter:drop-shadow(0 0 8px rgba(0,205,255,.55))!important;z-index:4!important;}

.store-dashboard .dashboard-topup:before{content:""!important;display:inline-block!important;flex:0 0 40px!important;width:40px!important;height:34px!important;min-width:40px!important;max-width:40px!important;margin:0 9px 0 0!important;padding:0!important;font-size:0!important;line-height:0!important;background-image:url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='100' height='82' viewBox='0 0 100 82'%3E%3Cdefs%3E%3ClinearGradient id='w' x1='0' y1='0' x2='1' y2='1'%3E%3Cstop stop-color='%2300e9ff'/%3E%3Cstop offset='1' stop-color='%23004dff'/%3E%3C/linearGradient%3E%3C/defs%3E%3Cpath d='M13 28 L34 13 H68 Q73 13 73 19 V26 H22 Q13 26 13 35 V62 Q13 69 21 69 H75 V57 H83 V72 H21 Q8 72 8 60 V38 Q8 30 13 28Z' fill='url(%23w)' stroke='%234ceaff' stroke-width='3'/%3E%3Cpath d='M20 31 H80 Q87 31 87 38 V57 Q87 63 80 63 H23 Q17 63 17 56 V38 Q17 31 20 31Z' fill='url(%23w)' stroke='%234ceaff' stroke-width='3'/%3E%3Cpath d='M77 42 H89 Q95 42 95 48 V52 Q95 58 89 58 H77' fill='%23006dff' stroke='%234ceaff' stroke-width='3'/%3E%3Ccircle cx='85' cy='50' r='3' fill='%23d4ffff'/%3E%3Ccircle cx='74' cy='15' r='13' fill='%23f8fbff' stroke='%234ceaff' stroke-width='3'/%3E%3Cpath d='M74 8 V22 M67 15 H81' stroke='%234f55ff' stroke-width='4' stroke-linecap='round'/%3E%3C/svg%3E")!important;background-position:center!important;background-size:contain!important;background-repeat:no-repeat!important;border:0!important;border-radius:0!important;box-shadow:none!important;filter:drop-shadow(0 0 7px rgba(0,205,255,.5))!important;vertical-align:middle!important;}
.store-dashboard .dashboard-topup{display:inline-flex!important;align-items:center!important;justify-content:center!important;gap:6px!important;}
@media(max-width:600px){.store-dashboard .dashboard-balance:before{left:15px!important;top:53px!important;width:55px!important;height:47px!important}.store-dashboard .dashboard-balance-value{margin-left:62px!important}.store-dashboard .dashboard-topup:before{flex-basis:30px!important;width:30px!important;height:28px!important;min-width:30px!important;max-width:30px!important;margin-right:5px!important}}
@media(max-width:380px){.store-dashboard .dashboard-balance:before{left:11px!important;top:51px!important;width:45px!important;height:39px!important}.store-dashboard .dashboard-balance-value{margin-left:51px!important}}

/* V18: Use the exact same cyan wallet icon in both Dashboard and Store balance/Add Funds areas. */
.store-dashboard .dashboard-balance:before{
 content:""!important;display:block!important;position:absolute!important;
 left:24px!important;top:54px!important;width:68px!important;height:58px!important;
 margin:0!important;float:none!important;font-size:0!important;line-height:0!important;
 background:url("assets/nav-icons/wallet-cyan-reference.png?v=18") center/contain no-repeat!important;
 filter:drop-shadow(0 0 8px rgba(0,205,255,.55))!important;z-index:4!important;
}
.store-dashboard .dashboard-balance-value{position:relative!important;z-index:5!important;margin-left:82px!important}
.store-dashboard .dashboard-actions a[href*="deposit.php"] .xt-wallet-add-icon,
.store-dashboard .dashboard-actions a[href*="deposit.php"] .qa-icon{
 display:inline-flex!important;align-items:center!important;justify-content:center!important;
 width:46px!important;height:46px!important;min-width:46px!important;min-height:46px!important;
 flex:0 0 46px!important;background:url("assets/nav-icons/wallet-cyan-reference.png?v=18") center/contain no-repeat!important;
 background-color:transparent!important;border:0!important;border-radius:0!important;box-shadow:none!important;
 font-size:0!important;line-height:0!important;filter:drop-shadow(0 0 7px rgba(0,205,255,.42))!important;
}

.store-dashboard .dashboard-topup:before{
 content:""!important;display:inline-block!important;flex:0 0 40px!important;width:40px!important;height:34px!important;
 min-width:40px!important;max-width:40px!important;margin:0 9px 0 0!important;padding:0!important;
 background:url("assets/nav-icons/wallet-cyan-reference.png?v=18") center/contain no-repeat!important;
 border:0!important;border-radius:0!important;box-shadow:none!important;font-size:0!important;line-height:0!important;
 filter:drop-shadow(0 0 7px rgba(0,205,255,.5))!important;vertical-align:middle!important;
}
@media(max-width:600px){
 .store-dashboard .dashboard-balance:before{left:15px!important;top:53px!important;width:52px!important;height:45px!important}
 .store-dashboard .dashboard-balance-value{margin-left:62px!important}
 .store-dashboard .dashboard-actions a[href*="deposit.php"] .xt-wallet-add-icon,
 .store-dashboard .dashboard-actions a[href*="deposit.php"] .qa-icon{width:39px!important;height:39px!important;min-width:39px!important;min-height:39px!important;flex-basis:39px!important}
 .store-dashboard .dashboard-topup:before{flex-basis:30px!important;width:30px!important;height:28px!important;min-width:30px!important;max-width:30px!important;margin-right:5px!important}
}
@media(max-width:380px){
 .store-dashboard .dashboard-balance:before{left:11px!important;top:51px!important;width:43px!important;height:38px!important}
 .store-dashboard .dashboard-balance-value{margin-left:51px!important}
 .store-dashboard .dashboard-actions a[href*="deposit.php"] .xt-wallet-add-icon,
 .store-dashboard .dashboard-actions a[href*="deposit.php"] .qa-icon{width:32px!important;height:32px!important;min-width:32px!important;min-height:32px!important;flex-basis:32px!important}
}
</style>


<style id="xtreme-dashboard-balance-fit-v19-from-v18">
/* V19 based directly on the original V18 archive. Keep this final block after legacy overrides. */
.store-dashboard .dashboard-balance{position:relative!important;min-width:0!important;}
.store-dashboard .dashboard-balance:before{
  content:""!important;display:block!important;position:absolute!important;
  left:18px!important;top:34px!important;width:88px!important;height:76px!important;
  margin:0!important;float:none!important;font-size:0!important;line-height:0!important;
  background-image:url("assets/nav-icons/wallet-cyan-reference.png?v=19")!important;
  background-position:center!important;background-size:contain!important;background-repeat:no-repeat!important;
  filter:drop-shadow(0 0 9px rgba(0,205,255,.58))!important;z-index:4!important;
}
.store-dashboard .dashboard-balance-value{
  position:relative!important;z-index:5!important;margin-left:96px!important;
  min-width:0!important;max-width:100%!important;white-space:nowrap!important;
  overflow-wrap:normal!important;word-break:normal!important;
  font-size:clamp(21px,5.8vw,37px)!important;line-height:1.08!important;
  letter-spacing:-.045em!important;font-weight:1000!important;
}
.store-dashboard .dashboard-topup{
  min-width:0!important;max-width:168px!important;padding:0 10px!important;
  gap:4px!important;font-size:clamp(10px,2.7vw,13px)!important;
  letter-spacing:0!important;white-space:nowrap!important;justify-self:end!important;
  overflow:hidden!important;
}
.store-dashboard .dashboard-topup:before{
  content:""!important;display:inline-block!important;flex:0 0 25px!important;
  width:25px!important;height:25px!important;min-width:25px!important;max-width:25px!important;
  margin:0 3px 0 0!important;padding:0!important;
  background:url("assets/nav-icons/wallet-cyan-reference.png?v=19") center/contain no-repeat!important;
  border:0!important;border-radius:0!important;box-shadow:none!important;
}
.store-dashboard .dashboard-actions a[href*="deposit.php"] .xt-wallet-add-icon,
.store-dashboard .dashboard-actions a[href*="deposit.php"] .qa-icon{
  display:inline-flex!important;align-items:center!important;justify-content:center!important;
  width:50px!important;height:48px!important;min-width:50px!important;min-height:48px!important;
  flex:0 0 50px!important;background:transparent!important;background-image:none!important;
}
.store-dashboard .dashboard-actions a[href*="deposit.php"] .xt-wallet-add-icon:before,
.store-dashboard .dashboard-actions a[href*="deposit.php"] .qa-icon:before{
  content:""!important;display:block!important;width:50px!important;height:48px!important;
  background:url("assets/nav-icons/wallet-cyan-reference.png?v=19") center/contain no-repeat!important;
  filter:drop-shadow(0 0 7px rgba(0,205,255,.48))!important;
}
.store-dashboard .dashboard-actions a[href*="deposit.php"] .xt-wallet-add-icon img,
.store-dashboard .dashboard-actions a[href*="deposit.php"] .qa-icon img{display:none!important}
@media(max-width:600px){
  .store-dashboard .dashboard-balance{grid-template-columns:minmax(0,1fr) auto!important;padding-left:12px!important;padding-right:10px!important;column-gap:7px!important}
  .store-dashboard .dashboard-balance:before{left:10px!important;top:34px!important;width:70px!important;height:62px!important}
  .store-dashboard .dashboard-balance-value{margin-left:72px!important;font-size:clamp(20px,5.5vw,29px)!important;letter-spacing:-.05em!important}
  .store-dashboard .dashboard-topup{max-width:138px!important;padding:0 7px!important;font-size:10px!important;min-height:42px!important;gap:3px!important}
  .store-dashboard .dashboard-topup:before{flex-basis:22px!important;width:22px!important;height:22px!important;min-width:22px!important;max-width:22px!important;margin-right:1px!important}
  .store-dashboard .dashboard-actions a[href*="deposit.php"] .xt-wallet-add-icon,
  .store-dashboard .dashboard-actions a[href*="deposit.php"] .qa-icon{width:48px!important;height:46px!important;min-width:48px!important;min-height:46px!important;flex-basis:48px!important}
  .store-dashboard .dashboard-actions a[href*="deposit.php"] .xt-wallet-add-icon:before,
  .store-dashboard .dashboard-actions a[href*="deposit.php"] .qa-icon:before{width:48px!important;height:46px!important}
}
@media(max-width:390px){
  .store-dashboard .dashboard-balance:before{left:8px!important;top:35px!important;width:62px!important;height:55px!important}
  .store-dashboard .dashboard-balance-value{margin-left:63px!important;font-size:clamp(18px,5.1vw,23px)!important;letter-spacing:-.055em!important}
  .store-dashboard .dashboard-topup{max-width:122px!important;padding:0 5px!important;font-size:9px!important}
  .store-dashboard .dashboard-topup:before{flex-basis:19px!important;width:19px!important;height:20px!important;min-width:19px!important;max-width:19px!important;margin-right:1px!important}
}
</style>


<style id="xtreme-v21-dashboard-polish">
/* V21: Use the supplied purple diamond logo for the Active Key dashboard stat. */
.store-dashboard .dashboard-stat:nth-child(4)::before,
html[data-theme] .store-dashboard .dashboard-stat:nth-child(4)::before{
  content:""!important;
  width:44px!important;height:44px!important;min-width:44px!important;
  background-image:url("assets/nav-icons/active-key-diamond.png?v=21")!important;
  background-position:center!important;background-repeat:no-repeat!important;
  background-size:contain!important;background-color:transparent!important;
  border:0!important;border-radius:0!important;box-shadow:none!important;
  filter:drop-shadow(0 0 7px rgba(151,70,255,.25))!important;
}
/* Keep the four Quick Access buttons premium, but lighter and less saturated/dark. */
.store-dashboard .dashboard-actions a,
html[data-theme] .store-dashboard .dashboard-actions a{
  box-shadow:inset 0 1px 0 rgba(255,255,255,.16),0 5px 14px rgba(0,0,0,.10)!important;
  border-width:1px!important;
}
.store-dashboard .dashboard-actions a:nth-child(1),
html[data-theme] .store-dashboard .dashboard-actions a:nth-child(1){
  background:linear-gradient(135deg,rgba(16,185,129,.42),rgba(20,145,112,.30))!important;
  border-color:rgba(52,211,153,.78)!important;
}
.store-dashboard .dashboard-actions a:nth-child(2),
html[data-theme] .store-dashboard .dashboard-actions a:nth-child(2){
  background:linear-gradient(135deg,rgba(14,165,233,.42),rgba(37,99,235,.32))!important;
  border-color:rgba(56,189,248,.78)!important;
}
.store-dashboard .dashboard-actions a:nth-child(3),
html[data-theme] .store-dashboard .dashboard-actions a:nth-child(3){
  background:linear-gradient(135deg,rgba(245,158,11,.40),rgba(217,119,6,.30))!important;
  border-color:rgba(251,191,36,.78)!important;
}
.store-dashboard .dashboard-actions a:nth-child(4),
html[data-theme] .store-dashboard .dashboard-actions a:nth-child(4){
  background:linear-gradient(135deg,rgba(168,85,247,.42),rgba(147,51,234,.32))!important;
  border-color:rgba(216,180,254,.76)!important;
}
.store-dashboard .dashboard-actions a .qa-label{color:#f8faff!important}
</style>

<style id="xtreme-v22-active-key-icon-sizing">
/* V22: Make the supplied Active Key diamond smaller and give its label/count breathing room. */
.store-dashboard .dashboard-stat:nth-child(4)::before,
html[data-theme] .store-dashboard .dashboard-stat:nth-child(4)::before{
  width:34px!important;height:34px!important;min-width:34px!important;
  background-size:contain!important;
}
.store-dashboard .dashboard-stat:nth-child(4),
html[data-theme] .store-dashboard .dashboard-stat:nth-child(4){
  padding-left:70px!important;
}
@media(max-width:600px){
  .store-dashboard .dashboard-stat:nth-child(4)::before,
  html[data-theme] .store-dashboard .dashboard-stat:nth-child(4)::before{
    width:31px!important;height:31px!important;min-width:31px!important;
  }
  .store-dashboard .dashboard-stat:nth-child(4),
  html[data-theme] .store-dashboard .dashboard-stat:nth-child(4){padding-left:61px!important}
}
@media(max-width:390px){
  .store-dashboard .dashboard-stat:nth-child(4),
  html[data-theme] .store-dashboard .dashboard-stat:nth-child(4){padding-left:57px!important}
}
</style>

<style id="xtreme-v23-active-key-icon-slightly-larger">
.store-dashboard .dashboard-stat:nth-child(4)::before,html[data-theme] .store-dashboard .dashboard-stat:nth-child(4)::before{width:39px!important;height:39px!important;min-width:39px!important;background-size:contain!important}
.store-dashboard .dashboard-stat:nth-child(4),html[data-theme] .store-dashboard .dashboard-stat:nth-child(4){padding-left:73px!important}
@media(max-width:600px){.store-dashboard .dashboard-stat:nth-child(4)::before,html[data-theme] .store-dashboard .dashboard-stat:nth-child(4)::before{width:36px!important;height:36px!important;min-width:36px!important}.store-dashboard .dashboard-stat:nth-child(4),html[data-theme] .store-dashboard .dashboard-stat:nth-child(4){padding-left:65px!important}}
@media(max-width:390px){.store-dashboard .dashboard-stat:nth-child(4),html[data-theme] .store-dashboard .dashboard-stat:nth-child(4){padding-left:61px!important}}
</style>
