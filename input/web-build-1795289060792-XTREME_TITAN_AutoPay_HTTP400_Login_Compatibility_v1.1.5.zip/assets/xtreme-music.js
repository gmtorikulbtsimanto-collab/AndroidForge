(function(){
'use strict';
var cfg=document.currentScript;
var enabled=!!(cfg && cfg.dataset.enabled==='1');
var src=(cfg && cfg.dataset.src)||'uploads/music/xtreme-background.m4a';
if(!enabled || !src) return;

/*
 * Reliable multi-page playback recovery:
 * - remember playback intent and position between customer pages
 * - retry after iOS Safari returns from background / screen lock
 * - never override an explicit user mute
 * Audible autoplay is still subject to browser gesture policies.
 */
var intentKey='xt_music_wants_play_v3';
var muteKey='xt_music_muted_v1';
var posKey='xt_music_pos_v3';
var muted=false, wantsPlay=true, userStarted=false, retryTimer=null, lastSave=0;
try {
  muted=localStorage.getItem(muteKey)==='1';
  wantsPlay=sessionStorage.getItem(intentKey)!=='0';
  userStarted=sessionStorage.getItem('xt_music_unlocked_v3')==='1';
} catch(e) {}

var audio=new Audio();
audio.src=src;
audio.preload='auto';
audio.loop=true;
audio.volume=.42;
audio.muted=muted;
audio.playsInline=true;
audio.setAttribute('playsinline','');
audio.setAttribute('webkit-playsinline','');

var player=document.createElement('button');
player.type='button';
player.className='xt-music-toggle';
player.setAttribute('aria-label',muted?'Unmute background music':'Mute background music');
player.title='Background music — tap to mute or unmute';
player.innerHTML='<span class="xt-music-icon" aria-hidden="true"><svg viewBox="0 0 24 24" focusable="false"><path d="M9 18V5l12-2v13M9 10l12-2M5.5 21a3.5 2.5 0 1 0 0-5 3.5 2.5 0 0 0 0 5Zm12-2a3.5 2.5 0 1 0 0-5 3.5 2.5 0 0 0 0 5Z"/></svg></span><span class="xt-music-state">'+(muted?'MUTED':'MUSIC')+'</span>';

function safeStore(store,key,value){try{store.setItem(key,String(value));}catch(e){}}
function update(){
  player.classList.toggle('is-muted',audio.muted);
  player.querySelector('.xt-music-state').textContent=audio.muted?'MUTED':'MUSIC';
  player.setAttribute('aria-label',audio.muted?'Unmute background music':'Mute background music');
  player.title=audio.muted?'Background music muted — tap to unmute':'Background music — tap to mute';
}
function mount(){
  if(document.body && !player.isConnected) document.body.appendChild(player);
}
if(document.readyState==='loading') document.addEventListener('DOMContentLoaded',mount,{once:true});
else mount();

function savePosition(){
  if(!Number.isFinite(audio.currentTime)) return;
  safeStore(sessionStorage,posKey,audio.currentTime);
  lastSave=Date.now();
}
function restorePosition(){
  var saved=0;
  try{saved=parseFloat(sessionStorage.getItem(posKey)||'0');}catch(e){}
  if(saved>0 && Number.isFinite(saved)){
    try{if(Math.abs(audio.currentTime-saved)>2) audio.currentTime=saved;}catch(e){}
  }
}
audio.addEventListener('loadedmetadata',restorePosition);

function playNow(fromGesture){
  if(!wantsPlay) return;
  if(fromGesture){
    userStarted=true;
    safeStore(sessionStorage,'xt_music_unlocked_v3','1');
  }
  try{
    var result=audio.play();
    if(result && typeof result.then==='function'){
      result.then(function(){
        player.classList.remove('needs-tap');
        update();
      }).catch(function(){
        player.classList.add('needs-tap');
      });
    }
  }catch(e){player.classList.add('needs-tap');}
}
function scheduleRecovery(){
  if(!wantsPlay || audio.muted || document.hidden) return;
  if(retryTimer) return;
  retryTimer=setTimeout(function(){
    retryTimer=null;
    if(wantsPlay && audio.paused && !document.hidden && userStarted) playNow(false);
  },900);
}

/* Restore saved time before attempting playback on each customer page. */
restorePosition();
playNow(false);

player.addEventListener('click',function(e){
  e.preventDefault();
  e.stopPropagation();
  if(audio.paused){
    wantsPlay=true;
    audio.muted=false;
    safeStore(sessionStorage,intentKey,'1');
    safeStore(localStorage,muteKey,'0');
    playNow(true);
  }else{
    audio.muted=!audio.muted;
    safeStore(localStorage,muteKey,audio.muted?'1':'0');
    if(!audio.muted){
      wantsPlay=true;
      safeStore(sessionStorage,intentKey,'1');
      playNow(true);
    }
  }
  update();
});

/* First real interaction unlocks audio where the browser permits it. */
function unlock(){
  if(!wantsPlay) return;
  userStarted=true;
  safeStore(sessionStorage,'xt_music_unlocked_v3','1');
  if(audio.paused) playNow(true);
  document.removeEventListener('pointerdown',unlock,true);
  document.removeEventListener('touchstart',unlock,true);
  document.removeEventListener('keydown',unlock,true);
}
document.addEventListener('pointerdown',unlock,true);
document.addEventListener('touchstart',unlock,true);
document.addEventListener('keydown',unlock,true);

/* iOS can suspend audio when the app is backgrounded or the screen locks. */
document.addEventListener('visibilitychange',function(){
  if(document.hidden){savePosition();return;}
  restorePosition();
  if(wantsPlay && userStarted && audio.paused) playNow(false);
});
window.addEventListener('pageshow',function(){
  restorePosition();
  if(wantsPlay && userStarted && audio.paused) playNow(false);
});
window.addEventListener('focus',function(){
  if(wantsPlay && userStarted && audio.paused) playNow(false);
});
window.addEventListener('online',function(){
  if(wantsPlay && userStarted && audio.paused) playNow(false);
});
audio.addEventListener('pause',function(){
  savePosition();
  if(wantsPlay && userStarted && !document.hidden) scheduleRecovery();
});
audio.addEventListener('stalled',scheduleRecovery);
audio.addEventListener('waiting',scheduleRecovery);
audio.addEventListener('error',function(){player.classList.add('needs-tap');});
window.addEventListener('pagehide',savePosition);
window.addEventListener('beforeunload',savePosition);
setInterval(savePosition,1200);
update();

/* Button click tones are scoped to the requested customer pages only. */
var AudioCtx=window.AudioContext||window.webkitAudioContext,ctx=null,seq=0;
function sectionFor(){
 var p=(location.pathname||'').toLowerCase();
 if(/(?:store|dashboard)\.php$/.test(p))return 0;
 if(/my-?keys\.php$/.test(p))return 1;
 if(/deposit\.php$/.test(p))return 2;
 if(/history\.php$/.test(p))return 3;
 if(/profile\.php$/.test(p))return 4;
 return -1;
}
function clickTone(el){
 var section=sectionFor();if(!AudioCtx||section<0||el===player||el.closest('.xt-music-toggle'))return;
 try{
  if(!ctx)ctx=new AudioCtx();if(ctx.state==='suspended')ctx.resume();
  var label=(el.getAttribute('aria-label')||el.getAttribute('title')||el.innerText||el.value||el.id||'button').trim().toLowerCase();
  var hash=0;for(var i=0;i<label.length;i++)hash=(hash*31+label.charCodeAt(i))>>>0;
  var base=[520,610,700,790,880][section],freq=base+(hash%9)*23+(seq++%2)*7;
  var osc=ctx.createOscillator(),gain=ctx.createGain();osc.type='sine';
  osc.frequency.setValueAtTime(freq,ctx.currentTime);osc.frequency.exponentialRampToValueAtTime(freq*.78,ctx.currentTime+.075);
  gain.gain.setValueAtTime(.0001,ctx.currentTime);gain.gain.exponentialRampToValueAtTime(.045,ctx.currentTime+.008);gain.gain.exponentialRampToValueAtTime(.0001,ctx.currentTime+.095);
  osc.connect(gain);gain.connect(ctx.destination);osc.start();osc.stop(ctx.currentTime+.1);
 }catch(e){}
}
document.addEventListener('pointerdown',function(e){var el=e.target.closest('a,button,[role="button"],[onclick],input[type="submit"],input[type="button"],summary');if(el)clickTone(el);},{capture:true,passive:true});
})();