XTREME TITAN LANGUAGE PATCH V7
Purpose: extend existing client-side translation dictionary for the country-selected languages while preserving markup, CSS, product media, and animations.
Updated: language-client.js and its cache-busting version references.
After uploading, hard-refresh the site or clear Safari website cache so language-client.js?v=20261022-ui-fix2 loads.
Note: Google account chooser behavior still depends on Google Identity Services and the configured OAuth client/origin; test the login/register flow on the live domain.
