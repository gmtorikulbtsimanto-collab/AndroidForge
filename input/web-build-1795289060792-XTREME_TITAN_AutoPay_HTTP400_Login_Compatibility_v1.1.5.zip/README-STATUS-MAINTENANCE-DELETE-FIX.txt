Extreme Titan Official — Status / Maintenance / Product Delete patch

Changes:
- A product marked Maintenance now shows an English warning dialog when Purchase Key is tapped.
- Cancel closes the dialog and leaves the user on the Store.
- Continue opens that product's plans and purchase controls.
- SAFE / RISK / UPDATING / TESTING badges show a pulsing dot animation.
- Admin product deletion asks for confirmation, displays a 3-2-1 deleting countdown, and deletes product keys and plans before deleting the product.

Important:
- Deleting a product also deletes all rows in user_keys for that product, including available/assigned keys. Back up your database before using DELETE PRODUCT.
- Upload the ZIP contents over the existing site files without deleting uploads/assets. Keep your existing config.php/database credentials.
