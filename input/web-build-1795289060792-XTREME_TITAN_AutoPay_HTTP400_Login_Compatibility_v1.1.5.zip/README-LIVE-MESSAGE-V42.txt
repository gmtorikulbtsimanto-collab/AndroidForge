XTREME TITAN OFFICIAL — Live Message + Floating Launcher update

Files added:
- messages.php
- admin/messages.php

Files updated:
- store.php (Live Message shortcut + animated fixed bottom-left launcher and timed popup)
- admin/dashboard.php (admin Live Messages entry)

What it does:
- User and admin can privately message each other through a database-backed conversation.
- Messages show timestamps in the viewer's local timezone.
- New messages are polled about every 2.5 seconds.
- Store has a small animated chat bubble icon fixed at the bottom-left.
- A “LIVE CHAT” caption is shown beside it.
- A popup appears after page load and then repeats on the configured interval.
- Admin can configure popup interval (60–7200 seconds), display duration (3–15 seconds), and popup text in Admin > Live Messages.
- The support_messages and support_chat_settings tables are created automatically if the database account has CREATE TABLE permission.

Installation:
1. Back up your current website files and database.
2. Upload/extract this ZIP into the website root, preserving folders and allowing updated files to replace old versions.
3. Keep your existing config.php and database credentials; this package retains the config.php from the uploaded ZIP.
4. Sign in as a normal user and open the Live Message launcher.
5. Sign in as admin and open Admin > Live Messages to reply and set popup timing.

Note:
The chat uses PHP polling rather than WebSockets. Server/database operation must be tested on the live hosting account. This ZIP has not been tested against the live database.
