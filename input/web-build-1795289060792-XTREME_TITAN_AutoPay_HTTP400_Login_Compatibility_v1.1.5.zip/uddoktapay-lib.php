<?php
// UddoktaPay integration helpers for XTREME TITAN.
require_once __DIR__ . '/config.php';

function xt_uddokta_settings_table(): void {
    db()->exec("CREATE TABLE IF NOT EXISTS uddoktapay_settings (
        id TINYINT UNSIGNED NOT NULL PRIMARY KEY,
        base_url VARCHAR(255) NOT NULL,
        api_key_enc TEXT NULL,
        enabled TINYINT(1) NOT NULL DEFAULT 0,
        updated_at DATETIME NOT NULL
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    db()->exec("INSERT IGNORE INTO uddoktapay_settings
        (id,base_url,api_key_enc,enabled,updated_at)
        VALUES (1,'https://xtremetitanofficial.paymently.io',NULL,0,UTC_TIMESTAMP())");
}
function xt_uddokta_crypto_key(): string {
    return hash('sha256', DB_NAME . '|' . DB_USER . '|' . DB_PASS . '|XTREME-TITAN-UDDOKTAPAY-v1', true);
}
function xt_uddokta_encrypt(string $plain): string {
    if ($plain === '') return '';
    if (!function_exists('openssl_encrypt')) throw new RuntimeException('OpenSSL is required to save the API key securely.');
    $iv = random_bytes(12); $tag = '';
    $cipher = openssl_encrypt($plain, 'aes-256-gcm', xt_uddokta_crypto_key(), OPENSSL_RAW_DATA, $iv, $tag);
    if ($cipher === false) throw new RuntimeException('Could not encrypt the API key.');
    return base64_encode($iv . $tag . $cipher);
}
function xt_uddokta_decrypt(?string $encoded): string {
    if (!$encoded) return '';
    $raw = base64_decode($encoded, true);
    if ($raw === false || strlen($raw) < 29 || !function_exists('openssl_decrypt')) return '';
    $plain = openssl_decrypt(substr($raw,28), 'aes-256-gcm', xt_uddokta_crypto_key(), OPENSSL_RAW_DATA, substr($raw,0,12), substr($raw,12,16));
    return $plain === false ? '' : $plain;
}
function xt_uddokta_config(): array {
    xt_uddokta_settings_table();
    $r = db()->query('SELECT * FROM uddoktapay_settings WHERE id=1')->fetch(PDO::FETCH_ASSOC) ?: [];
    $base = rtrim((string)($r['base_url'] ?? 'https://xtremetitanofficial.paymently.io'), '/');
    if (!preg_match('~^https://[a-z0-9.-]+(?::\d+)?$~i', $base)) $base = '';
    return ['base_url'=>$base,'api_key'=>xt_uddokta_decrypt($r['api_key_enc'] ?? null),'enabled'=>(int)($r['enabled'] ?? 0) === 1];
}
function xt_uddokta_api(string $endpoint, array $payload): array {
    $cfg = xt_uddokta_config();
    if (!$cfg['enabled'] || $cfg['api_key'] === '' || $cfg['base_url'] === '') {
        throw new RuntimeException('UddoktaPay is not configured. Open Admin → UddoktaPay Settings and save an active API key.');
    }
    if (!function_exists('curl_init')) throw new RuntimeException('PHP cURL extension is not enabled on this hosting account.');
    $url = $cfg['base_url'] . '/api/' . ltrim($endpoint,'/');
    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER=>true, CURLOPT_POST=>true,
        CURLOPT_POSTFIELDS=>json_encode($payload, JSON_UNESCAPED_SLASHES),
        CURLOPT_HTTPHEADER=>['Accept: application/json','Content-Type: application/json','RT-UDDOKTAPAY-API-KEY: '.$cfg['api_key']],
        CURLOPT_CONNECTTIMEOUT=>15, CURLOPT_TIMEOUT=>35,
        CURLOPT_SSL_VERIFYPEER=>true, CURLOPT_SSL_VERIFYHOST=>2
    ]);
    $body = curl_exec($ch); $err = curl_error($ch); $code = (int)curl_getinfo($ch,CURLINFO_HTTP_CODE); curl_close($ch);
    if ($body === false) throw new RuntimeException('Payment provider connection failed: ' . $err);
    $data = json_decode((string)$body, true);
    if (!is_array($data)) throw new RuntimeException('Payment provider returned an unreadable response (HTTP '.$code.').');
    if ($code < 200 || $code >= 300 || (array_key_exists('status',$data) && $data['status'] === false)) {
        $msg = trim((string)($data['message'] ?? ''));
        throw new RuntimeException($msg !== '' ? 'UddoktaPay: '.$msg : 'Payment provider rejected the request (HTTP '.$code.').');
    }
    return $data;
}
function xt_uddokta_ensure_deposit_columns(): void {
    $pdo=db(); $cols=$pdo->query('SHOW COLUMNS FROM deposits')->fetchAll(PDO::FETCH_COLUMN);
    $defs=['currency_code'=>'VARCHAR(10) NULL','amount_bdt'=>'DECIMAL(14,2) NULL','source_role'=>'VARCHAR(20) NULL','deposit_country'=>'VARCHAR(8) NULL','uddoktapay_invoice_id'=>'VARCHAR(100) NULL'];
    foreach($defs as $col=>$def) if(!in_array($col,$cols,true)) $pdo->exec("ALTER TABLE deposits ADD COLUMN `$col` $def");
    try { $pdo->exec("CREATE UNIQUE INDEX uq_deposits_uddokta_invoice ON deposits (uddoktapay_invoice_id)"); } catch (Throwable $ignore) {}
}
function xt_uddokta_complete_invoice(string $invoiceId): bool {
    $invoiceId = trim($invoiceId);
    if ($invoiceId === '' || strlen($invoiceId)>100) return false;
    xt_uddokta_ensure_deposit_columns();
    $verify = xt_uddokta_api('verify-payment',['invoice_id'=>$invoiceId]);
    if (strtoupper((string)($verify['status'] ?? '')) !== 'COMPLETED') return false;
    $pdo=db();
    $st=$pdo->prepare('SELECT * FROM deposits WHERE uddoktapay_invoice_id=? LIMIT 1');
    $st->execute([$invoiceId]); $dep=$st->fetch(PDO::FETCH_ASSOC);
    if (!$dep || strtolower((string)$dep['payment_method']) !== 'uddoktapay') return false;
    $expected=(float)$dep['amount']; $paid=(float)($verify['amount'] ?? $verify['charged_amount'] ?? 0);
    if ($paid <= 0 || abs($paid-$expected) > 0.009) return false;
    $meta=$verify['metadata'] ?? [];
    if (is_array($meta)) {
        if (isset($meta['user_id']) && (int)$meta['user_id'] !== (int)$dep['user_id']) return false;
        if (isset($meta['deposit_id']) && (int)$meta['deposit_id'] !== (int)$dep['id']) return false;
    }
    $txn=(string)($verify['transaction_id'] ?? $invoiceId);
    $pdo->beginTransaction();
    try {
        $lock=$pdo->prepare('SELECT id,user_id,amount,status FROM deposits WHERE id=? FOR UPDATE');
        $lock->execute([(int)$dep['id']]); $row=$lock->fetch(PDO::FETCH_ASSOC);
        if (!$row) { $pdo->commit(); return false; }
        $current=strtolower((string)$row['status']);
        if ($current !== 'pending') { $pdo->commit(); return $current === 'approved'; }
        $up=$pdo->prepare("UPDATE deposits SET status='approved', transaction_id=? WHERE id=? AND status='pending'");
        $up->execute([$txn,(int)$row['id']]);
        $credited=false;
        if ($up->rowCount() === 1) {
            $wallet=$pdo->prepare("INSERT INTO wallet_transactions (user_id,type,amount,description,created_at) VALUES (?,'deposit',?,?,UTC_TIMESTAMP())");
            $wallet->execute([(int)$row['user_id'],number_format((float)$row['amount'],2,'.',''),'UddoktaPay payment completed · Invoice '.$invoiceId.' · TXN '.$txn]);
            $credited=true;
        }
        $pdo->commit();
        if($credited){
            try{require_once __DIR__.'/topup-lib.php';xt_user_notification_tables();xt_user_notify((int)$row['user_id'],'deposit_approved','Deposit completed','Your automatic deposit #'.(int)$row['id'].' has been verified and your wallet was credited with ৳'.number_format((float)$row['amount'],2).'.','history.php?tab=deposit');}catch(Throwable $noticeError){error_log('UddoktaPay customer notification: '.$noticeError->getMessage());}
        }
        return true;
    } catch(Throwable $e) { if($pdo->inTransaction())$pdo->rollBack(); throw $e; }
}
