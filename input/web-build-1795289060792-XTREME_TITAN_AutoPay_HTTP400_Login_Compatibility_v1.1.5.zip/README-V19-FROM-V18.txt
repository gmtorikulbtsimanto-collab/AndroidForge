XTREME TITAN — V19 (based directly on original V18)

Changes in store.php only:
- Enlarged and raised Balance wallet icon.
- Increased Quick Access Add Funds icon size.
- Shortened Add Funds button.
- Reduced balance amount font responsively to help larger values fit.

This ZIP preserves the original V18 archive's root-level structure; it does not wrap all files in a v18/ or v19/ directory.

Install: back up the current website, then extract/overwrite files into the same website directory. The wallet icon asset is at assets/nav-icons/wallet-cyan-reference.png.
