<?php
require_once __DIR__ . '/config.php';
require_login();
ensure_account_role_columns();
if (current_user_role() !== 'reseller') { header('Location: store.php'); exit; }
header('Location: store.php');
exit;
