XTREME TITAN — Auth Country / Google Sign-in Preference Patch

Included changes:
- Login and registration Google buttons first open a six-region selector (Bangladesh, India, Nepal, Bhutan, Vietnam, Other).
- The selected region sets local country/currency/language values before Google sign-in. Google Identity Services is loaded with the closest supported UI locale after selection.
- Username/password login saves the selected region, currency, and language to the signed-in account.
- Google login saves the same values to the existing/new account before redirecting to dashboard.php.
- The login page has a region selector so password-based login can use the same country preference.
- Registration's secure-register subtitle has translations for the supported registration languages.

Install:
1. Back up the current website files and database.
2. Extract this ZIP and upload/overwrite the files while preserving their folders.
3. Clear browser cache or use a private tab for testing.
4. Test each region on register.php, then test Google sign-in and username/password login. Confirm the user's currency/language in Preferences and across the dashboard.

Important:
- The Google Identity Services button itself is Google's hosted UI. Its displayed language follows Google's supported locale selection and may fall back to English for languages Google does not support (for example Dzongkha).
- Existing product names, descriptions, and custom content are not automatically translated. The site's translation dictionaries determine which UI labels change.
- Live hosting/database behavior cannot be fully verified without deploying to the user's host.
