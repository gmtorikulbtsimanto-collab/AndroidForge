<?php
require_once __DIR__ . '/config.php';
require_login();
ensure_key_reset_tables();
$userId = (int)($_SESSION['user_id'] ?? 0);
$purchaseFlash = (string)($_SESSION['purchase_flash'] ?? '');
unset($_SESSION['purchase_flash']);
$keys=[];$error='';
$deviceToken = (string)($_COOKIE['xtreme_device_token'] ?? '');
if (!preg_match('/^[a-f0-9]{64}$/', $deviceToken)) {
    $deviceToken = bin2hex(random_bytes(32));
    setcookie('xtreme_device_token', $deviceToken, [
        'expires'=>time()+31536000, 'path'=>'/', 'secure'=>(!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS']!=='off'), 'httponly'=>true, 'samesite'=>'Lax'
    ]);
}

function h($v):string{return htmlspecialchars((string)$v,ENT_QUOTES,'UTF-8');}
try{
 $pdo=db();
 try { $pdo->exec("ALTER TABLE product_plans ADD COLUMN duration_seconds INT NULL"); } catch(Throwable $ignore) {}
 try { $pdo->exec("UPDATE product_plans SET duration_seconds = CASE WHEN duration_days < 0 THEN ABS(duration_days)*3600 ELSE duration_days*86400 END WHERE duration_seconds IS NULL"); } catch(Throwable $ignore) {}
 try { $pdo->exec("ALTER TABLE user_keys ADD COLUMN duration_seconds INT NULL"); } catch(Throwable $ignore) {}
 try { $pdo->exec("SET time_zone = '+00:00'"); } catch(Throwable $ignore) {}
 $stmt=$pdo->prepare("SELECT uk.id,uk.license_key,uk.product_id,uk.plan_id,uk.price,uk.purchased_at,uk.device_token,
 COALESCE(cp.name,'Product') product_name,COALESCE(cp.description,'') product_description,COALESCE(pp.duration_label,CONCAT(pp.duration_days,' Days'),'Plan') plan_name,COALESCE(uk.duration_seconds,pp.duration_seconds,CASE WHEN pp.duration_days < 0 THEN ABS(pp.duration_days)*3600 ELSE COALESCE(pp.duration_days,0)*86400 END,0) duration_seconds, COALESCE(pp.duration_days,0) duration_days
 FROM user_keys uk LEFT JOIN catalog_products cp ON cp.id=uk.product_id LEFT JOIN product_plans pp ON pp.id=uk.plan_id AND pp.product_id=uk.product_id
 WHERE uk.user_id=? ORDER BY uk.purchased_at DESC,uk.id DESC");
 $stmt->execute([$userId]);$keys=$stmt->fetchAll(PDO::FETCH_ASSOC);
 // Bind each key to the current browser/device the first time it is viewed.
 // Admin-approved Reset Key clears this token without touching purchased_at.
 $bind=$pdo->prepare("UPDATE user_keys SET device_token=? WHERE id=? AND user_id=? AND (device_token IS NULL OR device_token='')");
 foreach($keys as &$kk){
     $kk['device_locked']=false;
     $kk['device_is_current']=true;
     if(empty($kk['device_token'])){ $bind->execute([$deviceToken,(int)$kk['id'],$userId]); $kk['device_token']=$deviceToken; }
     elseif(!hash_equals((string)$kk['device_token'],$deviceToken)){ $kk['device_locked']=true; $kk['device_is_current']=false; }
 }
 unset($kk);
}catch(Throwable $e){$error='Unable to load your keys right now.';}
?>
<!doctype html><html lang="en"><head>
<link rel="stylesheet" href="theme.php?v=20261022-lightfix3"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no,viewport-fit=cover">
<title>My Keys - XTREME_TITAN_OFFICIAL SHOP</title><link rel="stylesheet" href="reference-theme.css?v=20261022-lightfix2">
<style>
.page{max-width:900px;margin:auto;padding:24px 14px 30px}.key-product-info{display:flex;align-items:center;min-width:0;flex:1}.key-product-title{display:flex;align-items:center;gap:10px;min-width:0;width:100%;min-height:66px;padding:8px 12px;border:1px solid color-mix(in srgb,var(--ui-accent,#18d9ff) 38%,#64748b);border-radius:22px;background:color-mix(in srgb,var(--ui-panel,#111827) 92%,transparent);box-shadow:0 5px 18px rgba(0,0,0,.08);box-sizing:border-box}.key-product-logo{display:block;flex:0 0 38px;width:38px;height:38px;object-fit:cover;border-radius:10px;border:1px solid color-mix(in srgb,var(--ui-accent,#18d9ff) 42%,#64748b);box-shadow:0 4px 14px rgba(0,0,0,.16);background:var(--ui-panel,#111827)}.key-product-copy{min-width:0;flex:1;text-align:center}.key-product-name{font-size:17px;font-weight:900;line-height:1.3;overflow-wrap:anywhere;color:var(--ui-text,#f8fafc)}.eyebrow{color:#12e58e;font-size:11px;font-weight:900;letter-spacing:.1em}h1{font-size:38px;margin:6px 0}.muted{color:#9aa9bf}.list{display:grid;gap:14px;margin-top:20px}.key-card{padding:18px}.row{display:flex;justify-content:space-between;gap:12px}.product{font-size:17px;font-weight:900}.price{color:#12e58e;font-weight:900}.meta{color:#91a2b8;font-size:11px;margin-top:6px}.key{margin-top:13px;padding:13px;background:#070d17;border:1px dashed rgba(16,216,255,.38);border-radius:14px;font-family:monospace;font-size:13px;word-break:break-all;color:#dfffd3}.key-actions{display:flex;gap:8px;align-items:center;margin-top:10px;flex-wrap:wrap}.copy-btn{border:0;border-radius:11px;padding:10px 13px;background:#168bff;color:#fff;font-weight:900;cursor:pointer}.countdown{font-size:11px;font-weight:900;color:#ffb20d}.countdown.expired{color:#ff6178}.empty{text-align:center;padding:50px 18px}.empty b{display:block;font-size:21px;color:#fff;margin-bottom:7px}.device-status{font-size:10px;font-weight:900;padding:7px 9px;border-radius:999px}.device-status.active{color:#63ff16;background:rgba(99,255,22,.08)}.device-status.locked{color:#ffb20d;background:rgba(255,178,13,.08)}.reset-link{font-size:10px;font-weight:900;color:#10d8ff;text-decoration:none;padding:7px 9px;border:1px solid rgba(16,216,255,.22);border-radius:999px}
@media(max-width:600px){.row{align-items:flex-start}.page{padding-top:20px}h1{font-size:34px}.key-product-logo{width:34px;height:34px;flex-basis:34px;border-radius:9px}.key-product-title{gap:8px;padding:8px 10px;min-height:62px;border-radius:20px}.key-product-name{font-size:15px}}
</style><link rel="stylesheet" href="site-polish.css?v=20261022-lightfix3">
<script src="theme-client.js?v=20260928-19" defer></script><link rel="stylesheet" href="premium-global.css?v=20261022-lightfix3"><script src="currency-client.js?v=20261018-fx1" defer></script><script src="language-client.js?v=20261023-full-language-v50" defer></script><script src="preference-sync.js?v=20260928-20" defer></script><link rel="stylesheet" href="responsive-lock.css?v=20260929-28">

<link rel="icon" type="image/png" sizes="48x48" href="/assets/pwa-icon-48.png">
<link rel="apple-touch-icon" sizes="180x180" href="/assets/pwa-icon-180.png">
<link rel="manifest" href="/pwa-manifest.json">
<meta name="apple-mobile-web-app-title" content="XTREME TITAN">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="mobile-web-app-capable" content="yes">
<meta name="theme-color" content="#080a14">
<script src="/admin/admin-action-progress.js?v=20261023-inline-progress25" defer></script>

<style id="xt-global-header-logo-unified-v29">
/* One consistent site-header logo and title scale on every customer page */
header.top, header.topbar {
  box-sizing:border-box!important;
  width:100%!important;
  min-height:0!important;
  height:auto!important;
  padding:14px 14px 16px!important;
  margin:0 auto!important;
  display:flex!important;
  align-items:center!important;
  justify-content:center!important;
  text-align:center!important;
}
header.top .brand-with-logo, header.topbar .brand-with-logo {
  box-sizing:border-box!important;
  width:100%!important;
  max-width:100%!important;
  display:flex!important;
  flex-direction:column!important;
  align-items:center!important;
  justify-content:center!important;
  gap:7px!important;
  margin:0 auto!important;
  text-align:center!important;
}
header.top .header-logo, header.topbar .header-logo {
  display:block!important;
  box-sizing:border-box!important;
  width:46px!important;height:46px!important;
  min-width:46px!important;min-height:46px!important;
  max-width:46px!important;max-height:46px!important;
  flex:0 0 46px!important;
  object-fit:contain!important;object-position:center!important;
  background:transparent!important;
  border:0!important;padding:0!important;margin:0 auto!important;
  border-radius:10px!important;
}
header.top .brand-text, header.topbar .top-title {
  display:block!important;
  max-width:100%!important;
  margin:0 auto!important;padding:0!important;
  text-align:center!important;
  font-size:clamp(17px,4.6vw,25px)!important;
  line-height:1.2!important;
  font-weight:900!important;
  letter-spacing:0!important;
  overflow-wrap:anywhere!important;
}
header.topbar .xt-dashboard-tagline {
  margin:0 auto!important;
  text-align:center!important;
  line-height:1.2!important;
}
@media(max-width:420px) {
  header.top,header.topbar{padding:12px 10px 14px!important}
  header.top .header-logo,header.topbar .header-logo {
    width:46px!important;height:46px!important;min-width:46px!important;min-height:46px!important;
    max-width:46px!important;max-height:46px!important;flex-basis:46px!important;
  }
}
</style>
<link rel="stylesheet" href="assets/xtreme-music.css?v=3">

<link rel="stylesheet" href="assets/xtreme-bottom-nav.css?v=20261117-border-v11">
</head><body>
<?php require __DIR__ . '/customer-wallet-header.php'; ?>
<main class="page"><div class="eyebrow">MY KEYS</div><h1>My Keys</h1><p class="muted">Your purchased license keys are shown here.</p>
<?php if($purchaseFlash !== ''): ?><div class="alert" role="status" style="border:1px solid #38bdf8!important;background:rgba(14,165,233,.16)!important;color:#bae6fd!important;padding:13px 15px;border-radius:13px;margin:14px 0;font-weight:800;"><?=h($purchaseFlash)?></div><?php endif; ?>
<?php if($error): ?><div class="alert"><?=h($error)?></div><?php endif; ?>
<?php if(!$keys): ?><div class="empty card"><b>🔐 No Keys Found</b>No digital keys are available under this view. Grab a key from the store.</div>
<?php else: ?><div class="list">
<?php foreach($keys as $k): $ts=utc_epoch_from_db($k['purchased_at']);$durationSeconds=(int)($k['duration_seconds']??0);$expiry=$durationSeconds>0?($ts+$durationSeconds):0;$id=(int)$k['id'];$productImage='';if(preg_match('/^\s*\[IMAGE\]\s*(.+?)\s*$/mi',(string)($k['product_description']??''),$imageMatch)){$productImage=trim($imageMatch[1]);if(!filter_var($productImage,FILTER_VALIDATE_URL)&&!preg_match('~^(?:/)?(?:uploads/product-media|media)/[A-Za-z0-9._/-]+$~',$productImage))$productImage='';} ?>
<article class="key-card">
<div class="row"><div class="key-product-info"><div class="key-product-title"><?php if($productImage!==''): ?><img class="key-product-logo" src="<?=h($productImage)?>" alt="" loading="lazy" referrerpolicy="no-referrer"><?php endif; ?><div class="key-product-copy"><div class="key-product-name"><?=h($k['product_name'])?></div><div class="meta"><?=h($k['plan_name'])?><?= $durationSeconds>0?' · '.h($k['plan_name']):'' ?></div></div></div></div><div class="price"><span data-currency-amount="<?=h((float)$k['price'])?>"><?=h(number_format((float)$k['price'],2))?></span></div></div>
<div class="key" id="key-<?=$id?>"><?=h($k['license_key'])?></div>
<div class="meta">Purchased: <span class="local-time" data-ts="<?=$ts?>"></span></div>
<div class="key-actions"><button type="button" class="copy-btn" onclick="copyKey(<?=$id?>,this)">📋 Copy Key</button><?php if($durationSeconds>0): ?><span class="countdown" data-expiry="<?=$expiry?>">Calculating…</span><?php endif; ?><?php if(!empty($k['device_locked'])): ?><span class="device-status locked">🔒 Different device — Reset required</span><a class="reset-link" href="profile.php#reset-key">Request Reset</a><?php else: ?><span class="device-status active">✓ Device active</span><?php endif; ?></div>
</article>
<?php endforeach; ?></div><?php endif; ?></main>
<nav class="xt-bottom-navigation-card" aria-label="Main navigation">
<a href="store.php" data-nav="store" aria-label="Store"><span class="xt-nav-icon"><img src="assets/nav-icons/store.png" alt="" aria-hidden="true"></span><span class="xt-nav-label">Store</span></a>
<a href="my-keys.php" class="is-active" data-nav="keys" aria-label="My Keys"><span class="xt-nav-icon"><img src="assets/nav-icons/keys.png" alt="" aria-hidden="true"></span><span class="xt-nav-label">My Keys</span></a>
<a href="deposit.php" data-nav="funds" aria-label="Add Funds"><span class="xt-nav-icon"><img src="assets/nav-icons/funds.png" alt="" aria-hidden="true"></span><span class="xt-nav-label">Add Funds</span></a>
<a href="history.php" data-nav="history" aria-label="History"><span class="xt-nav-icon"><img src="assets/nav-icons/history.png" alt="" aria-hidden="true"></span><span class="xt-nav-label">History</span></a>
<a href="profile.php" data-nav="profile" aria-label="Profile"><span class="xt-nav-icon"><img src="assets/nav-icons/profile.png" alt="" aria-hidden="true"></span><span class="xt-nav-label">Profile</span></a>
</nav>
<script>
function formatLocal(ts){const f=new Intl.DateTimeFormat(undefined,{day:'2-digit',month:'short',year:'numeric',hour:'2-digit',minute:'2-digit',second:'2-digit',hour12:true});const p=f.formatToParts(new Date(ts*1000));const g=k=>p.find(x=>x.type===k)?.value||'';return `${g('day')} ${g('month')} ${g('year')} at ${g('hour')}:${g('minute')}:${g('second')} ${g('dayPeriod')}`;}
document.querySelectorAll('.local-time').forEach(e=>e.textContent=formatLocal(Number(e.dataset.ts)));
function updateCountdown(){const now=Math.floor(Date.now()/1000);document.querySelectorAll('.countdown').forEach(e=>{let left=Number(e.dataset.expiry)-now;if(left<=0){e.textContent='⛔ Expired';e.classList.add('expired');return;}const d=Math.floor(left/86400);left%=86400;const h=Math.floor(left/3600);left%=3600;const m=Math.floor(left/60);const sec=left%60;e.textContent='⏳ Expires in '+(d>0?d+'d ':'')+String(h).padStart(2,'0')+'h '+String(m).padStart(2,'0')+'m '+String(sec).padStart(2,'0')+'s';});}updateCountdown();setInterval(updateCountdown,1000);
async function copyKey(id,btn){const text=document.getElementById('key-'+id).textContent.trim();try{await navigator.clipboard.writeText(text);}catch(e){const ta=document.createElement('textarea');ta.value=text;document.body.appendChild(ta);ta.select();document.execCommand('copy');ta.remove();}const old=btn.textContent;btn.textContent='✅ Copied!';setTimeout(()=>btn.textContent=old,1500);}
</script><script src="background-video.js?v=20261018-starfall2"></script>





































<script src="assets/xtreme-music.js?v=3" data-enabled="<?=e(site_setting('background_music_enabled','1'))?>" data-src="<?=e(site_setting('background_music_path','uploads/music/xtreme-background.m4a'))?>" defer></script>
</body></html>
