XTREME TITAN DASHBOARD ICON TRUE FIX V16

Fixes the actual dashboard pseudo-elements in store.php after all previous CSS rules. Replaces the balance wallet artwork and the top-up/Add Funds button icon with inline SVG artwork. Does not change balance or payment logic.

Upload/replace store.php in the same site folder, then hard-refresh/clear browser cache.
