XTREME TITAN — STORE REDESIGN + DYNAMIC TOP-UP + HISTORY PATCH
==============================================================

This is a targeted patch for the ZIP you uploaded. It is NOT a full-site ZIP.

FILES TO UPLOAD
---------------
Upload these paths into the website htdocs root, preserving folders and replacing existing files:

topup-lib.php
topup.php
history.php
store.php
store-redesign.css
language-client.js
history-category-lib.php
admin/dashboard.php
admin/topup-products.php
admin/topup-orders.php

WHAT IT ADDS
------------
1. Store visual refresh for existing product cards, filters, plans, buy buttons and dashboard.
2. A Gaming Top-Up & Services entry section on Store.
3. Dynamic Top-Up product manager in Admin:
   - Product name, category, category slug, image, amount/package label, price, min/max quantity, sort order, active/hidden.
   - Categories automatically become History filters.
4. Customer Top-Up page at topup.php:
   - Choose product, enter Player UID / optional Server ID and quantity.
   - The order amount is deducted from the user's existing approved-deposit wallet balance.
   - A pending topup request is created for Admin fulfillment.
5. Admin Top-Up Requests:
   - Processing / Completed / Rejected.
   - Reject automatically refunds the wallet ledger amount.
6. History:
   - Top-up requests appear with their actual category and current order status.
   - Top-up wallet-ledger rows are excluded from the normal key-purchase list to prevent duplicates.
   - Existing key countdowns are not changed.
7. Five-tab navigation icons on Store and History are constrained to compact 30px images in a 70px bar, and active state no longer enlarges them.
8. New customer-facing labels/product names use the existing language-client dynamic translation mechanism when a supported user language is selected. Translation depends on the browser reaching the external MyMemory translation service; if that service is unavailable, original text remains.

ADMIN LINKS
-----------
Admin Dashboard -> Quick Actions:
- Gaming Top-Up Products
- Top-Up Requests

Create your packages at Admin > Gaming Top-Up Products.
Review and fulfill customer orders at Admin > Top-Up Requests.

IMPORTANT BEHAVIOR
------------------
- This patch creates manual-fulfillment top-up requests. It does NOT connect to Free Fire or any game's official delivery API. Admin must deliver the purchased service and then mark the order Completed.
- It uses the site's existing wallet accounting: approved deposits minus user_purchases. A top-up request creates a ledger purchase and is therefore charged from wallet balance.
- If an order is Rejected, the ledger charge is set to zero to refund the wallet. Do not manually delete topup_orders or user_purchases rows.
- A completed or rejected order is final in this admin screen.
- Do not upload this patch over an unbacked-up site. Make a full hosting backup and database backup first.
- Test with a low-value test account before production.

SECURITY
--------
Your uploaded source archive contained live database, SMTP and web-push credentials in config.php. This patch does not include config.php and does not expose those values again. Rotate those credentials in the hosting/provider dashboards because they were included in a chat upload. Do not send API keys or passwords in screenshots.

VALIDATION
----------
Changed PHP files passed `php -l` syntax checks. The topup page inline JavaScript and language-client.js passed Node syntax checks. A live database/payment test was not possible from this patch build, so verify on staging or with a test user before production.
