<?php
require_once __DIR__ . '/config.php';
if (!isset($_SESSION['user_id'])) { header('Location: login.php'); exit; }
$id=(int)$_SESSION['user_id'];$error='';$message='';
$s=db()->prepare('SELECT name,email,phone,password_hash FROM users WHERE id=? LIMIT 1');$s->execute([$id]);$u=$s->fetch();
if($_SERVER['REQUEST_METHOD']==='POST'){
$email=trim($_POST['email']??'');$current=$_POST['current_password']??'';
if(!filter_var($email,FILTER_VALIDATE_EMAIL))$error='Enter a valid email address.';
elseif($email!==$u['email']&&!password_verify($current,$u['password_hash']))$error='Enter your current password to change email.';
else{try{$s=db()->prepare('SELECT id FROM users WHERE email=? AND id<>? LIMIT 1');$s->execute([$email,$id]);if($s->fetch())$error='That email is already in use.';else{$s=db()->prepare('UPDATE users SET email=? WHERE id=?');$s->execute([$email,$id]);$u['email']=$email;$message='Email updated successfully.';}}catch(Throwable $e){$error='Could not update email.';}}
}
?>
<!doctype html><html lang="en"><head>
<link rel="stylesheet" href="theme.php?v=20261022-lightfix3"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no"><title>Account Settings — XTREME_TITAN_OFFICIAL SHOP</title><link rel="stylesheet" href="style.css"><link rel="stylesheet" href="reference-theme.css">
<link rel="stylesheet" href="site-polish.css?v=20261022-lightfix3">
<script src="theme-client.js?v=20260928-19" defer></script><link rel="stylesheet" href="premium-global.css?v=20261022-lightfix3"><script src="currency-client.js?v=20261018-fx1" defer></script><script src="language-client.js?v=20261023-full-language-v50" defer></script><script src="preference-sync.js?v=20260928-20" defer></script><link rel="stylesheet" href="responsive-lock.css?v=20260929-28">

<link rel="icon" type="image/png" sizes="48x48" href="/assets/pwa-icon-48.png">
<link rel="apple-touch-icon" sizes="180x180" href="/assets/pwa-icon-180.png">
<link rel="manifest" href="/pwa-manifest.json">
<meta name="apple-mobile-web-app-title" content="XTREME TITAN">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="mobile-web-app-capable" content="yes">
<meta name="theme-color" content="#080a14">
<script src="/admin/admin-action-progress.js?v=20261023-inline-progress25" defer></script>

</head><body><div class="app"><aside class="sidebar" id="sidebar">
<div class="side-brand"><img class="header-logo" src="assets/xtreme-titan-logo.jpg" alt="XTREME TITAN"><span>XTREME_TITAN_OFFICIAL <b>SHOP</b></span></div>
<div class="nav-title">MAIN MENU</div><nav class="nav"><a href="store.php" aria-label="Store"><span class="nav-ico nav-svg-icon"><img class="xt-nav-image" src="assets/nav-icons/store.png" alt="" aria-hidden="true"></span><span>Store</span></a><a href="my-keys.php" aria-label="My Keys"><span class="nav-ico nav-svg-icon"><img class="xt-nav-image" src="assets/nav-icons/keys.png" alt="" aria-hidden="true"></span><span>My Keys</span></a><a href="deposit.php" aria-label="Add Funds"><span class="nav-ico nav-svg-icon"><img class="xt-nav-image" src="assets/nav-icons/funds.png" alt="" aria-hidden="true"></span><span>Add Funds</span></a><a href="history.php" aria-label="History"><span class="nav-ico nav-svg-icon"><img class="xt-nav-image" src="assets/nav-icons/history.png" alt="" aria-hidden="true"></span><span>History</span></a><a href="profile.php" aria-label="Profile"><span class="nav-ico nav-svg-icon"><img class="xt-nav-image" src="assets/nav-icons/profile.png" alt="" aria-hidden="true"></span><span>Profile</span></a></nav><div class="side-bottom"><a class="logout" href="logout.php">🚪 Logout</a></div></aside>
<section class="main"><header class="topbar"><button class="menu-btn" onclick="document.getElementById('sidebar').classList.toggle('open')">☰</button><div></div><div class="top-user"><div class="avatar"><?=htmlspecialchars($u['name']??'U',ENT_QUOTES,'UTF-8')?></div></div></header>
<main class="content"><div class="eyebrow">SETTINGS</div><h1>Account Settings</h1><p class="muted">Manage your email address and account details.</p><div class="card form-card">
<?php if($error):?><div class="alert error"><?=htmlspecialchars($error)?></div><?php endif;?>
<?php if($message):?><div class="alert success"><?=htmlspecialchars($message)?></div><?php endif;?>
<form method="post"><label>Email / Gmail</label><input name="email" type="email" required value="<?=htmlspecialchars($u['email'])?>"><label>Current password</label><input name="current_password" type="password" placeholder="Required when changing email"><button type="submit">Update Email</button></form></div></main><footer>© <?=date('Y')?> XTREME_TITAN_OFFICIAL SHOP</footer></section></div><script>document.querySelectorAll('.nav a').forEach(a=>a.addEventListener('click',()=>document.getElementById('sidebar').classList.remove('open')));</script>
</body></html>
<link rel="stylesheet" href="assets/xtreme-bottom-nav.css?v=20261117-canonical-all-pages-v5">
