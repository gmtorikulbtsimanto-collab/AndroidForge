XTREME TITAN Dashboard CSS patch v33
- Reapplies reference-style neon icons and gradients without requiring html[data-theme].
- Keeps Quick Access buttons compact (about 54-56px minimum height on mobile).
- Keeps purchase warning PHP logic unchanged.
- Only store.php dashboard presentation styles were appended.
