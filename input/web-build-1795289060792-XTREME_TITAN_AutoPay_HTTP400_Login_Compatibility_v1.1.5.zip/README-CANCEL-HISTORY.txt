XTREME TITAN — HISTORY CANCEL PATCH

Upload/overwrite these files into htdocs root:
- history.php
- uddoktapay-cancel.php

Behavior:
- The Paymently/UddoktaPay "Cancel and return to merchant" link marks the matching pending UddoktaPay deposit as cancelled and sends the user directly to history.php?tab=deposit.
- Transaction History shows a Cancel button only for pending UddoktaPay deposits that do not yet have an invoice_id.
- Cancel uses POST + CSRF and only changes the logged-in user's own pending UddoktaPay deposit.
- A cancelled deposit is not credited to the wallet.
- Deposits with an invoice_id are not manually cancelable from history to avoid canceling a payment that may already have been submitted for verification.

Payment method options:
The checkout screenshot shows the provider checkout page loaded, but no payment methods are configured/displayed. That list is controlled by the Paymently/UddoktaPay merchant gateway configuration, not by the website's HTML/PHP. In the Paymently admin dashboard, check Gateways and enable/activate the desired automatic or bank gateways (for example bKash/Nagad), check gateway status and amount limits, and save. If no gateways are available/enabled, contact Paymently support and send them the screenshot. Do not send API keys.

Note: Closing the browser or force-quitting Safari cannot reliably trigger a website redirect. The hosted checkout's own "Cancel and return to merchant" action will use cancel_url and return the user to History. If the user simply closes the tab, they can reopen the website's History and cancel the pending row there.
