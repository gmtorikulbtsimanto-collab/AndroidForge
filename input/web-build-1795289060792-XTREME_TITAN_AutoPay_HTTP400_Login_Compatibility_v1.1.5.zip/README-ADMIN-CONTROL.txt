ADMIN CONTROL UPDATE

Open /admin/site-settings.php to change: site title, homepage text, logo, background, both decoration images, payment number, PayPal URL, Telegram URL, Discord URL, support text and footer text.

Open /admin/products.php to add a new product. Each new product automatically receives 1 Day, 7 Days, 15 Days and 30 Days plans, which can then be edited.

The two uploaded images are already installed as:
assets/decoration-1.jpg
assets/decoration-2.jpg

The old InfinityFree placeholder index2.html has been removed.

Payment controls: Admin > Site Settings lets you change separate bKash/Nagad numbers and upload replacement bKash, Nagad and PayPal logos. The supplied payment images are installed with the correct visible branding: bKash uses the pink logo image and Nagad uses the orange/red logo image.
