/* XTREME TITAN OFFICIAL PWA Service Worker
 * Deliberately does not cache dynamic pages or private account/payment data.
 */
'use strict';

self.addEventListener('install', function (event) {
  self.skipWaiting();
});

self.addEventListener('activate', function (event) {
  event.waitUntil(self.clients.claim());
});

/* Leave requests to the browser/server. This registers a worker without storing
   account pages, keys, balances, payment pages, or admin responses offline. */
self.addEventListener('fetch', function (event) {
  // Intentionally no respondWith(): normal network behavior is preserved.
});
