XTREME TITAN OFFICIAL SHOP — FINAL REPAIR PACKAGE

Upload/replace the files from this package into your existing InfinityFree htdocs folder.
IMPORTANT: config.php is intentionally NOT included. Keep your existing live config.php.

Main fixes:
- 6 compact bottom buttons: Home Shop, Store, My Keys, Deposit, History, Profile.
- Profile button no longer drops to a second row.
- Login now has Forgot Password? link and compact Google sign-in area.
- Forgot Password + Reset Password use the same clean mobile style.
- Removed the unrequested/fake XTREME logo image from the UI.
- My Keys and History display timestamps explicitly in Europe/Rome time.
- Store product-link loop is protected from undefined/mixed productLinks warnings.
- Deposit page has compact PayPal/bKash/Nagad image cards and receipt upload (JPG/PNG/WebP, max 3 MB).
- Admin dashboard rebuilt as a premium control center with sales, deposits, users, inventory and quick actions.
- Admin deposit page can display uploaded receipts when the optional receipt_path column exists/is created.
- logout.php included.

After upload:
1. Do NOT delete config.php.
2. Replace the matching PHP/CSS/assets files.
3. Open login.php in a private/incognito tab or hard-refresh once so the new CSS is loaded.

LOGO UPDATE (2026-09-22)
- Added the user-provided XTREME TITAN image as assets/xtreme-titan-logo.jpg.
- The logo is intentionally very small (about 40–44px on user-facing pages, 30–34px in headers).
- The original large uploaded image is NOT included, only a compressed web-ready copy, to keep the package small.
- Keep your existing config.php and replace the matching website files from this package.
- If an old logo still appears, hard-refresh Safari or open the site in a Private tab.
