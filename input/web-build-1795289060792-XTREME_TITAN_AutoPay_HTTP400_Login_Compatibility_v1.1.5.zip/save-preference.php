<?php
declare(strict_types=1);
require_once __DIR__.'/config.php';
require_login();
if($_SERVER['REQUEST_METHOD']!=='POST'){http_response_code(405);exit;}
$data=json_decode(file_get_contents('php://input'),true);if(!is_array($data))$data=$_POST;
$currency=strtoupper(trim((string)($data['currency']??'')));$country=strtoupper(trim((string)($data['country_code']??'')));
$allowed=['BDT'=>'BD','USD'=>'US','EUR'=>'IT','AED'=>'AE','INR'=>'IN','NPR'=>'NP','VND'=>'VN','GBP'=>'GB'];
if(!isset($allowed[$currency])){http_response_code(422);echo json_encode(['ok'=>false]);exit;}
if($country===''||!in_array($country,$allowed,true))$country=$allowed[$currency];
try{ensure_user_preference_columns();$st=db()->prepare('UPDATE users SET currency=?, country_code=? WHERE id=?');$st->execute([$currency,$country,(int)$_SESSION['user_id']]);header('Content-Type: application/json');echo json_encode(['ok'=>true]);}catch(Throwable $e){http_response_code(500);header('Content-Type: application/json');echo json_encode(['ok'=>false]);}
