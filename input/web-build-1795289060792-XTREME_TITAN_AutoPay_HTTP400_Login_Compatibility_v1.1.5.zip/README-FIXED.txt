XTREME_TITAN_OFFICIAL SHOP — FINAL FIX PACKAGE

Upload/replace the files from this package in your site root.
KEEP YOUR EXISTING config.php — do NOT overwrite it.

FIXED:
1. My Keys: buyer/browser local Purchased time.
2. My Keys: live countdown based on plan duration.
3. My Keys: Copy Key button.
4. History: buyer/browser local time.
5. History: uses deposits + user_purchases; does NOT require a transactions table.
6. History: All / Key Purchases / Deposits + time filters.
7. Background GIF applied to index/auth/member pages through the reference theme.
8. Edit Profile page added with the same background/theme.
9. Register country selector + phone input sizing fixed for mobile.
10. Store product links added without a database migration.
11. Admin > Products now has:
    - Update File Link
    - Set Up Video Link
    - Product / Download Link
    These are saved automatically and appear as clickable buttons in Store.
12. Google Login uses the Client ID already configured in login.php and does not need a Client Secret.
13. Google login endpoint includes GIS CSRF checking and server-side token verification.

PRODUCT LINKS:
In Admin > Products, enter URLs in the three link fields and click SAVE PRODUCT.
No SQL is required.

IMPORTANT:
- Keep your current config.php with your real DB/mail credentials.
- The package intentionally does not include config.php.
- Google redirect URI should remain:
  https://xtremetitanofficial.gamer.free/google-login.php

LATEST BRANDING/PAYMENT/ADMIN UPDATE
- Removed remaining "My Panel", "Account Panel", and old TANOFFICIAL PANEL branding.
- Site branding is now XTREME_TITAN_OFFICIAL SHOP.
- Payment method buttons use letter badges only: P for PayPal, B for bKash, N for Nagad. No third-party logos/images are used.
- Admin login/dashboard/products/keys/deposits use the neon XTREME_TITAN_OFFICIAL SHOP admin theme and background.
- Admin dashboard now links to Products & Plans, Key Manager, Deposit Approvals, Plan Manager, and Logout.

FINAL UI FIX: Dashboard and Store are combined. The only bottom-nav buttons are Store, My Keys, Deposit, History, Profile. Dashboard URL redirects to Store. The user-supplied XTREME TITAN logo is branding only and is never used as a large product poster. Payment logos are loaded as recognizable wordmarks/icons.
