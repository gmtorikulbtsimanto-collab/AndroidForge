XTREME TITAN AutoPay - Background SMS Sync deployment notes

1. Upload the complete website package as usual. Keep website-mobile-api next to config.php.
2. The Android app requires RECEIVE_SMS permission on the designated admin-owned phone. The full SMS body is parsed locally; only method, amount, transaction ID, sender ID and received timestamp are sent to the API.
3. The app stores parsed events in a local SQLite queue and uses Android WorkManager to retry uploads when a network is available. Periodic retry cadence is Android's minimum 15 minutes; actual execution can be delayed by Doze/battery restrictions.
4. Force Stop prevents background execution until the user launches the app again. Android OEM battery managers may also delay jobs.
5. mobile_payment_sms.transaction_id is UNIQUE. Duplicate server submissions return HTTP 409 and are treated as already received by the app queue.
6. Captured SMS is stored as unmatched. SMS text alone is not authoritative proof of payment. Do not auto-credit a wallet based only on SMS. Enable automatic credit only after implementing and validating the relevant provider's official server-side API/webhook and matching amount, merchant account, transaction ID, and settlement status.
7. Google Play restricts SMS permissions to approved core use cases. This package is intended only for the merchant's explicitly authorized device and may need sideloading or policy review.
