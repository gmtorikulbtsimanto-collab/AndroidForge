<?php
require __DIR__.'/_bootstrap.php';
try {
 $pdo=db(); ensure_account_role_columns(); xt_api_schema($pdo);
 $users=xt_api_columns($pdo,'users');
 $role=xt_api_pick($users,['role','user_role','account_type','type','is_admin']);
 $adminTable=false;
 try { xt_api_columns($pdo,'admins'); $adminTable=true; } catch(Throwable $ignore) {}
 xt_api_out(200,[
  'ok'=>true,
  'service'=>'XTREME TITAN AutoPay API',
  'version'=>'1.1.0',
  'admin_login'=>[
   'users_table_role_supported'=>(bool)$role,
   'separate_admins_table_detected'=>$adminTable
  ],
  'endpoints'=>['login'=>'POST login.php','sms_ingest'=>'POST sms-ingest.php']
 ]);
} catch(Throwable $e) {
 error_log('XT AutoPay health: '.$e->getMessage());
 xt_api_out(500,['ok'=>false,'message'=>'API database setup failed. Check the website database connection and mobile_api_tokens table permissions.']);
}
