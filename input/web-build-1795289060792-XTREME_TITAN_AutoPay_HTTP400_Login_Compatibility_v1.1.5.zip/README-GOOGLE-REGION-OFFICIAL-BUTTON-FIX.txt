XTREME TITAN — Google region flow patch

This patch keeps the selected country/currency/language flow and removes the unreliable automatic One Tap prompt after country selection. Once a country is selected, the page reveals the Google Identity Services official rendered button. Tapping that button opens Google's account chooser, and the existing credential callback posts the chosen region to google-auth.php.

Only auth-region-picker.js and cache-version strings in login.php/register.php are changed. Other files and existing design assets are preserved.

After upload, test both login and registration on the live host. Google may require a user tap to start sign-in; browsers do not reliably allow websites to force-open Google's account chooser without a user gesture.
