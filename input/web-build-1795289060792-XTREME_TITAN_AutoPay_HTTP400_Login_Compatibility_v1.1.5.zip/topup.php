<?php
require_once __DIR__.'/config.php';
require_once __DIR__.'/topup-lib.php';
require_login();
xt_topup_ensure_tables();
xt_user_notification_tables();
xt_topup_sync_history_categories();
xt_topup_admin_notification_tables();
$pdo=db(); $uid=(int)($_SESSION['user_id']??0);
if(empty($_SESSION['topup_csrf'])) $_SESSION['topup_csrf']=bin2hex(random_bytes(32));
$csrf=$_SESSION['topup_csrf']; $error=''; $success='';
if($_SERVER['REQUEST_METHOD']==='POST'){
 try{
  if(!hash_equals($csrf,(string)($_POST['csrf']??''))) throw new RuntimeException('Security verification failed. Refresh and try again.');
  $pid=(int)($_POST['product_id']??0); $qty=max(1,(int)($_POST['quantity']??1));
  $pdo->beginTransaction();
  $st=$pdo->prepare('SELECT * FROM topup_products WHERE id=? AND status=1 FOR UPDATE'); $st->execute([$pid]); $prod=$st->fetch(PDO::FETCH_ASSOC);
  if(!$prod) throw new RuntimeException('This top-up product is not available.');
  $fieldDefs=json_decode((string)($prod['custom_fields_json']??'[]'),true);if(!is_array($fieldDefs))$fieldDefs=[];
  $submitted=$_POST['custom_fields']??[];if(!is_array($submitted))$submitted=[];
  $savedFields=[];$player='';$server='';
  $serverFieldSeen=false;
  foreach($fieldDefs as $idx=>$def){
   if(!is_array($def))continue;
   $label=trim((string)($def['label']??''));
   // Keep only the first server-selection field, including Bengali labels.
   if(preg_match('/server|সার্ভার/i',$label)){
    if($serverFieldSeen)continue;
    $serverFieldSeen=true;
   }
   $type=(string)($def['type']??'text');$required=!empty($def['required']);
   $value=trim((string)($submitted[(string)$idx]??''));
   if($required&&$value==='')throw new RuntimeException('Please fill in '.$label.'.');
   if(mb_strlen($value)>150)throw new RuntimeException($label.' is too long.');
   if($type==='select'&&$value!==''&&!in_array($value,(array)($def['options']??[]),true))throw new RuntimeException('Invalid option selected for '.$label.'.');
   if($value!=='')$savedFields[]=['label'=>$label,'value'=>$value];
   if(stripos($label,'uid')!==false||stripos($label,'player')!==false)$player=$value;
   if(stripos($label,'server')!==false)$server=$value;
  }
  // Backward compatibility for older products that do not define custom fields.
  if(!$fieldDefs){$player=trim((string)($_POST['player_uid']??''));$server=trim((string)($_POST['server_id']??''));if($player===''||mb_strlen($player)>100)throw new RuntimeException('Enter a valid Player UID / Account ID.');}
  $fieldsJson=$savedFields?json_encode($savedFields,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES):null;
  if($qty<(int)$prod['min_qty'] || $qty>(int)$prod['max_qty']) throw new RuntimeException('Quantity is outside the allowed limit.');
  $unit=(float)$prod['price']; $total=round($unit*$qty,2);
  $depCols=$pdo->query('SHOW COLUMNS FROM deposits')->fetchAll(PDO::FETCH_COLUMN);
  $depExpr=in_array('amount_bdt',$depCols,true)?'SUM(COALESCE(amount_bdt,amount))':'SUM(amount)';
  $q=$pdo->prepare("SELECT COALESCE($depExpr,0) FROM deposits WHERE user_id=? AND LOWER(status)='approved'"); $q->execute([$uid]); $deposits=(float)$q->fetchColumn();
  $q=$pdo->prepare('SELECT COALESCE(SUM(total_amount),0) FROM user_purchases WHERE user_id=?'); $q->execute([$uid]); $spent=(float)$q->fetchColumn();
  $balance=$deposits-$spent;
  if($balance+0.0001<$total) throw new RuntimeException('Insufficient wallet balance. Please add funds first.');
  $now=utc_sql_now();
  $q=$pdo->prepare("INSERT INTO user_purchases (user_id,product_id,product_name,plan_name,duration_days,quantity,unit_price,total_amount,created_at) VALUES (?,0,?,'Top-Up Request',0,?,?,?,?)");
  $q->execute([$uid,'Top-Up: '.$prod['name'],$qty,$unit,$total,$now]); $purchaseId=(int)$pdo->lastInsertId();
  $topupCols=$pdo->query('SHOW COLUMNS FROM topup_orders')->fetchAll(PDO::FETCH_COLUMN);
  $topupData=['user_id'=>$uid,'product_id'=>$pid,'purchase_id'=>$purchaseId,'product_name'=>$prod['name'],'category_slug'=>$prod['category_slug'],'amount_label'=>$prod['amount_label'],'player_uid'=>$player,'server_id'=>$server,'custom_fields_json'=>$fieldsJson,'quantity'=>$qty,'unit_price'=>$unit,'total_amount'=>$total,'status'=>'pending','created_at'=>$now];
  if(in_array('order_code',$topupCols,true)) $topupData['order_code']='XTU'.gmdate('ymdHis').strtoupper(bin2hex(random_bytes(5)));
  $topupData=array_intersect_key($topupData,array_flip($topupCols));
  $topupNames=implode(',',array_map(static fn($c)=>'`'.str_replace('`','``',$c).'`',array_keys($topupData)));
  $topupMarks=implode(',',array_fill(0,count($topupData),'?'));
  $q=$pdo->prepare("INSERT INTO topup_orders ({$topupNames}) VALUES ({$topupMarks})");
  $q->execute(array_values($topupData));
  $orderId=(int)$pdo->lastInsertId();
  xt_topup_admin_notify('New Top-Up Request', 'A new request #'.$orderId.' was submitted for '.$prod['name'].' ('.$total.').', 'topup-orders.php');
  xt_user_notify($uid,'topup_submitted','Top-Up request received','Your request #'.$orderId.' for '.$prod['name'].' has been received and is waiting for processing.','history.php?tab=topup');
  $pdo->commit();
  // Optional browser push; in-panel notification above is always stored independently.
  try {
   require_once __DIR__.'/admin-push-functions.php';
   if (function_exists('xt_admin_send_push')) xt_admin_send_push('New Top-Up Request', 'Request #'.$orderId.' - '.$prod['name'], 'topup-orders.php');
  } catch (Throwable $pushError) { error_log('XT Top-Up admin push: '.$pushError->getMessage()); }
  header('Location: history.php?tab=topup&notice=topup_submitted',true,303); exit;
 }catch(Throwable $e){if($pdo->inTransaction())$pdo->rollBack();$error=$e->getMessage();}
}
$requestedCategory=trim((string)($_GET['category']??''));
if($requestedCategory!=='' && !preg_match('/^[a-z0-9][a-z0-9-]{0,59}$/',$requestedCategory)) $requestedCategory='__invalid_category__';
if($requestedCategory!=='') {
 $q=$pdo->prepare('SELECT * FROM topup_products WHERE status=1 AND category_slug=? ORDER BY sort_order,id');
 $q->execute([$requestedCategory]);
 $products=$q->fetchAll(PDO::FETCH_ASSOC);
} else {
 $products=$pdo->query('SELECT * FROM topup_products WHERE status=1 ORDER BY sort_order,id')->fetchAll(PDO::FETCH_ASSOC);
}
$categoryTitle='';
if($requestedCategory!=='') {
 $q=$pdo->prepare('SELECT category_name FROM topup_products WHERE status=1 AND category_slug=? ORDER BY sort_order,id LIMIT 1');
 $q->execute([$requestedCategory]); $categoryTitle=(string)($q->fetchColumn()?:'');
}
function th($v){return htmlspecialchars((string)$v,ENT_QUOTES,'UTF-8');}
?>
<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover,maximum-scale=1,user-scalable=no"><title>Top-Up Store · XTREME TITAN</title>
<link rel="stylesheet" href="theme.php"><link rel="stylesheet" href="reference-theme.css"><link rel="stylesheet" href="site-polish.css"><link rel="stylesheet" href="premium-global.css"><script src="theme-client.js" defer></script><script src="currency-client.js" defer></script><script src="language-client.js?v=20261114-payment-history-v4" defer></script><script src="preference-sync.js" defer></script>
<style>
*{box-sizing:border-box}body{margin:0;background:#070b18;color:#f5f7ff;font-family:Arial,sans-serif;padding-bottom:24px}.tu-wrap{max-width:980px;margin:auto;padding:18px 14px 28px}.tu-hero{padding:22px;border-radius:24px;background:radial-gradient(circle at 90% 5%,#234d86 0,transparent 35%),linear-gradient(135deg,#151b36,#0c1224 70%);border:1px solid #35456d;box-shadow:0 18px 45px #0006}.tu-kicker{color:#69e5ff;font-weight:900;font-size:10px;letter-spacing:.16em}.tu-hero h1{margin:8px 0;font-size:clamp(25px,6vw,36px)}.tu-hero p{color:#aebbd2;font-size:13px;line-height:1.5;margin:0}.tu-filters{display:flex;gap:8px;overflow:auto;padding:16px 0 12px;scrollbar-width:none}.tu-filter{white-space:nowrap;border:1px solid #2d3a58;background:#121a30;color:#b8c5dc;border-radius:13px;padding:10px 14px;font-weight:850;font-size:12px}.tu-filter.active{background:linear-gradient(120deg,#087e9c,#5543c4);border-color:#4bd7f0;color:white}.tu-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:12px}.tu-card{min-width:0;border:1px solid #293a5a;border-radius:19px;padding:12px;background:linear-gradient(145deg,#151d34,#0c1325);box-shadow:0 10px 26px #0004}.tu-card img{width:100%;height:112px;object-fit:contain;border-radius:12px;background:#0b1222}.tu-card h3{font-size:15px;margin:10px 0 4px}.tu-amount{color:#7ddfff;font-size:12px;font-weight:800}.tu-desc{color:#98a9c6;font-size:11px;line-height:1.4}.tu-price{font-size:19px;color:#5ef0c0;font-weight:950;margin:8px 0}.tu-buy{width:100%;border:0;border-radius:12px;padding:12px;background:linear-gradient(110deg,#08c9b2,#2587ff);color:#04111c;font-weight:950}.tu-empty,.tu-alert{padding:18px;border-radius:15px;background:#111a2e;border:1px solid #30415e;color:#c6d1e5;margin:12px 0}.tu-alert.err{border-color:#a94d63;color:#ffd9e0}.tu-modal{display:none;position:fixed;inset:0;background:#000b;z-index:9999;align-items:center;justify-content:center;padding:16px}.tu-modal.open{display:flex}.tu-form{width:min(440px,100%);background:#111a30;border:1px solid #405276;border-radius:20px;padding:20px}.tu-form label{display:block;margin:12px 0 6px;color:#c6d2e8;font-size:12px;font-weight:800}.tu-form input{width:100%;padding:13px;border-radius:11px;border:1px solid #3b4a68;background:#080f20;color:white;font-size:15px}.tu-actions{display:flex;gap:9px;margin-top:16px}.tu-actions button{flex:1;padding:12px;border:0;border-radius:11px;font-weight:900}.tu-cancel{background:#27344f;color:white}.tu-submit{background:#08c9b2;color:#06131d}
nav.nav{position:fixed;left:0;right:0;bottom:0;height:calc(70px + env(safe-area-inset-bottom));padding:4px 3px env(safe-area-inset-bottom);display:grid;grid-template-columns:repeat(5,minmax(0,1fr));background:#070b18f5;border-top:1px solid #263450;z-index:1000}
nav.nav>a{display:flex;flex-direction:column;align-items:center;justify-content:center;gap:2px;color:#9aa9c5;text-decoration:none;font-size:10px;font-weight:800;min-width:0}
nav.nav .nav-ico{display:flex!important;position:static!important;width:32px!important;height:32px!important;min-width:32px!important;max-width:32px!important;flex:0 0 32px!important;transform:none!important}
nav.nav img{width:30px!important;height:30px!important;object-fit:contain}
nav.nav>a.active{color:#ed72d9;background:#ed72d915;border-radius:12px}
@media(max-width:430px){.tu-grid{gap:9px}.tu-card{padding:9px}.tu-card img{height:92px}.tu-card h3{font-size:13px}.tu-wrap{padding-left:11px;padding-right:11px}}
</style></head><body>
<main class="tu-wrap"><section class="tu-hero"><div class="tu-kicker">XTREME TITAN · DIGITAL SERVICES</div><h1 data-auto-button-label="1" data-original-button-label="Gaming Top-Up &amp; Services">Gaming Top-Up &amp; Services</h1><p data-auto-button-label="1" data-original-button-label="Diamond, Likes, Weekly, Monthly and Guild Glory packages.">Diamond, Likes, Weekly, Monthly and Guild Glory packages.</p></section>
<?php if($error):?><div class="tu-alert err"><?=th($error)?></div><?php endif;?>
<?php if(!$products):?><div class="tu-empty"><?php if($requestedCategory!==''):?>No products are currently available in this category.<?php else:?>No top-up products are available yet. Please check again later.<?php endif;?></div><?php else:?>
<div class="tu-grid"><?php foreach($products as $p):?><article class="tu-card" data-category="<?=th($p['category_slug'])?>">
<?php if($p['image_path']):?><img src="<?=th($p['image_path'])?>" alt="" loading="lazy"><?php else:?><img src="assets/brand-placeholder.svg" alt="" loading="lazy"><?php endif;?>
<h3 data-auto-button-label="1" data-original-button-label="<?=th($p['name'])?>"><?=th($p['name'])?></h3><div class="tu-amount" data-auto-button-label="1" data-original-button-label="<?=th($p['amount_label'])?>"><?=th($p['amount_label'])?></div><?php if(trim((string)$p['description'])!==''):?><p class="tu-desc" data-auto-button-label="1" data-original-button-label="<?=th($p['description'])?>"><?=th($p['description'])?></p><?php endif;?><div class="tu-price" data-currency-amount="<?=th($p['price'])?>">৳<?=number_format((float)$p['price'],2)?></div>
<button class="tu-buy" type="button" data-buy="<?= (int)$p['id'] ?>" data-name="<?=th($p['name'])?>" data-min="<?= (int)$p['min_qty']?>" data-max="<?= (int)$p['max_qty']?>" data-fields="<?=th((string)($p['custom_fields_json']??'[]'))?>" data-auto-button-label="1" data-original-button-label="BUY NOW">BUY NOW</button></article><?php endforeach;?></div><?php endif;?></main>
<div class="tu-modal" id="tuModal"><form class="tu-form" method="post"><h2 id="tuTitle" data-auto-button-label="1" data-original-button-label="Place Top-Up Request">Place Top-Up Request</h2><input type="hidden" name="csrf" value="<?=th($csrf)?>"><input type="hidden" name="product_id" id="tuProduct"><div id="tuCustomFields"></div><div id="tuLegacyFields"><label data-auto-button-label="1" data-original-button-label="Player UID / Account ID">Player UID / Account ID</label><input name="player_uid" required maxlength="100" placeholder="Enter Player UID"><label data-auto-button-label="1" data-original-button-label="Server Selection">Server Selection</label><select name="server_id"><option value="">Select your server</option><option>Bangladesh</option><option>India</option><option>Indonesia</option><option>Pakistan</option><option>Brazil</option><option>Vietnam</option><option>MENA</option><option>MY / SG</option></select></div><label data-auto-button-label="1" data-original-button-label="Quantity">Quantity</label><input name="quantity" id="tuQty" type="number" min="1" value="1" required><div class="tu-actions"><button class="tu-cancel" type="button" id="tuClose" data-auto-button-label="1" data-original-button-label="Cancel">Cancel</button><button class="tu-submit" type="submit" data-auto-button-label="1" data-original-button-label="Submit Request">Submit Request</button></div></form></div>

<script>
const modal=document.getElementById('tuModal');document.querySelectorAll('[data-buy]').forEach(b=>b.addEventListener('click',()=>{document.getElementById('tuProduct').value=b.dataset.buy;document.getElementById('tuTitle').textContent=b.dataset.name;document.getElementById('tuTitle').setAttribute('data-original-button-label',b.dataset.name);const host=document.getElementById('tuCustomFields'),legacy=document.getElementById('tuLegacyFields');host.innerHTML='';let defs=[];try{defs=JSON.parse(b.dataset.fields||'[]')}catch(e){defs=[]}legacy.style.display=defs.length?'none':'';legacy.querySelectorAll('input').forEach(i=>i.required=defs.length===0&&i.name==='player_uid');// Render exactly ONE server dropdown. Reuse the first configured server field's
// index/options and ignore every other server-labelled custom field.
// If there are no custom fields, the legacy form already contains its own
// Player UID and Server Selection. Do NOT create a second dropdown in that case.
if(defs.length){
 const serverIndexes=[];defs.forEach((f,i)=>{if(/server|সার্ভার/i.test(String(f.label||'')))serverIndexes.push(i)});
 const serverIndex=serverIndexes.length?serverIndexes[0]:defs.length;
 const serverDef=serverIndexes.length?defs[serverIndex]:null;
 const serverWrap=document.createElement('div');
 const serverLabel=document.createElement('label');
 serverLabel.textContent='Server Selection *';
 const serverSelect=document.createElement('select');
 serverSelect.name='custom_fields['+serverIndex+']';
 serverSelect.required=serverDef?!!serverDef.required:true;
 const serverBlank=document.createElement('option');serverBlank.value='';serverBlank.textContent='Select your server';serverSelect.appendChild(serverBlank);
 const serverOptions=(serverDef&&Array.isArray(serverDef.options)&&serverDef.options.length)?serverDef.options:['Bangladesh','India','Indonesia','Pakistan','Brazil','Vietnam','MENA','MY / SG'];
 serverOptions.forEach(v=>{const op=document.createElement('option');op.value=v;op.textContent=v;serverSelect.appendChild(op)});
 serverWrap.appendChild(serverLabel);serverWrap.appendChild(serverSelect);host.appendChild(serverWrap);
 defs.forEach((f,i)=>{if(serverIndexes.includes(i))return;const wrap=document.createElement('div');const label=document.createElement('label');label.textContent=f.label+(f.required?' *':'');wrap.appendChild(label);let el;if(f.type==='select'){el=document.createElement('select');(Array.isArray(f.options)?f.options:[]).forEach(v=>{const op=document.createElement('option');op.value=v;op.textContent=v;el.appendChild(op)});const blank=document.createElement('option');blank.value='';blank.textContent='Select '+f.label;el.insertBefore(blank,el.firstChild)}else{el=document.createElement('input');el.type='text';el.maxLength=150;el.placeholder='Enter '+f.label}el.name='custom_fields['+i+']';el.required=!!f.required;wrap.appendChild(el);host.appendChild(wrap)});
}
if(window.XtremeLanguage)window.XtremeLanguage.apply();const q=document.getElementById('tuQty');q.min=b.dataset.min;q.max=b.dataset.max;q.value=b.dataset.min;modal.classList.add('open')}));document.getElementById('tuClose').addEventListener('click',()=>modal.classList.remove('open'));modal.addEventListener('click',e=>{if(e.target===modal)modal.classList.remove('open')});
</script></body></html>
