XTREME TITAN — Requested changes only

Files included:
- topup.php: Server ID text input changed to Server Selection dropdown; custom product fields with a server label render as dropdowns; products without a configured server field receive a required Server Selection dropdown.
- admin/topup-products.php: server-labelled custom fields are saved as dropdowns.
- history-category-lib.php: category display name changed to Guild Glory while retaining the existing guild-war slug for compatibility.
- store.php: visible Guild War wording changed to Guild Glory where present.

Default server options: Bangladesh, India, Indonesia, Pakistan, Brazil, Vietnam, MENA, MY / SG.
No payment flow changes intended.

Before replacing, back up the existing files. Upload the included files to the matching paths.
