<?php
declare(strict_types=1);

define('DB_HOST','sql305.infinityfree.com');
define('DB_NAME','if0_42839302_xtreme_titan_official');
define('DB_USER','if0_42839302');
define('DB_PASS','EcYPviabi2w60');

define('MAIL_HOST','smtp.gmail.com');
define('MAIL_PORT',587);
define('MAIL_USERNAME','xtreme.titan.official.shop@gmail.com');
define('MAIL_PASSWORD','msvnybzlznnnwkzu');
define('MAIL_FROM_NAME','TITAN PANEL SHOP');

// Web Push VAPID credentials. Keep the private key secret and unchanged after subscriptions are created.
define('XT_ADMIN_VAPID_PUBLIC_KEY', 'BG-nRBzv-weJmgn0iUt0QHQQc6aQFud2u1sWG9BZCRcMuYvTwPAvLyHUVqiDWgiLRdF90vjy1EqXk6zOTQ1PBfw');
define('XT_ADMIN_VAPID_PRIVATE_KEY', 'qdthFn-sHmvcrNJSFUOtyqxCPtiCSNSYa_Efl8j-_uQ');
define('XT_ADMIN_VAPID_SUBJECT', 'mailto:xtreme.titan.official.shop@gmail.com');

date_default_timezone_set('UTC');

if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}

/**
 * Database connection.
 */
function db(): PDO
{
    static $pdo = null;
    if ($pdo === null) {
        $dsn = 'mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=utf8mb4';
        $pdo = new PDO($dsn, DB_USER, DB_PASS, [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false,
            PDO::ATTR_TIMEOUT => 10,
        ]);
        // Store all newly-created timestamps in UTC. The browser converts
        // them automatically to the visitor's own local timezone.
        try { $pdo->exec("SET time_zone = '+00:00'"); } catch (Throwable $ignore) {}
    }
    return $pdo;
}


/** UTC timestamp helpers. New purchase/deposit timestamps are stored as UTC.
 * The browser converts the resulting epoch to the visitor's local timezone.
 */
function utc_sql_now(): string { return gmdate('Y-m-d H:i:s'); }
function utc_epoch_from_db($value): int {
    if ($value === null || $value === '') return 0;
    try { return (new DateTimeImmutable((string)$value, new DateTimeZone('UTC')))->getTimestamp(); }
    catch (Throwable $e) { return 0; }
}

function e($value): string {
    return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');
}

// Backwards-compatible HTML escaping helper used by the newer UI pages.
if (!function_exists('h')) {
    function h($value): string {
        return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');
    }
}

/**
 * Settings used by the public site and admin panel.
 * The table is created automatically if this version of the site is installed
 * on a database that does not have it yet.
 */
function site_defaults(): array {
    return [
        'site_title' => 'XTREME_TITAN_OFFICIAL SHOP',
        'site_subtitle' => 'Premium digital products and services',
        'background_music_enabled' => '1',
        'background_music_path' => 'uploads/music/xtreme-background.m4a',
        'payment_number' => '',
        'bkash_number' => '',
        'nagad_number' => '',
        'binance_pay_id' => '1224732977',
        'payment_binance_logo' => 'assets/binance-pay.svg',
        'payment_binance_qr' => '',
        'payment_notice_text' => "পেমেন্ট করার আগে নিশ্চিত করুন: bKash/Nagad-এ শুধু Send Money ব্যবহার করুন। Cash Out, Mobile Recharge বা অন্য কোনো অপশন ব্যবহার করবেন না.\nBefore paying, use Send Money only for bKash/Nagad. Do not use Cash Out, Mobile Recharge, or other options.",
        // Admin-uploaded bKash/Nagad notice guide images (must be registered here
        // because site_settings() only returns keys declared in this defaults array).
        'bkash_payment_guide_image' => 'assets/bkash-payment-option-guide.jpg',
        'nagad_payment_guide_image' => '',
        'rocket_number' => '',
        'paypal_me' => '',
        'telegram_url' => '',
        'discord_url' => '',
        'support_text' => 'Need help? Contact our support team.',
        'footer_text' => '© XTREME_TITAN_OFFICIAL SHOP',
        'logo_path' => 'assets/xtreme-titan-logo.jpg',
        'background_path' => 'assets/tanofficial_neon_background.gif',
        'decor1_path' => 'assets/decoration-1.jpg',
        'decor2_path' => 'assets/decoration-2.jpg',
        'payment_bkash_logo' => 'assets/payment-bkash.jpg',
        'payment_nagad_logo' => 'assets/payment-nagad.jpg',
        'payment_rocket_logo' => '',
        'payment_paypal_logo' => 'assets/payment-paypal.svg',
        'add_funds_banner_path' => '',
        'add_funds_banner_url' => '',
        'header_banner_path' => '',
        'header_banner_url' => '',
        'header_banner_text' => '',
        'theme_default' => 'premium',
        'theme_primary' => '#16d9ff',
        'theme_secondary' => '#2685ff',
        'theme_background' => '#050b14',
        'theme_panel' => '#0d1b2d',
        'particle_mode' => 'dots',
        'particle_opacity' => '55',
        'particle_speed' => '18',
        'particle_size' => '3',
        'particle_color' => '#b8e7ff',
        'wallet_title' => 'My Wallet',
        'wallet_text' => 'Manage deposits & balance',
        'theme_section_title' => 'Theme & Appearance',
        'telegram_title' => 'Telegram Official Channel',
        'telegram_text' => 'Official announcements & updates',
        'rules_url' => 'rules.php',
        'rules_title' => 'Rules & Regulation',
        'rules_text' => 'Terms of service & platform policies',
        'rules_body' => 'Use the platform responsibly. Orders, deposits and account activity are subject to administrator review and the terms published by this website.',
        'referral_title' => 'Referral Hub',
        'referral_text' => 'Earn rewards & withdraw bonus',
        'top_members_title' => 'Top Members',
        'top_members_text' => 'Community leaderboard & rankings',
        'password_title' => 'Change Password',
        'password_text' => 'Security & credentials',
        'logout_title' => 'Logout',
        'logout_text' => 'Securely exit session',
        'referral_rate' => '5',
        'reseller_discount_percent' => '20',
    ];
}

function ensure_site_settings_table(): void {
    $pdo = db();
    $pdo->exec("
        CREATE TABLE IF NOT EXISTS site_settings (
            setting_key VARCHAR(100) NOT NULL PRIMARY KEY,
            setting_value TEXT NULL
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
    ");

    $defaults = site_defaults();
    $stmt = $pdo->prepare(
        'INSERT IGNORE INTO site_settings (setting_key, setting_value) VALUES (?, ?)'
    );
    foreach ($defaults as $key => $value) {
        $stmt->execute([$key, $value]);
    }
}

function site_settings(): array {
    $defaults = site_defaults();
    try {
        ensure_site_settings_table();
        $rows = db()->query('SELECT setting_key, setting_value FROM site_settings')
                    ->fetchAll(PDO::FETCH_KEY_PAIR);
        foreach ($defaults as $key => $value) {
            if (array_key_exists($key, $rows) && $rows[$key] !== null) {
                $defaults[$key] = (string)$rows[$key];
            }
        }
        // These old payment pictures were previously being used as floating
        // page decorations. Keep payment logos available for the Deposit page,
        // but never use the bKash/Nagad pictures as background decorations.
        if (basename((string)$defaults['decor1_path']) === 'decoration-1.jpg' || basename((string)$defaults['decor1_path']) === 'payment-nagad.jpg') {
            $defaults['decor1_path'] = '';
        }
        if (basename((string)$defaults['decor2_path']) === 'decoration-2.jpg' || basename((string)$defaults['decor2_path']) === 'payment-bkash.jpg') {
            $defaults['decor2_path'] = '';
        }
    } catch (Throwable $e) {
        // Keep safe defaults so the login/home page never becomes a blank page
        // merely because settings have not been initialized yet.
    }
    return $defaults;
}

function ensure_referral_tables(): void {
    $pdo=db();
    $pdo->exec("CREATE TABLE IF NOT EXISTS user_referrals (id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY, referrer_id INT NOT NULL, referred_user_id INT NOT NULL UNIQUE KEY uq_referred (referred_user_id), created_at DATETIME NOT NULL, INDEX idx_referrer (referrer_id)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
    $pdo->exec("CREATE TABLE IF NOT EXISTS referral_withdrawals (id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY, user_id INT NOT NULL, amount DECIMAL(12,2) NOT NULL, status VARCHAR(20) NOT NULL DEFAULT 'pending', note VARCHAR(255) NULL, created_at DATETIME NOT NULL, INDEX idx_user (user_id)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
}

function site_setting(string $key, $default = '') {
    $settings = site_settings();
    return array_key_exists($key, $settings) ? $settings[$key] : $default;
}



function currency_meta(string $currency): array {
    $map = [
        'BDT'=>['symbol'=>'৳','locale'=>'bn-BD','name'=>'Bangladeshi Taka','country'=>'BD'],
        'USD'=>['symbol'=>'$','locale'=>'en-US','name'=>'US Dollar','country'=>'US'],
        'EUR'=>['symbol'=>'€','locale'=>'it-IT','name'=>'Euro','country'=>'IT'],
        'AED'=>['symbol'=>'د.إ','locale'=>'ar-AE','name'=>'UAE Dirham','country'=>'AE'],
        'INR'=>['symbol'=>'₹','locale'=>'en-IN','name'=>'Indian Rupee','country'=>'IN'],
        'NPR'=>['symbol'=>'रू','locale'=>'ne-NP','name'=>'Nepalese Rupee','country'=>'NP'],
        'BTN'=>['symbol'=>'Nu.','locale'=>'dz-BT','name'=>'Bhutanese Ngultrum','country'=>'BT'],
        'VND'=>['symbol'=>'₫','locale'=>'vi-VN','name'=>'Vietnamese Dong','country'=>'VN'],
        'GBP'=>['symbol'=>'£','locale'=>'en-GB','name'=>'Pound Sterling','country'=>'GB'],
    ];
    return $map[$currency] ?? $map['USD'];
}
function ensure_user_preference_columns(): void {
    try {
        $pdo=db();
        $cols=$pdo->query('SHOW COLUMNS FROM users')->fetchAll(PDO::FETCH_ASSOC);
        $have=[]; foreach($cols as $c) $have[$c['Field']]=true;
        if(!isset($have['currency'])) $pdo->exec("ALTER TABLE users ADD COLUMN currency VARCHAR(10) NOT NULL DEFAULT 'USD'");
        if(!isset($have['country_code'])) $pdo->exec("ALTER TABLE users ADD COLUMN country_code VARCHAR(8) NULL");
        if(!isset($have['language'])) $pdo->exec("ALTER TABLE users ADD COLUMN language VARCHAR(10) NULL");
    } catch(Throwable $e) {}
}
function current_user_preferences(): array {
    $currency='USD'; $country=''; $language='';
    if(!empty($_SESSION['user_id'])) {
        try {
            ensure_user_preference_columns();
            $st=db()->prepare('SELECT currency,country_code,language FROM users WHERE id=? LIMIT 1');
            $st->execute([(int)$_SESSION['user_id']]); $r=$st->fetch() ?: [];
            $currency=strtoupper((string)($r['currency']??'USD'));
            $country=strtoupper((string)($r['country_code']??''));
            $language=strtolower((string)($r['language']??''));
        } catch(Throwable $e) {}
    }
    if(!isset(['BDT'=>1,'USD'=>1,'EUR'=>1,'AED'=>1,'INR'=>1,'NPR'=>1,'BTN'=>1,'VND'=>1,'GBP'=>1][$currency])) $currency='USD';
    if($country==='') $country=currency_meta($currency)['country'];
    if(!in_array($language,['en','bn','hi','ne','dz','it','ar','vi'],true)) {
        $language=['BD'=>'bn','IN'=>'hi','NP'=>'ne','BT'=>'dz','IT'=>'it','AE'=>'ar','VN'=>'vi','US'=>'en','GB'=>'en'][$country] ?? currency_meta($currency)['country'];
        $language=['BD'=>'bn','IN'=>'hi','NP'=>'ne','BT'=>'dz','IT'=>'it','AE'=>'ar','VN'=>'vi','US'=>'en','GB'=>'en'][$country] ?? 'en';
    }
    return ['currency'=>$currency,'country'=>$country,'language'=>$language]+currency_meta($currency);
}

function ensure_account_role_columns(): void {
    try {
        $pdo=db(); $cols=$pdo->query('SHOW COLUMNS FROM users')->fetchAll(PDO::FETCH_COLUMN);
        if(!in_array('role',$cols,true)) $pdo->exec("ALTER TABLE users ADD COLUMN role VARCHAR(20) NOT NULL DEFAULT 'user'");
        if(!in_array('profile_photo',$cols,true)) $pdo->exec("ALTER TABLE users ADD COLUMN profile_photo VARCHAR(255) NULL");
        if(!in_array('username',$cols,true)) $pdo->exec("ALTER TABLE users ADD COLUMN username VARCHAR(50) NULL DEFAULT NULL");

    } catch(Throwable $e) {}
}
function current_user_role(): string {
    if(empty($_SESSION['user_id'])) return 'guest';
    try { ensure_account_role_columns(); $st=db()->prepare('SELECT role FROM users WHERE id=? LIMIT 1'); $st->execute([(int)$_SESSION['user_id']]); $r=strtolower((string)($st->fetchColumn()??'user')); return in_array($r,['admin','reseller','user'],true)?$r:'user'; } catch(Throwable $e){ return 'user'; }
}

function ensure_catalog_product_columns(): void {
    try {
        $pdo=db();
        $cols=$pdo->query('SHOW COLUMNS FROM catalog_products')->fetchAll(PDO::FETCH_COLUMN);
        if(!in_array('category',$cols,true)) $pdo->exec("ALTER TABLE catalog_products ADD COLUMN category VARCHAR(30) NOT NULL DEFAULT 'PRO'");
        if(!in_array('platform',$cols,true)) { $pdo->exec("ALTER TABLE catalog_products ADD COLUMN platform VARCHAR(100) NOT NULL DEFAULT 'ALL'"); }
        else { $platformMeta=$pdo->query("SHOW COLUMNS FROM catalog_products LIKE 'platform'")->fetch(PDO::FETCH_ASSOC); $platformType=strtolower((string)($platformMeta['Type'] ?? '')); if(preg_match('/^varchar\((\d+)\)$/',$platformType,$m) && (int)$m[1] < 100) $pdo->exec("ALTER TABLE catalog_products MODIFY platform VARCHAR(100) NOT NULL DEFAULT 'ALL'"); }
        if(!in_array('live_status',$cols,true)) $pdo->exec("ALTER TABLE catalog_products ADD COLUMN live_status TINYINT(1) NOT NULL DEFAULT 1");
        if(!in_array('reseller_discount_percent',$cols,true)) $pdo->exec("ALTER TABLE catalog_products ADD COLUMN reseller_discount_percent DECIMAL(5,2) NULL DEFAULT NULL");
    } catch(Throwable $e) {}
}

function ensure_key_reset_tables(): void {
    try {
        $pdo=db();
        $cols=$pdo->query('SHOW COLUMNS FROM user_keys')->fetchAll(PDO::FETCH_COLUMN);
        if(!in_array('duration_seconds',$cols,true)) $pdo->exec("ALTER TABLE user_keys ADD COLUMN duration_seconds INT NULL");
        if(!in_array('reset_generation',$cols,true)) $pdo->exec("ALTER TABLE user_keys ADD COLUMN reset_generation INT NOT NULL DEFAULT 0");
        if(!in_array('device_token',$cols,true)) $pdo->exec("ALTER TABLE user_keys ADD COLUMN device_token VARCHAR(191) NULL");
        try { $pc=$pdo->query('SHOW COLUMNS FROM product_plans')->fetchAll(PDO::FETCH_COLUMN); if(!in_array('duration_seconds',$pc,true)) $pdo->exec("ALTER TABLE product_plans ADD COLUMN duration_seconds INT NULL"); $pdo->exec("UPDATE product_plans SET duration_seconds=CASE WHEN duration_days<0 THEN ABS(duration_days)*3600 ELSE duration_days*86400 END WHERE duration_seconds IS NULL"); } catch(Throwable $ignore) {}
        $pdo->exec("CREATE TABLE IF NOT EXISTS key_reset_requests (id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,user_id INT NOT NULL,key_id INT NOT NULL,status VARCHAR(20) NOT NULL DEFAULT 'pending',note VARCHAR(255) NULL,request_type VARCHAR(20) NOT NULL DEFAULT 'device',new_license_key VARCHAR(191) NULL,created_at DATETIME NOT NULL,reviewed_at DATETIME NULL,INDEX idx_user(user_id),INDEX idx_key(key_id),INDEX idx_status(status)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
        try { $cols=$pdo->query('SHOW COLUMNS FROM key_reset_requests')->fetchAll(PDO::FETCH_COLUMN); if(!in_array('request_type',$cols,true)) $pdo->exec("ALTER TABLE key_reset_requests ADD COLUMN request_type VARCHAR(20) NOT NULL DEFAULT 'device'"); if(!in_array('new_license_key',$cols,true)) $pdo->exec("ALTER TABLE key_reset_requests ADD COLUMN new_license_key VARCHAR(255) NULL"); else $pdo->exec("ALTER TABLE key_reset_requests MODIFY new_license_key VARCHAR(255) NULL"); if(!in_array('new_inventory_key_id',$cols,true)) $pdo->exec("ALTER TABLE key_reset_requests ADD COLUMN new_inventory_key_id INT NULL");
         // Remove the legacy unique index that blocks repeat requests for the same key/status.
         try {
             $indexes=$pdo->query("SHOW INDEX FROM key_reset_requests")->fetchAll(PDO::FETCH_ASSOC);
             $hasLegacy=false;
             foreach($indexes as $index) {
                 if(($index['Key_name'] ?? '') === 'uq_pending_key') { $hasLegacy=true; break; }
             }
             if($hasLegacy) $pdo->exec("ALTER TABLE key_reset_requests DROP INDEX uq_pending_key");
         } catch(Throwable $indexError) {}
         } catch(Throwable $ignore) {}
    } catch(Throwable $e) {}
}
/** Create the support-ticket tables used by the premium Support Center. */
function ensure_support_ticket_tables(): void {
    $pdo = db();
    $pdo->exec("CREATE TABLE IF NOT EXISTS support_tickets (
        id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
        user_id INT NOT NULL,
        subject VARCHAR(160) NOT NULL,
        category VARCHAR(40) NOT NULL DEFAULT 'general',
        priority VARCHAR(20) NOT NULL DEFAULT 'normal',
        status VARCHAR(20) NOT NULL DEFAULT 'open',
        created_at DATETIME NOT NULL,
        updated_at DATETIME NOT NULL,
        INDEX idx_ticket_user (user_id, id),
        INDEX idx_ticket_status (status, updated_at)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
    $pdo->exec("CREATE TABLE IF NOT EXISTS support_ticket_replies (
        id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
        ticket_id BIGINT UNSIGNED NOT NULL,
        user_id INT NOT NULL,
        sender_type VARCHAR(10) NOT NULL,
        message TEXT NOT NULL,
        created_at DATETIME NOT NULL,
        INDEX idx_ticket_replies (ticket_id, id),
        INDEX idx_ticket_sender (sender_type, created_at)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
}

function require_login(): void {
    if (empty($_SESSION['user_id'])) {
        header('Location: login.php');
        exit;
    }
}

function phpmailer_ready(): bool {
    return file_exists(__DIR__ . '/PHPMailer/src/PHPMailer.php')
        && file_exists(__DIR__ . '/PHPMailer/src/SMTP.php')
        && file_exists(__DIR__ . '/PHPMailer/src/Exception.php');
}

function send_otp_email(string $to, string $name, string $code): array {
    if (!phpmailer_ready()) {
        return [false, 'PHPMailer folder not found. Upload the existing PHPMailer folder beside these files.'];
    }

    require_once __DIR__ . '/PHPMailer/src/Exception.php';
    require_once __DIR__ . '/PHPMailer/src/PHPMailer.php';
    require_once __DIR__ . '/PHPMailer/src/SMTP.php';

    try {
        $mail = new PHPMailer\PHPMailer\PHPMailer(true);
        $mail->isSMTP();
        $mail->Host = MAIL_HOST;
        $mail->SMTPAuth = true;
        $mail->Username = MAIL_USERNAME;
        $mail->Password = MAIL_PASSWORD;
        $mail->SMTPSecure = PHPMailer\PHPMailer\PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port = MAIL_PORT;
        $mail->CharSet = 'UTF-8';

        // Keep the visible sender aligned with the authenticated Gmail account.
        $mail->setFrom(MAIL_USERNAME, 'XTREME TITAN Official Shop');
        $mail->addReplyTo(MAIL_USERNAME, 'XTREME TITAN Official Shop');
        $mail->addAddress($to, $name);
        $mail->isHTML(true);
        // A short, plain subject/body avoids unnecessary promotional-looking text.
        $mail->Subject = 'Your email verification code';
        $safeName = e($name);
        $safeCode = e($code);
        $mail->Body = '<!doctype html><html><body style="font-family:Arial,sans-serif;color:#222;line-height:1.6">'
            . '<p>Hello ' . $safeName . ',</p>'
            . '<p>Use this code to verify your email address:</p>'
            . '<p style="font-size:30px;font-weight:bold;letter-spacing:6px">' . $safeCode . '</p>'
            . '<p>This code expires in 10 minutes. If you did not request it, you can ignore this email.</p>'
            . '<p>XTREME TITAN Official Shop</p>'
            . '</body></html>';
        $mail->AltBody = "Hello {$name},\n\nYour email verification code is: {$code}\n\nThis code expires in 10 minutes. If you did not request it, you can ignore this email.\n\nXTREME TITAN Official Shop";
        $mail->send();
        return [true, ''];
    } catch (Throwable $ex) {
        return [false, $mail->ErrorInfo ?: $ex->getMessage()];
    }
}


function ensure_product_plan_type_column(): void {
    try { db()->exec("ALTER TABLE product_plans ADD COLUMN plan_type VARCHAR(16) NOT NULL DEFAULT 'PRO'"); } catch (Throwable $ignore) {}
    try { db()->exec("UPDATE product_plans pp JOIN catalog_products cp ON cp.id=pp.product_id SET pp.plan_type=UPPER(cp.category) WHERE (pp.plan_type IS NULL OR pp.plan_type='') AND UPPER(cp.category) IN ('PRO','BASIC')"); } catch (Throwable $ignore) {}
}

/** Admin notification centre shared by the live and backup configuration files. */
function ensure_admin_notification_tables(): void {
    $pdo = db();
    $pdo->exec("CREATE TABLE IF NOT EXISTS admin_notifications (
        id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
        event_type VARCHAR(40) NOT NULL,
        title VARCHAR(160) NOT NULL,
        body VARCHAR(500) NOT NULL,
        target_url VARCHAR(255) NOT NULL DEFAULT 'dashboard.php',
        created_at DATETIME NOT NULL,
        read_at DATETIME NULL,
        INDEX idx_admin_notice_unread (read_at, id),
        INDEX idx_admin_notice_type (event_type, id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
}
function notify_admin(string $eventType, string $title, string $body, string $targetUrl): void {
    try {
        $allowed = ['new_deposit','new_topup','key_reset','support_ticket','new_message','live_message'];
        if (!in_array($eventType, $allowed, true)) return;
        ensure_admin_notification_tables();
        $targetUrl = ltrim($targetUrl, '/');
        if ($targetUrl === '' || strpos($targetUrl, '..') !== false || preg_match('~^[a-z]+:~i', $targetUrl)) $targetUrl = 'dashboard.php';
        $st = db()->prepare('INSERT INTO admin_notifications(event_type,title,body,target_url,created_at) VALUES(?,?,?,?,UTC_TIMESTAMP())');
        $st->execute([$eventType, mb_substr($title,0,160), mb_substr($body,0,500), mb_substr($targetUrl,0,255)]);
        // Admin-only background Web Push. Never block the customer transaction.
        if (is_file(__DIR__ . '/admin-push-functions.php')) {
            require_once __DIR__ . '/admin-push-functions.php';
            xt_admin_send_push(
                mb_substr($title, 0, 160),
                mb_substr($body, 0, 500),
                $targetUrl
            );
        }
    } catch (Throwable $ignore) { /* Notifications must never block a customer action. */ }
}

