XTREME TITAN OFFICIAL SHOP — Premium Landing + PWA Icon Patch V15

Changes:
- Updated the landing page Sign In and Create Account buttons to a more premium violet/indigo/blue palette.
- Reduced the site title size and converted underscores to spaces for cleaner wrapping on mobile.
- Added root-relative favicon, Apple Touch Icon, web app manifest and theme metadata to internal PHP pages that lacked them, including account, store, My Keys, Add Funds, History and Profile routes, plus nested admin routes.
- Existing login/register/reseller authentication flow and database logic were not intentionally changed.

Deployment:
1. Back up the current website files.
2. Upload/replace the files from this ZIP while preserving config.php and database credentials.
3. On iPhone, remove the old Home Screen shortcut and add it again from Safari to refresh the cached icon.
4. The PWA icon is assets/pwa-icon-180.png (generated from the site's current XTREME TITAN logo). If you later change the logo in admin settings, regenerate/update the PWA icon files as well; iOS Home Screen icons are static image assets.

Validation: PHP syntax check passed for the PHP files in this package. Live-host behavior has not been tested from here.
