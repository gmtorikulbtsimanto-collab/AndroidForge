(function(){
 const map={BD:'BDT',US:'USD',IN:'INR',NP:'NPR',IT:'EUR',AE:'AED',VN:'VND',GB:'GBP'};
 function sync(){
  let country='',currency='';try{country=localStorage.getItem('xtreme_country')||'';currency=localStorage.getItem('xtreme_currency')||''}catch(e){}
  if(!currency&&map[country]) currency=map[country];
  if(!country) country=Object.keys(map).find(k=>map[k]===currency)||'';
  if(!currency)return;
  fetch('save-preference.php',{method:'POST',headers:{'Content-Type':'application/json'},credentials:'same-origin',body:JSON.stringify({country_code:country,currency:currency})}).catch(()=>{});
 }
 if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',sync);else sync();
 window.addEventListener('xtreme-currency-change',sync);
 window.addEventListener('storage',e=>{if(e.key==='xtreme_currency'||e.key==='xtreme_country')sync()});
})();
