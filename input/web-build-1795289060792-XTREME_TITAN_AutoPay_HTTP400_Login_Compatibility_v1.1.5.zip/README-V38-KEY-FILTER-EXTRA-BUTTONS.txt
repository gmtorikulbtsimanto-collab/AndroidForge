XTREME TITAN V38 — Product Key Manager Filter + Two Configurable Product Buttons

Changes:
1. Admin > Key Manager > Available Keys — Delete Inventory now has a product dropdown filter. Selecting a product shows only unassigned inventory keys belonging to that product. Delete actions retain the selected filter. Assigned keys remain protected.
2. Admin > Products editor now has two extra per-product buttons:
   - Button 1 defaults to “📁 Download File” (file manager/download URL)
   - Button 2 defaults to “🔗 More Info” (custom URL)
   Each button has an editable URL, editable label, and ON/OFF checkbox. It appears on the Store only when ON and a URL is provided.
3. Existing Setup Video, Join Product Group, product media, features and plans are preserved.

Install by backing up the live site and uploading the ZIP files to the existing website root, replacing matching files. Test on a copy first. Live hosting behavior has not been tested from this package.
