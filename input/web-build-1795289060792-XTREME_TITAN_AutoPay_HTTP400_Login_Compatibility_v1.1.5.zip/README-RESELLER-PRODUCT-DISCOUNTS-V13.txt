XTREME TITAN — Product-wise reseller discount update (V13)

What changed:
- Admin > Reseller Control now supports an individual reseller discount for each catalog product.
- Each product discount applies to all plans belonging to that product only.
- Product discount range is 0% to 90%.
- Reset to Global Default clears the product override (NULL), so the product follows the global default setting again.
- The global discount remains available as a fallback for products without an override. Set the global default to 0% if you want only explicitly selected products to receive a discount.
- Store display and buy.php server-side purchase calculations use the same product-specific discount, so the displayed price and charged price match.
- Normal customer pricing is unchanged.
- The database column catalog_products.reseller_discount_percent is added automatically by ensure_catalog_product_columns().

Install:
1. Back up the website files and database first.
2. Upload/extract this ZIP into the site root, preserving the folder structure.
3. Sign in to Admin > Reseller Control. Set the Global Default to 0% if desired, then set the percentage only on the products you want to discount.
4. Test one reseller purchase with a low-value plan and verify the amount before normal use.

Validation: PHP syntax checks passed for all PHP files and ZIP integrity check passed. Live database/OAuth/payment behavior has not been tested from this environment.
