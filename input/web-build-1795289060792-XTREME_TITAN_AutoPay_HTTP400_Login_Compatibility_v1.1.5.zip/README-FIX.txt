XTREME TITAN – CATEGORY FILTER & TOP-UP NOTIFICATION FIX

Replace these files in your website with the matching paths from this ZIP:
- topup.php
- topup-lib.php
- admin/topup-products.php

Fixes:
1. Category filters are registered before the URL category is applied. Matching is case-insensitive and uses the category slug.
2. Adding, editing, or deleting a visible Top-Up product sends an in-app notification to registered users.
3. Adds the shared xt_user_notify_all() helper, which is also used by the existing catalog product notifications in admin/products.php.

Important:
- Back up your current files before replacing them.
- The broadcast helper expects the site's customer table to be named `users` with primary key `id`, consistent with this project structure.
- This patch does not change the Top-Up order/payment flow or the store's existing Top Up entry button.
- PHP syntax was checked locally; live database and device testing still need to be done after upload.
