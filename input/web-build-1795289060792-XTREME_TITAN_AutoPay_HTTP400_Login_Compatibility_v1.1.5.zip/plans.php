<?php
require_once __DIR__ . '/config.php';
if (function_exists('require_login')) require_login();
elseif (empty($_SESSION['user_id'])) { http_response_code(403); exit; }
header('Content-Type: application/json; charset=utf-8');
try {
 $pdo=db(); ensure_product_plan_type_column(); $pid=(int)($_GET['product_id']??0);
 if($pid<=0){echo json_encode([]);exit;}
 $s=$pdo->prepare("SELECT pp.id,pp.plan_type,pp.duration_days,pp.duration_label,pp.price,pp.status,(SELECT COUNT(*) FROM user_keys uk WHERE uk.product_id=pp.product_id AND uk.plan_id=pp.id AND uk.user_id IS NULL) available_keys FROM product_plans pp WHERE pp.product_id=? AND pp.status=1 ORDER BY FIELD(UPPER(pp.plan_type),'PRO','BASIC','NORMAL'),pp.duration_days,pp.id");
 $s->execute([$pid]); echo json_encode($s->fetchAll(PDO::FETCH_ASSOC));
} catch(Throwable $e){ http_response_code(500); echo json_encode(['error'=>'Unable to load plans']);}
