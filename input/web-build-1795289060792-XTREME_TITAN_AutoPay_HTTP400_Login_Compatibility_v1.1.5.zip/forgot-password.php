<?php
require_once __DIR__ . '/config.php';

if (!empty($_SESSION['user_id'])) {
    header('Location: dashboard.php');
    exit;
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $identifier = trim($_POST['identifier'] ?? '');

    if ($identifier === '') {

        $error = 'Enter your email or phone number.';

    } else {

        try {

            $s = db()->prepare(
                'SELECT id, name, email, phone
                 FROM users
                 WHERE email = ? OR phone = ?
                 LIMIT 1'
            );

            $s->execute([$identifier, $identifier]);
            $u = $s->fetch();

            if (!$u) {

                $error = 'No account was found with that email or phone number.';

            } else {

                // Generate a 6-digit password reset OTP
                $code = (string) random_int(100000, 999999);

                // Hash the OTP before saving it
                $otpHash = password_hash(
                    $code,
                    PASSWORD_DEFAULT
                );

                // OTP valid for 10 minutes
                $expires = date(
                    'Y-m-d H:i:s',
                    time() + 600
                );

                $s = db()->prepare(
                    'UPDATE users
                     SET reset_otp_hash = ?,
                         reset_otp_expires_at = ?,
                         reset_otp_attempts = 0
                     WHERE id = ?'
                );

                $s->execute([
                    $otpHash,
                    $expires,
                    $u['id']
                ]);

                // Send OTP to registered email
                [$ok, $mailError] = send_otp_email(
                    $u['email'],
                    $u['name'],
                    $code
                );

                if (!$ok) {

                    $error = 'Unable to send the reset code. Please check your Gmail SMTP settings.';

                } else {

                    $_SESSION['reset_user_id'] = (int) $u['id'];
                    $_SESSION['reset_email'] = $u['email'];
                    $_SESSION['reset_name'] = $u['name'];

                    header('Location: reset-password.php');
                    exit;
                }
            }

        } catch (Throwable $e) {

            $error = 'Password reset failed. Please try again.';
        }
    }
}
?>

<!doctype html>
<html lang="en">

<head>
<link rel="stylesheet" href="theme.php?v=20261022-lightfix3">

    <meta charset="utf-8">

    <meta
        name="viewport"
        content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no"
    >

    <title>Forgot Password — XTREME_TITAN_OFFICIAL SHOP</title>

    <link rel="stylesheet" href="style.css">
<style>.auth-brand{text-align:center;color:#fff;font-weight:1000;font-size:22px;letter-spacing:.7px;margin:8px auto 12px}.auth-brand span{color:#10d8ff}.auth-brand small{display:block;color:#91a0b5;font-size:9px;font-weight:700;letter-spacing:.5px;margin-top:5px}.page{width:min(430px,calc(100% - 24px));margin:auto;padding:18px 0 30px}.auth-card{background:rgba(5,14,25,.92)!important;border:1px solid rgba(16,216,255,.22)!important;border-radius:20px!important;padding:20px!important;box-shadow:0 20px 60px rgba(0,0,0,.42)}.auth-card h1{font-size:27px!important}.auth-card .btn{width:100%;border:0;border-radius:12px;padding:13px;background:linear-gradient(135deg,#10d8ff,#1681ff);color:#fff;font-weight:900}.auth-card input{border-radius:12px!important}.links a{color:#10d8ff!important}</style>

<link rel="stylesheet" href="reference-theme.css">
<link rel="stylesheet" href="site-polish.css?v=20261022-lightfix3">
<script src="theme-client.js?v=20260928-19" defer></script><link rel="stylesheet" href="premium-global.css?v=20261022-lightfix3"><script src="currency-client.js?v=20261018-fx1" defer></script><link rel="stylesheet" href="responsive-lock.css?v=20260929-28">

<link rel="icon" type="image/png" sizes="48x48" href="/assets/pwa-icon-48.png">
<link rel="apple-touch-icon" sizes="180x180" href="/assets/pwa-icon-180.png">
<link rel="manifest" href="/pwa-manifest.json">
<meta name="apple-mobile-web-app-title" content="XTREME TITAN">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="mobile-web-app-capable" content="yes">
<meta name="theme-color" content="#080a14">
<script src="/admin/admin-action-progress.js?v=20261023-inline-progress25" defer></script>
</head>

<body>

<div class="page">

    <div class="auth-brand"><img class="site-logo" src="assets/xtreme-titan-logo.jpg" alt="XTREME TITAN">XTREME <span>TITAN</span><small>XTREME_TITAN_OFFICIAL SHOP</small></div>

    <div class="auth-card">

        <div class="eyebrow">
            PASSWORD RECOVERY
        </div>

        <h1>
            Forgot password?
        </h1>

        <p class="intro">
            Enter your registered email or phone number.
            We'll send a 6-digit reset code to your email.
        </p>

        <?php if ($error): ?>

            <div class="alert error">
                <?= e($error) ?>
            </div>

        <?php endif; ?>

        <form method="post" autocomplete="on">

            <label for="identifier">
                Email or phone number
            </label>

            <input
                id="identifier"
                type="text"
                name="identifier"
                value="<?= e($_POST['identifier'] ?? '') ?>"
                placeholder="Email or phone number"
                required
                autocomplete="username"
            >

            <button
                class="btn"
                type="submit"
            >
                Send reset code
            </button>

        </form>

        <div class="links">

            <a href="login.php">
                Back to sign in
            </a>

        </div>

    </div>

    <footer>
        © <?= date('Y') ?> XTREME_TITAN_OFFICIAL SHOP
    </footer>

</div>

</body>

</html>