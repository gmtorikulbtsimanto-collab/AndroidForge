XTREME TITAN — Reseller Store + $50 Approved Deposit Unlock

Changes in this patch:
- Reseller login/register now lands on store.php, the same user-facing store layout with the standard Store / My Keys / Add Funds / History / Profile navigation.
- Reseller pricing discount is shown on the store plan cards and buy confirmation page.
- The reseller dashboard route redirects to store.php so the separate plain HTML reseller page is no longer used.
- A reseller-only progress panel shows approved deposits toward the $50 threshold.
- Every reseller purchase is blocked server-side until cumulative APPROVED deposits reach $50.00. Pending deposits do not count. Once an admin approves enough deposits, the requirement automatically unlocks; no manual unlock is needed.

Install:
1. Back up the live site first.
2. Extract this ZIP and upload the included files to the same locations under htdocs, preserving folder structure.
3. Test with a reseller account: below $50 approved deposits, purchase should be blocked and Add Funds link shown. After the approved-deposit total reaches $50, reseller purchasing should unlock and show the configured discount.

Important assumption:
The existing application stores deposit amounts as raw numeric amounts and its wallet logic sums them directly. This patch uses that same approved-deposit total as the $50 threshold. Confirm the site's existing deposit amounts are recorded in the same base unit as the displayed $ balance. Pending deposits do not unlock purchases.

No live InfinityFree database test was possible here. PHP syntax was checked for changed PHP files.
