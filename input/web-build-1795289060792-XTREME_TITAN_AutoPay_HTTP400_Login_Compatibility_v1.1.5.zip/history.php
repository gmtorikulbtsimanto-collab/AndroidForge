<?php
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/history-category-lib.php';
require_once __DIR__ . '/topup-lib.php';
require_login();
$userId=(int)($_SESSION['user_id']??0);
$rows=[]; $error=''; $notice=''; $userNotices=[]; $userUnreadCount=0;
if(!function_exists('h')){function h($v):string{return htmlspecialchars((string)$v,ENT_QUOTES,'UTF-8');}}
if(empty($_SESSION['history_csrf'])) $_SESSION['history_csrf']=bin2hex(random_bytes(32));
$historyCsrf=$_SESSION['history_csrf'];
function xt_hist_columns(PDO $pdo,string $table):array {
    $safe=preg_replace('/[^a-zA-Z0-9_]/','',$table);
    try{return $pdo->query("SHOW COLUMNS FROM `$safe`")->fetchAll(PDO::FETCH_COLUMN);}catch(Throwable $e){return [];}
}
function xt_hist_add_missing(PDO $pdo,string $table,array $defs):void {
    $cols=xt_hist_columns($pdo,$table);
    if(!$cols) return;
    foreach($defs as $name=>$definition){
        if(!in_array($name,$cols,true)){
            try{$pdo->exec("ALTER TABLE `$table` ADD COLUMN `$name` $definition");}
            catch(Throwable $e){error_log("XT History migration $table.$name: ".$e->getMessage());}
        }
    }
}
function xt_hist_ensure_cancel_status(PDO $pdo):void {
    try {
        $meta=$pdo->query("SHOW COLUMNS FROM deposits LIKE 'status'")->fetch(PDO::FETCH_ASSOC);
        $type=strtolower((string)($meta['Type']??''));
        // Older installations used ENUM('pending','approved','rejected'), which silently
        // prevents the customer cancellation state from being stored. VARCHAR preserves
        // all existing values while allowing 'cancelled'.
        if(str_starts_with($type,'enum(') && !str_contains($type,"'cancelled'")) {
            $nullable=strtoupper((string)($meta['Null']??'NO'))==='YES'?'NULL':'NOT NULL';
            $default=array_key_exists('Default',$meta) && $meta['Default']!==null ? " DEFAULT '".str_replace("'","''",(string)$meta['Default'])."'" : '';
            $pdo->exec("ALTER TABLE deposits MODIFY status VARCHAR(20) $nullable$default");
        }
    } catch(Throwable $e) { error_log('XT History deposit status migration: '.$e->getMessage()); }
}
function xt_hist_status(string $raw):string {
    $s=strtolower(trim($raw));
    $s=preg_replace('/[\\s-]+/','_', $s);
    if(in_array($s,['cancelled','canceled','cancel','void','voided','user_cancelled','user_canceled','payment_cancelled','payment_canceled','cancel_by_user','cancelled_by_user','canceled_by_user'],true) || str_contains($s,'cancel')) return 'Cancelled';
    if(in_array($s,['approved','completed','complete','success','successful','paid','verified','confirmed','processed'],true)) return 'Completed';
    if(in_array($s,['rejected','failed','declined','denied'],true)) return 'Cancelled';
    // Only an explicitly completed/canceled record changes state; all other states stay pending.
    return 'Pending';
}
try {
    $pdo=db();
    try{$pdo->exec("SET time_zone = '+00:00'");}catch(Throwable $ignore){}
    xt_hist_ensure_cancel_status($pdo);
    // Ensure new tables exist, then upgrade older installations without dropping data.
    try{xt_topup_ensure_tables();}catch(Throwable $e){error_log('XT History table ensure: '.$e->getMessage());}
    xt_hist_add_missing($pdo,'topup_orders',[
        'user_id'=>'INT NOT NULL DEFAULT 0',
        'product_id'=>'BIGINT UNSIGNED NULL',
        'purchase_id'=>'BIGINT UNSIGNED NULL',
        'product_name'=>"VARCHAR(150) NOT NULL DEFAULT ''",
        'category_slug'=>"VARCHAR(60) NOT NULL DEFAULT 'other'",
        'amount_label'=>"VARCHAR(100) NOT NULL DEFAULT ''",
        'player_uid'=>"VARCHAR(100) NOT NULL DEFAULT ''",
        'server_id'=>'VARCHAR(80) NULL',
        'quantity'=>'INT NOT NULL DEFAULT 1',
        'unit_price'=>'DECIMAL(12,2) NOT NULL DEFAULT 0',
        'total_amount'=>'DECIMAL(12,2) NOT NULL DEFAULT 0',
        'status'=>"VARCHAR(20) NOT NULL DEFAULT 'pending'",
        'created_at'=>'DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP',
        'updated_at'=>'DATETIME NULL'
    ]);
    xt_hist_add_missing($pdo,'user_purchases',[
        'user_id'=>'INT NOT NULL DEFAULT 0',
        'product_name'=>"VARCHAR(150) NOT NULL DEFAULT ''",
        'plan_name'=>"VARCHAR(150) NOT NULL DEFAULT ''",
        'total_amount'=>'DECIMAL(12,2) NOT NULL DEFAULT 0',
        'created_at'=>'DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP'
    ]);
    xt_hist_add_missing($pdo,'history_categories',[
        'name'=>"VARCHAR(60) NOT NULL DEFAULT 'Other'",
        'slug'=>"VARCHAR(60) NOT NULL DEFAULT 'other'",
        'keywords'=>'TEXT NULL',
        'kind'=>"VARCHAR(20) NOT NULL DEFAULT 'purchase'",
        'sort_order'=>'INT NOT NULL DEFAULT 0',
        'enabled'=>'TINYINT(1) NOT NULL DEFAULT 1'
    ]);
    xt_hist_add_missing($pdo,'deposits',[
        'transaction_id'=>"VARCHAR(150) NOT NULL DEFAULT ''",
        'uddoktapay_invoice_id'=>'VARCHAR(100) NULL'
    ]);
    try{xt_topup_sync_history_categories();}catch(Throwable $e){error_log('XT History category sync: '.$e->getMessage());}
    try{xt_user_notification_tables();}catch(Throwable $e){error_log('XT History notification table: '.$e->getMessage());}
    try{$categories=xt_history_categories();}catch(Throwable $e){$categories=[];error_log('XT History categories: '.$e->getMessage());}

    if($_SERVER['REQUEST_METHOD']==='POST' && ($_POST['action']??'')==='mark_notifications_read'){
        if(!hash_equals($historyCsrf,(string)($_POST['csrf']??''))) { http_response_code(403); header('Content-Type: application/json; charset=utf-8'); echo json_encode(['ok'=>false]); exit; }
        $read=$pdo->prepare('UPDATE user_notifications SET read_at=UTC_TIMESTAMP() WHERE user_id=? AND read_at IS NULL');
        $read->execute([$userId]);
        header('Content-Type: application/json; charset=utf-8'); header('Cache-Control: no-store');
        echo json_encode(['ok'=>true]); exit;
    }
    if($_SERVER['REQUEST_METHOD']==='POST' && ($_POST['action']??'')==='cancel_deposit'){
        if(!hash_equals($historyCsrf,(string)($_POST['csrf']??''))) throw new RuntimeException('Security check failed. Refresh the page.');
        $depositId=(int)($_POST['deposit_id']??0);
        if($depositId<1) throw new RuntimeException('Invalid deposit reference.');
        $dcols=xt_hist_columns($pdo,'deposits');
        if(!in_array('user_id',$dcols,true)) throw new RuntimeException('Deposit account reference is unavailable.');
        $select=['id','payment_method','status'];
        if(in_array('uddoktapay_invoice_id',$dcols,true)) $select[]='uddoktapay_invoice_id';
        $st=$pdo->prepare('SELECT '.implode(',',$select).' FROM deposits WHERE id=? AND user_id=? LIMIT 1');
        $st->execute([$depositId,$userId]);$dep=$st->fetch(PDO::FETCH_ASSOC);
        if(!$dep) throw new RuntimeException('This deposit could not be found.');
        if(strtolower(trim((string)$dep['status']))!=='pending') throw new RuntimeException('Only pending deposits can be canceled.');
        // For UddoktaPay, verify once more before cancellation so a paid invoice is never canceled.
        if(preg_match('/uddokta|paymently/i',(string)($dep['payment_method']??'')) && !empty($dep['uddoktapay_invoice_id']) && is_file(__DIR__.'/uddoktapay-lib.php')){
            require_once __DIR__.'/uddoktapay-lib.php';
            try{xt_uddokta_complete_invoice((string)$dep['uddoktapay_invoice_id']);}catch(Throwable $verifyError){error_log('XT History cancel verification: '.$verifyError->getMessage());}
        }
        $set="status='cancelled'";
        if(in_array('user_cancelled_at',$dcols,true)) $set.=", user_cancelled_at=UTC_TIMESTAMP()";
        $cancel=$pdo->prepare("UPDATE deposits SET $set WHERE id=? AND user_id=? AND LOWER(status)='pending'");
        $cancel->execute([$depositId,$userId]);
        if($cancel->rowCount()!==1) throw new RuntimeException('Payment was already completed or processed. Refresh your history.');
        try{xt_user_notify($userId,'deposit_cancelled','Deposit cancelled','Your deposit #'.$depositId.' was cancelled. No wallet balance was added.','history.php?tab=deposit');}catch(Throwable $ignore){}
        header('Location: history.php?notice=cancelled',true,303);exit;
    }
    if(($_GET['notice']??'')==='cancelled') $notice='Your pending deposit was canceled. No wallet balance was added.';
    if(($_GET['notice']??'')==='topup_submitted') $notice='Your top-up request was submitted. The team will process it shortly.';

    // Load each activity source independently. A problem in one optional table must not hide all history.
    try{
        $cols=xt_hist_columns($pdo,'deposits');
        if(in_array('user_id',$cols,true)&&in_array('amount',$cols,true)&&in_array('status',$cols,true)&&in_array('created_at',$cols,true)){
            $method=in_array('payment_method',$cols,true)?'payment_method':"'' AS payment_method";
            $tx=in_array('transaction_id',$cols,true)?'transaction_id':"'' AS transaction_id";
            // Keep every deposit record, including canceled ones. Cancellation changes status only; no history row is deleted.
            $st=$pdo->prepare("SELECT id,amount,status,$method,$tx,created_at FROM deposits WHERE user_id=? ORDER BY created_at DESC,id DESC");
            $st->execute([$userId]);
            foreach($st->fetchAll(PDO::FETCH_ASSOC) as $r){
                $raw=strtolower(trim((string)$r['status']));
                $rows[]=['kind'=>'deposit','category'=>'deposit','id'=>(int)$r['id'],'icon'=>'💰','title'=>'Deposit','desc'=>!empty($r['transaction_id'])&&strtoupper((string)$r['transaction_id'])!=='PENDING'?'Transaction ID: '.$r['transaction_id']:'Wallet deposit','amount'=>(float)$r['amount'],'status'=>xt_hist_status($raw),'can_cancel'=>xt_hist_status($raw)==='Pending','ts'=>(int)utc_epoch_from_db($r['created_at'])];
            }
        }
    }catch(Throwable $e){error_log('XT History deposits query: '.$e->getMessage());}

    try{
        $pcols=xt_hist_columns($pdo,'user_purchases');
        if(in_array('user_id',$pcols,true)&&in_array('product_name',$pcols,true)&&in_array('plan_name',$pcols,true)&&in_array('total_amount',$pcols,true)&&in_array('created_at',$pcols,true)){
            $excluded=[];
            $tcols=xt_hist_columns($pdo,'topup_orders');
            if(in_array('purchase_id',$tcols,true)){
                try{$q=$pdo->query('SELECT purchase_id FROM topup_orders WHERE purchase_id IS NOT NULL');$excluded=array_map('intval',$q->fetchAll(PDO::FETCH_COLUMN));}catch(Throwable $ignore){}
            }
            $st=$pdo->prepare('SELECT id,product_name,plan_name,total_amount,created_at FROM user_purchases WHERE user_id=? ORDER BY created_at DESC,id DESC');
            $st->execute([$userId]);
            foreach($st->fetchAll(PDO::FETCH_ASSOC) as $r){
                if(in_array((int)$r['id'],$excluded,true)) continue;
                $cat=isset($categories)?xt_history_classify_purchase((string)$r['product_name'],(string)$r['plan_name'],$categories):'other';
                $rows[]=['kind'=>'purchase','category'=>'key-purchases','icon'=>'🛒','title'=>(string)$r['product_name'].' — '.(string)$r['plan_name'],'desc'=>'Key purchase','amount'=>(float)$r['total_amount'],'status'=>'Completed','ts'=>(int)utc_epoch_from_db($r['created_at'])];
            }
        }
    }catch(Throwable $e){error_log('XT History key purchases query: '.$e->getMessage());}

    try{
        $tcols=xt_hist_columns($pdo,'topup_orders');
        $required=['id','user_id','product_name','player_uid','total_amount','status','created_at'];
        if(!array_diff($required,$tcols)){
            $server=in_array('server_id',$tcols,true)?'server_id':"'' AS server_id";
            $st=$pdo->prepare("SELECT id,product_name,player_uid,$server,total_amount,status,created_at FROM topup_orders WHERE user_id=? ORDER BY created_at DESC,id DESC");
            $st->execute([$userId]);
            foreach($st->fetchAll(PDO::FETCH_ASSOC) as $r){
                $rows[]=['kind'=>'topup','category'=>'top-up','icon'=>'💎','title'=>(string)$r['product_name'],'desc'=>'UID: '.(string)$r['player_uid'].(!empty($r['server_id'])?' · Server: '.$r['server_id']:''),'amount'=>(float)$r['total_amount'],'status'=>xt_hist_status((string)$r['status']),'ts'=>(int)utc_epoch_from_db($r['created_at'])];
            }
        }
    }catch(Throwable $e){error_log('XT History top-up query: '.$e->getMessage());}
    try{$ns=$pdo->prepare('SELECT id,event_type,title,body,target_url,created_at,read_at FROM user_notifications WHERE user_id=? ORDER BY id DESC');$ns->execute([$userId]);$userNotices=$ns->fetchAll(PDO::FETCH_ASSOC);$uc=$pdo->prepare('SELECT COUNT(*) FROM user_notifications WHERE user_id=? AND read_at IS NULL');$uc->execute([$userId]);$userUnreadCount=(int)$uc->fetchColumn();}
    catch(Throwable $ne){error_log('XT History customer notifications: '.$ne->getMessage());}
    usort($rows,fn($a,$b)=>$b['ts']<=>$a['ts']);
}catch(Throwable $e){
    error_log('XT History page: '.$e->getMessage());
    $error='History could not be loaded right now. Please refresh the page.';
}
?>

<!doctype html><html lang="en"><head>
<link rel="stylesheet" href="theme.php?v=20261113-history2"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no,viewport-fit=cover"><title>History - XTREME TITAN</title>
<link rel="stylesheet" href="reference-theme.css"><link rel="stylesheet" href="site-polish.css"><link rel="stylesheet" href="premium-global.css"><link rel="stylesheet" href="responsive-lock.css">
<script src="theme-client.js" defer></script><script src="currency-client.js" defer></script><script src="language-client.js?v=20261114-payment-history-v5" defer></script><script src="preference-sync.js" defer></script>
<style>
.history-page{max-width:980px;margin:auto;padding:22px 14px 110px}
.history-hero{position:relative;overflow:hidden;padding:22px;border-radius:24px;border:1px solid rgba(81,115,173,.32);background:linear-gradient(145deg,#101a32,#0a1020 70%,#15102c);box-shadow:0 20px 55px #0006}
.history-kicker{color:#55e6ee;font-size:10px;font-weight:950;letter-spacing:.18em}.history-title{font-size:clamp(27px,6vw,36px);font-weight:950;letter-spacing:-.04em;margin:7px 0}.history-sub{color:#9baec9;font-size:12px;line-height:1.5}
.history-filters{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:9px;padding:15px 1px 5px;overflow:visible}
.history-filter{display:flex;align-items:center;justify-content:center;min-width:0;width:100%;min-height:44px;padding:11px 10px;border-radius:14px;border:1px solid rgba(111,145,190,.3);background:linear-gradient(145deg,#18243b,#0b1222);color:#c0cce0;font-size:12px;font-weight:900;cursor:pointer;white-space:normal;text-align:center;box-shadow:inset 0 1px 0 #ffffff0b;transition:border-color .18s,background .18s,box-shadow .18s}
.history-filter.active{color:#fff;border-color:#18d4df;background:linear-gradient(120deg,#087e9c,#3049b9);box-shadow:0 8px 22px #087e9c35,0 0 0 1px #18d4df22}
.history-ranges{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:7px;padding:7px 1px 3px}.history-range{min-width:0;border:1px solid #27334a;background:#0c1424;color:#91a2bb;border-radius:12px;padding:8px 12px;font-size:10px;font-weight:850}.history-range.active{border-color:#6d58c9;color:#e8ddff;background:#281c4b}
.history-list{display:grid;gap:11px;margin-top:15px}.history-card{position:relative;display:flex;align-items:center;gap:12px;padding:15px;border-radius:20px;border:1px solid rgba(123,139,177,.26);background:linear-gradient(145deg,rgba(23,30,51,.97),rgba(13,17,32,.98));box-shadow:0 12px 28px #0003;min-width:0}
.history-card:before{content:"";position:absolute;left:0;top:15px;bottom:15px;width:3px;border-radius:0 5px 5px 0;background:linear-gradient(#12d8c0,#448aff)}
.history-icon{flex:0 0 46px;width:46px;height:46px;display:grid;place-items:center;border-radius:14px;background:linear-gradient(145deg,#182d48,#10172a);border:1px solid #2d4160;font-size:22px}
.history-main{flex:1;min-width:0}.history-name{font-size:13px;font-weight:950;color:#f3f6ff;overflow-wrap:anywhere}.history-desc{font-size:10px;color:#8496b2;margin-top:4px;overflow-wrap:anywhere}.history-time{font-size:10px;color:#71839f;margin-top:5px}
.history-side{min-width:92px;text-align:right;display:flex;flex-direction:column;align-items:flex-end;gap:5px}.history-amount{font-size:14px;font-weight:950;white-space:nowrap;color:#36dca9}.history-card.purchase .history-amount{color:#f6bd55}
.history-status{display:inline-flex;align-items:center;justify-content:center;border-radius:99px;padding:5px 9px;font-size:9px;font-weight:950;letter-spacing:.02em;background:#253149;color:#b6c4d8}
.history-status.approved,.history-status.completed{background:#103c35;color:#62edc2;border:1px solid #1a715d}.history-status.pending{background:#44351b;color:#ffd078;border:1px solid #806025}.history-status.cancelled,.history-status.rejected,.history-status.failed{background:#481f2b;color:#ff9baa;border:1px solid #80394b}
.history-cancel{border:1px solid #a34c62;background:linear-gradient(135deg,#642438,#351a2a);color:#ffdce4;border-radius:10px;padding:7px 10px;font-size:10px;font-weight:950;cursor:pointer}
.history-notice,.history-error{padding:12px 14px;margin:12px 0;border-radius:13px;font-size:12px;line-height:1.5}.history-notice{background:#10382f;border:1px solid #248b70;color:#c6ffeb}.history-error{background:#4a1d2b;border:1px solid #a6475e;color:#ffe4eb}
.history-hero-top{display:flex;align-items:center;justify-content:space-between;gap:12px}.history-notification-btn{position:relative;flex:0 0 auto;width:42px;height:42px;border-radius:14px;border:1px solid #3b5278;background:linear-gradient(145deg,#1a2a48,#111a30);color:#f5f7ff;font-size:20px;display:grid;place-items:center;cursor:pointer;box-shadow:0 6px 18px #0004}.history-notification-count{position:absolute;top:-6px;right:-6px;min-width:18px;height:18px;padding:0 4px;border-radius:99px;background:#f04468;color:white;font-size:10px;font-weight:950;display:grid;place-items:center;border:2px solid #10182b}.history-notification-count.hidden{display:none!important}.user-notification-panel{position:fixed;z-index:1000001;top:calc(env(safe-area-inset-top,0px) + 78px);right:12px;width:min(390px,calc(100vw - 24px));max-height:min(72vh,620px);overflow:auto;padding:15px;border:1px solid #405b84;border-radius:19px;background:linear-gradient(145deg,#121f38,#090f1e);box-shadow:0 22px 70px #000b}.user-notification-panel[hidden]{display:none}.user-notification-head{display:flex;align-items:center;justify-content:space-between;gap:10px;margin-bottom:9px}.user-notification-head h2{margin:0;color:#f2f6ff;font-size:15px}.user-notification-close{border:1px solid #394d6c;background:#1a2942;color:#dce7f8;border-radius:9px;padding:6px 10px;font-weight:900}.user-notice{padding:11px 0;border-top:1px solid #263752}.user-notice b{display:block;color:#6ee7df;font-size:12px}.user-notice p{margin:4px 0;color:#c0cce0;font-size:11px;line-height:1.5}.user-notice time{color:#7589a8;font-size:10px}.user-notice.unread b:after{content:"NEW";display:inline-block;margin-left:7px;padding:2px 5px;border-radius:6px;background:#183f50;color:#8eeaff;font-size:8px}.user-notice-empty{padding:20px 8px;text-align:center;color:#aebbd0;font-size:12px}
.history-empty{text-align:center;padding:42px 18px;border-radius:20px;background:#0c1424;border:1px solid #28344e;color:#aebbd0}.history-empty strong{display:block;font-size:18px;color:#fff;margin:8px}
.hidden{display:none!important}
@media(max-width:420px){.history-ranges{grid-template-columns:repeat(2,minmax(0,1fr))}.history-page{padding-left:11px;padding-right:11px}.history-card{padding:12px 11px;gap:9px}.history-icon{width:40px;height:40px;flex-basis:40px}.history-side{min-width:82px}.history-amount{font-size:12px}.history-name{font-size:12px}}

</style>
<link rel="icon" type="image/png" sizes="48x48" href="/assets/pwa-icon-48.png"><link rel="apple-touch-icon" sizes="180x180" href="/assets/pwa-icon-180.png"><link rel="manifest" href="/pwa-manifest.json"><meta name="theme-color" content="#080a14">

<link rel="stylesheet" href="assets/xtreme-music.css?v=4">
<link rel="stylesheet" href="assets/xtreme-bottom-nav.css?v=20261117-border-v11">
</head><body>
<?php require __DIR__ . '/customer-wallet-header.php'; ?>
<main class="history-page">
<section class="history-hero"><div class="history-hero-top"><div class="history-kicker">XTREME TITAN · ACCOUNT ACTIVITY</div><button type="button" class="history-notification-btn" id="historyNotificationToggle" aria-label="Open notifications" aria-expanded="false">🔔<span class="history-notification-count <?= $userUnreadCount>0?'':'hidden' ?>" id="historyNotificationCount"><?= $userUnreadCount>99?'99+':(int)$userUnreadCount ?></span></button></div><div class="history-title" data-auto-button-label="1" data-original-button-label="Transaction History">Transaction History</div><div class="history-sub" data-auto-button-label="1" data-original-button-label="Track deposits, purchases and service activity in one place.">Track deposits, purchases and service activity in one place.</div>
<div class="history-filters" id="historyFilters">
<button class="history-filter active" data-category="all" data-auto-button-label="1" data-original-button-label="All">All</button>
<button class="history-filter" data-category="key-purchases" data-auto-button-label="1" data-original-button-label="Key History">Key History</button>
<button class="history-filter" data-category="top-up" data-auto-button-label="1" data-original-button-label="Top-Up">Top-Up</button>
<button class="history-filter" data-category="deposit" data-auto-button-label="1" data-original-button-label="Deposits">Deposits</button>
</div>
<div class="history-ranges"><button class="history-range active" data-days="0" data-auto-button-label="1" data-original-button-label="All time">All time</button><button class="history-range" data-days="1" data-auto-button-label="1" data-original-button-label="24 Hours">24 Hours</button><button class="history-range" data-days="7" data-auto-button-label="1" data-original-button-label="7 Days">7 Days</button><button class="history-range" data-days="31" data-auto-button-label="1" data-original-button-label="31 Days">31 Days</button></div>
</section>
<?php if($notice): ?><div class="history-notice" data-auto-button-label="1" data-original-button-label="<?=h($notice)?>"><?=h($notice)?></div><?php endif; ?>
<?php if($error): ?><div class="history-error" data-auto-button-label="1" data-original-button-label="<?=h($error)?>"><?=h($error)?></div><?php endif; ?>
<section class="user-notification-panel" id="historyNotificationPanel" aria-label="Notifications" hidden><div class="user-notification-head"><h2 data-auto-button-label="1" data-original-button-label="Notifications · All Updates">🔔 Notifications · All Updates</h2><button type="button" class="user-notification-close" id="historyNotificationClose">✕</button></div><?php if(!empty($userNotices)): ?><?php foreach($userNotices as $un): $noticeUrl=(string)($un['target_url']??'history.php'); if($noticeUrl===''||strpos($noticeUrl,'..')!==false||preg_match('~^[a-z]+:~i',$noticeUrl))$noticeUrl='history.php'; ?><article class="user-notice <?=empty($un['read_at'])?'unread':''?>"><a href="<?=h($noticeUrl)?>" style="display:block;color:inherit;text-decoration:none"><b data-auto-button-label="1" data-original-button-label="<?=h($un['title'])?>"><?=h($un['title'])?></b><p data-auto-button-label="1" data-original-button-label="<?=h($un['body'])?>"><?=h($un['body'])?></p><time><?=h($un['created_at'])?></time></a></article><?php endforeach; ?><?php else: ?><div class="user-notice-empty" data-auto-button-label="1" data-original-button-label="No notifications yet.">No notifications yet.</div><?php endif; ?></section>
<section id="historyList" class="history-list">
<?php foreach($rows as $r): $statusClass=strtolower((string)$r['status']); ?>
<article class="history-card <?=$r['kind']?>" data-category="<?=h($r['category'])?>" data-ts="<?=h((string)$r['ts'])?>">
<div class="history-icon"><?=$r['icon']?></div><div class="history-main"><div class="history-name" data-auto-button-label="1" data-original-button-label="<?=h($r['title'])?>"><?=h($r['title'])?></div><div class="history-desc" data-auto-button-label="1" data-original-button-label="<?=h($r['desc'])?>"><?=h($r['desc'])?></div><div class="history-time local-time" data-ts="<?=h((string)$r['ts'])?>"></div></div>
<div class="history-side"><div class="history-amount"><?=($r['kind']==='deposit'?'+':'−')?> ৳<?=h(number_format($r['amount'],2))?></div><span class="history-status <?=h($statusClass)?>" data-auto-button-label="1" data-original-button-label="<?=h($r['status'])?>"><?=h($r['status'])?></span>
<?php if($r['kind']==='deposit' && !empty($r['can_cancel'])): ?><form method="post" onsubmit="return confirm('Cancel this pending deposit? No wallet balance will be added.');"><input type="hidden" name="csrf" value="<?=h($historyCsrf)?>"><input type="hidden" name="action" value="cancel_deposit"><input type="hidden" name="deposit_id" value="<?=h((string)$r['id'])?>"><button class="history-cancel" type="submit" data-auto-button-label="1" data-original-button-label="Cancel">Cancel</button></form><?php endif; ?>
</div></article>
<?php endforeach; ?>
</section>
<div id="historyEmpty" class="history-empty <?=count($rows)?'hidden':''?>">📂<strong>No History Records</strong>Try another category or date range.<br><a class="add" href="deposit.php">＋ Add Funds</a></div>
</main>
<nav class="xt-bottom-navigation-card" aria-label="Main navigation">
<a href="store.php" data-nav="store" aria-label="Store"><span class="xt-nav-icon"><img src="assets/nav-icons/store.png" alt="" aria-hidden="true"></span><span class="xt-nav-label">Store</span></a>
<a href="my-keys.php" data-nav="keys" aria-label="My Keys"><span class="xt-nav-icon"><img src="assets/nav-icons/keys.png" alt="" aria-hidden="true"></span><span class="xt-nav-label">My Keys</span></a>
<a href="deposit.php" data-nav="funds" aria-label="Add Funds"><span class="xt-nav-icon"><img src="assets/nav-icons/funds.png" alt="" aria-hidden="true"></span><span class="xt-nav-label">Add Funds</span></a>
<a href="history.php" class="is-active" data-nav="history" aria-label="History"><span class="xt-nav-icon"><img src="assets/nav-icons/history.png" alt="" aria-hidden="true"></span><span class="xt-nav-label">History</span></a>
<a href="profile.php" data-nav="profile" aria-label="Profile"><span class="xt-nav-icon"><img src="assets/nav-icons/profile.png" alt="" aria-hidden="true"></span><span class="xt-nav-label">Profile</span></a>
</nav>
<script>
const tz=Intl.DateTimeFormat().resolvedOptions().timeZone||'Local';
const fmt=new Intl.DateTimeFormat(undefined,{day:'2-digit',month:'short',year:'numeric',hour:'2-digit',minute:'2-digit',hour12:true});
document.querySelectorAll('.local-time').forEach(e=>{const ts=Number(e.dataset.ts);e.textContent=ts>0?fmt.format(new Date(ts*1000))+' · '+tz:'Time unavailable';});
const requestedTab=new URLSearchParams(location.search).get('tab');let category=requestedTab==='deposit'?'deposit':(requestedTab==='topup'?'top-up':'all'),days=0;
function filterHistory(){const now=Math.floor(Date.now()/1000),cut=days?now-days*86400:0;let count=0;document.querySelectorAll('.history-card').forEach(card=>{const ok=(category==='all'||card.dataset.category===category)&&Number(card.dataset.ts)>=cut;card.classList.toggle('hidden',!ok);if(ok)count++;});document.getElementById('historyEmpty').classList.toggle('hidden',count!==0);document.querySelectorAll('.history-filter').forEach(b=>b.classList.toggle('active',b.dataset.category===category));}
document.querySelectorAll('.history-filter').forEach(b=>b.addEventListener('click',()=>{category=b.dataset.category;filterHistory();}));
document.querySelectorAll('.history-range').forEach(b=>b.addEventListener('click',()=>{document.querySelectorAll('.history-range').forEach(x=>x.classList.remove('active'));b.classList.add('active');days=Number(b.dataset.days);filterHistory();}));
filterHistory();
const noticeToggle=document.getElementById('historyNotificationToggle');
const noticePanel=document.getElementById('historyNotificationPanel');
const noticeClose=document.getElementById('historyNotificationClose');
const noticeCount=document.getElementById('historyNotificationCount');
function closeHistoryNotices(){noticePanel.hidden=true;noticeToggle.setAttribute('aria-expanded','false');}
noticeToggle.addEventListener('click',async()=>{const opening=noticePanel.hidden;noticePanel.hidden=!opening;noticeToggle.setAttribute('aria-expanded',opening?'true':'false');if(opening&&noticeCount&&!noticeCount.classList.contains('hidden')){const data=new FormData();data.append('action','mark_notifications_read');data.append('csrf',<?=json_encode($historyCsrf)?>);try{const response=await fetch('history.php',{method:'POST',body:data,credentials:'same-origin',headers:{'X-Requested-With':'XMLHttpRequest'}});const result=await response.json();if(result.ok){noticeCount.classList.add('hidden');noticeCount.textContent='0';noticePanel.querySelectorAll('.user-notice.unread').forEach(n=>n.classList.remove('unread'));}}catch(e){/* Keep the panel usable if marking read is temporarily unavailable. */}}});
noticeClose.addEventListener('click',closeHistoryNotices);
document.addEventListener('click',e=>{if(!noticePanel.hidden&&!noticePanel.contains(e.target)&&!noticeToggle.contains(e.target))closeHistoryNotices();});
</script>
<script src="background-video.js"></script><script src="assets/xtreme-music.js?v=4" data-enabled="<?=e(site_setting('background_music_enabled','1'))?>" data-src="<?=e(site_setting('background_music_path','uploads/music/xtreme-background.m4a'))?>" defer></script>
</body></html>
