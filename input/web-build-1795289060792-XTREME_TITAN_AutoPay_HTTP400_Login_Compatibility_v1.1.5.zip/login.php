<?php
declare(strict_types=1);
require_once __DIR__ . '/config.php';
if (session_status() !== PHP_SESSION_ACTIVE) session_start();
if (!empty($_SESSION['user_id'])) { header('Location: dashboard.php'); exit; }

$lockUntil = (int)($_SESSION['login_lockout_until'] ?? 0);
if ($lockUntil > time()) { header('Location: lockout.php'); exit; }
if ($lockUntil > 0) { unset($_SESSION['login_lockout_until'], $_SESSION['login_failed_attempts']); }

$pdo = null;
$error = '';
try { ensure_account_role_columns(); } catch (Throwable $ignore) {}
try { $pdo = db(); } catch (Throwable $e) { $error = 'Database connection failed. Please check the MySQL settings in config.php.'; }

if (empty($_SESSION['login_csrf'])) $_SESSION['login_csrf'] = bin2hex(random_bytes(32));
$csrf = $_SESSION['login_csrf'];

function lh($v): string { return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }

function col(PDO $pdo, array $names): ?string {
    $cols = $pdo->query("SHOW COLUMNS FROM users")->fetchAll(PDO::FETCH_COLUMN);
    foreach ($names as $n) if (in_array($n, $cols, true)) return $n;
    return null;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && $pdo instanceof PDO) {
    try {
        if (!hash_equals($csrf, (string)($_POST['csrf'] ?? '')))
            throw new RuntimeException('Security verification failed. Refresh and try again.');

        $identifier = trim((string)($_POST['identifier'] ?? ''));
        $password = (string)($_POST['password'] ?? '');
        if ($identifier === '') throw new RuntimeException('Enter your username, email or phone number.');
        if ($password === '') throw new RuntimeException('Enter your password.');

        $id = col($pdo, ['id','user_id']);
        $name = col($pdo, ['name','full_name']);
        $username = col($pdo, ['username']);
        $email = col($pdo, ['email','email_address']);
        $phone = col($pdo, ['phone','phone_number','mobile']);
        $pass = col($pdo, ['password','password_hash','pass']);

        if (!$id || !$pass) throw new RuntimeException('Users table is missing the required ID/password column.');

        $where = [];
        $params = [];
        if ($username) { $where[] = "`$username` = ?"; $params[] = $identifier; }
        if ($email) { $where[] = "`$email` = ?"; $params[] = $identifier; }
        if ($phone) { $where[] = "`$phone` = ?"; $params[] = $identifier; }
        if (!$where) throw new RuntimeException('No username, email or phone login field exists in users table.');

        $select = ["`$id` AS uid", "`$pass` AS pwd"];
        $select[] = $name ? "`$name` AS uname" : "'' AS uname";
        $select[] = $email ? "`$email` AS uemail" : "'' AS uemail";

        $stmt = $pdo->prepare(
            "SELECT ".implode(',',$select)." FROM users WHERE (".implode(' OR ',$where).") LIMIT 1"
        );
        $stmt->execute($params);
        $user = $stmt->fetch();

        if (!$user) throw new RuntimeException('Invalid username, email/phone or password.');

        $valid = password_verify($password, (string)$user['pwd']);

        /* Compatibility with an old plain-text installation; upgrades it immediately. */
        if (!$valid && hash_equals((string)$user['pwd'], $password)) {
            $valid = true;
            $hash = password_hash($password, PASSWORD_DEFAULT);
            $up = $pdo->prepare("UPDATE users SET `$pass`=? WHERE `$id`=? LIMIT 1");
            $up->execute([$hash, (int)$user['uid']]);
        }

        if (!$valid) throw new RuntimeException('Invalid username, email/phone or password.');

        session_regenerate_id(true);
        $_SESSION['user_id'] = (int)$user['uid'];
        $_SESSION['user_name'] = (string)$user['uname'];
        $_SESSION['user_email'] = (string)$user['uemail'];
        // Apply the country selected on the login page to this account.
        $region = strtoupper(trim((string)($_POST['region'] ?? 'BD')));
        $regionSettings = ['BD'=>['currency'=>'BDT','language'=>'bn'],'IN'=>['currency'=>'INR','language'=>'hi'],'NP'=>['currency'=>'NPR','language'=>'ne'],'BT'=>['currency'=>'BTN','language'=>'dz'],'VN'=>['currency'=>'VND','language'=>'vi'],'OT'=>['currency'=>'USD','language'=>'en']];
        if (!isset($regionSettings[$region])) $region = 'BD';
        try {
            ensure_user_preference_columns();
            $prefs = $regionSettings[$region];
            $up = $pdo->prepare('UPDATE users SET currency=?, country_code=?, language=? WHERE id=?');
            $up->execute([$prefs['currency'], $region, $prefs['language'], (int)$user['uid']]);
        } catch (Throwable $prefError) { error_log('Login preference save failed: '.$prefError->getMessage()); }
        $_SESSION['user_country'] = $region;
        $_SESSION['user_currency'] = $regionSettings[$region]['currency'];
        $_SESSION['user_language'] = $regionSettings[$region]['language'];
        unset($_SESSION['login_failed_attempts'], $_SESSION['login_lockout_until']);

        header('Location: dashboard.php');
        exit;
    } catch (Throwable $e) {
        $error = $e->getMessage();
        $attempts = (int)($_SESSION['login_failed_attempts'] ?? 0) + 1;
        $_SESSION['login_failed_attempts'] = $attempts;
        if ($attempts >= 5) {
            $_SESSION['login_lockout_until'] = time() + 600;
            header('Location: lockout.php');
            exit;
        }
    }
}
?>
<!doctype html>
<html lang="en">
<head>
<link rel="stylesheet" href="theme.php?v=20261022-lightfix3">
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover,maximum-scale=1,user-scalable=no">
<title>XTREME TITAN</title>

<?php if (empty($_SESSION['google_login_nonce'])) $_SESSION['google_login_nonce']=bin2hex(random_bytes(24)); ?>
<style>
:root{--bg:#040a12;--card:#0a1422;--text:#f2f7ff;--muted:#8395ae;--line:rgba(54,101,136,.55);--cyan:#12d9ff;--blue:#198cff;--green:#65ff16}
*{box-sizing:border-box}html,body{margin:0;min-height:100%;font-family:-apple-system,BlinkMacSystemFont,"SF Pro Text","SF Pro Display",Inter,Arial,sans-serif;color:var(--text);background:var(--bg)}
body{min-height:100vh;overflow-x:hidden}.bg{position:fixed;inset:0;width:100%;height:100%;object-fit:cover;z-index:0;filter:brightness(.48) saturate(.85)}.scrim{position:fixed;inset:0;background:linear-gradient(180deg,rgba(1,7,13,.58),rgba(1,7,13,.88));z-index:1}
.page{position:relative;z-index:2;width:min(100%,430px);min-height:100vh;margin:auto;padding:26px 12px 30px;display:flex;flex-direction:column;align-items:center}
.brand{text-align:center;width:100%;margin:0 0 15px}.brand img{width:46px;height:46px;border-radius:15px;object-fit:cover;display:block;margin:0 auto 9px;box-shadow:0 0 22px rgba(101,255,22,.16)}.brand h1{margin:0;font-size:19px;line-height:1.2;font-weight:950;letter-spacing:.15px}.brand p{margin:6px 0 0;color:var(--muted);font-size:11px}
.card{width:100%;background:linear-gradient(150deg,rgba(11,24,40,.97),rgba(5,14,25,.96));border:1px solid var(--line);border-radius:19px;padding:17px 14px 15px;box-shadow:0 18px 45px rgba(0,0,0,.34),inset 0 1px 0 rgba(255,255,255,.035);backdrop-filter:blur(15px)}
.alert{background:rgba(255,76,105,.08);border:1px solid rgba(255,76,105,.3);color:#ff9bad;border-radius:11px;padding:10px 11px;font-size:11px;line-height:1.4;margin-bottom:12px}.field{margin-bottom:12px}.field label{display:block;font-size:10px;font-weight:900;color:#9eb0c7;margin-bottom:6px;letter-spacing:.02em}.input-wrap{position:relative}.input-wrap input{width:100%;height:47px;border:1px solid var(--line);border-radius:11px;padding:0 12px;background:#050d18;color:#f2f7ff;font-size:14px;outline:0}.input-wrap input:focus{border-color:rgba(18,217,255,.75);box-shadow:0 0 0 3px rgba(18,217,255,.08)}.show{position:absolute;right:6px;top:7px;height:31px;padding:0 8px;border:1px solid rgba(54,101,136,.35);border-radius:8px;background:#0c1a2b;color:#91a4bc;font-size:10px;font-weight:900}
.submit{width:100%;height:48px;border:0;border-radius:12px;background:linear-gradient(135deg,var(--cyan),var(--blue));color:#fff;font-size:14px;font-weight:950;box-shadow:0 10px 24px rgba(25,140,255,.18)}.links{display:flex;justify-content:space-between;gap:10px;margin-top:12px}.links a{color:#12d9ff;text-decoration:none;font-size:10px;font-weight:850}.divider{display:flex;align-items:center;gap:9px;color:#6f829c;font-size:10px;margin:16px 0 10px}.divider:before,.divider:after{content:"";height:1px;background:rgba(54,101,136,.38);flex:1}.google-wrap{margin-top:4px}.google-title{text-align:center;color:#dce7f5;font-size:11px;font-weight:900;margin-bottom:7px}.google{display:flex;justify-content:center;align-items:center;min-height:44px;width:100%}.login-google{display:flex!important;justify-content:center!important;align-items:center!important;width:100%;min-height:44px}.google-wrap iframe{max-width:100%!important}.country-trigger{width:100%;margin-top:13px;height:44px;border:1px solid var(--line);border-radius:11px;background:#081321;display:flex;align-items:center;justify-content:space-between;padding:0 11px;color:#b8c5d6;font-size:11px;font-weight:800}.country-panel{display:none;margin-top:7px;border:1px solid rgba(54,101,136,.45);border-radius:13px;background:#081321;padding:5px;box-shadow:0 15px 35px rgba(0,0,0,.24)}.country-panel.open{display:block}.country-option{width:100%;display:flex;align-items:center;gap:8px;border:0;background:transparent;color:#dce6f2;border-radius:9px;padding:9px 7px;text-align:left}.country-option.selected,.country-option:hover{background:#0d2032}.flag{width:24px;font-size:17px}.country-name{flex:1}.country-name b{display:block;font-size:11px}.country-name small{display:block;color:#71859e;font-size:9px;margin-top:1px}.country-code{font-size:9px;color:#71859e;font-weight:900}.footer-note{text-align:center;color:#63758d;font-size:8px;margin-top:11px}
@media(max-width:430px){.page{padding:20px 10px 24px}.brand h1{font-size:18px}.card{padding:15px 12px 13px}}
</style>
<link rel="stylesheet" href="site-polish.css?v=20260928-v7">
<script>
function handleGoogleCredential(response){if(!response||!response.credential){alert('Google did not return a login credential. Please try again.');return;}const body=new URLSearchParams();body.set('credential',response.credential);try{body.set('region',localStorage.getItem('xtreme_country')||document.getElementById('login_region')?.value||'BD')}catch(e){body.set('region',document.getElementById('login_region')?.value||'BD')}fetch('google-auth.php',{method:'POST',body:body.toString(),credentials:'same-origin',headers:{'Accept':'application/json','Content-Type':'application/x-www-form-urlencoded; charset=UTF-8'}}).then(async r=>{const raw=await r.text();let j;try{j=JSON.parse(raw);}catch(e){console.error('google-auth.php non-JSON response:',r.status,raw.slice(0,1000));throw new Error('Google Login server error (HTTP '+r.status+'). Response: '+raw.replace(/<[^>]*>/g,' ').replace(/\s+/g,' ').trim().slice(0,220));}if(j.ok){location.href='dashboard.php';return;}throw new Error(j.error||'Google Login failed.');}).catch(e=>alert(e.message||'Google Login failed. Please try again.'));}
</script>
<script src="theme-client.js?v=20260928-200" defer></script><link rel="stylesheet" href="premium-global.css?v=20261022-lightfix3"><script src="currency-client.js?v=20261018-fx1" defer></script><script src="language-client.js?v=20261023-full-language-v50" defer></script><link rel="stylesheet" href="responsive-lock.css?v=20260929-28">
<link rel="stylesheet" href="auth-premium.css?v=20261022-1">
<link rel="icon" type="image/png" sizes="48x48" href="favicon.png"><link rel="apple-touch-icon" sizes="180x180" href="assets/pwa-icon-180.png"><link rel="manifest" href="pwa-manifest.json"><meta name="apple-mobile-web-app-title" content="XTREME TITAN"><meta name="apple-mobile-web-app-capable" content="yes"><meta name="theme-color" content="#080a14"><script src="/admin/admin-action-progress.js?v=20261023-inline-progress25" defer></script>

<link rel="stylesheet" href="pwa-install-prompt.css?v=1">
</head>
<body class="auth-login">
<img class="bg" src="assets/tanofficial_neon_background.gif" alt="">
<div class="scrim"></div>
<main class="page">
  <header class="brand">
    <img src="assets/xtreme-titan-logo.jpg" alt="XTREME TITAN OFFICIAL">
    <h1>XTREME_TITAN_OFFICIAL SHOP</h1>
    <p>Sign in to your account</p>
  </header>

  <section class="card">
    <?php if ($error !== ''): ?><div class="alert"><?=lh($error)?></div><?php endif; ?>
    <button type="button" class="auth-region-trigger" id="auth-region-trigger">🌍 <span id="auth-region-label">Select Your Region · Bangladesh (BDT)</span> <b>⌄</b></button>
    <form method="post" autocomplete="on">
      <input type="hidden" name="csrf" value="<?=lh($csrf)?>">
      <input type="hidden" name="region" id="login_region" value="BD">
      <div class="field">
        <label for="identifier">Username / Email / Phone</label>
        <div class="input-wrap"><input id="identifier" name="identifier" type="text" autocomplete="username" placeholder="Enter your login" required autofocus value="<?=lh($_POST['identifier'] ?? '')?>"></div>
      </div>
      <div class="field">
        <label for="password">Password</label>
        <div class="input-wrap"><input id="password" name="password" type="password" autocomplete="current-password" placeholder="Enter your password" required><button class="show" type="button" id="show">SHOW</button></div>
      </div>
      <button class="submit" type="submit">Sign in</button>
    </form>

    <div class="links"><a href="register.php">Create account</a><a href="forgot-password.php">Forgot password?</a></div>

    <div class="divider">or</div>
    <div class="google-wrap"><div class="google-title">Continue with Google</div><div id="g_id_onload" data-client_id="865419675972-n8g84i701iu6ngui7c9auvoqv889v17n.apps.googleusercontent.com" data-callback="handleGoogleCredential" data-auto_prompt="false" data-auto_select="false" data-nonce="<?=lh((string)($_SESSION['google_login_nonce']??''))?>"></div><div class="google-button-shell"><button type="button" class="google-region-proxy" id="google-region-proxy"><svg class="google-g-mark" aria-hidden="true" viewBox="0 0 48 48"><path fill="#EA4335" d="M24 9.5c3.54 0 6.71 1.22 9.21 3.6l6.85-6.85C35.9 2.38 30.47 0 24 0 14.62 0 6.51 5.38 2.56 13.22l7.98 6.19C12.43 13.72 17.74 9.5 24 9.5z"/><path fill="#4285F4" d="M46.98 24.55c0-1.57-.15-3.09-.38-4.55H24v9.02h12.94c-.58 2.96-2.26 5.48-4.74 7.18l7.65 5.93c4.47-4.13 7.13-10.2 7.13-17.58z"/><path fill="#FBBC05" d="M10.53 28.59A14.4 14.4 0 0 1 9.75 24c0-1.59.27-3.13.76-4.59l-7.98-6.19A23.9 23.9 0 0 0 0 24c0 3.87.93 7.52 2.56 10.78l7.97-6.19z"/><path fill="#34A853" d="M24 48c6.48 0 11.93-2.13 15.9-5.87l-7.65-5.93c-2.12 1.42-4.84 2.26-8.25 2.26-6.26 0-11.57-4.22-13.47-9.91l-7.98 6.19C6.51 42.62 14.62 48 24 48z"/></svg><span>Continue with Google</span></button><div class="g_id_signin login-google" data-type="standard" data-shape="rectangular" data-theme="outline" data-text="continue_with" data-size="large" data-width="320"></div></div></div>

    <div style="text-align:center;margin-top:12px;font-size:10px"><a href="reseller-login.php" style="color:#c084fc;text-decoration:none;font-weight:900">Reseller Login</a> · <a href="reseller-register.php" style="color:#c084fc;text-decoration:none;font-weight:900">Reseller Register</a></div><div class="footer-note">Secure account authentication. Your existing XTREME TITAN images and branding are unchanged.</div>
  </section>
</main>
<script>
const pw=document.getElementById('password'),show=document.getElementById('show');
show.addEventListener('click',()=>{const plain=pw.type==='text';pw.type=plain?'password':'text';show.textContent=plain?'SHOW':'HIDE'});
</script>
<link rel="stylesheet" href="auth-region-picker.css?v=20261022-official-google-button-fix2"><script src="auth-region-picker.js?v=20261022-official-google-button-fix2" defer></script>

<script src="pwa-install-prompt.js?v=1" defer></script>
</body>
</html>

<style id="login-final-controls">.google-wrap{margin-top:10px!important;width:100%!important}.google-title{font-size:10px!important;margin-bottom:8px!important}.login-google{margin:0 auto!important;max-width:100%!important}.google-wrap iframe{max-width:100%!important}.brand h1{font-size:18px!important}</style>
