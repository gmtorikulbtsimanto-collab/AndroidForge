<?php
declare(strict_types=1);
require_once __DIR__.'/config.php';
header('Content-Type: application/json; charset=utf-8');
if(empty($_SESSION['user_id'])){http_response_code(401);echo json_encode(['ok'=>false,'error'=>'Login required']);exit;}
ensure_user_preference_columns();
if ($_SERVER['REQUEST_METHOD'] === 'GET') { try { $st=db()->prepare('SELECT currency,country_code,language FROM users WHERE id=? LIMIT 1'); $st->execute([(int)$_SESSION['user_id']]); $r=$st->fetch(PDO::FETCH_ASSOC) ?: []; $c=strtoupper((string)($r['country_code']??'US')); $cur=strtoupper((string)($r['currency']??'USD')); $lang=strtolower((string)($r['language']??'en')); echo json_encode(['ok'=>true,'currency'=>$cur,'country'=>$c,'language'=>$lang,'meta'=>currency_meta($cur)]); } catch(Throwable $e) { http_response_code(500); echo json_encode(['ok'=>false]); } exit; }
$country=strtoupper(trim((string)($_POST['country']??'')));
$currency=strtoupper(trim((string)($_POST['currency']??'')));
$language=strtolower(trim((string)($_POST['language']??'')));
if(!in_array($language,['en','bn','hi','ne','dz','it','ar','vi'],true)) $language='en';
$allowed=['BD'=>'BDT','IT'=>'EUR','AE'=>'AED','IN'=>'INR','NP'=>'NPR','BT'=>'BTN','VN'=>'VND','GB'=>'GBP','US'=>'USD','OT'=>'USD'];
if($language==='') $language=['BD'=>'bn','IN'=>'hi','NP'=>'ne','BT'=>'dz','VN'=>'vi','OT'=>'en','US'=>'en','IT'=>'it','AE'=>'ar','GB'=>'en'][$country]??'en';
if(isset($allowed[$country])) $currency=$allowed[$country];
if(!in_array($currency,['USD','EUR','BDT','AED','INR','NPR','BTN','VND','GBP'],true)) $currency='USD';
if($country==='' || !isset($allowed[$country])) foreach($allowed as $cc=>$cur){if($cur===$currency){$country=$cc;break;}}
try{
 ensure_user_preference_columns();
 $st=db()->prepare('UPDATE users SET currency=?, country_code=?, language=? WHERE id=?');
 $st->execute([$currency,$country,$language,(int)$_SESSION['user_id']]);
 echo json_encode(['ok'=>true,'currency'=>$currency,'country'=>$country,'language'=>$language,'meta'=>currency_meta($currency)]);
}catch(Throwable $e){http_response_code(500);echo json_encode(['ok'=>false,'error'=>'Could not save preferences']);}
