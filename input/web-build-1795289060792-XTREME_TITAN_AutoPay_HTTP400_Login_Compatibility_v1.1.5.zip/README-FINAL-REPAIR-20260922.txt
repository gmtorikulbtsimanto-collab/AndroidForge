XTREME_TITAN_OFFICIAL SHOP — FINAL REPAIR

Fixed in this package:
1) My Keys purchase time is displayed in Europe/Rome and countdown expiry is calculated from the purchased timestamp using Rome calendar days, including DST-safe day addition.
2) Admin panel uses the supplied XTREME TITAN logo as a small centered logo at the top.
3) Admin Products now supports direct upload of product image/video from the phone, in addition to media URL. Allowed: JPG, PNG, WebP, GIF, MP4, WebM, OGG, MOV. Max 25 MB. Uploaded files are stored in uploads/product-media/.
4) Store supports uploaded relative media files, direct video, YouTube and Vimeo embeds.
5) Store keeps the animated tanofficial_neon_background.gif background.
6) Google Identity Services now enables One Tap / auto-select settings. Google verification has a cURL fallback to PHP URL streams if cURL is unavailable.
7) Bottom navigation remains exactly 5 items: Store, My Keys, Deposit, History, Profile.

IMPORTANT:
- Do NOT replace your existing config.php.
- Upload/replace the other files from this ZIP.
- The product-media upload directory is created automatically when an admin uploads the first file.
- For Google automatic sign-in, the Google OAuth client must have the exact authorized origin https://xtremetitanofficial.gamer.free and authorized redirect URI https://xtremetitanofficial.gamer.free/google-login.php. Google documents that data-login_uri must exactly match an authorized redirect URI and data-auto_prompt/data-auto_select control One Tap/automatic selection.
