XTREME_TITAN_OFFICIAL SHOP — FIXED5

This build includes:
1. Purchase timestamps are stored in UTC for new purchases/deposits.
2. My Keys countdown starts from the exact purchase timestamp and counts exactly 30/15/7/1 days in seconds.
3. Dates/times shown in My Keys and History use the visitor's own device timezone automatically (Italy, Bangladesh, Dubai, etc.). No Europe/Rome hard-code remains.
4. A purchased key now receives purchased_at = UTC_TIMESTAMP() at the moment the buy transaction assigns it.
5. Deposit form has stronger client-side validation and a clear submitting state; server-side errors are shown instead of silently failing.
6. Old Nagad/bKash floating decoration images are removed from the background. Payment logos remain available on the Deposit payment-method cards.
7. The accidental visible CSS comment on the Store page is removed.
8. Premium glass/gradient/shadow styling has been added to key cards, history cards, payment methods and buttons.

IMPORTANT:
- Upload/replace the files from this ZIP in htdocs.
- Do not expose or share config.php publicly.
- Existing historical timestamps already stored in the database cannot be reconstructed reliably without knowing the original stored timezone. New records will use UTC and display in each visitor's local timezone.
