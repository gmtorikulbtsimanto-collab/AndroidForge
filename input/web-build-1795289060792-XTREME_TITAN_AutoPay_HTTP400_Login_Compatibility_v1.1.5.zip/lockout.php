<?php
declare(strict_types=1);
require_once __DIR__ . '/config.php';
if (session_status() !== PHP_SESSION_ACTIVE) session_start();
$until=(int)($_SESSION['login_lockout_until']??0);
$seconds=max(0,$until-time());
if($seconds<=0){unset($_SESSION['login_lockout_until'],$_SESSION['login_failed_attempts']); header('Location: login.php'); exit;}
?>
<!doctype html><html lang="en"><head>
<link rel="stylesheet" href="theme.php?v=20261022-lightfix3"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no"><title>Temporarily Locked — XTREME_TITAN_OFFICIAL SHOP</title><link rel="stylesheet" href="reference-auth.css"><link rel="stylesheet" href="site-polish.css?v=20261022-lightfix3"><script src="theme-client.js?v=20260928-19" defer></script><link rel="stylesheet" href="premium-global.css?v=20261022-lightfix3"><script src="currency-client.js?v=20261018-fx1" defer></script><link rel="stylesheet" href="responsive-lock.css?v=20260929-28">

<link rel="icon" type="image/png" sizes="48x48" href="/assets/pwa-icon-48.png">
<link rel="apple-touch-icon" sizes="180x180" href="/assets/pwa-icon-180.png">
<link rel="manifest" href="/pwa-manifest.json">
<meta name="apple-mobile-web-app-title" content="XTREME TITAN">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="mobile-web-app-capable" content="yes">
<meta name="theme-color" content="#080a14">
<script src="/admin/admin-action-progress.js?v=20261023-inline-progress25" defer></script>
</head><body><img class="tanofficial-neon-bg" src="assets/tanofficial_neon_background.gif" alt=""><main class="box lockout-card" style="text-align:center"><div class="logo lockout-brand">XTREME <span>TITAN</span> OFFICIAL</div><h1 style="font-size:28px;margin:18px 0 8px">Temporarily Locked</h1><p class="sub">Too many unsuccessful login attempts. Please wait a few minutes and try again.</p><div class="alert" style="text-align:center">Security lockout is active for this session.</div><a class="btn" href="login.php" style="display:block;text-decoration:none;text-align:center">BACK TO LOGIN</a></main></body></html>