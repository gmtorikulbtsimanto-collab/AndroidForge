XTREME TITAN DASHBOARD QUICK ACCESS V14

Dashboard-only fix in store.php. Normalizes the four Quick Access icon images to equal visible size, removes duplicate wallet background artwork from Add Funds, uses a fixed grid so labels do not push arrows into oval shapes, and gives arrows fixed circular dimensions. Unique green, blue, amber, and purple gradients retained. Does not alter purchase, deposit, key, balance, or navigation logic.
