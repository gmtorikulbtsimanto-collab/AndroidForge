<?php

require_once __DIR__ . '/../config.php';
// Avoid stale admin forms carrying expired CSRF tokens.
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
header('Pragma: no-cache');


/*
|--------------------------------------------------------------------------
| ADMIN PROTECTION
|--------------------------------------------------------------------------
*/

if (empty($_SESSION['admin_id']) && empty($_SESSION['admin_logged_in'])) {
    header('Location: login.php');
    exit;
}


$pdo = db();
ensure_catalog_product_columns();
// Ensure plan duration in seconds exists before the Product Editor saves hour-based plans.
try {
    $planCols = $pdo->query('SHOW COLUMNS FROM product_plans')->fetchAll(PDO::FETCH_COLUMN);
    if (!in_array('duration_seconds', $planCols, true)) {
        $pdo->exec("ALTER TABLE product_plans ADD COLUMN duration_seconds INT NULL");
    }
    $pdo->exec("UPDATE product_plans SET duration_seconds = CASE WHEN duration_days < 0 THEN ABS(duration_days) * 3600 ELSE duration_days * 86400 END WHERE duration_seconds IS NULL");
} catch (Throwable $ignore) {}

$message = (string)($_SESSION['product_flash'] ?? '');
unset($_SESSION['product_flash']);
$error = '';

function parseProductLinks(string $description): array
{
    $out = ['UPDATE'=>'','SETUP'=>'','LINK'=>'','MEDIA'=>'','IMAGE'=>'','VIDEO'=>'','GROUP'=>'','SETUP_LABEL'=>'','GROUP_LABEL'=>'','EXTRA1'=>'','EXTRA1_LABEL'=>'','EXTRA1_ON'=>'0','EXTRA2'=>'','EXTRA2_LABEL'=>'','EXTRA2_ON'=>'0','FEATURES'=>'','STATUS_TAGS'=>''];
    foreach (preg_split('/\R/', $description) ?: [] as $line) {
        if (preg_match('/^\s*\[(UPDATE|SETUP|LINK|MEDIA|IMAGE|VIDEO|GROUP|SETUP_LABEL|GROUP_LABEL|EXTRA1|EXTRA1_LABEL|EXTRA1_ON|EXTRA2|EXTRA2_LABEL|EXTRA2_ON|FEATURE_ON|FEATURE_OFF|STATUS_TAGS)\]\s*(.*?)\s*$/i', $line, $m)) {
            $value = trim($m[2]);
            if ($value !== '' && (filter_var($value, FILTER_VALIDATE_URL) || preg_match('~^(?:/)?(?:uploads/product-media|media)/[A-Za-z0-9._/-]+$~', $value))) {
                if (strtoupper($m[1]) === 'FEATURE_ON' || strtoupper($m[1]) === 'FEATURE_OFF') { $out['FEATURES'] .= strtoupper($m[1]) . '|' . $value . "\n"; } else { $out[strtoupper($m[1])] = $value; }
            } else {
                if (strtoupper($m[1]) === 'FEATURE_ON' || strtoupper($m[1]) === 'FEATURE_OFF') { $out['FEATURES'] .= strtoupper($m[1]) . '|' . $value . "\n"; } else { $out[strtoupper($m[1])] = $value; }
            }
        }
    }
    return $out;
}

function cleanProductDescription(string $description): string
{
    return trim((string)preg_replace('/^\s*\[(UPDATE|SETUP|LINK|MEDIA|IMAGE|VIDEO|GROUP|SETUP_LABEL|GROUP_LABEL|EXTRA1|EXTRA1_LABEL|EXTRA1_ON|EXTRA2|EXTRA2_LABEL|EXTRA2_ON|FEATURE_ON|FEATURE_OFF|STATUS_TAGS)\]\s*.*?\s*$/im', '', $description));
}

function saveProductMediaUpload(array $file): string
{
    if (($file['error'] ?? UPLOAD_ERR_NO_FILE) === UPLOAD_ERR_NO_FILE) return '';
    $uploadError = (int)($file['error'] ?? UPLOAD_ERR_NO_FILE);
    if ($uploadError === UPLOAD_ERR_NO_FILE) return '';
    if ($uploadError !== UPLOAD_ERR_OK) {
        if ($uploadError === UPLOAD_ERR_INI_SIZE || $uploadError === UPLOAD_ERR_FORM_SIZE) {
            throw new RuntimeException('The server rejected this media file because it exceeds the hosting upload limit. Try a smaller video.');
        }
        if ($uploadError === UPLOAD_ERR_PARTIAL) throw new RuntimeException('The media upload was interrupted. Please select the file and try again.');
        throw new RuntimeException('Product media upload failed (upload error ' . $uploadError . ').');
    }
    // Large videos are transferred in small chunks by the browser and arrive here as a saved URL.
    if (str_starts_with((string)($file['type'] ?? ''), 'image/') && (int)($file['size'] ?? 0) > 8 * 1024 * 1024) throw new RuntimeException('Product photos must be 8 MB or smaller.');
    if (str_starts_with((string)($file['type'] ?? ''), 'video/') && (int)($file['size'] ?? 0) > 8 * 1024 * 1024) throw new RuntimeException('Please use the chunked video upload control.');
    $tmp = (string)($file['tmp_name'] ?? '');
    if ($tmp === '' || !is_uploaded_file($tmp)) throw new RuntimeException('Invalid uploaded media.');
    $mime = function_exists('finfo_open') ? (function() use ($tmp) { $f=finfo_open(FILEINFO_MIME_TYPE); $m=$f?finfo_file($f,$tmp):''; if($f) finfo_close($f); return (string)$m; })() : (string)($file['type'] ?? '');
    $allowed = [
        'image/jpeg'=> 'jpg', 'image/png'=>'png', 'image/webp'=>'webp', 'image/gif'=>'gif',
        'video/mp4'=>'mp4', 'video/webm'=>'webm', 'video/ogg'=>'ogv', 'video/quicktime'=>'mov'
    ];
    // Some mobile/browser uploads are sniffed as application/octet-stream by shared hosting.
    // Fall back to a strict extension allowlist rather than rejecting valid iPhone MOV/MP4 files.
    $ext = strtolower(pathinfo((string)($file['name'] ?? ''), PATHINFO_EXTENSION));
    $extensionMap = ['jpg'=>'jpg','jpeg'=>'jpg','png'=>'png','webp'=>'webp','gif'=>'gif','mp4'=>'mp4','webm'=>'webm','ogv'=>'ogv','ogg'=>'ogv','mov'=>'mov'];
    if (!isset($allowed[$mime]) && isset($extensionMap[$ext])) {
        $isImageExt = in_array($ext, ['jpg','jpeg','png','webp','gif'], true);
        $isVideoExt = in_array($ext, ['mp4','webm','ogv','ogg','mov'], true);
        if (($isImageExt && str_starts_with($mime, 'image/')) || ($isVideoExt && (str_starts_with($mime, 'video/') || $mime === 'application/octet-stream' || $mime === ''))) {
            $allowed[$mime] = $extensionMap[$ext];
        }
    }
    if (!isset($allowed[$mime])) throw new RuntimeException('Only JPG, PNG, WebP, GIF, MP4, WebM, OGG or MOV files are allowed.');
    $dir = dirname(__DIR__) . '/uploads/product-media';
    if (!is_dir($dir) && !mkdir($dir, 0755, true) && !is_dir($dir)) throw new RuntimeException('Could not create product media folder.');
    $name = 'product_' . date('Ymd_His') . '_' . bin2hex(random_bytes(5)) . '.' . $allowed[$mime];
    $dest = $dir . '/' . $name;
    if (!move_uploaded_file($tmp, $dest)) throw new RuntimeException('Could not save uploaded product media.');
    return 'uploads/product-media/' . $name;
}


/*
|--------------------------------------------------------------------------
| CSRF
|--------------------------------------------------------------------------
*/

if (empty($_SESSION['admin_csrf'])) {
    $_SESSION['admin_csrf'] = bin2hex(random_bytes(32));
}

$csrf = $_SESSION['admin_csrf'];


/*
|--------------------------------------------------------------------------
| SAVE PRODUCT
|--------------------------------------------------------------------------
*/


/**
 * Remove rows that reference a parent row through a declared foreign key.
 * Used only for deleting a product and its dependent records. Wallets and
 * deposits are not deleted unless they explicitly have a foreign key to the
 * product being removed.
 */
function deleteProductDependents(PDO $pdo, string $parentTable, string $parentColumn, array $ids, int $depth = 0, array &$path = []): void
{
    $ids = array_values(array_unique(array_filter(array_map('intval', $ids), static fn($v) => $v > 0)));
    if (!$ids || $depth > 8 || !preg_match('/^[A-Za-z0-9_]+$/', $parentTable) || !preg_match('/^[A-Za-z0-9_]+$/', $parentColumn)) return;
    $pathKey = strtolower($parentTable . '.' . $parentColumn);
    if (isset($path[$pathKey])) return;
    $path[$pathKey] = true;

    $meta = $pdo->prepare(
        "SELECT TABLE_NAME, COLUMN_NAME
           FROM information_schema.KEY_COLUMN_USAGE
          WHERE REFERENCED_TABLE_SCHEMA = DATABASE()
            AND REFERENCED_TABLE_NAME = ?
            AND REFERENCED_COLUMN_NAME = ?"
    );
    $meta->execute([$parentTable, $parentColumn]);
    $children = $meta->fetchAll(PDO::FETCH_ASSOC);
    $marks = implode(',', array_fill(0, count($ids), '?'));

    foreach ($children as $child) {
        $table = (string)($child['TABLE_NAME'] ?? '');
        $column = (string)($child['COLUMN_NAME'] ?? '');
        if (!preg_match('/^[A-Za-z0-9_]+$/', $table) || !preg_match('/^[A-Za-z0-9_]+$/', $column)) continue;
        if (strtolower($table) === strtolower($parentTable) && strtolower($column) === strtolower($parentColumn)) continue;

        // Find child primary-key columns so their own dependents can be cleared first.
        $pkStmt = $pdo->prepare(
            "SELECT COLUMN_NAME FROM information_schema.KEY_COLUMN_USAGE
              WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ? AND CONSTRAINT_NAME = 'PRIMARY'
              ORDER BY ORDINAL_POSITION"
        );
        $pkStmt->execute([$table]);
        $pkColumns = $pkStmt->fetchAll(PDO::FETCH_COLUMN);
        $qt = '`' . $table . '`';
        $qc = '`' . $column . '`';

        if ($pkColumns) {
            $selectPk = implode(',', array_map(static fn($c) => '`' . str_replace('`', '``', (string)$c) . '`', $pkColumns));
            $rowsStmt = $pdo->prepare("SELECT {$selectPk} FROM {$qt} WHERE {$qc} IN ({$marks})");
            $rowsStmt->execute($ids);
            foreach ($rowsStmt->fetchAll(PDO::FETCH_ASSOC) as $row) {
                foreach ($pkColumns as $pkColumn) {
                    $pkValue = $row[$pkColumn] ?? null;
                    if ($pkValue !== null && ctype_digit((string)$pkValue) && (int)$pkValue > 0) {
                        deleteProductDependents($pdo, $table, (string)$pkColumn, [(int)$pkValue], $depth + 1, $path);
                    }
                }
            }
        }
        $delete = $pdo->prepare("DELETE FROM {$qt} WHERE {$qc} IN ({$marks})");
        $delete->execute($ids);
    }
    unset($path[$pathKey]);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    // PHP empties both $_POST and $_FILES when the full multipart body exceeds post_max_size.
    // That is an upload-size problem, not a bad CSRF token.
    $contentLength = (int)($_SERVER['CONTENT_LENGTH'] ?? 0);
    $postMaxRaw = trim((string)ini_get('post_max_size'));
    $postMaxBytes = 0;
    if ($postMaxRaw !== '') {
        $unit = strtolower(substr($postMaxRaw, -1));
        $num = (float)$postMaxRaw;
        $postMaxBytes = (int)($num * (['g'=>1073741824,'m'=>1048576,'k'=>1024][$unit] ?? 1));
    }
    if ($contentLength > 0 && empty($_POST) && empty($_FILES) && $postMaxBytes > 0 && $contentLength > $postMaxBytes) {
        $error = 'Upload too large for this hosting server. Please choose smaller files (keep photo + video together under about 7 MB), then save again.';
    } elseif (
        !isset($_POST['csrf']) || !is_string($_POST['csrf']) ||
        !hash_equals($csrf, $_POST['csrf'])
    ) {
        $error = 'Security verification failed. Refresh Admin Products and try again. If this repeats with small files, sign out of Admin and sign in again.';
    }

    elseif (($_POST['action'] ?? '') === 'add_product') {
        $name = trim((string)($_POST['new_product_name'] ?? ''));
        $description = trim((string)($_POST['new_product_description'] ?? ''));
        $category = strtoupper(trim((string)($_POST['new_product_category'] ?? 'PRO')));
        $platformInput = array_map(static fn($v) => strtoupper(trim((string)$v)), (array)(!empty($_POST['new_product_platform']) ? $_POST['new_product_platform'] : (isset($_POST['new_product_platform_csv']) ? explode(',', (string)$_POST['new_product_platform_csv']) : ['ALL'])));
        $allowedPlatforms = ['ALL','ANDROID_NONROOT','IPHONE','ANDROID_ROOT','PC_PANEL_FF','LIVE_KEY'];
        $platforms = array_values(array_intersect($allowedPlatforms, $platformInput));
        $chosenPlatforms = array_values(array_diff($platforms, ['ALL']));
        $platform = $chosenPlatforms ? implode(',', $chosenPlatforms) : 'ALL';
        $liveStatus = isset($_POST['new_product_live']) ? 1 : 0;
        $allowedStatusTags = ['SAFE'=>'SAFE','RISK'=>'RISK','UPDATING'=>'UPDATING','TESTING'=>'TESTING'];
        $newStatusTags = array_values(array_intersect(array_keys($allowedStatusTags), array_map('strtoupper', (array)($_POST['new_product_status_tags'] ?? []))));
        if ($newStatusTags) $description .= ($description !== '' ? "\n" : '') . '[STATUS_TAGS] ' . implode(',', $newStatusTags);
        if (!in_array($category,['PRO','BASIC','CUSTOM'],true)) $category='PRO';
        if ($platform === '') $platform = 'ALL';
        if ($name === '') {
            $error = 'Product name is required.';
        } else {
            try {
                $newImage = saveProductMediaUpload($_FILES['new_image_file'] ?? []);
                $newVideo = saveProductMediaUpload($_FILES['new_video_file'] ?? []);
                if ($newImage !== '' && !preg_match('/\.(jpg|jpeg|png|webp|gif)$/i', $newImage)) throw new RuntimeException('Please choose an image file for Product Photo.');
                if ($newVideo !== '' && !preg_match('/\.(mp4|webm|ogv|mov)$/i', $newVideo)) throw new RuntimeException('Please choose a video file for Product Video.');
                if ($newImage !== '') $description .= ($description !== '' ? "\n" : '') . '[IMAGE] ' . $newImage;
                if ($newVideo !== '') $description .= ($description !== '' ? "\n" : '') . '[VIDEO] ' . $newVideo;
                $pdo->beginTransaction();
                $stmt = $pdo->prepare('INSERT INTO catalog_products(name,description,status,category,platform,live_status) VALUES(?,?,?,?,?,?)');
                $stmt->execute([$name, $description, 1, $category, $platform, $liveStatus]);
                $productId = (int)$pdo->lastInsertId();
                // Do not seed hard-coded plans. Admin creates only the durations needed in Plan Manager.
                $pdo->commit();
                $message = 'New product added. Add only the plans you need in Plan Manager.';
            } catch (Throwable $e) {
                if ($pdo->inTransaction()) $pdo->rollBack();
                $error = $e->getMessage();
            }
        }
    }

    elseif (($_POST['action'] ?? '') === 'delete_product') {
        $productId = (int)($_POST['product_id'] ?? 0);
        if ($productId <= 0) {
            $error = 'Invalid product.';
        } else {
            try {
                $pdo->beginTransaction();
                // First remove rows declared as foreign-key dependents (including
                // key/reset/history rows), then clear any legacy product_id tables.
                // Account-wide wallet balances and deposits are not touched.
                try {
                    $path = [];
                    deleteProductDependents($pdo, 'catalog_products', 'id', [$productId], 0, $path);
                } catch (Throwable $fkCleanupError) {
                    // Continue with explicit legacy cleanup below; the final DELETE
                    // reports any remaining foreign-key constraint clearly.
                }
                try {
                    $pdo->prepare('DELETE FROM key_reset_requests WHERE key_id IN (SELECT id FROM user_keys WHERE product_id = ?)')->execute([$productId]);
                } catch (Throwable $ignored) {}
                try {
                    $meta = $pdo->prepare("SELECT TABLE_NAME FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND COLUMN_NAME = 'product_id' AND TABLE_NAME NOT IN ('catalog_products','product_plans','user_keys')");
                    $meta->execute();
                    foreach ($meta->fetchAll(PDO::FETCH_COLUMN) as $childTable) {
                        if (!preg_match('/^[A-Za-z0-9_]+$/', (string)$childTable)) continue;
                        $quotedTable = '`' . str_replace('`', '``', (string)$childTable) . '`';
                        $pdo->prepare("DELETE FROM {$quotedTable} WHERE product_id = ?")->execute([$productId]);
                    }
                } catch (Throwable $cleanupError) {}
                $pdo->prepare('DELETE FROM user_keys WHERE product_id = ?')->execute([$productId]);
                $pdo->prepare('DELETE FROM product_plans WHERE product_id = ?')->execute([$productId]);
                $deleteProduct = $pdo->prepare('DELETE FROM catalog_products WHERE id = ?');
                $deleteProduct->execute([$productId]);
                if ($deleteProduct->rowCount() < 1) {
                    throw new RuntimeException('Product was not deleted: no matching product ID was found.');
                }
                if ($pdo->inTransaction()) $pdo->commit();
                $message = 'Product deleted successfully.';
            } catch (Throwable $e) {
                if ($pdo->inTransaction()) $pdo->rollBack();
                $error = $e->getMessage();
            }
        }
    }

    elseif (
        ($_POST['action'] ?? '') === 'save_product'
    ) {

        $productId = (int)($_POST['product_id'] ?? 0);

        $name = trim($_POST['name'] ?? '');

        $description = cleanProductDescription(trim((string)($_POST['description'] ?? '')));
        $allowedStatusTags = ['SAFE'=>'SAFE','RISK'=>'RISK','UPDATING'=>'UPDATING','TESTING'=>'TESTING'];
        $selectedStatusTags = array_values(array_intersect(array_keys($allowedStatusTags), array_map('strtoupper', (array)($_POST['product_status_tags'] ?? []))));
        if ($selectedStatusTags) $description .= ($description !== '' ? "\n" : '') . '[STATUS_TAGS] ' . implode(',', $selectedStatusTags);
        $category = strtoupper(trim((string)($_POST['category'] ?? 'PRO')));
        $platformInput = array_map(static fn($v) => strtoupper(trim((string)$v)), (array)(!empty($_POST['platform']) ? $_POST['platform'] : (isset($_POST['platform_csv']) ? explode(',', (string)$_POST['platform_csv']) : ['ALL'])));
        $allowedPlatforms = ['ALL','ANDROID_NONROOT','IPHONE','ANDROID_ROOT','PC_PANEL_FF','LIVE_KEY'];
        $platforms = array_values(array_intersect($allowedPlatforms, $platformInput));
        $chosenPlatforms = array_values(array_diff($platforms, ['ALL']));
        $platform = $chosenPlatforms ? implode(',', $chosenPlatforms) : 'ALL';
        $liveStatus = isset($_POST['live_status']) ? 1 : 0;
        if (!in_array($category,['PRO','BASIC','CUSTOM'],true)) $category='PRO';
        if ($platform === '') $platform = 'ALL';

        $productBeforeEdit = [];
        if ($productId > 0) { $oldStmt = $pdo->prepare('SELECT description FROM catalog_products WHERE id=?'); $oldStmt->execute([$productId]); $productBeforeEdit = ['description'=>(string)$oldStmt->fetchColumn()]; }
        $updateLink = trim((string)($_POST['update_link'] ?? ''));
        $setupLink = trim((string)($_POST['setup_link'] ?? ''));
        $mediaLink = trim((string)($_POST['media_link'] ?? ''));
        $groupLink = trim((string)($_POST['group_link'] ?? ''));
        $setupLabel = trim((string)($_POST['setup_label'] ?? ''));
        $groupLabel = trim((string)($_POST['group_label'] ?? ''));
        $extra1Link = trim((string)($_POST['extra1_link'] ?? ''));
        $extra1Label = trim((string)($_POST['extra1_label'] ?? ''));
        $extra1On = isset($_POST['extra1_on']) ? '1' : '0';
        $extra2Link = trim((string)($_POST['extra2_link'] ?? ''));
        $extra2Label = trim((string)($_POST['extra2_label'] ?? ''));
        $extra2On = isset($_POST['extra2_on']) ? '1' : '0';
        if ($setupLabel === '') $setupLabel = '🎥 Setup Video';
        if ($groupLabel === '') $groupLabel = '👥 Join Product Group';
        if ($extra1Label === '') $extra1Label = '📁 Download File';
        if ($extra2Label === '') $extra2Label = '🔗 More Info';
        // Keep Setup Video separate from the product card media.
        // Older records that only have SETUP are still supported by the Store.
        $productLink = trim((string)($_POST['product_link'] ?? ''));

        foreach (['Update File'=>$updateLink,'Product Media'=>$mediaLink,'Product Group'=>$groupLink,'Product Link'=>$productLink,'Extra Button 1'=>$extra1Link,'Extra Button 2'=>$extra2Link] as $label=>$url) {
            $ok = $url === '' || filter_var($url, FILTER_VALIDATE_URL);
            // Also allow safe site-relative links, e.g. /downloads/file.zip or /files/manual.pdf.
            if ($url !== '' && preg_match('~^/(?!/)[A-Za-z0-9._~!$&\'()*+,;=:@%/-]+$~', $url)) $ok = true;
            if ($label === 'Product Media' && $url !== '' && preg_match('~^(?:/)?(?:uploads/product-media|media)/[A-Za-z0-9._/-]+$~', $url)) $ok = true;
            if (!$ok) { $error = $label . ' must be a valid URL.'; break; }
        }
        $imageLink = trim((string)($_POST['image_link'] ?? ''));
        $videoLink = trim((string)($_POST['video_link'] ?? ''));
        foreach (['Product Image'=>$imageLink, 'Product Video'=>$videoLink] as $label=>$url) {
            if ($url !== '' && !filter_var($url, FILTER_VALIDATE_URL) && !preg_match('~^(?:/)?(?:uploads/product-media|media)/[A-Za-z0-9._/-]+$~', $url)) {
                $error = $label . ' must be a valid URL.'; break;
            }
        }
        if ($error === '') {
            try {
                $uploadedImage = saveProductMediaUpload($_FILES['image_file'] ?? []);
                $uploadedVideo = saveProductMediaUpload($_FILES['video_file'] ?? []);
                // Validate that each upload matches its dedicated field.
                if ($uploadedImage !== '' && !preg_match('/\.(jpg|jpeg|png|webp|gif)$/i', $uploadedImage)) throw new RuntimeException('Please choose an image file for Product Image.');
                if ($uploadedVideo !== '' && !preg_match('/\.(mp4|webm|ogv|mov)$/i', $uploadedVideo)) throw new RuntimeException('Please choose a video file for Product Video.');
                if ($uploadedImage !== '') $imageLink = $uploadedImage;
                if ($uploadedVideo !== '') $videoLink = $uploadedVideo;
                // Backwards compatibility: old single media input still works.
                $uploadedMedia = saveProductMediaUpload($_FILES['media_file'] ?? []);
                if ($uploadedMedia !== '') $mediaLink = $uploadedMedia;
            } catch (Throwable $uploadError) {
                $error = $uploadError->getMessage();
            }
        }
        // Preserve previously saved URLs when an edit form submits an empty URL field.
        // A blank field must not erase existing media/link metadata; choose a new URL to replace it.
        $oldLinks = parseProductLinks((string)($productBeforeEdit['description'] ?? ''));
        foreach (['UPDATE'=>'updateLink','SETUP'=>'setupLink','MEDIA'=>'mediaLink','GROUP'=>'groupLink','LINK'=>'productLink','IMAGE'=>'imageLink','VIDEO'=>'videoLink','EXTRA1'=>'extra1Link','EXTRA2'=>'extra2Link'] as $kind=>$varName) {
            if ($$varName === '' && !empty($oldLinks[$kind])) { $hasReplacement = (($kind==='IMAGE' && !empty($uploadedImage)) || ($kind==='VIDEO' && !empty($uploadedVideo)) || ($kind==='MEDIA' && !empty($uploadedMedia))); if (!$hasReplacement) $$varName = $oldLinks[$kind]; }
        }
        if ($error === '' && $updateLink !== '') $description .= ($description !== '' ? "\n" : '') . '[UPDATE] ' . $updateLink;
        if ($error === '' && $imageLink !== '') $description .= ($description !== '' ? "\n" : '') . '[IMAGE] ' . $imageLink;
        if ($error === '' && $videoLink !== '') $description .= ($description !== '' ? "\n" : '') . '[VIDEO] ' . $videoLink;
        if ($error === '' && $mediaLink !== '') $description .= ($description !== '' ? "\n" : '') . '[MEDIA] ' . $mediaLink;
        if ($error === '' && $setupLink !== '') $description .= ($description !== '' ? "\n" : '') . '[SETUP] ' . $setupLink;
        if ($error === '' && $groupLink !== '') $description .= ($description !== '' ? "\n" : '') . '[GROUP] ' . $groupLink;
        if ($error === '') $description .= ($description !== '' ? "\n" : '') . '[SETUP_LABEL] ' . $setupLabel;
        if ($error === '') $description .= "\n" . '[GROUP_LABEL] ' . $groupLabel;
        if ($error === '' && $productLink !== '') $description .= ($description !== '' ? "\n" : '') . '[LINK] ' . $productLink;
        if ($error === '') $description .= "\n[EXTRA1_LABEL] " . $extra1Label . "\n[EXTRA1_ON] " . $extra1On;
        if ($error === '' && $extra1Link !== '') $description .= "\n[EXTRA1] " . $extra1Link;
        if ($error === '') $description .= "\n[EXTRA2_LABEL] " . $extra2Label . "\n[EXTRA2_ON] " . $extra2On;
        if ($error === '' && $extra2Link !== '') $description .= "\n[EXTRA2] " . $extra2Link;
        if ($error === '') {
    // Preserve feature cards on an ordinary re-save. Some mobile/browser form
    // submissions can omit or empty the textarea; do not silently erase saved
    // ON/OFF features unless the user submits replacement feature lines.
    $submittedFeatureLines = [];
    // Accept both the human-facing format (ON | text) and the stored-tag
    // format used by earlier builds (FEATURE_ON|text). This was the cause of
    // features disappearing on a second save: neither format was parsed by V33.
    $parseFeatureLine = static function (string $line): ?array {
        $line = trim($line);
        if ($line === '') return null;
        if (preg_match('/^(ON|OFF)\s*\|\s*(.+)$/i', $line, $m)) {
            return [strtoupper($m[1]) === 'ON' ? 'FEATURE_ON' : 'FEATURE_OFF', trim($m[2])];
        }
        if (preg_match('/^(FEATURE_ON|FEATURE_OFF)\s*\|\s*(.+)$/i', $line, $m)) {
            return [strtoupper($m[1]), trim($m[2])];
        }
        return null;
    };
    foreach (preg_split('/\R/', (string)($_POST['features_text'] ?? '')) ?: [] as $featureLine) {
        $parsedFeature = $parseFeatureLine($featureLine);
        if ($parsedFeature !== null) $submittedFeatureLines[] = $parsedFeature;
    }
    if (!$submittedFeatureLines) {
        $savedFeatureMeta = parseProductLinks((string)($productBeforeEdit['description'] ?? ''));
        foreach (preg_split('/\R/', trim((string)($savedFeatureMeta['FEATURES'] ?? ''))) ?: [] as $savedFeatureLine) {
            $parsedFeature = $parseFeatureLine($savedFeatureLine);
            if ($parsedFeature !== null) $submittedFeatureLines[] = $parsedFeature;
        }
    }
    foreach ($submittedFeatureLines as [$featureTag, $featureText]) {
        $description .= ($description !== '' ? "\n" : '') . '[' . $featureTag . '] ' . $featureText;
    }
}

        $productStatus =
            isset($_POST['product_status'])
            ? 1
            : 0;


        if ($productId <= 0) {

            $error = 'Invalid product.';

        }

        elseif ($name === '') {

            $error = 'Product name is required.';

        }

        else {

            try {

                $pdo->beginTransaction();


                /*
                |--------------------------------------------------------------------------
                | UPDATE PRODUCT
                |--------------------------------------------------------------------------
                */

                $stmt = $pdo->prepare(
                    'UPDATE catalog_products
                     SET
                        name = ?,
                        description = ?,
                        status = ?,
                        category = ?,
                        platform = ?,
                        live_status = ?
                     WHERE id = ?'
                );

                $stmt->execute([
                    $name,
                    $description,
                    $productStatus,
                    $category,
                    $platform,
                    $liveStatus,
                    $productId
                ]);


                /*
                |--------------------------------------------------------------------------
                | UPDATE 4 PLANS
                |--------------------------------------------------------------------------
                */

                $planIds =
                    $_POST['plan_id'] ?? [];

                $durationDays =
                    $_POST['duration_days'] ?? [];

                $durationLabels =
                    $_POST['duration_label'] ?? [];

                $prices =
                    $_POST['price'] ?? [];

                $stocks =
                    $_POST['stock'] ?? [];

                $planStatuses =
                    $_POST['plan_status'] ?? [];


                $planStmt = $pdo->prepare(
                    'UPDATE product_plans
                     SET
                        duration_days = ?,
                        duration_seconds = ?,
                        duration_label = ?,
                        price = ?,
                        stock = ?,
                        status = ?
                     WHERE id = ?
                     AND product_id = ?'
                );


                foreach ($planIds as $index => $planId) {

                    $planId = (int)$planId;

                    if ($planId <= 0) {
                        continue;
                    }


                    $days =
                        (int)($durationDays[$index] ?? 0);

                    $label =
                        trim(
                            $durationLabels[$index] ?? ''
                        );

                    $price =
                        (float)($prices[$index] ?? 0);

                    $stock =
                        (int)($stocks[$index] ?? 0);

                    $planStatus =
                        isset($planStatuses[$index])
                        ? 1
                        : 0;


                    if ($label === '') {
                        throw new Exception(
                            'Plan name cannot be empty.'
                        );
                    }

                    // Negative duration_days is the existing storage convention for hours.
                    // The form shows a positive number; infer the unit from the plan label.
                    $isHourPlan = (bool)preg_match('/\b(hours?|hrs?)\b/i', $label);
                    if ($days === 0 || (!$isHourPlan && $days < 1) || ($isHourPlan && abs($days) < 1)) {
                        throw new Exception($isHourPlan ? 'Duration must be at least 1 hour.' : 'Duration must be at least 1 day.');
                    }
                    $days = $isHourPlan ? -abs($days) : abs($days);
                    $durationSeconds = $isHourPlan ? abs($days) * 3600 : $days * 86400;

                    if ($price < 0) {
                        throw new Exception(
                            'Price cannot be negative.'
                        );
                    }

                    if ($stock < 0) {
                        throw new Exception(
                            'Stock cannot be negative.'
                        );
                    }


                    $planStmt->execute([
                        $days,
                        $durationSeconds,
                        $label,
                        number_format(
                            $price,
                            2,
                            '.',
                            ''
                        ),
                        $stock,
                        $planStatus,
                        $planId,
                        $productId
                    ]);
                }


                $pdo->commit();

                $_SESSION['product_flash'] = 'Product and all 4 plans updated successfully.';
                header('Location: products.php', true, 303);
                exit;


            } catch (Throwable $e) {

                if ($pdo->inTransaction()) {
                    $pdo->rollBack();
                }

                $error =
                    $e->getMessage();
            }
        }
    }
}


/*
|--------------------------------------------------------------------------
| LOAD PRODUCTS + PLANS
|--------------------------------------------------------------------------
*/

$products = [];

try {

    $stmt = $pdo->query(
        'SELECT
            id,
            name,
            description,
            status,
            category,
            platform,
            live_status,
            created_at
         FROM catalog_products
         ORDER BY id ASC'
    );

    $products = $stmt->fetchAll();


    $planStmt = $pdo->prepare(
        'SELECT
            id,
            product_id,
            duration_days,
            duration_label,
            price,
            stock,
            status
         FROM product_plans
         WHERE product_id = ?
         ORDER BY duration_days ASC'
    );


    foreach ($products as &$product) {

        $planStmt->execute([
            (int)$product['id']
        ]);

        $product['plans'] =
            $planStmt->fetchAll();
    }

    unset($product);


} catch (Throwable $e) {

    $error =
        'Unable to load product catalog.';
}

?>

<!doctype html>

<html lang="en">

<head>

<meta charset="utf-8">

<meta
    name="viewport"
    content="width=device-width,initial-scale=1"
>

<title>
    Products — XTREME_TITAN_OFFICIAL SHOP
</title>


<style>

* {
    box-sizing: border-box;
}

body {
    margin: 0;
    background: #07111d;
    color: #eef4ff;
    font-family: Arial, Helvetica, sans-serif;
}

.container {
    max-width: 1000px;
    margin: auto;
    padding: 20px 14px 50px;
}


/* HEADER */

.header {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 12px;
    margin-bottom: 25px;
}

.brand {
    font-size: 19px;
    font-weight: 900;
}

.brand span {
    opacity: .55;
}

.admin-text {
    color: #8799b0;
    font-size: 11px;
    margin-top: 4px;
}

.header-links {
    display: flex;
    gap: 8px;
}

.header-links a {
    text-decoration: none;
    color: #63ff16;
    background: rgba(99,255,22,.07);
    padding: 8px 10px;
    border-radius: 9px;
    font-size: 11px;
    font-weight: 900;
}


/* TITLE */

h1 {
    margin: 0 0 6px;
    font-size: 32px;
}

.subtitle {
    margin: 0 0 20px;
    color: #9aa9bf;
    font-size: 13px;
}


/* ALERT */

.alert {
    padding: 12px 14px;
    border-radius: 11px;
    margin-bottom: 15px;
    font-size: 12px;
}

.success {
    background: #15351c;
    border: 1px solid #285e31;
    color: #8dff63;
}

.error {
    background: #3b1c24;
    border: 1px solid #63303b;
    color: #ff8999;
}


/* PRODUCT */

.product {
    background: #0e1a29;
    border: 1px solid #26384e;
    border-radius: 18px;
    padding: 18px;
    margin-bottom: 15px;
}

.product-head {
    display: flex;
    justify-content: space-between;
    align-items: center;
    gap: 10px;
    margin-bottom: 15px;
}

.product-number {
    color: #71839a;
    font-size: 10px;
    margin-bottom: 3px;
}

.product-title {
    font-size: 18px;
    font-weight: 900;
}

.badge {
    padding: 5px 9px;
    border-radius: 999px;
    font-size: 9px;
    font-weight: 900;
}

.badge.on {
    background: #17351c;
    color: #8dff63;
}

.badge.off {
    background: #3b1c24;
    color: #ff8999;
}


/* FORM */

label {
    display: block;
    color: #9aa9bf;
    font-size: 10px;
    font-weight: 900;
    margin: 11px 0 5px;
}

input,
textarea {
    width: 100%;
    padding: 10px 11px;
    border-radius: 9px;
    border: 1px solid #293c53;
    background: #091522;
    color: #eef4ff;
    outline: none;
    font-family: inherit;
}

textarea {
    min-height: 65px;
    resize: vertical;
}

input:focus,
textarea:focus {
    border-color: #63ff16;
}


/* PLANS */

.plans-title {
    margin-top: 18px;
    margin-bottom: 8px;
    font-size: 13px;
    font-weight: 900;
}

.plan {
    border: 1px solid #21334a;
    background: #0a1624;
    border-radius: 12px;
    padding: 12px;
    margin-top: 9px;
}

.plan-label {
    font-size: 11px;
    font-weight: 900;
    margin-bottom: 8px;
    color: #d8e3f1;
}

.plan-grid {
    display: grid;
    grid-template-columns: 1fr 1fr 1fr 1fr;
    gap: 8px;
}

.checkbox {
    display: flex;
    align-items: center;
    gap: 7px;
    color: #aab9cb;
    font-size: 10px;
    margin-top: 9px;
}

.checkbox input {
    width: auto;
}


/* SAVE */

.save {
    width: 100%;
    margin-top: 15px;
    padding: 12px;
    border: 0;
    border-radius: 10px;
    background: #63ff16;
    color: #06101c;
    font-size: 13px;
    font-weight: 900;
    cursor: pointer;
}

.save:hover {
    opacity: .9;
}


/* MOBILE */

@media(max-width:700px) {

    .header {
        align-items: flex-start;
    }

    .header-links {
        flex-direction: column;
    }

    h1 {
        font-size: 27px;
    }

    .plan-grid {
        grid-template-columns: 1fr 1fr;
    }
}

@media(max-width:420px) {

    .container {
        padding: 15px 10px 40px;
    }

    .product {
        padding: 13px;
    }

    .plan-grid {
        grid-template-columns: 1fr;
    }
}


/* Fixed28 product editor: compact selector + focused editing */
.product-toolbar{display:grid;grid-template-columns:1fr minmax(300px,420px);gap:14px;align-items:center;padding:16px 18px;margin:0 0 16px;border:1px solid rgba(16,216,255,.22);border-radius:18px;background:linear-gradient(145deg,rgba(10,23,38,.94),rgba(5,13,24,.94));box-shadow:0 18px 50px rgba(0,0,0,.24);position:sticky;top:10px;z-index:30;backdrop-filter:blur(16px)}
.toolbar-copy{display:flex;flex-direction:column;gap:4px}.toolbar-copy strong{font-size:15px}.toolbar-copy span{font-size:11px;color:#8ea0b6;line-height:1.45}.toolbar-controls{display:grid;grid-template-columns:1.2fr .8fr;gap:8px}.toolbar-controls select,.toolbar-controls input{min-height:44px;margin:0!important}.product-editor{scroll-margin-top:90px}.product-editor.is-hidden{display:none!important}.product-editor.is-focused{border-color:rgba(16,216,255,.58)!important;box-shadow:0 24px 70px rgba(0,0,0,.30),0 0 0 2px rgba(16,216,255,.08)!important}.editor-actions{display:grid;grid-template-columns:1fr 180px;gap:10px;margin-top:15px}.delete-product{width:100%;padding:12px;border:1px solid rgba(255,76,118,.42);border-radius:10px;background:rgba(255,76,118,.10);color:#ff9aae;font-size:13px;font-weight:900;cursor:pointer}.delete-product:hover{background:rgba(255,76,118,.18)}
@media(max-width:700px){.product-toolbar{grid-template-columns:1fr;position:sticky;top:6px;padding:13px}.toolbar-controls{grid-template-columns:1fr}.editor-actions{grid-template-columns:1fr}.delete-product{min-height:48px}}
</style><link rel="stylesheet" href="../theme.php?v=20260929-27"><link rel="stylesheet" href="admin-theme.css">

<script src="admin-background.js?v=20260929-27" defer></script><link rel="stylesheet" href="../responsive-lock.css?v=20260929-28">
<style>.status-tag-admin{margin:12px 0;padding:12px;border:1px solid rgba(80,180,255,.28);border-radius:12px;background:rgba(15,30,50,.55)}.status-tag-admin>strong{display:block;margin-bottom:9px}.status-tag-options{display:flex;flex-wrap:wrap;gap:8px}.status-tag-options label{display:inline-flex;align-items:center;gap:5px;padding:7px 9px;border:1px solid rgba(140,170,200,.3);border-radius:9px;font-size:12px}.status-tag-admin small{display:block;margin-top:7px;color:#8ea4bd;font-size:11px}</style>
<script src="admin-action-progress.js?v=20261023-inline-progress25" defer></script>
<script>
/* Shared-hosting compatibility: send ordinary admin edits as URL-encoded POST.
   Only use multipart encoding when a real file is selected for upload. */
(function () {
  document.addEventListener('submit', function (event) {
    var form = event.target;
    if (!(form instanceof HTMLFormElement)) return;
    var action = form.querySelector('input[name="action"]');
    var actionName = action ? action.value : '';
    if (!['add_product', 'save_product', 'delete_product'].includes(actionName)) return;
    var fileInputs = Array.prototype.slice.call(form.querySelectorAll('input[type="file"]'));
    var hasSelectedFile = fileInputs.some(function (input) {
      return input.files && input.files.length > 0;
    });
    form.enctype = hasSelectedFile ? 'multipart/form-data' : 'application/x-www-form-urlencoded';
  }, true);
})();
</script>
<link rel="icon" type="image/png" sizes="48x48" href="/assets/pwa-icon-48.png">
<link rel="apple-touch-icon" sizes="180x180" href="/assets/pwa-icon-180.png">
<link rel="manifest" href="/admin/admin-manifest.json">
<meta name="apple-mobile-web-app-title" content="XTREME TITAN">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="mobile-web-app-capable" content="yes">
<meta name="theme-color" content="#080a14">
</head>


<body><div class="admin-panel-logo"><img src="../assets/xtreme-titan-logo.jpg" alt="XTREME TITAN"></div>


<div class="container">


<header class="header">

    <div>

        <div class="brand">
            XTREME_TITAN_OFFICIAL
            <span>SHOP</span>
        </div>

        <div class="admin-text">
            Admin Product Management
        </div>

    </div>


    <div class="header-links">

        <a href="dashboard.php">Dashboard</a>
        <a href="site-settings.php">Site Settings</a>
        <a href="deposits.php">
            Deposits
        </a>

        <a href="logout.php">
            Logout
        </a>

    </div>

</header>


<h1>
    Products
</h1>

<p class="subtitle">
    Add new products, edit existing products, change media/links, prices, stock and 1 / 7 / 15 / 30 day plans.
</p>


<?php if ($message): ?>

<div class="alert success">
    <?= e($message) ?>
</div>

<?php endif; ?>


<?php if ($error): ?>

<div class="alert error">
    <?= e($error) ?>
</div>

<?php endif; ?>



<section class="product" style="border-color:rgba(16,216,255,.32);">
<div class="product-head"><div><div class="product-number">ADD NEW PRODUCT</div><div class="product-title">Create from Admin Panel</div></div><span class="badge on">NEW</span></div>
<form method="post" action="products.php" enctype="application/x-www-form-urlencoded">
<input type="hidden" name="csrf" value="<?= e($csrf) ?>"><input type="hidden" name="action" value="add_product">
<label>New Product Name</label><input type="text" name="new_product_name" maxlength="150" placeholder="Example: Free Fire Panel" required>
<input type="hidden" name="new_product_platform_csv" value="ALL"><div class="plan-grid"><div><label>Product Type</label><select name="new_product_category"><option value="PRO">PRO</option><option value="BASIC">BASIC</option><option value="CUSTOM">CUSTOM</option></select></div><div><label>Platform</label><div class="platform-choice-grid"><label><input type="checkbox" name="new_product_platform[]" value="ALL" checked> All / Multi-platform</label><label><input type="checkbox" name="new_product_platform[]" value="ANDROID_NONROOT"> Android Non Root</label><label><input type="checkbox" name="new_product_platform[]" value="IPHONE"> Apple iOS Product</label><label><input type="checkbox" name="new_product_platform[]" value="ANDROID_ROOT"> Android Root</label><label><input type="checkbox" name="new_product_platform[]" value="PC_PANEL_FF"> PC PANEL FF</label><label><input type="checkbox" name="new_product_platform[]" value="LIVE_KEY"> LIVE KEYS</label></div></div></div>
<label class="checkbox"><input type="checkbox" name="new_product_live" value="1" checked> Online (ON) / Maintenance (OFF)</label>
<div class="status-tag-admin"><strong>Photo top-left badges</strong><div class="status-tag-options">
<label><input type="checkbox" name="new_product_status_tags[]" value="SAFE"> SAFE</label>
<label><input type="checkbox" name="new_product_status_tags[]" value="RISK"> RISK</label>
<label><input type="checkbox" name="new_product_status_tags[]" value="UPDATING"> UPDATING</label>
<label><input type="checkbox" name="new_product_status_tags[]" value="TESTING"> TESTING</label>
</div><small>Select any badges to show on the product photo.</small></div>
<label>Initial Description</label><textarea name="new_product_description" placeholder="Optional product description"></textarea>
<label>Product Photo (optional, max 8 MB)</label><input type="file" name="new_image_file" accept="image/jpeg,image/png,image/webp,image/gif">
<label>Product Video (optional; up to 300 MB via chunked upload)</label><input type="file" name="new_video_file" accept="video/mp4,video/webm,video/ogg,video/quicktime">
<div style="color:#71839a;font-size:10px;line-height:1.5;margin:6px 0 12px">You can upload a photo (max 8 MB) and a video (max 300 MB) for the same product. Videos upload in 2 MB chunks to work around PHP post_max_size limits; the host must still have enough storage and allow the request rate.</div>
<button class="save" type="submit">+ ADD PRODUCT</button>
</form></section>

<section class="product-toolbar">
    <div class="toolbar-copy">
        <strong>Product Editor</strong>
        <span>Select one product to edit it. You no longer need to scroll through every product.</span>
    </div>
    <div class="toolbar-controls">
        <select id="productPicker" aria-label="Select product">
            <option value="all" selected>Show all products</option><option value="">Select a product to edit</option>
            <?php foreach ($products as $pick): ?>
                <option value="product-<?= (int)$pick['id'] ?>">#<?= (int)$pick['id'] ?> — <?= e($pick['name']) ?></option>
            <?php endforeach; ?>
        </select>
        <input id="productSearch" type="search" placeholder="Search product…" aria-label="Search product">
    </div>
</section>

<?php foreach ($products as $product): ?>


<form
    method="post"
    action="<?= e(basename(__FILE__)) ?>"
    enctype="application/x-www-form-urlencoded"
    class="product product-editor"
    id="product-<?= (int)$product['id'] ?>"
    data-product-name="<?= e(strtolower($product['name'])) ?>"
>


<input
    type="hidden"
    name="csrf"
    value="<?= e($csrf) ?>"
>


<input
    type="hidden"
    name="action"
    value="save_product"
>


<input
    type="hidden"
    name="product_id"
    value="<?= (int)$product['id'] ?>"
>


<div class="product-head">

    <div>

        <div class="product-number">
            PRODUCT #<?= (int)$product['id'] ?>
        </div>

        <div class="product-title">
            <?= e($product['name']) ?>
        </div>

    </div>


    <?php if ((int)$product['status'] === 1): ?>

        <span class="badge on">
            ACTIVE
        </span>

    <?php else: ?>

        <span class="badge off">
            INACTIVE
        </span>

    <?php endif; ?>

</div>


<label>
    Product Name
</label>

<input
    type="text"
    name="name"
    maxlength="150"
    value="<?= e($product['name']) ?>"
    required
>

<div class="plan-grid">
<div><label>Product Type</label><select name="category"><option value="PRO" <?= (($product['category'] ?? 'PRO')==='PRO'?'selected':'') ?>>PRO</option><option value="BASIC" <?= (($product['category'] ?? '')==='BASIC'?'selected':'') ?>>BASIC</option><option value="CUSTOM" <?= (($product['category'] ?? '')==='CUSTOM'?'selected':'') ?>>CUSTOM</option></select></div>
<input type="hidden" name="platform_csv" value="ALL"><div><label>Platform</label><?php $selectedPlatforms = array_map('trim', explode(',', strtoupper((string)($product['platform'] ?? 'ALL')))); ?><div class="platform-choice-grid"><label><input type="checkbox" name="platform[]" value="ALL" <?= (in_array('ALL', $selectedPlatforms, true)?'checked':'') ?>> All / Multi-platform</label><label><input type="checkbox" name="platform[]" value="ANDROID_NONROOT" <?= (in_array('ANDROID_NONROOT', $selectedPlatforms, true)?'checked':'') ?>> Android Non Root</label><label><input type="checkbox" name="platform[]" value="IPHONE" <?= (in_array('IPHONE', $selectedPlatforms, true)?'checked':'') ?>> Apple iOS Product</label><label><input type="checkbox" name="platform[]" value="ANDROID_ROOT" <?= (in_array('ANDROID_ROOT', $selectedPlatforms, true)?'checked':'') ?>> Android Root</label><label><input type="checkbox" name="platform[]" value="PC_PANEL_FF" <?= (in_array('PC_PANEL_FF', $selectedPlatforms, true)?'checked':'') ?>> PC PANEL FF</label><label><input type="checkbox" name="platform[]" value="LIVE_KEY" <?= (in_array('LIVE_KEY', $selectedPlatforms, true)?'checked':'') ?>> LIVE KEYS</label></div></div>
</div>
<label class="checkbox"><input type="checkbox" name="live_status" value="1" <?= ((int)($product['live_status'] ?? 1)===1?'checked':'') ?>> Online (ON) / Maintenance (OFF)</label>
<?php $productStatusTags = array_filter(array_map('trim', explode(',', (string)(parseProductLinks((string)($product['description'] ?? ''))['STATUS_TAGS'] ?? '')))); ?>
<div class="status-tag-admin"><strong>Photo top-left badges</strong><div class="status-tag-options">
<label><input type="checkbox" name="product_status_tags[]" value="SAFE" <?= in_array('SAFE',$productStatusTags,true)?'checked':'' ?>> SAFE</label>
<label><input type="checkbox" name="product_status_tags[]" value="RISK" <?= in_array('RISK',$productStatusTags,true)?'checked':'' ?>> RISK</label>
<label><input type="checkbox" name="product_status_tags[]" value="UPDATING" <?= in_array('UPDATING',$productStatusTags,true)?'checked':'' ?>> UPDATING</label>
<label><input type="checkbox" name="product_status_tags[]" value="TESTING" <?= in_array('TESTING',$productStatusTags,true)?'checked':'' ?>> TESTING</label>
</div><small>Check or uncheck badges for this product. Maintenance / Online stays on the right.</small></div>

<label>
    Product Description
</label>

<textarea
    name="description"
><?= e(cleanProductDescription((string)($product['description'] ?? ''))) ?></textarea>

<?php $links = parseProductLinks((string)($product['description'] ?? '')); ?>
<?php $mediaLink = $links['MEDIA']; $imageLink = $links['IMAGE']; $videoLink = $links['VIDEO']; $setupLink = $links['SETUP']; ?>
<label>Product Image URL (optional)</label>
<input type="text" inputmode="url" name="image_link" placeholder="https://... image.jpg" value="<?= e($imageLink) ?>">
<label>Upload Product Photo</label>
<input type="file" name="image_file" accept="image/jpeg,image/png,image/webp,image/gif">
<label>Product Video URL (optional)</label>
<input type="text" inputmode="url" name="video_link" placeholder="https://... video.mp4 or YouTube/Vimeo link" value="<?= e($videoLink) ?>">
<label>Upload Product Video</label>
<input type="file" name="video_file" accept="video/mp4,video/webm,video/ogg,video/quicktime">
<label>Legacy Media URL (optional)</label>
<input type="text" inputmode="url" name="media_link" placeholder="Older single image/video link" value="<?= e($mediaLink) ?>">
<label>Setup Video Link</label>
<input type="url" name="setup_link" placeholder="https://youtube.com/... or https://.../setup.mp4" value="<?= e($setupLink) ?>">
<div style="color:#71839a;font-size:10px;margin-top:6px;line-height:1.5">This link is used only by the Setup Video button. It does not replace the product card image/video.</div>
<div style="color:#71839a;font-size:10px;margin-top:6px;line-height:1.5">Upload photo and video separately. Product photos: max 8 MB. Product videos: max 300 MB using chunked upload. InfinityFree may still enforce storage, bandwidth, or request limits; if a 100 MB upload is blocked by the host, use a direct MP4/WebM URL instead.</div>
<div style="color:#71839a;font-size:10px;margin-top:6px;line-height:1.5">The product photo appears first with a play icon over it; tapping the icon starts the video. Direct MP4/WebM/Ogg links and YouTube/Vimeo URLs are supported.</div>

<label>Join Product Group / Channel</label>
<input type="url" name="group_link" placeholder="https://t.me/... or https://discord.gg/..." value="<?= e($links['GROUP']) ?>">
<label>Setup Video Button Text</label>
<input type="text" name="setup_label" maxlength="40" placeholder="🎥 Setup Video" value="<?= e($links['SETUP_LABEL'] ?: '🎥 Setup Video') ?>">
<label>Group / Channel Button Text</label>
<input type="text" name="group_label" maxlength="40" placeholder="👥 Join Product Group" value="<?= e($links['GROUP_LABEL'] ?: '👥 Join Product Group') ?>">
<div style="color:#71839a;font-size:10px;margin-top:6px;line-height:1.5">Store-এ এই দুইটি button সব product-এ একই লাইনে, সমান width-এ থাকবে। প্রতিটি product-এর text ও link এখান থেকেই পরিবর্তন করতে পারবেন।</div>

<div style="margin-top:18px;padding:14px;border:1px solid #1e4960;border-radius:14px;background:rgba(8,25,40,.55)">
<strong style="display:block;margin-bottom:10px">Extra Button 1 — File Manager / Download</strong>
<label>Button 1 Link</label><input type="url" name="extra1_link" placeholder="https://... (file manager / download URL)" value="<?= e($links['EXTRA1'] ?? '') ?>">
<label>Button 1 Name</label><input type="text" name="extra1_label" maxlength="40" placeholder="📁 Download File" value="<?= e($links['EXTRA1_LABEL'] ?: '📁 Download File') ?>">
<label class="checkbox"><input type="checkbox" name="extra1_on" value="1" <?= (($links['EXTRA1_ON'] ?? '0') === '1') ? 'checked' : '' ?>> Show Button 1 on Store (ON/OFF)</label>
<hr style="border:0;border-top:1px solid #26384e;margin:14px 0">
<strong style="display:block;margin-bottom:10px">Extra Button 2 — Custom Link</strong>
<label>Button 2 Link</label><input type="url" name="extra2_link" placeholder="https://..." value="<?= e($links['EXTRA2'] ?? '') ?>">
<label>Button 2 Name</label><input type="text" name="extra2_label" maxlength="40" placeholder="🔗 More Info" value="<?= e($links['EXTRA2_LABEL'] ?: '🔗 More Info') ?>">
<label class="checkbox"><input type="checkbox" name="extra2_on" value="1" <?= (($links['EXTRA2_ON'] ?? '0') === '1') ? 'checked' : '' ?>> Show Button 2 on Store (ON/OFF)</label>
<div style="color:#71839a;font-size:10px;line-height:1.5;margin-top:8px">Link, button name and visibility are saved per product. Turn OFF to hide the button from the user-facing Store.</div>
</div>

<label>Update File Link (optional)</label>
<input type="url" name="update_link" placeholder="https://..." value="<?= e($links['UPDATE']) ?>">

<label>Product / Download Link (optional)</label>
<input type="url" name="product_link" placeholder="https://..." value="<?= e($links['LINK']) ?>">
<div style="color:#71839a;font-size:10px;margin-top:6px;line-height:1.5">All product links are editable from this Admin page.</div>

<?php $featureMeta = parseProductLinks((string)($product['description'] ?? '')); ?>
<label>Product Feature Cards (one per line: ON | Feature text or OFF | Feature text)</label>
<textarea name="features_text" rows="4" placeholder="ON | Aim Silent
ON | ESP Location
OFF | Coming Soon"><?php foreach (preg_split('/\R/', trim((string)($featureMeta['FEATURES'] ?? ''))) ?: [] as $featureLine) { $featureLine=trim($featureLine); if ($featureLine==='') continue; if (preg_match('/^FEATURE_ON\s*\|\s*(.+)$/i',$featureLine,$fm)) $featureLine='ON | '.trim($fm[1]); elseif (preg_match('/^FEATURE_OFF\s*\|\s*(.+)$/i',$featureLine,$fm)) $featureLine='OFF | '.trim($fm[1]); echo e($featureLine)."\n"; } ?></textarea>
<div style="color:#71839a;font-size:10px;line-height:1.5;margin:5px 0 12px">ON lines appear as small feature cards on the Store. OFF lines stay saved in Admin but are hidden. Add or remove as many lines as needed.</div>

<label class="checkbox">

    <input
        type="checkbox"
        name="product_status"
        value="1"
        <?= ((int)$product['status'] === 1)
            ? 'checked'
            : ''
        ?>
    >

    Product Active / Visible in Store

</label>


<div class="plans-title">
    4 Plans
</div>


<?php foreach ($product['plans'] as $index => $plan): ?>


<div class="plan">


    <div class="plan-label">

        PLAN <?= $index + 1 ?>

    </div>


    <input
        type="hidden"
        name="plan_id[]"
        value="<?= (int)$plan['id'] ?>"
    >


    <div class="plan-grid">


        <div>

            <label>
                Days
            </label>

            <input
                type="number"
                name="duration_days[]"
                min="1"
                value="<?= abs((int)$plan['duration_days']) ?>"
                required
            >

        </div>


        <div>

            <label>
                Plan Name
            </label>

            <input
                type="text"
                name="duration_label[]"
                value="<?= e($plan['duration_label']) ?>"
                maxlength="50"
                required
            >

        </div>


        <div>

            <label>
                Price
            </label>

            <input
                type="number"
                name="price[]"
                min="0"
                step="0.01"
                value="<?= e($plan['price']) ?>"
                required
            >

        </div>


        <div>

            <label>
                Stock
            </label>

            <input
                type="number"
                name="stock[]"
                min="0"
                value="<?= (int)$plan['stock'] ?>"
                required
            >

        </div>


    </div>


    <label class="checkbox">

        <input
            type="checkbox"
            name="plan_status[<?= $index ?>]"
            value="1"
            <?= ((int)$plan['status'] === 1)
                ? 'checked'
                : ''
            ?>
        >

        Plan Active

    </label>


</div>


<?php endforeach; ?>


<div class="editor-actions">
<button type="submit" class="save">SAVE PRODUCT #<?= (int)$product['id'] ?></button>
<button type="submit" name="action" value="delete_product" class="delete-product" onclick="return confirmProductDelete(this);">DELETE PRODUCT</button>
</div>


</form>


<?php endforeach; ?>


</div>



<script>
function confirmProductDelete(button){
  if(button.dataset.confirmed==='1') return true;
  if(!confirm('Delete this product and all keys assigned to it? This cannot be undone.')) return false;
  button.dataset.confirmed='1';
  button.disabled=true;
  let remaining=3;
  const original=button.textContent;
  button.textContent='DELETING IN '+remaining+'...';
  const tick=()=>{
    remaining--;
    if(remaining>0){button.textContent='DELETING IN '+remaining+'...';window.setTimeout(tick,700);}
    else {
      button.textContent='DELETING...';
      const actionField=button.form.querySelector('input[name="action"]');
      if(actionField) actionField.value='delete_product';
      button.name='';
      button.disabled=false;
      if(button.form.requestSubmit) { try { button.form.requestSubmit(); } catch(e) { HTMLFormElement.prototype.submit.call(button.form); } } else { HTMLFormElement.prototype.submit.call(button.form); }
    }
  };
  window.setTimeout(tick,700);
  return false;
}
(function(){
  // Do not fake a 1–100% save countdown. Let the browser submit the form;
  // the shared progress overlay stays in a processing state until the server responds.
  document.addEventListener('submit', function(ev){
    var form=ev.target;
    if(!(form instanceof HTMLFormElement)) return;
    var action=form.querySelector('input[name="action"]');
    if(!action || !['add_product','save_product','delete_product'].includes(action.value)) return;
    if(form.dataset.xtSubmitting==='1') return;
    var submitter=ev.submitter;
    if(submitter && submitter.classList.contains('delete-product')) return;
    form.dataset.xtSubmitting='1';
    if(submitter){
      if(submitter.tagName==='INPUT') submitter.value='SAVING…';
      else submitter.textContent='SAVING…';
      submitter.disabled=true;
    }
  }, false);
})();
(function(){
  const picker=document.getElementById('productPicker');
  const search=document.getElementById('productSearch');
  const cards=[...document.querySelectorAll('.product-editor')];
  function apply(){
    const wanted=(picker?.value||'all');
    const q=(search?.value||'').trim().toLowerCase();
    cards.forEach(card=>{
      const id=card.id;
      const name=card.dataset.productName||'';
      const matchPicker=(wanted==='all'||id===wanted);
      const matchSearch=!q||name.includes(q);
      card.classList.toggle('is-hidden',!(matchPicker&&matchSearch));
      card.classList.toggle('is-focused',wanted!==''&&wanted!=='all'&&id===wanted);
    });
    if(wanted!==''&&wanted!=='all'){
      const el=document.getElementById(wanted);
      if(el && !el.classList.contains('is-hidden')) setTimeout(()=>el.scrollIntoView({behavior:'smooth',block:'start'}),30);
    }
  }
  picker?.addEventListener('change',apply);
  search?.addEventListener('input',()=>{if(search.value.trim()) picker.value='all'; else picker.value=''; apply();});
})();
</script>
<style id="consolidated-mobile-repair">html,body{max-width:100%;overflow-x:hidden}*,*::before,*::after{box-sizing:border-box}img,video,iframe{max-width:100%;height:auto}input,select,textarea,button{max-width:100%;min-width:0}form{min-width:0;max-width:100%}.product,.product-toolbar,.toolbar-controls,.plan-grid,.product-head{min-width:0;max-width:100%}.product input[type=file]{display:block;width:100%;max-width:100%;font-size:14px;line-height:1.4;white-space:normal}.product label{overflow-wrap:anywhere}@media(max-width:480px){.plan-grid{grid-template-columns:minmax(0,1fr)!important;gap:10px!important}.product{padding:14px!important}.product-title{overflow-wrap:anywhere;font-size:18px!important}.product input,.product select,.product textarea{width:100%;min-width:0}.product input[type=file]{padding:10px!important;font-size:12px!important}}
</style>
<script id="xt-chunked-video-upload">
(function(){
  const CHUNK=2*1024*1024, MAX_VIDEO=300*1024*1024, MAX_IMAGE=8*1024*1024;
  const csrf=document.querySelector('input[name="csrf"]')?.value||'';
  let busy=false, replay=false;
  const panel=document.createElement('div');
  panel.id='xt-media-upload-progress';
  panel.setAttribute('role','status'); panel.setAttribute('aria-live','polite');
  panel.style.cssText='display:none;position:sticky;top:8px;z-index:9999;margin:12px 0;padding:14px;border:1px solid #64748b;border-radius:12px;background:#111827;color:#fff;box-shadow:0 4px 18px #0003';
  panel.innerHTML='<div id="xt-media-progress-label" style="font-weight:700;margin-bottom:8px">Preparing upload…</div><div style="height:10px;background:#374151;border-radius:999px;overflow:hidden"><div id="xt-media-progress-fill" style="height:100%;width:0%;background:#22c55e;transition:width .15s"></div></div><div id="xt-media-progress-percent" style="font-size:12px;margin-top:6px">0%</div>';
  function showPanel(form){if(!panel.isConnected)form.prepend(panel);panel.style.display='block';}
  function setProgress(percent,label){const p=Math.max(0,Math.min(100,Math.round(percent)));const fill=panel.querySelector('#xt-media-progress-fill');if(fill)fill.style.width=p+'%';const out=panel.querySelector('#xt-media-progress-percent');if(out)out.textContent=p+'%';const title=panel.querySelector('#xt-media-progress-label');if(title)title.textContent=label;}
  function xhrChunk(url, blob, onByteProgress){return new Promise((resolve,reject)=>{const xhr=new XMLHttpRequest();xhr.open('POST',url,true);xhr.withCredentials=true;xhr.setRequestHeader('Content-Type','application/octet-stream');xhr.timeout=120000;xhr.upload.onprogress=e=>{if(e.lengthComputable&&typeof onByteProgress==='function')onByteProgress(Math.min(0.995,e.loaded/e.total));};xhr.onload=()=>{let data={};try{data=JSON.parse(xhr.responseText||'{}')}catch(e){reject(new Error('সার্ভার থেকে সঠিক উত্তর পাওয়া যায়নি (HTTP '+xhr.status+')।'));return;}if(xhr.status<200||xhr.status>=300||!data.ok){reject(new Error(data.error||'আপলোড ব্যর্থ হয়েছে (HTTP '+xhr.status+')'));return;}resolve(data)};xhr.onerror=()=>reject(new Error('সার্ভারের সঙ্গে সংযোগ বিচ্ছিন্ন হয়েছে। ইন্টারনেট পরীক্ষা করে আবার চেষ্টা করুন।'));xhr.ontimeout=()=>reject(new Error('আপলোডে বেশি সময় লাগছে। আবার চেষ্টা করুন।'));xhr.onabort=()=>reject(new Error('আপলোড বাতিল হয়েছে।'));xhr.send(blob);});}
  async function upload(file, onProgress){
    const ext=(file.name.split('.').pop()||'').toLowerCase();
    const imageExts=['jpg','jpeg','png','webp','gif'], videoExts=['mp4','webm','ogg','ogv','mov'];
    const isImage=imageExts.includes(ext);
    if(!isImage&&!videoExts.includes(ext))throw new Error('JPG, PNG, WebP, GIF, MP4, WebM, OGG, OGV বা MOV ফাইল দিন।');
    if(!file.size)throw new Error('ফাইলটি খালি। অন্য ফাইল নির্বাচন করুন।');
    if(file.size>(isImage?MAX_IMAGE:MAX_VIDEO))throw new Error(isImage?'ছবির সাইজ সর্বোচ্চ 8 MB হতে পারবে।':'ভিডিও সর্বোচ্চ 300 MB হতে পারবে।');
    if(!csrf)throw new Error('Security token পাওয়া যায়নি। পেজটি Refresh করে আবার চেষ্টা করুন।');
    const bytes=crypto.getRandomValues(new Uint8Array(16));
    const id=Array.from(bytes).map(x=>x.toString(16).padStart(2,'0')).join('');
    const count=Math.ceil(file.size/CHUNK);let finalPath='';
    for(let i=0;i<count;i++){
      const part=file.slice(i*CHUNK,Math.min(file.size,(i+1)*CHUNK));
      const u=new URL('../chunked-video-upload.php',document.baseURI);
      u.searchParams.set('id',id);u.searchParams.set('index',String(i));u.searchParams.set('count',String(count));u.searchParams.set('total',String(file.size));u.searchParams.set('name',file.name);u.searchParams.set('csrf',csrf);
      let data, lastError;
      for(let attempt=0;attempt<3;attempt++){
        try{data=await xhrChunk(u.toString(),part,f=>onProgress((i*CHUNK+f*part.size)/file.size));lastError=null;break;}catch(err){lastError=err;if(attempt<2)await new Promise(r=>setTimeout(r,500*(attempt+1)));}
      }
      if(lastError)throw lastError;
      if(data.complete&&data.path)finalPath=data.path;
      onProgress(Math.min(0.994,(Math.min(file.size,(i+1)*CHUNK))/file.size));
    }
    if(!finalPath)throw new Error('সার্ভার ফাইলটি সম্পূর্ণ হয়েছে বলে নিশ্চিত করেনি। আবার চেষ্টা করুন।');
    onProgress(1); // 100% only after the server confirms the complete file.
    return finalPath;
  }
  document.querySelectorAll('form').forEach(form=>{
    form.addEventListener('submit',async function(ev){
      if(replay||busy)return;
      const inputs=Array.from(form.querySelectorAll('input[type=file][name="image_file"],input[type=file][name="new_image_file"],input[type=file][name="video_file"],input[type=file][name="new_video_file"]'));
      const selected=[];inputs.forEach(input=>{if(input.files&&input.files[0])selected.push({input,file:input.files[0],kind:/image/.test(input.name)?'image':'video'});});
      if(!selected.length)return;
      ev.preventDefault();busy=true;showPanel(form);
      const submit=ev.submitter||form.querySelector('button[type=submit],input[type=submit]');
      const old=submit?(submit.textContent||submit.value):'';if(submit)submit.disabled=true;
      try{
        for(let n=0;n<selected.length;n++){
          const item=selected[n];
          setProgress(0,'ফাইল আপলোড হচ্ছে ('+(n+1)+'/'+selected.length+'): '+item.file.name);
          const path=await upload(item.file,f=>setProgress(f*100,'ফাইল আপলোড হচ্ছে ('+(n+1)+'/'+selected.length+'): '+item.file.name));
          if(item.kind==='image'){
            if(item.input.name==='new_image_file'){const desc=form.querySelector('[name="new_product_description"]');if(desc)desc.value=desc.value.replace(/^\s*\[IMAGE\].*$/gim,'').trim()+'\n[IMAGE] '+path;}
            else{const link=form.querySelector('[name="image_link"]');if(link)link.value=path;}
          }else{
            if(item.input.name==='new_video_file'){const desc=form.querySelector('[name="new_product_description"]');if(desc)desc.value=desc.value.replace(/^\s*\[VIDEO\].*$/gim,'').trim()+'\n[VIDEO] '+path;}
            else{const link=form.querySelector('[name="video_link"]');if(link)link.value=path;}
          }
          item.input.value='';
        }
        setProgress(100,'ফাইল সার্ভারে সেভ হয়েছে। এখন পণ্যের তথ্য সেভ করা হচ্ছে…');
        replay=true;busy=false;
        if(submit){if(submit.tagName==='INPUT')submit.value=old;else submit.textContent=old;submit.disabled=false;}
        if(form.requestSubmit&&submit)form.requestSubmit(submit);else HTMLFormElement.prototype.submit.call(form);
      }catch(err){setProgress(0,'আপলোড ব্যর্থ: '+(err.message||'আবার চেষ্টা করুন।'));const fill=panel.querySelector('#xt-media-progress-fill');if(fill)fill.style.background='#ef4444';busy=false;if(submit){submit.disabled=false;if(submit.tagName==='INPUT')submit.value=old;else submit.textContent=old;}alert(err.message||'ফাইল আপলোড করা যায়নি।');}
    });
  });
})();
</script>
<script src="../background-video.js?v=20261018-starfall2"></script>

<style id="xt-multi-platform-editor">.platform-choice-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:8px;margin-top:8px}.platform-choice-grid label{display:flex;align-items:center;gap:8px;padding:10px 12px;border:1px solid rgba(120,145,180,.28);border-radius:10px;background:rgba(120,145,180,.06);font-size:13px;line-height:1.35}.platform-choice-grid input{width:18px;height:18px;flex:0 0 auto}.platform-choice-grid label:has(input:checked){border-color:#38bdf8;background:rgba(56,189,248,.12)}</style>
<script id="xt-multi-platform-post-fix">
(function(){
  document.querySelectorAll('form.product-editor, form[enctype="multipart/form-data"]').forEach(function(form){
    form.addEventListener('submit', function(){
      form.querySelectorAll('.platform-choice-grid').forEach(function(group){
        var checks=Array.from(group.querySelectorAll('input[type="checkbox"]'));
        if(!checks.length)return;
        var values=checks.filter(function(x){return x.checked;}).map(function(x){return x.value;});
        var hiddenName=checks[0].name==='new_product_platform[]'?'new_product_platform_csv':'platform_csv';
        var hidden=form.querySelector('input[name="'+hiddenName+'"]');
        if(hidden) hidden.value=values.length?values.join(','):'ALL';
        // Keep checkboxes enabled so the browser submits the original array fields too.
      });
    }, true);
  });
})();
</script>
<script id="xt-multi-platform-exclusive">document.addEventListener('change',function(e){var input=e.target;if(!input.matches('.platform-choice-grid input[type="checkbox"]'))return;var group=input.closest('.platform-choice-grid');if(!group)return;var all=group.querySelector('input[value="ALL"]');var others=Array.from(group.querySelectorAll('input:not([value="ALL"])'));if(input.value==='ALL'&&input.checked){others.forEach(function(x){x.checked=false;});}else if(input.value!=='ALL'&&input.checked&&all){all.checked=false;}if(!group.querySelector('input:checked')&&all)all.checked=true;});</script>
</body>

</html>