(()=>{
'use strict';
const bell=document.getElementById('adminNoticeBell');
if(!bell)return;
const count=bell.querySelector('[data-count]');
const panel=document.getElementById('adminNoticePanel');
const list=document.getElementById('adminNoticeList');
const soundBtn=document.getElementById('adminNoticeSound');
const enableBtn=document.getElementById('adminNoticeEnable');
let last=Number(localStorage.getItem('xt_admin_notice_last')||0);
let csrf='',first=true,soundOn=localStorage.getItem('xt_admin_notice_sound')!=='off';
let audioCtx=null, audioUnlocked=false;
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'" :'&#39;'}[c]));
function unlockAudio(){
 try{const C=window.AudioContext||window.webkitAudioContext;if(!C)return;if(!audioCtx)audioCtx=new C();if(audioCtx.state==='suspended')audioCtx.resume();audioUnlocked=true;}catch(e){}
}
function beep(){
 if(!soundOn||!audioCtx||audioCtx.state!=='running')return;
 try{const o=audioCtx.createOscillator(),g=audioCtx.createGain();o.type='sine';o.frequency.setValueAtTime(880,audioCtx.currentTime);o.frequency.exponentialRampToValueAtTime(520,audioCtx.currentTime+.22);g.gain.setValueAtTime(.0001,audioCtx.currentTime);g.gain.exponentialRampToValueAtTime(.14,audioCtx.currentTime+.025);g.gain.exponentialRampToValueAtTime(.0001,audioCtx.currentTime+.42);o.connect(g);g.connect(audioCtx.destination);o.start();o.stop(audioCtx.currentTime+.44);}catch(e){}
}
function placePanel(){
 if(!panel)return;
 // Move it outside header/backdrop-filter/overflow containers so it cannot be clipped or hidden behind dashboard cards.
 if(panel.parentElement!==document.body)document.body.appendChild(panel);
 const r=bell.getBoundingClientRect();
 const top=Math.min(Math.max(12,r.bottom+8),Math.max(12,window.innerHeight-180));
 panel.style.top=top+'px';
 panel.style.right='12px';
 panel.style.left='auto';
}
function render(items){
 if(!items.length){list.dataset.loaded='1';list.innerHTML='<div class="notice-empty">You are all caught up.</div>';return;}
 list.dataset.loaded='1';
 const html=items.map(n=>`<a class="notice-item ${n.read_at?'':'unread'}" href="${esc(n.target_url||'dashboard.php')}" data-id="${Number(n.id)}"><b>${esc(n.title)}</b><span>${esc(n.body)}</span><small>${esc(n.created_at)} · ${esc(String(n.event_type||'').replaceAll('_',' '))}</small></a>`).join('');
 list.insertAdjacentHTML('afterbegin',html);
}
async function mark(id=0){
 if(!csrf)return;
 try{const b=new URLSearchParams({id:String(id),csrf});await fetch('notifications.php?action=read',{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded','X-Notice-CSRF':csrf},body:b,credentials:'same-origin'});}catch(e){}
}
async function enablePush(){
 if(!('Notification'in window)){alert('এই ব্রাউজারে Notification সুবিধা নেই। iPhone-এ Admin App Home Screen থেকে খুলুন।');return;}
 if(!('serviceWorker'in navigator)){alert('Service Worker সমর্থিত নয়।');return;}
 if(!window.isSecureContext){alert('Push Notification চালাতে HTTPS প্রয়োজন।');return;}
 try{
  const reg=await navigator.serviceWorker.register('admin-sw.js',{scope:'./'});
  let permission=Notification.permission;
  if(permission==='default')permission=await Notification.requestPermission();
  if(permission==='granted'){
    enableBtn.textContent='Permission: ON';
    // No VAPID public key / server-side subscription endpoint is configured in this package.
    alert('Admin অ্যাপের Notification অনুমতি দেওয়া হয়েছে। Lock Screen-এ Push পেতে সার্ভারে VAPID subscription ও push sender সংযোগও প্রয়োজন।');
  }else{
    alert(permission==='denied'?'Notification permission বন্ধ আছে। iPhone Settings > Notifications থেকে Admin App-এর অনুমতি চালু করুন।':'Notification permission দেওয়া হয়নি।');
  }
 }catch(e){alert('Notification চালু করা যায়নি। Admin Panel HTTPS এবং Home Screen App থেকে খুলে আবার চেষ্টা করুন।');}
}
list.addEventListener('click',async e=>{
 const a=e.target.closest('a.notice-item');if(!a)return;e.preventDefault();const href=a.href,id=Number(a.dataset.id||0);a.classList.remove('unread');await mark(id);window.location.assign(href);
});
async function poll(){
 try{
  const r=await fetch('notifications.php?action=poll&after='+last,{cache:'no-store',credentials:'same-origin'});
  let d={};try{d=await r.json();}catch(e){}
  if(!r.ok||!d.ok){
    if(!list.dataset.loaded){
      list.dataset.loaded='1';
      list.innerHTML='<div class="notice-empty">Notifications could not load. Check admin login, database access, and notifications.php.</div>';
    }
    return;
  }
  count.textContent=d.unread>99?'99+':String(d.unread);
  count.hidden=!d.unread;
  const fresh=(d.items||[]).filter(n=>Number(n.id)>last);
  if(!first&&fresh.length)beep();
  if(fresh.length){
    render(fresh);
    last=Math.max(last,...fresh.map(n=>Number(n.id)));
    localStorage.setItem('xt_admin_notice_last',String(last));
  }else if(first){
    last=Math.max(last,Number(d.latest_id)||0);
    localStorage.setItem('xt_admin_notice_last',String(last));
    render(d.items||[]);
  }
  first=false;
 }catch(e){
  if(!list.dataset.loaded){
    list.dataset.loaded='1';
    list.innerHTML='<div class="notice-empty">Could not connect to notifications.php. Refresh Admin Panel and check server response.</div>';
  }
 }
}
bell.addEventListener('pointerdown',unlockAudio,{once:true});
bell.addEventListener('click',()=>{if(panel.parentElement!==document.body)placePanel();panel.hidden=!panel.hidden;bell.setAttribute('aria-expanded',String(!panel.hidden));if(!panel.hidden){placePanel();mark(0);}});
soundBtn.addEventListener('click',e=>{e.preventDefault();unlockAudio();soundOn=!soundOn;localStorage.setItem('xt_admin_notice_sound',soundOn?'on':'off');soundBtn.textContent=soundOn?'Sound: ON':'Sound: OFF';if(soundOn){if(!audioUnlocked)unlockAudio();setTimeout(beep,80);}});
if(enableBtn)enableBtn.addEventListener('click',enablePush);
document.addEventListener('pointerdown',unlockAudio,{once:true});
soundBtn.textContent=soundOn?'Sound: ON':'Sound: OFF';
if('serviceWorker'in navigator&&window.isSecureContext)navigator.serviceWorker.register('admin-sw.js',{scope:'./'}).catch(()=>{});
fetch('notifications.php?action=csrf',{credentials:'same-origin'}).then(r=>r.json()).then(d=>{csrf=d.csrf||'';}).catch(()=>{});
poll();setInterval(poll,5000);
document.addEventListener('visibilitychange',()=>{if(!document.hidden)poll();});
document.addEventListener('click',e=>{if(!e.target.closest('.notice-wrap')&&!e.target.closest('#adminNoticePanel'))panel.hidden=true;});
window.addEventListener('resize',()=>{if(!panel.hidden)placePanel();});
window.addEventListener('scroll',()=>{if(!panel.hidden)placePanel();},{passive:true});
})();
