<?php

require_once __DIR__ . '/../config.php';
ensure_product_plan_type_column();

if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}

/*
|--------------------------------------------------------------------------
| ADMIN ACCESS
|--------------------------------------------------------------------------
*/

if (empty($_SESSION['admin_id']) && empty($_SESSION['admin_logged_in'])) {
    header('Location: login.php');
    exit;
}

$pdo = db();

/*
|--------------------------------------------------------------------------
| CSRF
|--------------------------------------------------------------------------
*/

if (empty($_SESSION['admin_csrf'])) {
    $_SESSION['admin_csrf'] = bin2hex(random_bytes(32));
}

$csrf = $_SESSION['admin_csrf'];

/*
|--------------------------------------------------------------------------
| HELPERS
|--------------------------------------------------------------------------
*/

function h($value): string
{
    return htmlspecialchars(
        (string)$value,
        ENT_QUOTES,
        'UTF-8'
    );
}

/*
|--------------------------------------------------------------------------
| MESSAGE
|--------------------------------------------------------------------------
*/

$message = '';
$error = '';

/*
|--------------------------------------------------------------------------
| IMPORT KEYS
|--------------------------------------------------------------------------
*/

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $postedCsrf = (string)($_POST['csrf'] ?? '');

    if (
        $postedCsrf === '' ||
        !hash_equals($csrf, $postedCsrf)
    ) {

        $error = 'Security verification failed.';

    } else {

        $action = trim(
            (string)($_POST['action'] ?? '')
        );

        if ($action === 'import_keys') {

            $productId = (int)(
                $_POST['product_id'] ?? 0
            );

            $planId = (int)(
                $_POST['plan_id'] ?? 0
            );

            $rawKeys = trim(
                (string)($_POST['keys'] ?? '')
            );

            /*
             * Validate Product
             */
            if ($productId <= 0) {

                $error =
                    'Please select a product.';

            /*
             * Validate Plan
             */
            } elseif ($planId <= 0) {

                $error =
                    'Please select a plan.';

            /*
             * Validate Keys
             */
            } elseif ($rawKeys === '') {

                $error =
                    'Please enter at least one key.';

            } else {

                try {

                    /*
                     * Make sure selected plan belongs
                     * to selected product.
                     */
                    $stmt = $pdo->prepare("
                        SELECT
                            p.id AS product_id,
                            p.name AS product_name,
                            pp.id AS plan_id,
                            pp.duration_days,
                            pp.duration_label,
                            pp.price
                        FROM catalog_products p

                        INNER JOIN product_plans pp
                            ON pp.product_id = p.id

                        WHERE p.id = ?
                          AND pp.id = ?
                          AND p.status = 1
                          AND pp.status = 1

                        LIMIT 1
                    ");

                    $stmt->execute([
                        $productId,
                        $planId
                    ]);

                    $selectedPlan =
                        $stmt->fetch(PDO::FETCH_ASSOC);

                    if (!$selectedPlan) {

                        throw new RuntimeException(
                            'Invalid product or plan.'
                        );
                    }

                    /*
                     * One key per line.
                     */
                    $lines = preg_split(
                        '/\R/',
                        $rawKeys
                    );

                    $keys = [];

                    foreach ($lines as $line) {

                        $key = trim($line);

                        if ($key === '') {
                            continue;
                        }

                        if (strlen($key) > 255) {

                            throw new RuntimeException(
                                'A license key cannot be longer than 255 characters.'
                            );
                        }

                        $keys[] = $key;
                    }

                    /*
                     * Remove duplicates from
                     * this import itself.
                     */
                    $keys = array_values(
                        array_unique($keys)
                    );

                    if (!$keys) {

                        throw new RuntimeException(
                            'No valid keys were found.'
                        );
                    }

                    /*
                     * Start transaction.
                     */
                    $pdo->beginTransaction();

                    /*
                     * Check existing key.
                     */
                    $checkKey = $pdo->prepare("
                        SELECT id
                        FROM user_keys
                        WHERE license_key = ?
                        LIMIT 1
                    ");

                    /*
                     * Insert unused key.
                     *
                     * user_id = NULL
                     * means this key is available.
                     */
                    $insertKey = $pdo->prepare("
                        INSERT INTO user_keys
                        (
                            user_id,
                            product_id,
                            plan_id,
                            license_key,
                            price
                        )
                        VALUES
                        (
                            NULL,
                            ?,
                            ?,
                            ?,
                            ?
                        )
                    ");

                    $inserted = 0;
                    $skipped = 0;

                    foreach ($keys as $key) {

                        $checkKey->execute([
                            $key
                        ]);

                        if ($checkKey->fetch()) {

                            $skipped++;

                            continue;
                        }

                        $insertKey->execute([
                            $productId,
                            $planId,
                            $key,
                            (float)$selectedPlan['price']
                        ]);

                        $inserted++;
                    }

                    $pdo->commit();

                    $message =
                        $inserted .
                        ' key(s) imported successfully.';

                    if ($skipped > 0) {

                        $message .=
                            ' ' .
                            $skipped .
                            ' duplicate key(s) skipped.';
                    }

                } catch (Throwable $e) {

                    if (
                        $pdo instanceof PDO &&
                        $pdo->inTransaction()
                    ) {
                        $pdo->rollBack();
                    }

                    $error =
                        $e->getMessage();
                }
            }
        }
    }
}

// Allow admins to delete only unused inventory keys. Keys assigned to users are protected.
if ($_SERVER['REQUEST_METHOD'] === 'POST' && (string)($_POST['action'] ?? '') === 'delete_inventory_key') {
    try {
        if (!hash_equals($csrf, (string)($_POST['csrf'] ?? ''))) throw new RuntimeException('Security verification failed.');
        $deleteId = (int)($_POST['inventory_key_id'] ?? 0);
        $del = $pdo->prepare('DELETE FROM user_keys WHERE id=? AND user_id IS NULL');
        $del->execute([$deleteId]);
        if (!$del->rowCount()) throw new RuntimeException('Key not found or already assigned to a user. Assigned user keys cannot be deleted here.');
        $message = 'Unused inventory key deleted successfully.';
    } catch (Throwable $e) { $error = $e->getMessage(); }
}

/*
|--------------------------------------------------------------------------
| LOAD PRODUCTS
|--------------------------------------------------------------------------
*/

$products = [];

try {

    $stmt = $pdo->query("
        SELECT
            id,
            name,
            category
        FROM catalog_products
        WHERE status = 1
        ORDER BY id ASC
    ");

    $products =
        $stmt->fetchAll(PDO::FETCH_ASSOC);

} catch (Throwable $e) {

    $error =
        'Unable to load products.';
}

/*
|--------------------------------------------------------------------------
| LOAD ALL PLANS + KEY COUNTS
|--------------------------------------------------------------------------
*/

$plans = [];

try {

    $stmt = $pdo->query("
        SELECT
            pp.id,
            pp.product_id,
            pp.plan_type,
            pp.duration_days,
            pp.duration_label,
            pp.price,
            pp.stock,
            pp.status,

            COUNT(uk.id) AS total_keys,

            COALESCE(
                SUM(
                    CASE
                        WHEN uk.user_id IS NULL
                        THEN 1
                        ELSE 0
                    END
                ),
                0
            ) AS available_keys

        FROM product_plans pp

        LEFT JOIN user_keys uk
            ON uk.plan_id = pp.id
           AND uk.product_id = pp.product_id

        WHERE pp.status = 1

        GROUP BY
            pp.id,
            pp.product_id,
            pp.plan_type,
            pp.duration_days,
            pp.duration_label,
            pp.price,
            pp.stock,
            pp.status

        ORDER BY
            pp.product_id ASC,
            FIELD(UPPER(pp.plan_type),'PRO','BASIC'),
            pp.duration_days ASC
    ");

    $plans =
        $stmt->fetchAll(PDO::FETCH_ASSOC);

} catch (Throwable $e) {

    $error =
        'Unable to load plans.';
}

/*
|--------------------------------------------------------------------------
| GROUP PLANS BY PRODUCT
|--------------------------------------------------------------------------
*/

$plansByProduct = [];

foreach ($plans as $plan) {

    $plansByProduct[
        (int)$plan['product_id']
    ][] = $plan;
}

?>

<!doctype html>

<html lang="en">

<head>

<meta charset="utf-8">

<meta
    name="viewport"
    content="width=device-width,initial-scale=1"
>

<title>
    Key Manager — Admin
</title>

<style>

*{
    box-sizing:border-box;
}

body{
    margin:0;
    background:#06101c;
    color:#eef4ff;
    font-family:Arial,Helvetica,sans-serif;
}

.container{
    max-width:1100px;
    margin:auto;
    padding:25px 15px 70px;
}

.header{
    display:flex;
    justify-content:space-between;
    align-items:flex-start;
    gap:15px;
}

h1{
    margin:0 0 7px;
    font-size:30px;
}

.muted{
    color:#8fa0b5;
    font-size:13px;
}

.back{
    color:#9eb1c9;
    text-decoration:none;
    font-size:12px;
    font-weight:800;
}

.alert{
    margin-top:18px;
    padding:13px;
    border-radius:11px;
    font-size:12px;
}

.success{
    background:#15351c;
    border:1px solid #285b32;
    color:#9aff78;
}

.error{
    background:#3b1c24;
    border:1px solid #65313d;
    color:#ff9aaa;
}

.panel{
    margin-top:20px;
    background:#0d1928;
    border:1px solid #26384e;
    border-radius:18px;
    padding:18px;
}

.panel-title{
    font-size:18px;
    font-weight:900;
    margin-bottom:14px;
}

label{
    display:block;
    margin:13px 0 6px;
    color:#9aa9bf;
    font-size:11px;
    font-weight:900;
}

select,
textarea{
    width:100%;
    border:1px solid #293c53;
    border-radius:10px;
    background:#091522;
    color:#eef4ff;
    padding:12px;
    outline:none;
}

select:focus,
textarea:focus{
    border-color:#63ff16;
}

textarea{
    min-height:270px;
    resize:vertical;
    font-family:monospace;
    line-height:1.5;
}

.info{
    margin-top:12px;
    padding:12px;
    border-radius:10px;
    background:#091522;
    border:1px solid #203147;
    color:#9aa9bf;
    font-size:11px;
    line-height:1.6;
}

button{
    width:100%;
    margin-top:15px;
    padding:13px;
    border:0;
    border-radius:10px;
    background:#63ff16;
    color:#06101c;
    font-weight:900;
    cursor:pointer;
}

button:hover{
    filter:brightness(1.05);
}

.product-box{
    margin-top:20px;
}

.product-title{
    font-size:16px;
    font-weight:900;
    margin-bottom:10px;
}

.plans{
    display:grid;
    grid-template-columns:repeat(4,1fr);
    gap:10px;
}

.plan{
    background:#091522;
    border:1px solid #26384e;
    border-radius:13px;
    padding:13px;
}

.plan-name{
    font-size:14px;
    font-weight:900;
}

.plan-price{
    margin-top:5px;
    color:#63ff16;
    font-weight:900;
}

.plan-count{
    margin-top:10px;
    font-size:11px;
    color:#9aa9bf;
}

.available{
    color:#63ff16;
    font-weight:900;
}

@media(max-width:800px){

    .plans{
        grid-template-columns:repeat(2,1fr);
    }

}

@media(max-width:500px){

    .header{
        flex-direction:column;
    }

    .plans{
        grid-template-columns:1fr;
    }

}

</style><link rel="stylesheet" href="../theme.php?v=20260929-27"><link rel="stylesheet" href="admin-theme.css">

<script src="admin-background.js?v=20260929-27" defer></script><link rel="stylesheet" href="../responsive-lock.css?v=20260929-28">
<script src="admin-action-progress.js?v=20261023-inline-progress25" defer></script>
<link rel="icon" type="image/png" sizes="48x48" href="/assets/pwa-icon-48.png">
<link rel="apple-touch-icon" sizes="180x180" href="/assets/pwa-icon-180.png">
<link rel="manifest" href="/admin/admin-manifest.json">
<meta name="apple-mobile-web-app-title" content="XTREME TITAN">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="mobile-web-app-capable" content="yes">
<meta name="theme-color" content="#080a14">
<script src="admin-action-progress.js?v=20261023-inline-progress25" defer></script>
</head>

<body><div class="admin-panel-logo"><img src="../assets/xtreme-titan-logo.jpg" alt="XTREME TITAN"></div>

<div class="container">

<div class="header">

    <div>

        <h1>
            Key Manager
        </h1>

        <div class="muted">
            Import license keys into Product → Plan
        </div>

    </div>

    <a
        class="back"
        href="../dashboard.php"
    >
        ← Home Shop
    </a>

</div>


<?php if ($message !== ''): ?>

<div class="alert success">
    <?= h($message) ?>
</div>

<?php endif; ?>


<?php if ($error !== ''): ?>

<div class="alert error">
    <?= h($error) ?>
</div>

<?php endif; ?>


<!--
|--------------------------------------------------------------------------
| IMPORT
|--------------------------------------------------------------------------
-->

<section class="panel">

<div class="panel-title">
    Import Keys
</div>

<form
    method="post"
    autocomplete="off"
>

<input
    type="hidden"
    name="csrf"
    value="<?= h($csrf) ?>"
>

<input
    type="hidden"
    name="action"
    value="import_keys"
>


<label>
    Product
</label>

<select
    name="product_id"
    id="product_id"
    required
>

<option value="">
    Select Product
</option>

<?php foreach ($products as $product): ?>

<option value="<?= (int)$product['id'] ?>" data-category="<?= h(strtoupper((string)($product['category'] ?? 'PRO'))) ?>">Product #<?= (int)$product['id'] ?> — <?= h($product['name']) ?></option>

<?php endforeach; ?>

</select>

<label>
    Product Type
</label>
<select id="product_type_filter">
    <option value="ALL">All Types</option>
    <option value="PRO">PRO Key</option>
    <option value="BASIC">BASIC Key</option>
</select>

<label>
    Plan
</label>

<select
    name="plan_id"
    id="plan_id"
    required
    disabled
>

<option value="">
    Select Product first
</option>

</select>


<div class="info">

    প্রতিটি key আলাদা লাইনে দিন।<br>

    উদাহরণ:<br><br>

    KEY-AAAA-1111<br>
    KEY-BBBB-2222<br>
    KEY-CCCC-3333<br>
    KEY-DDDD-4444<br><br>

    একই key আগে database-এ থাকলে সেটি automatically skip হবে।

</div>


<label>
    License Keys
</label>

<textarea
    name="keys"
    placeholder="প্রতি লাইনে একটি করে key লিখুন..."
    required
></textarea>


<button type="submit">
    IMPORT KEYS
</button>

</form>

</section>


<!-- Available inventory keys can be reviewed and deleted individually. -->
<section class="panel">
<div class="panel-title">Available Keys — Delete Inventory</div>
<div class="muted">Only unassigned keys are deletable here. Keys already assigned to users are intentionally protected.</div>
<?php
$inventoryProductFilter = (int)($_GET['product_filter'] ?? $_POST['product_filter'] ?? 0);
$inventoryProducts = [];
try { $inventoryProducts = $pdo->query("SELECT id,name FROM catalog_products ORDER BY name ASC")->fetchAll(PDO::FETCH_ASSOC); } catch(Throwable $e) {}
$inventoryRows=[];
try {
    $inventorySql = "SELECT uk.id,uk.license_key,COALESCE(cp.name,'Product') product_name,COALESCE(pp.duration_label,'Plan') plan_name FROM user_keys uk LEFT JOIN catalog_products cp ON cp.id=uk.product_id LEFT JOIN product_plans pp ON pp.id=uk.plan_id WHERE uk.user_id IS NULL";
    $inventoryArgs = [];
    if ($inventoryProductFilter > 0) { $inventorySql .= " AND uk.product_id = ?"; $inventoryArgs[] = $inventoryProductFilter; }
    $inventorySql .= " ORDER BY uk.id DESC LIMIT 500";
    $inventoryStmt = $pdo->prepare($inventorySql); $inventoryStmt->execute($inventoryArgs); $inventoryRows = $inventoryStmt->fetchAll(PDO::FETCH_ASSOC);
} catch(Throwable $e) {}
?>
<form method="get" style="display:flex;gap:10px;align-items:center;flex-wrap:wrap;margin:14px 0">
<label for="inventory-product-filter" style="margin:0">Show keys for product</label>
<select id="inventory-product-filter" name="product_filter" style="flex:1;min-width:200px;padding:12px;border-radius:12px;background:#07111e;color:#e5eefc;border:1px solid #26384e">
<option value="0" <?= $inventoryProductFilter===0?'selected':'' ?>>All products</option>
<?php foreach($inventoryProducts as $ip): ?><option value="<?= (int)$ip['id'] ?>" <?= $inventoryProductFilter===(int)$ip['id']?'selected':'' ?>><?=h($ip['name'])?></option><?php endforeach; ?>
</select><button type="submit" style="width:auto;margin:0;padding:12px 18px">FILTER KEYS</button>
</form>
<?php if(!$inventoryRows): ?><p class="muted">No unused inventory keys<?= $inventoryProductFilter>0?' for this product':'' ?>.</p><?php else: ?>
<div class="muted" style="margin-bottom:8px">Showing <?=count($inventoryRows)?> unused key(s)<?= $inventoryProductFilter>0?' for the selected product':'' ?>.</div>
<div style="overflow:auto"><table style="width:100%;border-collapse:collapse;min-width:620px"><thead><tr><th style="text-align:left;padding:9px">Product / Plan</th><th style="text-align:left;padding:9px">License Key</th><th style="text-align:left;padding:9px">Action</th></tr></thead><tbody>
<?php foreach($inventoryRows as $ir): ?><tr><td style="padding:9px;border-top:1px solid #26384e"><?=h($ir['product_name'])?> / <?=h($ir['plan_name'])?></td><td style="padding:9px;border-top:1px solid #26384e;word-break:break-all"><?=h($ir['license_key'])?></td><td style="padding:9px;border-top:1px solid #26384e"><form method="post" onsubmit="return confirm('Permanently delete this unused key?')"><input type="hidden" name="csrf" value="<?=h($csrf)?>"><input type="hidden" name="action" value="delete_inventory_key"><input type="hidden" name="inventory_key_id" value="<?=h($ir['id'])?>"><input type="hidden" name="product_filter" value="<?= $inventoryProductFilter ?>"><button type="submit" style="margin:0;width:auto;background:#be123c;color:#fff;padding:8px 12px">DELETE KEY</button></form></td></tr><?php endforeach; ?>
</tbody></table></div><?php endif; ?>
</section>

<!--
|--------------------------------------------------------------------------
| STOCK OVERVIEW
|--------------------------------------------------------------------------
-->

<section class="panel">

<div class="panel-title">
    Product / Plan Key Stock
</div>


<?php if (!$products): ?>

<div class="muted">
    No active products found.
</div>

<?php else: ?>


<?php foreach ($products as $product): ?>

<?php

$productId =
    (int)$product['id'];

$productPlans =
    $plansByProduct[$productId]
    ?? [];

?>

<div class="product-box">

<div class="product-title">

    Product #<?= $productId ?>

    —
    <?= h($product['name']) ?>

</div>


<?php if (!$productPlans): ?>

<div class="muted">
    No active plans.
</div>

<?php else: ?>

<div class="plans">


<?php foreach ($productPlans as $plan): ?>

<div class="plan">

<div class="plan-name">

    <?= h(
        $plan['duration_label']
    ) ?>

</div>


<div class="plan-price">

    ৳<?= number_format(
        (float)$plan['price'],
        2
    ) ?>

</div>


<div class="plan-count">

    Total keys:
    <strong>
        <?= (int)$plan['total_keys'] ?>
    </strong>

    <br>

    Available:
    <span class="available">
        <?= (int)$plan['available_keys'] ?>
    </span>

</div>

</div>

<?php endforeach; ?>


</div>

<?php endif; ?>

</div>

<?php endforeach; ?>


<?php endif; ?>


</section>


</div>


<script>

/*
|--------------------------------------------------------------------------
| PRODUCT → PLAN
|--------------------------------------------------------------------------
*/

const productSelect =
    document.getElementById('product_id');

const planSelect =
    document.getElementById('plan_id');


const plans = <?= json_encode(
    $plans,
    JSON_UNESCAPED_UNICODE |
    JSON_UNESCAPED_SLASHES
) ?>;


productSelect.addEventListener(
    'change',
    function(){

        const productId =
            parseInt(this.value || '0');

        planSelect.innerHTML = '';

        if (!productId) {

            planSelect.disabled = true;

            const option =
                document.createElement('option');

            option.value = '';

            option.textContent =
                'Select Product first';

            planSelect.appendChild(option);

            return;
        }


        planSelect.disabled = false;


        const first =
            document.createElement('option');

        first.value = '';

        first.textContent =
            'Select Plan';

        planSelect.appendChild(first);


        plans
            .filter(function(plan){

                return parseInt(
                    plan.product_id
                ) === productId;

            })
            .forEach(function(plan){

                const option =
                    document.createElement('option');

                option.value =
                    plan.id;

                option.textContent =
                    (String(plan.plan_type || 'PRO').toUpperCase() + ' · ') + plan.duration_label +
                    ' — ৳' +
                    parseFloat(
                        plan.price
                    ).toFixed(2) +
                    ' — ' +
                    parseInt(
                        plan.available_keys
                    ) +
                    ' available';

                planSelect.appendChild(option);

            });

    }
);

</script>

<script>document.addEventListener('DOMContentLoaded',()=>{const f=document.getElementById('product_type_filter'),p=document.getElementById('product_id');if(!f||!p)return;f.addEventListener('change',()=>{[...p.options].forEach((o,i)=>{if(i===0){o.hidden=false;return;}o.hidden=f.value!=='ALL'&&o.dataset.category!==f.value;});p.value='';const plan=document.getElementById('plan_id');if(plan){plan.innerHTML='<option value="">Select Product first</option>';plan.disabled=true;}});});</script></body>

</html>