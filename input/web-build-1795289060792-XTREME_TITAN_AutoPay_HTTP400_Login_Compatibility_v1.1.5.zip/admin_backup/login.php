<?php
require_once __DIR__ . '/../config.php';
if (session_status() !== PHP_SESSION_ACTIVE) session_start();
if (!empty($_SESSION['admin_id'])) { header('Location: dashboard.php'); exit; }
$error='';

function h($v){return htmlspecialchars((string)$v,ENT_QUOTES,'UTF-8');}

if($_SERVER['REQUEST_METHOD']==='POST'){
 $identifier=trim((string)($_POST['identifier']??''));
 $password=(string)($_POST['password']??'');
 if($identifier===''||$password===''){ $error='Enter your admin login details.'; }
 else{
  try{
   $pdo=db(); $admin=null;
   // Support a conventional admins table if it exists.
   try{
    $q=$pdo->prepare("SELECT id,name,email,password_hash FROM admins WHERE (email=? OR username=?) LIMIT 1");
    $q->execute([$identifier,$identifier]); $admin=$q->fetch(PDO::FETCH_ASSOC);
   }catch(Throwable $ignore){}
   if($admin && password_verify($password,(string)$admin['password_hash'])){
    session_regenerate_id(true); $_SESSION['admin_id']=(int)$admin['id']; $_SESSION['admin_name']=$admin['name']??'Admin'; $_SESSION['admin_logged_in']=1;
    header('Location: dashboard.php'); exit;
   }
   // Also support users table when it has an admin/role flag.
   $cols=[];
   try{$cols=$pdo->query("SHOW COLUMNS FROM users")->fetchAll(PDO::FETCH_COLUMN);}catch(Throwable $ignore){}
   $lower=array_map('strtolower',$cols);
   $roleCol=null; foreach(['role','user_role','account_type','type','is_admin'] as $c){$i=array_search($c,$lower,true);if($i!==false){$roleCol=$cols[$i];break;}}
   if($roleCol){
    $q=$pdo->prepare("SELECT id,name,email,phone,password_hash,`".str_replace("`","``",$roleCol)."` AS admin_flag FROM users WHERE (email=? OR phone=?) LIMIT 1");
    $q->execute([$identifier,$identifier]); $u=$q->fetch(PDO::FETCH_ASSOC);
    $flag=strtolower(trim((string)($u['admin_flag']??'')));
    if($u && password_verify($password,(string)$u['password_hash']) && in_array($flag,['admin','administrator','1','true','yes'],true)){
      session_regenerate_id(true); $_SESSION['admin_id']=(int)$u['id']; $_SESSION['admin_name']=$u['name']??'Admin'; $_SESSION['admin_logged_in']=1;
      header('Location: dashboard.php'); exit;
    }
   }
   $error='Invalid admin credentials.';
  }catch(Throwable $e){$error='Unable to sign in to the admin panel.';}
 }
}
?>
<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Admin Login — XTREME_TITAN_OFFICIAL SHOP</title>
<style>*{box-sizing:border-box}body{margin:0;min-height:100vh;display:grid;place-items:center;background:#06101c;color:#eef4ff;font-family:Arial,sans-serif}.card{width:min(420px,calc(100% - 28px));background:#0d1928;border:1px solid #26384e;border-radius:20px;padding:24px}h1{margin:0 0 7px}.muted{color:#91a2b8;font-size:13px;margin-bottom:20px}label{display:block;color:#9aa9bf;font-size:11px;font-weight:900;margin:13px 0 6px}input{width:100%;padding:13px;border-radius:11px;border:1px solid #293c53;background:#071220;color:#fff;outline:0}input:focus{border-color:#63ff16}button{width:100%;margin-top:18px;padding:13px;border:0;border-radius:11px;background:#63ff16;color:#06101c;font-weight:900}.error{background:#3b1c24;color:#ff9aaa;border:1px solid #6b2b38;padding:12px;border-radius:11px;font-size:12px}</style><link rel="stylesheet" href="../theme.php?v=20260929-27"><link rel="stylesheet" href="admin-theme.css"><link rel="stylesheet" href="../site-polish.css?v=20261022-lightfix3"><script src="admin-background.js?v=20260929-27" defer></script><link rel="stylesheet" href="../responsive-lock.css?v=20260929-28">

<link rel="icon" type="image/png" sizes="48x48" href="/assets/pwa-icon-48.png">
<link rel="apple-touch-icon" sizes="180x180" href="/assets/pwa-icon-180.png">
<link rel="manifest" href="/admin/admin-manifest.json">
<meta name="apple-mobile-web-app-title" content="XTREME TITAN">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="mobile-web-app-capable" content="yes">
<meta name="theme-color" content="#080a14">
</head><body><div class="admin-panel-logo"><img src="../assets/xtreme-titan-logo.jpg" alt="XTREME TITAN"></div><div class="card"><img class="site-logo" src="../assets/xtreme-titan-logo.jpg" alt="XTREME TITAN"><h1>XTREME_TITAN_OFFICIAL SHOP</h1><div class="admin-badge">ADMIN AREA</div><div class="muted">Secure administrator sign in</div><?php if($error):?><div class="error"><?=h($error)?></div><?php endif;?><form method="post"><label>Email / Username / Phone</label><input name="identifier" required value="<?=h($_POST['identifier']??'')?>"><label>Password</label><input name="password" type="password" required><button type="submit">SIGN IN</button></form></div></body></html>