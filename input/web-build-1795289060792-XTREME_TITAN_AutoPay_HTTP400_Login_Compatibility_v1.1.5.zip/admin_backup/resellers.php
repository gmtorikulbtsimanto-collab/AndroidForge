<?php
declare(strict_types=1);
require_once __DIR__.'/../config.php';
if (empty($_SESSION['admin_id']) && empty($_SESSION['admin_logged_in'])) { header('Location: login.php'); exit; }
ensure_account_role_columns(); ensure_site_settings_table(); ensure_catalog_product_columns();
$pdo = db(); $msg = ''; $error = '';
if (empty($_SESSION['reseller_control_csrf'])) $_SESSION['reseller_control_csrf'] = bin2hex(random_bytes(32));
$csrf = $_SESSION['reseller_control_csrf'];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!isset($_POST['csrf']) || !is_string($_POST['csrf']) || !hash_equals($csrf, $_POST['csrf'])) {
        $error = 'Security check failed. Refresh this page and try again.';
    } else {
        $action = (string)($_POST['action'] ?? '');
        try {
            if ($action === 'save_global') {
                $v = max(0, min(90, (float)($_POST['discount'] ?? 20)));
                $st = $pdo->prepare('INSERT INTO site_settings(setting_key,setting_value) VALUES(?,?) ON DUPLICATE KEY UPDATE setting_value=VALUES(setting_value)');
                $st->execute(['reseller_discount_percent', (string)$v]);
                $msg = 'Default reseller discount saved. Products without an individual override use this percentage.';
            } elseif ($action === 'save_product') {
                $id = (int)($_POST['product_id'] ?? 0);
                $v = max(0, min(90, (float)($_POST['product_discount'] ?? 0)));
                if ($id <= 0) throw new RuntimeException('Select a valid product.');
                $st = $pdo->prepare('UPDATE catalog_products SET reseller_discount_percent=? WHERE id=?');
                $st->execute([$v, $id]);
                if ($st->rowCount() === 0) {
                    $check = $pdo->prepare('SELECT id FROM catalog_products WHERE id=?'); $check->execute([$id]);
                    if (!$check->fetchColumn()) throw new RuntimeException('Product not found.');
                }
                $msg = 'Product-specific reseller discount saved. Only this product is affected.';
            } elseif ($action === 'reset_product') {
                $id = (int)($_POST['product_id'] ?? 0);
                if ($id <= 0) throw new RuntimeException('Select a valid product.');
                $st = $pdo->prepare('UPDATE catalog_products SET reseller_discount_percent=NULL WHERE id=?'); $st->execute([$id]);
                $msg = 'Product reset to the global default discount.';
            }
        } catch (Throwable $e) { $error = $e instanceof RuntimeException ? $e->getMessage() : 'Could not save reseller pricing. Check the database and try again.'; }
    }
}
$discount = max(0, min(90, (float)site_setting('reseller_discount_percent', '20')));
$rows = []; $products = [];
try { $rows = $pdo->query("SELECT id,name,email,phone,role,created_at FROM users WHERE role='reseller' ORDER BY id DESC LIMIT 100")->fetchAll(); } catch (Throwable $e) {}
try { $products = $pdo->query('SELECT id,name,category,reseller_discount_percent FROM catalog_products ORDER BY name ASC, id ASC')->fetchAll(); } catch (Throwable $e) { $error = $error ?: 'Could not load products. Please verify the catalog_products table.'; }
function rh($v): string { return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }
?><!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Reseller Pricing Control</title><link rel="stylesheet" href="../theme.php?v=20261022-reseller-product-pricing"><link rel="stylesheet" href="admin-theme.css"><link rel="stylesheet" href="../responsive-lock.css"><script src="admin-background.js" defer></script><style>
:root{color-scheme:dark}.wrap{width:min(1120px,100%);box-sizing:border-box;margin:0 auto;padding:clamp(12px,3vw,28px)}.panel{box-sizing:border-box;padding:clamp(15px,3vw,24px);margin:0 0 16px;border:1px solid rgba(22,217,255,.18);border-radius:20px;background:linear-gradient(145deg,rgba(11,23,39,.97),rgba(8,13,26,.97));box-shadow:0 12px 32px rgba(0,0,0,.16);min-width:0}h1{font-size:clamp(24px,4vw,34px);margin:0 0 8px}h2{font-size:clamp(18px,3vw,23px);margin:0 0 10px}.muted{color:#9aaac0;font-size:13px;line-height:1.55}.field{margin:14px 0}.field label{display:block;font-size:12px;font-weight:800;margin-bottom:7px;color:#c5d3e6}.field input,.field select{box-sizing:border-box;width:100%;max-width:100%;padding:13px 14px;border:1px solid #2b3b52;border-radius:12px;background:#070e19;color:#f5f8ff;font-size:16px}.btn{display:inline-flex;justify-content:center;align-items:center;gap:7px;border:0;border-radius:12px;padding:12px 16px;background:linear-gradient(120deg,#10cfe8,#7357ff);color:#fff;font-weight:900;text-decoration:none;cursor:pointer;min-height:44px}.btn.secondary{background:#18253a;border:1px solid #34445e}.notice{padding:12px 14px;border-radius:12px;margin:0 0 14px;line-height:1.5}.success{background:rgba(34,197,94,.12);color:#86efac;border:1px solid rgba(34,197,94,.25)}.error{background:rgba(244,63,94,.12);color:#fda4af;border:1px solid rgba(244,63,94,.25)}.product-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:12px}.product-card{min-width:0;padding:15px;border:1px solid rgba(148,163,184,.2);border-radius:16px;background:rgba(3,9,19,.55)}.product-head{display:flex;gap:10px;align-items:flex-start;justify-content:space-between;margin-bottom:10px}.product-name{font-weight:900;overflow-wrap:anywhere}.meta{font-size:12px;color:#9aaac0;margin-top:4px}.pill{display:inline-block;white-space:nowrap;padding:5px 8px;border-radius:999px;background:rgba(22,217,255,.1);color:#6ee7f9;font-size:11px;font-weight:900}.price-row{display:flex;justify-content:space-between;gap:8px;margin:10px 0;color:#b6c5d8;font-size:13px}.price-row strong{color:#fff}.form-row{display:grid;grid-template-columns:minmax(0,1fr) auto;gap:8px;align-items:end}.form-row .field{margin:0}.reseller-list{overflow-wrap:anywhere}.table-wrap{overflow-x:auto}.table{width:100%;border-collapse:collapse}.table th,.table td{padding:11px;border-bottom:1px solid rgba(255,255,255,.08);text-align:left;font-size:12px}.table th{color:#a8b8cc}@media(max-width:680px){.product-grid{grid-template-columns:minmax(0,1fr)}.form-row{grid-template-columns:minmax(0,1fr)}.form-row .btn{width:100%}.table{min-width:560px}}
</style>
<link rel="icon" type="image/png" sizes="48x48" href="/assets/pwa-icon-48.png">
<link rel="apple-touch-icon" sizes="180x180" href="/assets/pwa-icon-180.png">
<link rel="manifest" href="/admin/admin-manifest.json">
<meta name="apple-mobile-web-app-title" content="XTREME TITAN">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="mobile-web-app-capable" content="yes">
<meta name="theme-color" content="#080a14">
<script src="admin-action-progress.js?v=20261023-inline-progress25" defer></script>
</head><body><main class="wrap"><section class="panel"><h1>Reseller Pricing Control</h1><div class="muted">Set a default discount, then override it for individual products. An individual product discount affects only that product and all of its plans; customer pricing stays unchanged.</div><?php if($msg):?><p class="notice success"><?=rh($msg)?></p><?php endif;?><?php if($error):?><p class="notice error"><?=rh($error)?></p><?php endif;?></section>
<section class="panel"><h2>Global default</h2><p class="muted">Used only for products set to “Use global default”. This keeps the existing reseller discount behavior for products without an override.</p><form method="post"><input type="hidden" name="csrf" value="<?=rh($csrf)?>"><input type="hidden" name="action" value="save_global"><div class="form-row"><div class="field"><label for="discount">DEFAULT RESELLER DISCOUNT (%)</label><input id="discount" type="number" name="discount" min="0" max="90" step="0.01" value="<?=rh($discount)?>" required></div><button class="btn" type="submit">Save Default</button></div></form></section>
<section class="panel"><h2>Per-product discounts</h2><p class="muted">Set 0% to disable the discount for a product. Use “Reset to default” to make that product follow the global default again. Discount is limited to 0–90%.</p><?php if(!$products):?><p class="muted">No products found.</p><?php else:?><div class="product-grid"><?php foreach($products as $p): $hasOverride=($p['reseller_discount_percent']!==null); $effective=$hasOverride?max(0,min(90,(float)$p['reseller_discount_percent'])):$discount; $basePrice=isset($p['price'])?(float)$p['price']:0; ?><article class="product-card"><div class="product-head"><div><div class="product-name"><?=rh($p['name']??('Product #'.$p['id']))?></div><div class="meta">Product ID: <?= (int)$p['id']?> · <?=rh($p['category']??'Product')?></div></div><span class="pill"><?=$hasOverride?'CUSTOM':'GLOBAL DEFAULT'?></span></div><div class="price-row"><span>Discount applied</span><strong><?=rh(number_format($effective,2))?>%</strong></div><form method="post"><input type="hidden" name="csrf" value="<?=rh($csrf)?>"><input type="hidden" name="action" value="save_product"><input type="hidden" name="product_id" value="<?=(int)$p['id']?>"><div class="form-row"><div class="field"><label>THIS PRODUCT DISCOUNT (%)</label><input type="number" name="product_discount" min="0" max="90" step="0.01" value="<?=rh($hasOverride?number_format((float)$p['reseller_discount_percent'],2,'.',''):'0')?>" required></div><button class="btn" type="submit">Save Product</button></div></form><?php if($hasOverride):?><form method="post" style="margin-top:9px"><input type="hidden" name="csrf" value="<?=rh($csrf)?>"><input type="hidden" name="action" value="reset_product"><input type="hidden" name="product_id" value="<?=(int)$p['id']?>"><button class="btn secondary" type="submit">Reset to Global Default</button></form><?php endif;?></article><?php endforeach;?></div><?php endif;?></section>
<section class="panel"><h2>Reseller accounts</h2><?php if(!$rows):?><p class="muted">No reseller accounts found.</p><?php else:?><div class="table-wrap"><table class="table"><thead><tr><th>ID</th><th>Name</th><th>Email</th><th>Phone</th><th>Status</th></tr></thead><tbody><?php foreach($rows as $r):?><tr><td><?=rh($r['id'])?></td><td><?=rh($r['name'])?></td><td><?=rh($r['email'])?></td><td><?=rh($r['phone'])?></td><td><span class="pill">RESELLER</span></td></tr><?php endforeach;?></tbody></table></div><?php endif;?></section><p><a class="btn secondary" href="dashboard.php">← Admin Dashboard</a></p></main></body></html>
