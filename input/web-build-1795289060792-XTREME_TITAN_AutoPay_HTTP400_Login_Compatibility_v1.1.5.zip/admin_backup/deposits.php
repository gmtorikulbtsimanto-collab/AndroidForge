<?php

require_once __DIR__ . '/../config.php';

/*
|--------------------------------------------------------------------------
| DEBUG
|--------------------------------------------------------------------------
| সমস্যা হলে hosting error log-এও error যাবে।
|--------------------------------------------------------------------------
*/

ini_set('display_errors', '1');
ini_set('display_startup_errors', '1');
error_reporting(E_ALL);


/*
|--------------------------------------------------------------------------
| ADMIN ACCESS
|--------------------------------------------------------------------------
*/

if (empty($_SESSION['admin_id']) && empty($_SESSION['admin_logged_in'])) {
    header('Location: login.php');
    exit;
}


/*
|--------------------------------------------------------------------------
| DATABASE
|--------------------------------------------------------------------------
*/

$pdo = db();
try { $dc=$pdo->query('SHOW COLUMNS FROM deposits')->fetchAll(PDO::FETCH_COLUMN); foreach ([ 'currency_code'=>"ALTER TABLE deposits ADD COLUMN currency_code VARCHAR(10) NULL", 'amount_bdt'=>"ALTER TABLE deposits ADD COLUMN amount_bdt DECIMAL(14,2) NULL", 'source_role'=>"ALTER TABLE deposits ADD COLUMN source_role VARCHAR(20) NULL", 'deposit_country'=>"ALTER TABLE deposits ADD COLUMN deposit_country VARCHAR(8) NULL"] as $col=>$ddl) { if(!in_array($col,$dc,true)){try{$pdo->exec($ddl);}catch(Throwable $ignore){}} } } catch(Throwable $ignore) {}


/*
|--------------------------------------------------------------------------
| CSRF
|--------------------------------------------------------------------------
*/

if (empty($_SESSION['admin_csrf'])) {
    $_SESSION['admin_csrf'] = bin2hex(random_bytes(32));
}

$csrf = $_SESSION['admin_csrf'];


/*
|--------------------------------------------------------------------------
| HELPER
|--------------------------------------------------------------------------
*/

if (!function_exists('e')) {
    function e($value): string
    {
        return htmlspecialchars(
            (string)$value,
            ENT_QUOTES,
            'UTF-8'
        );
    }
}


/*
|--------------------------------------------------------------------------
| MESSAGE
|--------------------------------------------------------------------------
*/

$success = '';
$error = '';

if (isset($_GET['success'])) {
    $success = trim((string)$_GET['success']);
}


/*
|--------------------------------------------------------------------------
| APPROVE / REJECT
|--------------------------------------------------------------------------
*/

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $action = trim($_POST['action'] ?? '');

    $depositId = (int)(
        $_POST['deposit_id'] ?? 0
    );

    $postedCsrf = (string)(
        $_POST['csrf'] ?? ''
    );


    /*
     * CSRF CHECK
     */

    if (
        $postedCsrf === '' ||
        !hash_equals($csrf, $postedCsrf)
    ) {

        $error = 'Security verification failed.';

    } elseif ($depositId <= 0) {

        $error = 'Invalid deposit ID.';

    } elseif (
        !in_array(
            $action,
            ['approve', 'reject'],
            true
        )
    ) {

        $error = 'Invalid action.';

    } else {

        try {

            $pdo->beginTransaction();


            /*
             * Lock deposit row.
             */

            $stmt = $pdo->prepare("
                SELECT
                    d.id,
                    d.user_id,
                    d.amount,
                    COALESCE(d.currency_code, CASE WHEN LOWER(d.payment_method)='paypal' THEN 'USD' WHEN LOWER(d.payment_method) IN ('bkash','nagad') THEN 'BDT' ELSE NULL END) AS currency_code,
                    d.amount_bdt,
                    COALESCE(d.source_role, u.role, 'user') AS source_role,
                    COALESCE(d.deposit_country, u.country_code) AS deposit_country,
                    d.status,
                    d.payment_method,
                    d.transaction_id
                FROM deposits d
                LEFT JOIN users u ON u.id=d.user_id
                WHERE d.id = ?
                LIMIT 1
                FOR UPDATE
            ");

            $stmt->execute([
                $depositId
            ]);

            $deposit = $stmt->fetch(
                PDO::FETCH_ASSOC
            );


            if (!$deposit) {

                throw new RuntimeException(
                    'Deposit not found.'
                );
            }


            $status = strtolower(
                trim(
                    (string)$deposit['status']
                )
            );


            /*
             * Only pending deposits can be processed.
             */

            if ($status !== 'pending') {

                throw new RuntimeException(
                    'This deposit has already been processed.'
                );
            }


            $userId = (int)$deposit['user_id'];

            $amount = (float)$deposit['amount'];
            $currencyForCredit = strtoupper((string)($deposit['currency_code'] ?? 'BDT'));
            $bdtPerUnitForApproval = ['BDT'=>1.0,'USD'=>122.0,'EUR'=>133.33,'AED'=>33.22,'INR'=>1.77,'NPR'=>0.88,'BTN'=>1.77,'VND'=>0.0049,'GBP'=>154.0];
            $walletAmount = (isset($deposit['amount_bdt']) && (float)$deposit['amount_bdt'] > 0) ? (float)$deposit['amount_bdt'] : round($amount * ($bdtPerUnitForApproval[$currencyForCredit] ?? 1.0), 2);


            if ($userId <= 0) {

                throw new RuntimeException(
                    'Invalid user ID.'
                );
            }


            if ($amount <= 0) {

                throw new RuntimeException(
                    'Invalid deposit amount.'
                );
            }


            /*
             |--------------------------------------------------------------------------
             | APPROVE
             |--------------------------------------------------------------------------
             */

            if ($action === 'approve') {


                /*
                 * Change deposit status.
                 */

                $update = $pdo->prepare("
                    UPDATE deposits
                    SET status = 'approved'
                    WHERE id = ?
                      AND status = 'pending'
                    LIMIT 1
                ");

                $update->execute([
                    $depositId
                ]);


                if ($update->rowCount() !== 1) {

                    throw new RuntimeException(
                        'Deposit could not be approved.'
                    );
                }


                /*
                 * Add money to wallet_transactions.
                 *
                 * Your database uses:
                 * type = deposit
                 */

                $description =
                    'Deposit approved';

                if (!empty($deposit['payment_method'])) {

                    $description .=
                        ' - ' .
                        $deposit['payment_method'];
                }

                if (!empty($deposit['transaction_id'])) {

                    $description .=
                        ' - TXN: ' .
                        $deposit['transaction_id'];
                }


                $wallet = $pdo->prepare("
                    INSERT INTO wallet_transactions
                    (
                        user_id,
                        type,
                        amount,
                        description,
                        created_at
                    )
                    VALUES
                    (
                        ?,
                        'deposit',
                        ?,
                        ?,
                        NOW()
                    )
                ");

                $wallet->execute([
                    $userId,
                    number_format(
                        $walletAmount,
                        2,
                        '.',
                        ''
                    ),
                    $description
                ]);


                $pdo->commit();


                header(
                    'Location: deposits.php?success=' .
                    urlencode(
                        'Deposit #' .
                        $depositId .
                        ' approved. User balance updated.'
                    )
                );

                exit;
            }


            /*
             |--------------------------------------------------------------------------
             | REJECT
             |--------------------------------------------------------------------------
             */

            if ($action === 'reject') {


                $update = $pdo->prepare("
                    UPDATE deposits
                    SET status = 'rejected'
                    WHERE id = ?
                      AND status = 'pending'
                    LIMIT 1
                ");

                $update->execute([
                    $depositId
                ]);


                if ($update->rowCount() !== 1) {

                    throw new RuntimeException(
                        'Deposit could not be rejected.'
                    );
                }


                /*
                 * No wallet transaction for rejected deposit.
                 */

                $pdo->commit();


                header(
                    'Location: deposits.php?success=' .
                    urlencode(
                        'Deposit #' .
                        $depositId .
                        ' rejected.'
                    )
                );

                exit;
            }


        } catch (Throwable $ex) {

            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }

            $error =
                'Error: ' .
                $ex->getMessage();
        }
    }
}


/*
|--------------------------------------------------------------------------
| LOAD PENDING DEPOSITS
|--------------------------------------------------------------------------
*/

$deposits = [];

// Optional receipt column used by the customer deposit form.
try { $dc = $pdo->query("SHOW COLUMNS FROM deposits")->fetchAll(PDO::FETCH_COLUMN); if (!in_array('receipt_path',$dc,true)) { try{$pdo->exec("ALTER TABLE deposits ADD COLUMN receipt_path VARCHAR(255) NULL");}catch(Throwable $ignore){} } } catch(Throwable $ignore) {}

try {

    $hasReceiptColumn = false;
    try { $colsNow = $pdo->query("SHOW COLUMNS FROM deposits")->fetchAll(PDO::FETCH_COLUMN); $hasReceiptColumn = in_array('receipt_path',$colsNow,true); } catch(Throwable $ignore) {}
    $receiptSelect = $hasReceiptColumn ? 'd.receipt_path,' : 'NULL AS receipt_path,';
    $stmt = $pdo->query("
        SELECT
            d.id,
            d.user_id,
            d.amount,
            COALESCE(d.currency_code, CASE WHEN LOWER(d.payment_method)='paypal' THEN 'USD' WHEN LOWER(d.payment_method) IN ('bkash','nagad') THEN 'BDT' ELSE NULL END) AS currency_code,
            d.amount_bdt,
            COALESCE(d.source_role, u.role, 'user') AS source_role,
            COALESCE(d.deposit_country, u.country_code) AS deposit_country,
            d.status,
            d.payment_method,
            d.transaction_id,
            d.created_at,
            {$receiptSelect}
            u.name,
            u.email,
            u.phone
        FROM deposits d

        LEFT JOIN users u
            ON u.id = d.user_id

        WHERE LOWER(d.status) = 'pending'

        ORDER BY
            d.id DESC
    ");

    $deposits =
        $stmt->fetchAll(
            PDO::FETCH_ASSOC
        );

} catch (Throwable $ex) {

    $error =
        'Unable to load deposits: ' .
        $ex->getMessage();
}


$pendingCount = count($deposits);

?>

<!doctype html>

<html lang="en">

<head>

<meta charset="utf-8">

<meta
    name="viewport"
    content="width=device-width,initial-scale=1"
>

<title>
    Deposit Approvals
</title>


<style>

*{
    box-sizing:border-box;
}

body{
    margin:0;
    background:#06101c;
    color:#eef4ff;
    font-family:Arial,Helvetica,sans-serif;
}

.topbar{
    min-height:68px;
    padding:15px 20px;

    display:flex;
    align-items:center;
    justify-content:space-between;

    background:#071220;
    border-bottom:1px solid #1b2b40;
}

.brand{
    font-size:19px;
    font-weight:900;
}

.admin{
    color:#63ff16;
    font-size:11px;
    font-weight:900;
}

.container{
    max-width:1050px;
    margin:auto;
    padding:25px 14px 60px;
}

h1{
    margin:0 0 6px;
    font-size:31px;
}

.subtitle{
    margin:0 0 20px;
    color:#91a1b5;
    font-size:13px;
}

.alert{
    padding:13px 15px;
    border-radius:11px;
    margin-bottom:15px;
    font-size:12px;
}

.success{
    background:#14331b;
    border:1px solid #285e31;
    color:#9cff79;
}

.error{
    background:#3b1b24;
    border:1px solid #682e3b;
    color:#ff9baa;
}

.summary{
    background:#0d1928;
    border:1px solid #26384e;
    border-radius:15px;
    padding:15px;
    margin-bottom:18px;
}

.summary-label{
    color:#8798ad;
    font-size:10px;
    font-weight:900;
}

.summary-number{
    margin-top:5px;
    font-size:25px;
    font-weight:900;
    color:#ffd36e;
}

.list{
    display:flex;
    flex-direction:column;
    gap:12px;
}

.card{
    background:#0d1928;
    border:1px solid #26384e;
    border-radius:17px;
    padding:16px;
}

.card-top{
    display:flex;
    justify-content:space-between;
    gap:15px;
}

.user-name{
    font-size:16px;
    font-weight:900;
}

.user-info{
    margin-top:5px;
    color:#91a1b5;
    font-size:11px;
    line-height:1.6;
}

.amount{
    color:#63ff16;
    font-size:20px;
    font-weight:900;
    white-space:nowrap;
}

.details{
    display:grid;
    grid-template-columns:repeat(2,1fr);
    gap:8px;
    margin-top:14px;
}

.detail{
    background:#091522;
    border:1px solid #1d3045;
    border-radius:10px;
    padding:10px;
}

.detail-label{
    display:block;
    color:#708198;
    font-size:9px;
    font-weight:900;
    text-transform:uppercase;
    margin-bottom:4px;
}

.detail-value{
    font-size:11px;
    font-weight:700;
    word-break:break-word;
}

.actions{
    display:flex;
    gap:9px;
    margin-top:14px;
}

.actions form{
    flex:1;
}

button{
    width:100%;
    border:0;
    border-radius:10px;
    padding:12px;
    cursor:pointer;
    font-weight:900;
    font-size:12px;
}

.approve{
    background:#1d681f;
    color:#c4ffad;
}

.reject{
    background:#5c202c;
    color:#ffb0bc;
}

.empty{
    text-align:center;
    padding:55px 15px;
    background:#0d1928;
    border:1px solid #26384e;
    border-radius:17px;
    color:#91a1b5;
}

.empty strong{
    display:block;
    color:#eef4ff;
    font-size:17px;
    margin-bottom:5px;
}

.back{
    display:inline-block;
    margin-top:18px;
    color:#9bacc0;
    text-decoration:none;
    font-size:12px;
    font-weight:800;
}

@media(max-width:600px){

    .topbar{
        padding:14px;
    }

    .card-top{
        flex-direction:column;
    }

    .details{
        grid-template-columns:1fr;
    }

    .actions{
        flex-direction:column;
    }

    h1{
        font-size:27px;
    }

}

</style><link rel="stylesheet" href="../theme.php?v=20260929-27"><link rel="stylesheet" href="admin-theme.css">

<script src="admin-background.js?v=20260929-27" defer></script><link rel="stylesheet" href="../responsive-lock.css?v=20260929-28">
<script src="admin-action-progress.js?v=20261023-inline-progress25" defer></script>
<link rel="icon" type="image/png" sizes="48x48" href="/assets/pwa-icon-48.png">
<link rel="apple-touch-icon" sizes="180x180" href="/assets/pwa-icon-180.png">
<link rel="manifest" href="/admin/admin-manifest.json">
<meta name="apple-mobile-web-app-title" content="XTREME TITAN">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="mobile-web-app-capable" content="yes">
<meta name="theme-color" content="#080a14">
<script src="admin-action-progress.js?v=20261023-inline-progress25" defer></script>

<style id="xtreme-receipt-neon-v35">
/* Branded payment receipt presentation; keeps receipt URL and approval logic unchanged. */
.detail-label{color:#aeb8ff!important;font-weight:900!important;letter-spacing:.035em}
.detail-value{overflow-wrap:anywhere}
.detail-value a[href*="receipts"],.detail-value a[href*="uploads"]{
 display:inline-flex;align-items:center;justify-content:center;gap:8px;
 padding:10px 15px;border-radius:13px;color:#fff!important;text-decoration:none;
 background:linear-gradient(110deg,#087cf0,#9b16d8,#f0229c);
 border:1px solid rgba(255,255,255,.22);
 box-shadow:0 0 18px rgba(170,35,255,.18);font-weight:900
}
.detail-value a[href*="receipts"]:before,.detail-value a[href*="uploads"]:before{content:"▣";font-size:16px}
</style>

</head>


<body><div class="admin-panel-logo"><img src="../assets/xtreme-titan-logo.jpg" alt="XTREME TITAN"></div>


<header class="topbar">

    <div class="brand">
        XTREME_TITAN_OFFICIAL SHOP
    </div>

    <div class="admin">
        XTREME_TITAN_OFFICIAL SHOP — ADMIN
    </div>

</header>


<main class="container">


<h1>
    Deposit Approvals
</h1>

<p class="subtitle">
    Review and approve pending user deposits.
</p>


<?php if ($success !== ''): ?>

<div class="alert success">
    <?= e($success) ?>
</div>

<?php endif; ?>


<?php if ($error !== ''): ?>

<div class="alert error">
    <?= e($error) ?>
</div>

<?php endif; ?>


<div class="summary">

    <div class="summary-label">
        PENDING DEPOSITS
    </div>

    <div class="summary-number">
        <?= $pendingCount ?>
    </div>

</div>


<?php if (!$deposits): ?>


<div class="empty">

    <strong>
        No pending deposits
    </strong>

    New deposit requests will appear here.

</div>


<?php else: ?>


<div class="list">


<?php foreach ($deposits as $deposit): ?>


<article class="card">


<div class="card-top">


<div>

    <div class="user-name">

        <?= e(
            $deposit['name']
            ?: 'Unknown User'
        ) ?>

    </div>


    <div class="user-info">

        User ID:
        #<?= (int)$deposit['user_id'] ?>

        <br>

        <?= e(
            $deposit['email']
            ?: 'No email'
        ) ?>

        <?php if (!empty($deposit['phone'])): ?>

            <br>

            <?= e($deposit['phone']) ?>

        <?php endif; ?>

    </div>

</div>


<div class="amount">
    <?php $depCurrency = strtoupper((string)($deposit['currency_code'] ?? '')); $depSymbols = ['USD'=>'$','BDT'=>'৳','INR'=>'₹','NPR'=>'रू','BTN'=>'Nu.','VND'=>'₫','EUR'=>'€','AED'=>'د.إ','GBP'=>'£']; ?>
    <?= e($depSymbols[$depCurrency] ?? '') ?><?= number_format((float)$deposit['amount'], 2) ?> <?= e($depCurrency ?: 'LEGACY') ?>
</div>


</div>


<div class="details">

<div class="detail"><span class="detail-label">Request Source</span><span class="detail-value"><?= strtolower((string)($deposit['source_role'] ?? '')) === 'reseller' ? 'Reseller Panel' : (strtolower((string)($deposit['source_role'] ?? '')) === 'user' ? 'User Panel' : 'Legacy / Unknown') ?></span></div>
<div class="detail"><span class="detail-label">Submitted Currency</span><span class="detail-value"><?= e(($deposit['currency_code'] ?? '') ?: 'Unknown (older request)') ?><?= !empty($deposit['deposit_country']) ? ' · '.e($deposit['deposit_country']) : '' ?></span></div>
<div class="detail"><span class="detail-label">Wallet Credit (BDT)</span><span class="detail-value">৳<?= number_format((float)($deposit['amount_bdt'] ?? $deposit['amount']),2) ?></span></div>

<div class="detail">

    <span class="detail-label">
        Deposit ID
    </span>

    <span class="detail-value">
        #<?= (int)$deposit['id'] ?>
    </span>

</div>


<div class="detail">

    <span class="detail-label">
        Payment Method
    </span>

    <span class="detail-value">

        <?= e(
            $deposit['payment_method']
            ?: 'N/A'
        ) ?>

    </span>

</div>


<div class="detail">

    <span class="detail-label">
        Transaction ID
    </span>

    <span class="detail-value">

        <?= e(
            $deposit['transaction_id']
            ?: 'N/A'
        ) ?>

    </span>

</div>


<?php if (!empty($deposit['receipt_path'])): ?>
<div class="detail">
    <span class="detail-label">Payment Receipt</span>
    <span class="detail-value"><a href="../<?= e($deposit['receipt_path']) ?>" target="_blank" rel="noopener" style="color:#10d8ff;font-weight:900">View Receipt</a></span>
</div>
<?php endif; ?>

<div class="detail">

    <span class="detail-label">
        Date
    </span>

    <span class="detail-value">

        <?= e(
            $deposit['created_at']
            ?: 'N/A'
        ) ?>

    </span>

</div>


</div>


<div class="actions">


<form
    method="post"
    onsubmit="return confirm(
        'Approve this deposit and add the money to the user balance?'
    );"
>

    <input
        type="hidden"
        name="csrf"
        value="<?= e($csrf) ?>"
    >

    <input
        type="hidden"
        name="deposit_id"
        value="<?= (int)$deposit['id'] ?>"
    >

    <input
        type="hidden"
        name="action"
        value="approve"
    >

    <button
        type="submit"
        class="approve"
    >
        ✓ APPROVE
    </button>

</form>


<form
    method="post"
    onsubmit="return confirm(
        'Reject this deposit?'
    );"
>

    <input
        type="hidden"
        name="csrf"
        value="<?= e($csrf) ?>"
    >

    <input
        type="hidden"
        name="deposit_id"
        value="<?= (int)$deposit['id'] ?>"
    >

    <input
        type="hidden"
        name="action"
        value="reject"
    >

    <button
        type="submit"
        class="reject"
    >
        ✕ REJECT
    </button>

</form>


</div>


</article>


<?php endforeach; ?>


</div>


<?php endif; ?>


<a
    href="../dashboard.php"
    class="back"
>
    ← Back to Home Shop
</a>


</main>


</body>

</html>