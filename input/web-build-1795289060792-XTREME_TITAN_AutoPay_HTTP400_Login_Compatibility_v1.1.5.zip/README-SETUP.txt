XTREME TITAN — UDDOKTAPAY FIX UPDATE

This is a PATCH ZIP, not a full website backup.

Upload/overwrite these paths into your website's htdocs root, preserving folders:
- uddoktapay-lib.php
- uddoktapay-start.php
- uddoktapay-return.php
- uddoktapay-webhook.php
- uddoktapay-cancel.php
- admin/uddoktapay-settings.php
- admin/dashboard.php

Important fixes:
1. UddoktaPay Create Charge returns payment_url (not invoice_id). The invoice_id is returned to redirect_url after checkout.
2. The redirect URL now carries the local deposit_id; return handler attaches invoice_id and verifies the payment with Verify Payment API.
3. Wallet is credited only after verified status=COMPLETED and amount/user/deposit metadata checks.
4. Admin menu points directly to /admin/uddoktapay-settings.php.
5. Automatic Add Funds page has a premium responsive layout.
6. Admin settings page has a redesigned UI and encrypted API key storage.

After upload:
- Open https://YOUR-DOMAIN/admin/uddoktapay-settings.php
- Base URL: https://xtremetitanofficial.paymently.io
- Add API key with payment:checkout and payment:verify abilities.
- Enable gateway and save.
- Test with a small amount, then verify the deposit and wallet history.

Do not upload API keys in this ZIP. Never share API keys or database/email passwords in chat.
Make a full backup before replacing files.
