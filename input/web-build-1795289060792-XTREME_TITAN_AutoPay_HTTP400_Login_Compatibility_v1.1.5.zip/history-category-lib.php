<?php
// Shared editable History category definitions for XTREME TITAN.
function xt_history_categories(): array {
    $pdo = db();
    $pdo->exec("CREATE TABLE IF NOT EXISTS history_categories (
        id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
        name VARCHAR(60) NOT NULL,
        slug VARCHAR(60) NOT NULL UNIQUE,
        keywords TEXT NULL,
        kind VARCHAR(20) NOT NULL DEFAULT 'purchase',
        sort_order INT NOT NULL DEFAULT 0,
        enabled TINYINT(1) NOT NULL DEFAULT 1,
        created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    $defaults = [
        ['Diamond','diamond','diamond,diamonds,topup,top-up','purchase',10],
        ['Weekly','weekly','weekly,week,7 day,7-day','purchase',20],
        ['Monthly','monthly','monthly,month,30 day,30-day','purchase',30],
        ['Like','like','like,likes','purchase',40],
        ['Guild Glory','guild-war','guild,guild glory,guildglory','purchase',50],
        ['Top-Up','top-up','topup,top-up,diamond top-up','purchase',55],
        ['Deposit','deposit','','deposit',60],
        ['Other','other','','other',90],
    ];
    $ins = $pdo->prepare("INSERT IGNORE INTO history_categories (name,slug,keywords,kind,sort_order,enabled) VALUES (?,?,?,?,?,1)");
    foreach ($defaults as $d) $ins->execute($d);
    $pdo->prepare("UPDATE history_categories SET name='Guild Glory', keywords='guild,guild glory,guildglory' WHERE slug='guild-war' AND kind='purchase'")->execute();
    return $pdo->query("SELECT id,name,slug,keywords,kind,sort_order,enabled FROM history_categories WHERE enabled=1 ORDER BY sort_order,id")->fetchAll(PDO::FETCH_ASSOC);
}
function xt_history_slug(string $name): string {
    $slug = strtolower(trim($name));
    $slug = preg_replace('/[^a-z0-9]+/', '-', $slug);
    return trim((string)$slug, '-') ?: 'category';
}
function xt_history_classify_purchase(string $product, string $plan, array $categories): string {
    $hay = strtolower($product.' '.$plan);
    foreach ($categories as $cat) {
        if (($cat['kind'] ?? '') !== 'purchase' || empty($cat['keywords'])) continue;
        foreach (explode(',', (string)$cat['keywords']) as $keyword) {
            $keyword = trim(strtolower($keyword));
            if ($keyword !== '' && strpos($hay, $keyword) !== false) return (string)$cat['slug'];
        }
    }
    return 'other';
}
