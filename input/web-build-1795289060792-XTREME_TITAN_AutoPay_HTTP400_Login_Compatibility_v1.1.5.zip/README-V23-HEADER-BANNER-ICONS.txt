XTREME TITAN V23 — HEADER BANNER + ICON POLISH

Changes in this package:
- Increased the Profile page Wallet Balance icon while keeping the amount readable.
- Made the dashboard Active Key diamond icon slightly larger while preserving space for its label and count.
- Added an optional announcement/banner directly below the Store logo and title.
- Added Admin > Site Settings controls for banner image, optional notice text, and click-through URL.
- The click-through URL accepts any valid URL, including a YouTube channel or video. It opens in a new tab.
- Existing add-funds banner settings and other features remain unchanged.

Setup:
1. Back up the currently installed website files and database first.
2. Extract this ZIP and upload/replace the included website files, preserving the folder structure.
3. Open Admin Panel > Site Settings > Header announcement banner.
4. Upload a JPG, PNG, WebP or GIF banner; optionally enter a notice caption and destination URL.
5. Click SAVE ALL WEBSITE SETTINGS.

The banner is optional. If no image and no text are set, the Store header will not show it.
