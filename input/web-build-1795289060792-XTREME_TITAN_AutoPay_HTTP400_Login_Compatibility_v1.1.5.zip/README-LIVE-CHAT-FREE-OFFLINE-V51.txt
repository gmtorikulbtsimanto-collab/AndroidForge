XTREME TITAN OFFICIAL — Free Offline Live Chat Translation V51

Changes:
- Removed the Google Cloud Translation API key field from Admin > Live Messages.
- Removes any previously saved translation API key when saving popup settings.
- No paid translation API or external translation request is used.
- Added offline phrase translations for common support phrases in Bengali, English, Italian, Hindi, Nepali, Arabic, and Vietnamese.
- Admin conversation UI now renders the server-provided display_message field, so supported offline translations actually appear.
- User conversation UI now renders the server-provided display_message field, so supported offline translations actually appear.
- Existing private conversation, message polling, and popup timing settings remain in place.

Important limitation:
Offline phrasebooks cannot translate arbitrary free-form sentences. If a message does not match a phrase included in the local dictionary, it remains in its original language. Fully automatic translation of any message generally requires a translation engine/API or a separately hosted translation model.

Deploy by uploading the ZIP contents over the existing site after keeping a backup. Existing support messages/settings are retained; the old translation API key is removed the next time popup settings are saved.
