XTREME TITAN - Category Page Fix

Replace the existing topup.php file in your website root with the topup.php included in this ZIP.

Changes:
- Category buttons are removed from the Top-Up/category product page.
- Category selection remains on the main Store page (store.php).
- Opening store.php? category links (topup.php?category=slug) now filters products server-side by the exact category_slug.
- If a category has no active products, the page shows an empty-category message instead of showing products from another category.
- The Top-Up order form and payment/order processing code are retained.

Before replacing, keep a backup of your current topup.php.
PHP syntax check: passed.
