XTREME TITAN ADMIN PANEL PATCH

Scope: Admin panel only. User-facing storefront, login/register, Google OAuth, checkout/payment processing, and reseller storefront behavior were not intentionally changed.

Changes:
- Dashboard now counts pending key reset/replacement requests separately from pending deposits.
- Dashboard pending-actions card combines pending deposits and pending key requests, and request-related cards open the corresponding admin review page.
- Added a compact admin control shortcut strip for key requests, deposits, reseller account count, and site controls.
- Fixed mobile Site Settings layout: two-column forms collapse to one column on narrow screens, inputs/file inputs cannot force horizontal overflow, long asset paths wrap, and navigation can wrap.
- Kept the existing database and authentication logic; dashboard request count uses the existing key_reset_requests table helper.

Deployment:
1. Back up the current site files and database.
2. Upload/replace the archive contents in the same website root, preserving existing files as appropriate.
3. Open Admin Dashboard and Site Settings on mobile; verify pending counts against the request pages.
4. This patch has PHP syntax checks but has not been tested against the live hosting database.
