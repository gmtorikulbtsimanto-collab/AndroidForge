<?php
require_once __DIR__.'/config.php';
require_once __DIR__.'/uddoktapay-lib.php';
require_login();
$error='';
$checkoutMethod='bKash';
if($_SERVER['REQUEST_METHOD']==='POST'){
  try{
    if(!isset($_SESSION['uddokta_csrf']) || !hash_equals($_SESSION['uddokta_csrf'],(string)($_POST['csrf']??''))) throw new RuntimeException('Session expired. Refresh and try again.');
    $amountRaw=trim((string)($_POST['amount']??''));
    $chosenMethod=trim((string)($_POST['payment_method']??''));
    $checkoutMethod=$chosenMethod;
    if(!in_array($chosenMethod,['bKash','Nagad'],true)) throw new RuntimeException('Please select bKash or Nagad from the Deposit page.');
    $pendingCreated=(int)($_POST['pending_created']??0);
    $pendingSignature=(string)($_POST['pending_signature']??'');
    $uidForSignature=(int)($_SESSION['user_id']??0);
    $normalizedAmount=number_format((float)$amountRaw,2,'.','');
    $expectedSignature=hash_hmac('sha256',$uidForSignature.'|'.$chosenMethod.'|'.$normalizedAmount.'|'.$pendingCreated,DB_PASS);
    if($pendingCreated<1 || time()-$pendingCreated>900 || $pendingCreated>time()+60 || $uidForSignature<1 || $pendingSignature==='' || !hash_equals($expectedSignature,$pendingSignature)) throw new RuntimeException('Your payment session expired. Please return to Deposit and try again.');
    if($amountRaw==='' || !is_numeric($amountRaw) || (float)$amountRaw<10 || (float)$amountRaw>1000000) throw new RuntimeException('Enter an amount between ৳10 and ৳1,000,000.');
    $amount=number_format((float)$amountRaw,2,'.','');
    $pdo=db(); xt_uddokta_ensure_deposit_columns();
    $depositCols=$pdo->query('SHOW COLUMNS FROM deposits')->fetchAll(PDO::FETCH_COLUMN);
    if(!in_array('cancel_token',$depositCols,true)){try{$pdo->exec('ALTER TABLE deposits ADD COLUMN cancel_token CHAR(64) NULL');}catch(Throwable $ignore){}}
    $uid=(int)($_SESSION['user_id']??0); if($uid<1) throw new RuntimeException('Please sign in again.');
    $u=$pdo->prepare('SELECT name,email,country_code,role FROM users WHERE id=? LIMIT 1');
    $u->execute([$uid]); $user=$u->fetch(PDO::FETCH_ASSOC);
    if(!$user) throw new RuntimeException('User account not found.');
    $now=utc_sql_now();
    $ins=$pdo->prepare("INSERT INTO deposits (user_id,amount,status,payment_method,transaction_id,currency_code,amount_bdt,source_role,deposit_country,created_at) VALUES (?,?,'pending','UddoktaPay','PENDING','BDT',?,?,?,?)");
    $ins->execute([$uid,$amount,$amount,$user['role']??'user',$user['country_code']??'BD',$now]);
    $depositId=(int)$pdo->lastInsertId();
    // New automatic-payment deposits must appear in the admin notification centre.
    notify_admin('new_deposit','New Automatic Deposit Request','Deposit #'.$depositId.' · User #'.$uid.' · ৳'.number_format((float)$amount,2).' via UddoktaPay','deposits.php');
    // Keep the customer informed; the notification bell displays this with later status updates.
    require_once __DIR__.'/topup-lib.php';
    xt_user_notification_tables();
    xt_user_notify($uid,'deposit_pending','Deposit request received','Your automatic deposit request #'.$depositId.' for ৳'.number_format((float)$amount,2).' is waiting for payment verification.','history.php?tab=deposit');
    $cancelToken=bin2hex(random_bytes(32));
    $saveCancelToken=$pdo->prepare('UPDATE deposits SET cancel_token=? WHERE id=? AND user_id=?');
    $saveCancelToken->execute([$cancelToken,$depositId,$uid]);
    $host=(isset($_SERVER['HTTPS'])&&$_SERVER['HTTPS']!=='off'?'https':'http').'://'.($_SERVER['HTTP_HOST']??'');
    $scriptDir=rtrim(str_replace('\\','/',dirname($_SERVER['SCRIPT_NAME']??'/')),'/.');
    $root=$host.($scriptDir!==''?'/'.$scriptDir:'');
    // UddoktaPay returns payment_url on Create Charge; invoice_id arrives only at redirect_url.
    $redirect=$root.'/uddoktapay-return.php?deposit_id='.$depositId;
    $payload=[
      'full_name'=>(string)($user['name']?:'Customer'),
      'email'=>(string)($user['email']?:'customer@example.com'),
      'amount'=>$amount,
      'metadata'=>['user_id'=>(string)$uid,'deposit_id'=>(string)$depositId],
      'redirect_url'=>$redirect,
      'return_type'=>'GET',
      'cancel_url'=>$root.'/uddoktapay-cancel.php?deposit_id='.$depositId.'&token='.rawurlencode($cancelToken),
      'webhook_url'=>$root.'/uddoktapay-webhook.php'
    ];
    $res=xt_uddokta_api('checkout-v2',$payload);
    $payUrl=(string)($res['payment_url']??$res['data']['payment_url']??'');
    $createdInvoice=trim((string)($res['invoice_id']??$res['data']['invoice_id']??''));
    if($createdInvoice!=='' && strlen($createdInvoice)<=100){
      $saveInvoice=$pdo->prepare("UPDATE deposits SET uddoktapay_invoice_id=? WHERE id=? AND user_id=? AND (uddoktapay_invoice_id IS NULL OR uddoktapay_invoice_id='')");
      $saveInvoice->execute([$createdInvoice,$depositId,$uid]);
    }
    if(!filter_var($payUrl,FILTER_VALIDATE_URL) || stripos($payUrl,'https://')!==0) {
      throw new RuntimeException('The secure payment service did not return a checkout link. Please contact XTREME TITAN OFFICIAL support.');
    }
    unset($_SESSION['xt_paymently_pending']);
    header('Location: '.$payUrl,true,303); exit;
  }catch(Throwable $e){$error=$e->getMessage();}
}
if(empty($_SESSION['uddokta_csrf']))$_SESSION['uddokta_csrf']=bin2hex(random_bytes(32));
$cfg=xt_uddokta_config();
$pendingStart=$_SESSION['xt_paymently_pending']??null;
if(is_array($pendingStart) && isset($pendingStart['amount'])) $startAmount=(string)$pendingStart['amount']; else $startAmount='';
?><!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no"><title>Automatic Add Funds · XTREME TITAN</title><link rel="stylesheet" href="theme.php"><link rel="stylesheet" href="reference-theme.css"><link rel="stylesheet" href="site-polish.css"><link rel="stylesheet" href="premium-global.css"><style>
:root{color-scheme:dark}.up-wrap{width:min(560px,calc(100% - 28px));margin:clamp(24px,7vh,70px) auto;padding:0 0 34px;font-family:Inter,system-ui,-apple-system,Arial,sans-serif}
.up-card{position:relative;overflow:hidden;padding:clamp(22px,5vw,34px);border:1px solid rgba(39,208,255,.34);border-radius:28px;background:linear-gradient(145deg,rgba(13,29,49,.98),rgba(5,13,25,.98));color:#f5f9ff;box-shadow:0 24px 70px #0008, inset 0 1px 0 #ffffff12}
.up-card:before{content:"";position:absolute;inset:-120px -80px auto auto;width:260px;height:260px;border-radius:50%;background:radial-gradient(circle,#00d6ff2b,transparent 68%);pointer-events:none}
.up-brand{display:flex;align-items:center;gap:10px;color:#7eeaff;font-size:11px;font-weight:900;letter-spacing:.18em;text-transform:uppercase}
.up-mark{display:grid;place-items:center;width:38px;height:38px;border-radius:12px;background:linear-gradient(135deg,#00d6aa,#149dff);color:#03121e;font-size:19px;box-shadow:0 8px 24px #00c7db33}
.up-card h1{position:relative;margin:18px 0 10px;font-size:clamp(27px,7vw,38px);line-height:1.08;letter-spacing:-.04em;font-weight:950}
.up-sub{position:relative;margin:0;color:#b7c9dc;font-size:15px;line-height:1.65}
.up-secure{display:flex;align-items:center;gap:8px;margin:22px 0 18px;padding:11px 13px;border:1px solid #1b6a6b;background:#062c31a8;border-radius:13px;color:#a7f6e6;font-size:12px;font-weight:750}
.up-card label{display:block;margin:18px 0 8px;color:#e8f3ff;font-size:14px;font-weight:800}
.up-input{width:100%;box-sizing:border-box;padding:17px 16px;border-radius:15px;border:1px solid #28445e;background:#050f1d;color:#fff;font-size:18px;font-weight:750;outline:none;transition:.2s}
.up-input:focus{border-color:#00d7d1;box-shadow:0 0 0 4px #00d7d11b}
.up-hint{margin:8px 2px 0;color:#8299b3;font-size:11px}
.up-btn{width:100%;display:flex;align-items:center;justify-content:center;gap:10px;margin-top:20px;padding:17px 18px;border:0;border-radius:15px;background:linear-gradient(100deg,#00d0a7,#0eb5ed 58%,#258cff);color:#03111c;font-size:16px;font-weight:950;box-shadow:0 12px 28px #009fd733;cursor:pointer;transition:transform .18s,filter .18s}
.up-btn:hover{filter:brightness(1.08);transform:translateY(-1px)}.up-btn:active{transform:translateY(1px)}
.up-alert{position:relative;margin:18px 0 8px;padding:14px 15px;border-radius:14px;border:1px solid #b34a60;background:linear-gradient(135deg,#571d2b,#391927);color:#ffe8ee;font-size:13px;line-height:1.55;overflow-wrap:anywhere}
.up-alert:before{content:"!";display:inline-grid;place-items:center;width:20px;height:20px;margin-right:8px;border-radius:50%;background:#ffcad5;color:#5a1d2b;font-weight:950}
.up-back{display:inline-flex;align-items:center;gap:8px;margin-top:23px;color:#7edfff;font-weight:800;text-decoration:none}.up-back:hover{text-decoration:underline}
.up-foot{margin-top:22px;padding-top:16px;border-top:1px solid #1d3046;color:#7189a5;text-align:center;font-size:10px;letter-spacing:.04em}
@media(max-width:420px){.up-wrap{margin:20px auto}.up-card{border-radius:22px}.up-sub{font-size:14px}}
</style><script src="language-client.js?v=20261119-deposit-localize1" defer></script></head><body><main class="up-wrap"><section class="up-card">
<div class="up-brand"><span class="up-mark">↗</span> XTREME TITAN · SECURE CHECKOUT</div>
<h1 data-auto-button-label="1" data-original-button-label="Automatic Add Funds">Automatic Add Funds</h1>
<p class="up-sub" data-auto-button-label="1" data-original-button-label="Top up your wallet securely with XTREME TITAN OFFICIAL. Your balance is added only after the payment is verified directly with the payment server.">Top up your wallet securely with XTREME TITAN OFFICIAL. Your balance is added only after the payment is verified directly with the payment server.</p>
<div class="up-secure" data-auto-button-label="1" data-original-button-label="Secure server-side verification · BDT wallet deposits">✦ Secure server-side verification · BDT wallet deposits</div>
<?php if($error):?><div class="up-alert"><?=h($error)?></div><?php endif;?>
<?php if(!$cfg['enabled']):?><div class="up-alert">Automatic payment is currently unavailable. Please contact the administrator.</div><?php else:?>
<form method="post"><input type="hidden" name="csrf" value="<?=h($_SESSION['uddokta_csrf'])?>"><input type="hidden" name="payment_method" value="<?=h($checkoutMethod)?>">
<label for="amount" data-auto-button-label="1" data-original-button-label="Deposit amount">Deposit amount <span style="color:#7de5f5">(BDT)</span></label>
<input class="up-input" id="amount" name="amount" type="number" min="10" max="1000000" step="0.01" required inputmode="decimal" placeholder="Enter amount in BDT" value="<?=h($startAmount)?>" data-auto-button-label="1" data-original-button-label="Enter amount in BDT" data-translate-attribute="placeholder">
<div class="up-hint" data-auto-button-label="1" data-original-button-label="Minimum ৳10 · Maximum ৳1,000,000">Minimum ৳10 · Maximum ৳1,000,000</div>
<button class="up-btn" type="submit" data-auto-button-label="1" data-original-button-label="Proceed to Secure Payment">Proceed to Secure Payment <span aria-hidden="true">→</span></button>
</form><?php endif;?>
<a class="up-back" href="deposit.php" data-auto-button-label="1" data-original-button-label="Back to Add Funds">← Back to Add Funds</a>
<div class="up-foot">PAYMENT PROTECTED · XTREME TITAN OFFICIAL</div>
</section></main></body></html>
