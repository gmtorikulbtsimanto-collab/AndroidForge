<?php require __DIR__ . '/my-keys.php';
