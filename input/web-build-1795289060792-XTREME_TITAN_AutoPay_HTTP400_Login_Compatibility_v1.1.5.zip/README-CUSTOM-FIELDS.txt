XTREME TITAN — PER-PRODUCT CUSTOM ORDER FIELDS PATCH

Changed files:
- topup-lib.php
- admin/topup-products.php
- topup.php
- admin/topup-orders.php

What it does:
- Adds custom_fields_json to topup_products and topup_orders automatically.
- Admin can define per-product fields as JSON, with text or select type, required flag, and dropdown options.
- Checkout displays only the selected product's own fields.
- Submitted values are validated and saved with the order.
- Admin Top-Up Requests displays the submitted custom fields.

Example for Basic Bots:
[
  {"label":"Server Selection","type":"select","required":true,"options":["Bangladesh","Indonesia","MY / SG","MENA","Pakistan","Vietnam","Brazil"]},
  {"label":"Guild ID","type":"text","required":true}
]

For a Free Fire diamond product, define different fields such as Player UID and Server ID.
Leave Custom Order Fields empty if the product needs no user details.

Install:
1. Back up the four existing files and database.
2. Extract the ZIP preserving folder structure.
3. Replace files in their existing locations.
4. Open Admin > Top-Up Products, edit each product and enter its own Custom Order Fields JSON.
5. Save and test one low-value order.

Note:
- PHP syntax checks passed.
- Live hosting/database and payment checkout were not available for end-to-end testing.
- Existing products are not automatically assigned fields; configure each product in Admin.
