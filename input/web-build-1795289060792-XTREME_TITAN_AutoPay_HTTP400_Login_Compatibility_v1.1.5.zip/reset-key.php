<?php
require_once __DIR__.'/config.php';
require_login();
ensure_key_reset_tables();
$uid=(int)($_SESSION['user_id']??0);
if(empty($_SESSION['reset_key_csrf'])) $_SESSION['reset_key_csrf']=bin2hex(random_bytes(32));
$postedCsrf=(string)($_POST['csrf']??'');
if($postedCsrf===''||!hash_equals($_SESSION['reset_key_csrf'],$postedCsrf)){http_response_code(403);exit('Security verification failed. Please return to Profile and submit again.');}
$keyId=(int)($_POST['key_id']??0);
$device=!empty($_POST['request_device']);
$replace=!empty($_POST['request_replace']);
$msg='';$err='';
try{
 if(!$device&&!$replace) throw new RuntimeException('Select Device Reset, Reset with a New Key, or both.');
 $type=$device&&$replace?'both':($replace?'replace':'device');
 $pdo=db();
 $st=$pdo->prepare('SELECT id FROM user_keys WHERE id=? AND user_id=? LIMIT 1');$st->execute([$keyId,$uid]);
 if(!$st->fetch()) throw new RuntimeException('Invalid key selection.');
 $st=$pdo->prepare("SELECT id FROM key_reset_requests WHERE user_id=? AND key_id=? AND status='pending' LIMIT 1");$st->execute([$uid,$keyId]);
 if($st->fetch()) throw new RuntimeException('A reset request for this key is already pending.');
 $st=$pdo->prepare("INSERT INTO key_reset_requests(user_id,key_id,status,request_type,new_license_key,new_inventory_key_id,created_at) VALUES(?,?,?,?,?,?,?)");
 $st->execute([$uid,$keyId,'pending',$type,null,null,utc_sql_now()]);
 notify_admin('key_reset', 'New Key Reset Request', 'A customer submitted a ' . $type . ' reset request for key #' . $keyId . '.', 'reset-requests.php');
 $msg=$type==='both'?'Device reset and new-key request submitted. Admin approval is required.':($type==='replace'?'New-key request submitted. The admin will assign a replacement key after approval.':'Device reset request submitted. Countdown will stay unchanged after approval.');
}catch(Throwable $e){$err=$e->getMessage();}
?><!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no"><title>Reset Key</title><link rel="stylesheet" href="premium-global.css"><link rel="stylesheet" href="reference-theme.css"><link rel="stylesheet" href="responsive-lock.css?v=20260929-28">
<link rel="icon" type="image/png" sizes="48x48" href="/assets/pwa-icon-48.png">
<link rel="apple-touch-icon" sizes="180x180" href="/assets/pwa-icon-180.png">
<link rel="manifest" href="/pwa-manifest.json">
<meta name="apple-mobile-web-app-title" content="XTREME TITAN">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="mobile-web-app-capable" content="yes">
<meta name="theme-color" content="#080a14">
<script src="/admin/admin-action-progress.js?v=20261023-inline-progress25" defer></script>
</head><body><main style="max-width:520px;margin:auto;padding:30px 14px"><section class="panel" style="padding:22px"><h1>Reset Key</h1><?php if($msg):?><p style="color:#34d399;font-weight:900"><?=h($msg)?></p><?php endif;?><?php if($err):?><p style="color:#fb7185;font-weight:900"><?=h($err)?></p><?php endif;?><a class="submit" style="display:block;text-align:center;text-decoration:none;padding:14px;border-radius:12px" href="profile.php#reset-key">Back to Profile</a></section></main><script src="background-video.js?v=20261018-starfall2"></script></body></html>
