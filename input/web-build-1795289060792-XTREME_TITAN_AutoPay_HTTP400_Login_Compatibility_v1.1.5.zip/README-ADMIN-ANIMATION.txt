XTREME TITAN OFFICIAL — ADMIN ANIMATION SETTINGS

New Site Control fields:
- Animation type: Off / Small falling dots / Falling stars / Light particle rain
- Opacity slider: 0–100%
- Speed: 5–60 seconds (lower = faster)
- Particle size: 1–8 px
- Particle color picker

To use: Admin Panel > Site Settings > Global animation controls > Save All Website Settings.
For an animated logo, upload a GIF file under Logo & decoration > Main logo. Static PNG/JPG/WebP still work.

The settings are stored in the existing site_settings table; no manual SQL migration is needed because this code adds defaults using INSERT IGNORE.
The global animation is rendered through theme.php, so it appears on pages that include the global theme stylesheet. Pages that do not load theme.php will not show it unless their header is updated.
This package has only been syntax-checked; it has not been deployed or live-tested on the user's hosting.
