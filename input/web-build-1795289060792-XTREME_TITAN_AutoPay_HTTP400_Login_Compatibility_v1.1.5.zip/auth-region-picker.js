(function(){
  'use strict';
  const regions={
    BD:{name:'Bangladesh',flag:'🇧🇩',currency:'BDT',language:'bn',label:'বাংলা'},
    IN:{name:'India',flag:'🇮🇳',currency:'INR',language:'hi',label:'हिन्दी'},
    NP:{name:'Nepal',flag:'🇳🇵',currency:'NPR',language:'ne',label:'नेपाली'},
    BT:{name:'Bhutan',flag:'🇧🇹',currency:'BTN',language:'dz',label:'རྫོང་ཁ'},
    VN:{name:'Vietnam',flag:'🇻🇳',currency:'VND',language:'vi',label:'Tiếng Việt'},
    OT:{name:'Other Country',flag:'🌐',currency:'USD',language:'en',label:'English'}
  };
  const sel=document.getElementById('region');
  const loginRegion=document.getElementById('login_region');
  const trigger=document.getElementById('auth-region-trigger');
  const proxy=document.getElementById('google-region-proxy');
  const shell=proxy&&proxy.parentElement;
  if(!sel&&!loginRegion&&!proxy)return;
  let current='BD';
  let googleScriptLoading=false;
  let googlePromptPending=false;
  try { const saved=localStorage.getItem('xtreme_country'); if(regions[saved])current=saved; } catch(e){}
  if(sel&&regions[sel.value])current=sel.value;
  if(loginRegion)loginRegion.value=current;

  const modal=document.createElement('div');
  modal.className='auth-region-modal';
  modal.setAttribute('aria-hidden','true');
  modal.innerHTML='<div class="auth-region-backdrop" data-close="1"></div><section class="auth-region-dialog" role="dialog" aria-modal="true" aria-labelledby="auth-region-title"><header><h2 id="auth-region-title">🌍 Select Your Region</h2><button type="button" class="auth-region-close" aria-label="Close">×</button></header><p class="auth-region-hint">Choose your country before continuing. The website language and currency will follow this choice.</p><div class="auth-region-options"></div></section>';
  document.body.appendChild(modal);

  // A separate, compact second step containing Google's official rendered button.
  const googleModal=document.createElement('div');
  googleModal.className='auth-google-modal';
  googleModal.setAttribute('aria-hidden','true');
  googleModal.innerHTML='<div class="auth-google-backdrop" data-google-close="1"></div><section class="auth-google-dialog" role="dialog" aria-modal="true" aria-labelledby="auth-google-title"><header><h2 id="auth-google-title">Continue with Google</h2><button type="button" class="auth-google-close" aria-label="Close">×</button></header><p class="auth-google-selected"></p><div class="auth-google-official" id="auth-google-official"></div><p class="auth-google-note">Choose your Google account to continue securely.</p></section>';
  document.body.appendChild(googleModal);
  const options=modal.querySelector('.auth-region-options');
  Object.keys(regions).forEach(code=>{
    const r=regions[code],b=document.createElement('button');
    b.type='button';b.className='auth-region-option';b.dataset.region=code;
    b.innerHTML='<span class="auth-region-flag">'+r.flag+'</span><span class="auth-region-copy"><strong>'+r.name+'</strong><small>Currency: '+r.currency+' · '+r.label+'</small></span><span class="auth-region-code">'+(code==='OT'?'$':code)+'</span>';
    b.addEventListener('click',()=>choose(code)); options.appendChild(b);
  });
  function ensureGoogleScript(){
    if(window.google&&window.google.accounts&&window.google.accounts.id)return;
    if(googleScriptLoading)return;
    googleScriptLoading=true;
    const hl={BD:'bn',IN:'hi',NP:'ne',BT:'en',VN:'vi',OT:'en'}[current]||'en';
    const script=document.createElement('script');
    script.src='https://accounts.google.com/gsi/client?hl='+encodeURIComponent(hl);
    script.async=true;script.defer=true;
    script.onload=()=>{
      googleScriptLoading=false;
      if(googlePromptPending){googlePromptPending=false;openGoogleStep();}
    };
    script.onerror=()=>{
      googleScriptLoading=false;
      alert('Google sign-in could not load. Please check your connection and refresh.');
    };
    document.head.appendChild(script);
  }
  function open(){if(proxy){proxy.hidden=false;if(shell)shell.classList.remove('region-chosen');}modal.classList.add('open');modal.setAttribute('aria-hidden','false');document.body.classList.add('auth-region-lock');refresh();}
  function close(){modal.classList.remove('open');modal.setAttribute('aria-hidden','true');document.body.classList.remove('auth-region-lock');}
  function refresh(){modal.querySelectorAll('.auth-region-option').forEach(b=>b.classList.toggle('selected',b.dataset.region===current));const r=regions[current];const label=document.getElementById('auth-region-label');if(label)label.textContent='Selected: '+r.name+' · '+r.currency;}
  function openGoogleStep(){
    const r=regions[current];
    googleModal.querySelector('.auth-google-selected').textContent='Selected: '+r.name+' · '+r.currency;
    googleModal.classList.add('open');
    googleModal.setAttribute('aria-hidden','false');
    document.body.classList.add('auth-region-lock');
    const target=document.getElementById('auth-google-official');
    if(target && !target.dataset.rendered && window.google && window.google.accounts && window.google.accounts.id){
      try{
        const width=Math.max(220,Math.min(320,window.innerWidth-100));
        window.google.accounts.id.renderButton(target,{type:'standard',theme:'outline',size:'large',text:'continue_with',shape:'rectangular',logo_alignment:'left',width:width,locale:({BD:'bn',IN:'hi',NP:'ne',BT:'en',VN:'vi',OT:'en'}[current]||'en')});
        target.dataset.rendered='1';
      }catch(e){console.error('Could not render official Google button',e);}
    }
  }
  function closeGoogleStep(){
    googleModal.classList.remove('open');
    googleModal.setAttribute('aria-hidden','true');
    document.body.classList.remove('auth-region-lock');
  }
  function choose(code){
    current=regions[code]?code:'BD';const r=regions[current];
    try{localStorage.setItem('xtreme_country',current);localStorage.setItem('xtreme_currency',r.currency);localStorage.setItem('xtreme_language',r.language);}catch(e){}
    if(sel){sel.value=current;sel.dispatchEvent(new Event('change',{bubbles:true}));}
    if(loginRegion)loginRegion.value=current;
    document.documentElement.lang=r.language;
    window.dispatchEvent(new Event('xtreme-currency-change'));window.dispatchEvent(new Event('xtreme-language-change'));
    refresh();close();
    // Country selection automatically advances to a compact page with the
    // official Google button. One tap on that button opens Google's account chooser.
    if(proxy)proxy.hidden=false;
    if(shell)shell.classList.remove('region-chosen');
    ensureGoogleScript();
    if(window.google&&window.google.accounts&&window.google.accounts.id){openGoogleStep();}
    else {googlePromptPending=true;}
  }
  if(trigger)trigger.addEventListener('click',open);
  if(proxy)proxy.addEventListener('click',open);
  modal.querySelector('.auth-region-close').addEventListener('click',close);
  googleModal.querySelector('.auth-google-close').addEventListener('click',closeGoogleStep);
  googleModal.addEventListener('click',e=>{if(e.target&&e.target.dataset&&e.target.dataset.googleClose)closeGoogleStep();});
  modal.addEventListener('click',e=>{if(e.target&&e.target.dataset&&e.target.dataset.close)close();});
  document.addEventListener('keydown',e=>{if(e.key==='Escape'&&modal.classList.contains('open'))close();if(e.key==='Escape'&&googleModal.classList.contains('open'))closeGoogleStep();});
  if(proxy){proxy.hidden=false;if(shell)shell.classList.remove('region-chosen');}
  refresh();
  // Preload Google before the user chooses a country. Do not show a prompt until
  // the country has been selected.
  ensureGoogleScript();
})();
