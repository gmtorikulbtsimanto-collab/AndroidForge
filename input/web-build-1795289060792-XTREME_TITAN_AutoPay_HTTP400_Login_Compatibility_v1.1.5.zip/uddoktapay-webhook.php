<?php
require_once __DIR__.'/config.php';
require_once __DIR__.'/uddoktapay-lib.php';
header('Content-Type: application/json; charset=utf-8');
try {
    // The webhook is only a notification. A wallet credit is always gated by
    // a fresh server-to-server Verify Payment API response.
    $raw=file_get_contents('php://input');
    $data=json_decode($raw?:'{}',true);
    $invoice=trim((string)($data['invoice_id']??$data['data']['invoice_id']??$_POST['invoice_id']??''));
    if($invoice===''){http_response_code(400);echo json_encode(['ok'=>false,'message'=>'Missing invoice_id']);exit;}
    // The webhook can arrive before the customer's browser return. Attach the
    // invoice to the original deposit using checkout metadata when available.
    $meta=$data['metadata']??$data['data']['metadata']??[];
    if(!is_array($meta)) $meta=[];
    $depositId=(int)($meta['deposit_id']??$data['deposit_id']??$data['data']['deposit_id']??0);
    $userId=(int)($meta['user_id']??$data['user_id']??$data['data']['user_id']??0);
    if($depositId>0 && $userId>0){
      xt_uddokta_ensure_deposit_columns();
      $attach=db()->prepare("UPDATE deposits SET uddoktapay_invoice_id=? WHERE id=? AND user_id=? AND LOWER(payment_method)='uddoktapay' AND (uddoktapay_invoice_id IS NULL OR uddoktapay_invoice_id='' OR uddoktapay_invoice_id=?)");
      $attach->execute([$invoice,$depositId,$userId,$invoice]);
    }
    $done=xt_uddokta_complete_invoice($invoice);
    echo json_encode(['ok'=>$done,'message'=>$done?'Payment verified':'Payment is not completed or deposit is not matched']);
} catch(Throwable $e) {
    error_log('UddoktaPay webhook: '.$e->getMessage());
    http_response_code(500);
    echo json_encode(['ok'=>false,'message'=>'Verification failed']);
}
