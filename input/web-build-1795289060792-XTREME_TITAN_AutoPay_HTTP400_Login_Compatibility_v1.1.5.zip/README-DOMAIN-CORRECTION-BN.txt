XTREME TITAN OFFICIAL — DOMAIN CORRECTION

এই প্যাকেজে Android app-এর default API domain মূল সরবরাহকৃত Website ZIP-এর ডকুমেন্টেশন ও পুরোনো app source-এর সঙ্গে মিলিয়ে দেওয়া হয়েছে:
https://xtremetitanofficial.gamer.free/website-mobile-api

পরিবর্তন:
- MainActivity.java default API URL সংশোধন।
- PaymentSmsSyncWorker.java background sync default API URL সংশোধন।
- README-তে API URL নির্দেশনা একীভূত।

গুরুত্বপূর্ণ:
- এই পরিবর্তনটি সরবরাহকৃত Website ZIP-এর ভিতরের রেফারেন্সের ভিত্তিতে। Live domain/DNS এই পরিবেশ থেকে নিশ্চিত করা যায়নি।
- HTTP 400 যদি সঠিক domain-এও থাকে, Hosting-এর response/body এবং PHP/server log দেখে আলাদাভাবে সমাধান করতে হবে।
- AndroidForge-এ Build ও live admin login পরীক্ষা করা হয়নি।
- Website-এর config.php, database credentials বা অন্য live settings overwrite করবেন না।
