<?php
require_once __DIR__ . '/config.php';
require_login();
$id=(int)($_SESSION['user_id']??0); $error=''; $message='';
$u=['name'=>'User','password_hash'=>''];
try{$s=db()->prepare('SELECT name,password_hash FROM users WHERE id=? LIMIT 1');$s->execute([$id]);$row=$s->fetch(PDO::FETCH_ASSOC);if($row)$u=$row;}catch(Throwable $e){$error='Unable to load account.';}
if($_SERVER['REQUEST_METHOD']==='POST'){
 $current=(string)($_POST['current_password']??''); $new=(string)($_POST['new_password']??''); $confirm=(string)($_POST['confirm_password']??'');
 if(!password_verify($current,(string)$u['password_hash'])) $error='Current password is incorrect.';
 elseif(strlen($new)<8) $error='New password must be at least 8 characters.';
 elseif($new!==$confirm) $error='New passwords do not match.';
 else{try{$s=db()->prepare('UPDATE users SET password_hash=? WHERE id=?');$s->execute([password_hash($new,PASSWORD_DEFAULT),$id]);$message='Password changed successfully.';}catch(Throwable $e){$error='Could not change password.';}}
}
function h($v){return htmlspecialchars((string)$v,ENT_QUOTES,'UTF-8');}
$name=(string)($u['name']??'User');
?>
<!doctype html><html lang="en"><head>
<link rel="stylesheet" href="theme.php?v=20261022-lightfix3"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no"><title>Change Password — XTREME_TITAN_OFFICIAL SHOP</title>
<link rel="stylesheet" href="reference-theme.css"><link rel="stylesheet" href="site-polish.css?v=20261022-lightfix3">
<style>
body{min-height:100vh;background:#06101c;color:#eef4ff;font-family:Arial,sans-serif;padding-bottom:92px!important}.cp-wrap{max-width:520px;margin:auto;padding:22px 14px 30px}.cp-logo{display:block;width:52px;height:52px;margin:0 auto 12px;object-fit:contain}.cp-card{background:#0d1928;border:1px solid #26384e;border-radius:18px;padding:18px}.cp-card h1{font-size:30px;margin:0 0 7px;text-align:center}.cp-card .sub{text-align:center;color:#9aa9bf;font-size:13px;margin:0 0 18px}.cp-card label{display:block;font-size:12px;font-weight:900;margin:13px 0 7px}.cp-card input{width:100%;height:48px;padding:0 13px;border-radius:12px;border:1px solid #29415d;background:#071220;color:#fff;outline:none}.cp-card button{width:100%;margin-top:18px;height:48px;border:0;border-radius:13px;background:linear-gradient(135deg,#168bff,#12e58e);color:#06101c;font-weight:900}.cp-back{display:block;text-align:center;margin-top:13px;color:#9aa9bf;text-decoration:none;font-size:12px}.alert{padding:10px 12px;border-radius:11px;margin-bottom:10px;font-size:12px}.alert.error{background:#35151d;color:#ff9cab}.alert.success{background:#123622;color:#7dffad}
</style><script src="theme-client.js?v=20260928-19" defer></script><link rel="stylesheet" href="premium-global.css?v=20261022-lightfix3"><script src="currency-client.js?v=20261018-fx1" defer></script><script src="language-client.js?v=20261023-full-language-v50" defer></script><script src="preference-sync.js?v=20260928-20" defer></script><link rel="stylesheet" href="responsive-lock.css?v=20260929-28">

<link rel="icon" type="image/png" sizes="48x48" href="/assets/pwa-icon-48.png">
<link rel="apple-touch-icon" sizes="180x180" href="/assets/pwa-icon-180.png">
<link rel="manifest" href="/pwa-manifest.json">
<meta name="apple-mobile-web-app-title" content="XTREME TITAN">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="mobile-web-app-capable" content="yes">
<meta name="theme-color" content="#080a14">
<script src="/admin/admin-action-progress.js?v=20261023-inline-progress25" defer></script>

</head><body>
<header class="top"><div class="brand-with-logo"><img class="header-logo" src="assets/xtreme-titan-logo.jpg" alt="XTREME TITAN"><div class="brand-text">XTREME_TITAN_OFFICIAL SHOP</div></div></header>
<main class="cp-wrap"><section class="cp-card"><h1>Change Password</h1><p class="sub">Update your account password securely.</p>
<?php if($error):?><div class="alert error"><?=h($error)?></div><?php endif;?><?php if($message):?><div class="alert success"><?=h($message)?></div><?php endif;?>
<form method="post"><label>Current password</label><input name="current_password" type="password" autocomplete="current-password" required><label>New password</label><input name="new_password" type="password" minlength="8" autocomplete="new-password" required><label>Confirm new password</label><input name="confirm_password" type="password" minlength="8" autocomplete="new-password" required><button type="submit">Change Password</button></form><a class="cp-back" href="profile.php">← Back to Profile</a></section></main>
<nav class="nav"><a href="store.php" aria-label="Store"><span class="nav-ico nav-svg-icon"><img class="xt-nav-image" src="assets/nav-icons/store.png" alt="" aria-hidden="true"></span><span>Store</span></a><a href="my-keys.php" aria-label="My Keys"><span class="nav-ico nav-svg-icon"><img class="xt-nav-image" src="assets/nav-icons/keys.png" alt="" aria-hidden="true"></span><span>My Keys</span></a><a href="deposit.php" aria-label="Add Funds"><span class="nav-ico nav-svg-icon"><img class="xt-nav-image" src="assets/nav-icons/funds.png" alt="" aria-hidden="true"></span><span>Add Funds</span></a><a href="history.php" aria-label="History"><span class="nav-ico nav-svg-icon"><img class="xt-nav-image" src="assets/nav-icons/history.png" alt="" aria-hidden="true"></span><span>History</span></a><a href="profile.php" aria-label="Profile"><span class="nav-ico nav-svg-icon"><img class="xt-nav-image" src="assets/nav-icons/profile.png" alt="" aria-hidden="true"></span><span>Profile</span></a></nav>
<script src="background-video.js?v=20261018-starfall2"></script>
</body></html>
<link rel="stylesheet" href="assets/xtreme-bottom-nav.css?v=20261117-canonical-all-pages-v5">
