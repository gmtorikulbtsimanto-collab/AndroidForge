XTREME TITAN DASHBOARD V13

This update targets the main user dashboard panel rendered inside store.php, because dashboard.php redirects authenticated users to store.php.

Changes scoped to .store-dashboard only:
- distinct neon gradients and borders for the four dashboard statistic cards;
- premium gradient/border treatment for the balance card and Quick Access panel;
- matching icon sizing and visible icon artwork for My Keys, Add Funds, History, and Profile;
- unique green, blue, amber, and purple Quick Access button treatments.

Product listing cards and other account pages are not targeted by this final V13 style block. Existing purchase, balance, payment, and navigation logic is unchanged.
