XTREME TITAN V21 — Dashboard/Profile polish (based on the uploaded V19 ZIP)

Changes:
1. Dashboard Active Key stat uses the supplied purple diamond logo at assets/nav-icons/active-key-diamond.png.
2. Dashboard Quick Access buttons (My Keys, Add Funds, History, Profile) keep their premium styling but use lighter, less dark gradients.
3. Profile Wallet Balance displays the cyan wallet icon from assets/nav-icons/wallet-cyan-reference.png.

Updated files:
- store.php
- profile.php
- assets/nav-icons/active-key-diamond.png

PHP syntax check passed for store.php and profile.php. Please back up the live site before uploading and test the Dashboard/Profile pages after upload. Live hosting/browser rendering has not been verified here.
