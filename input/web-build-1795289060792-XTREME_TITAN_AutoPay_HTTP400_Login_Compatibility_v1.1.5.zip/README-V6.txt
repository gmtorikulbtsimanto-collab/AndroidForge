XTREME TITAN — HISTORY LABEL / STATUS TRANSLATION / TOP-UP CATEGORY STYLE PATCH

Files:
- history.php
- language-client.js
- store.php

Changes:
- History filter label is Key History instead of Key Purchases.
- Explicit Pending / Completed / Cancelled translations are supplied for supported locales.
  Bengali labels: অপেক্ষাধীন / সম্পূর্ণ / বাতিল.
- Gaming Top-Up category anchors receive premium card/button styling and no underlines.
- Existing five bottom navigation buttons are not modified.

Install:
1. Back up the website files and database.
2. Extract this ZIP.
3. Upload the three files to the same locations in the website root, replacing matching files.
4. Clear browser cache and test History and Store on a user account.

Important:
- This patch is based on the supplied V4 store/language files and V5 history file.
- It has not been tested against the live hosting database or payment provider.
