<?php
require_once __DIR__.'/config.php';
$depositId=(int)($_GET['deposit_id']??0);
$token=(string)($_GET['token']??'');
if($depositId>0 && preg_match('/^[a-f0-9]{64}$/i',$token)){
 try{
  if(is_file(__DIR__.'/uddoktapay-lib.php')){
   require_once __DIR__.'/uddoktapay-lib.php';
   if(function_exists('xt_uddokta_ensure_deposit_columns')) xt_uddokta_ensure_deposit_columns();
  }
  $pdo=db();
  $cols=$pdo->query('SHOW COLUMNS FROM deposits')->fetchAll(PDO::FETCH_COLUMN);
  if(!in_array('cancel_token',$cols,true)) $pdo->exec('ALTER TABLE deposits ADD COLUMN cancel_token CHAR(64) NULL');
  $st=$pdo->prepare("SELECT id,payment_method,status,uddoktapay_invoice_id,cancel_token FROM deposits WHERE id=? LIMIT 1");
  $st->execute([$depositId]);$dep=$st->fetch(PDO::FETCH_ASSOC);
  $valid=$dep && !empty($dep['cancel_token']) && hash_equals((string)$dep['cancel_token'],$token) && preg_match('/uddokta|paymently/i',(string)$dep['payment_method'])===1;
  if($valid && strtolower(trim((string)$dep['status']))==='pending'){
   // Verify with the provider first; a completed payment must never be overwritten as canceled.
   if(!empty($dep['uddoktapay_invoice_id']) && function_exists('xt_uddokta_complete_invoice')){
    try{xt_uddokta_complete_invoice((string)$dep['uddoktapay_invoice_id']);}catch(Throwable $verifyError){error_log('UddoktaPay cancel verification: '.$verifyError->getMessage());}
   }
   // Older databases used an ENUM without a cancelled value. Upgrade the status
   // column without deleting or rewriting any existing deposit records.
   $meta=$pdo->query("SHOW COLUMNS FROM deposits LIKE 'status'")->fetch(PDO::FETCH_ASSOC);
   $type=strtolower((string)($meta['Type']??''));
   if(str_starts_with($type,'enum(') && !str_contains($type,"'cancelled'")){
    $nullable=strtoupper((string)($meta['Null']??'NO'))==='YES'?'NULL':'NOT NULL';
    $default=array_key_exists('Default',$meta) && $meta['Default']!==null ? " DEFAULT '".str_replace("'","''",(string)$meta['Default'])."'" : '';
    $pdo->exec("ALTER TABLE deposits MODIFY status VARCHAR(20) $nullable$default");
   }
   // Mark the existing transaction as canceled. Never delete the deposit/history record.
   $set="status='cancelled'";
   if(in_array('user_cancelled_at',$cols,true)) $set.=", user_cancelled_at=UTC_TIMESTAMP()";
   $cancel=$pdo->prepare("UPDATE deposits SET $set WHERE id=? AND LOWER(status)='pending' AND cancel_token=?");
   $cancel->execute([$depositId,$token]);
   try{require_once __DIR__.'/topup-lib.php';xt_user_notification_tables();$u=$pdo->prepare('SELECT user_id FROM deposits WHERE id=? LIMIT 1');$u->execute([$depositId]);$owner=(int)$u->fetchColumn();xt_user_notify($owner,'deposit_cancelled','Deposit cancelled','Your automatic deposit #'.$depositId.' was cancelled. No wallet balance was added.','history.php?tab=deposit');}catch(Throwable $noticeError){error_log('UddoktaPay cancellation notification: '.$noticeError->getMessage());}
  }
 }catch(Throwable $e){error_log('UddoktaPay cancel callback: '.$e->getMessage());}
}
header('Location: history.php?notice=cancelled',true,303);
exit;
