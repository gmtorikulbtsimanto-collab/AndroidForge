XTREME TITAN OFFICIAL — VIDEO UPLOAD LIMIT

This package does NOT make InfinityFree accept 100 MB uploads. The host/PHP upload limits are applied before PHP code runs, so changing application code cannot raise the server's actual upload ceiling.

The admin video upload message now explains this and directs large videos to the existing Product Video URL field. Upload a video up to 100 MB to an external video host (for example an unlisted YouTube video or a direct MP4/WebM URL), then paste that link into Product Video URL. Keep Product Image as a separate upload.

For genuine 100 MB direct uploads, move to hosting that permits it and configure upload_max_filesize to at least 110M and post_max_size to at least 120M. Back up the live site before replacing files. This package has not been deployed to your live InfinityFree site.
