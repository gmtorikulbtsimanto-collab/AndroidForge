<?php
require_once __DIR__.'/../config.php';require_once __DIR__.'/../topup-lib.php';require_once __DIR__.'/../history-category-lib.php';
if(empty($_SESSION['admin_id'])&&empty($_SESSION['admin_logged_in'])){header('Location: login.php');exit;}
xt_topup_ensure_tables();xt_topup_sync_history_categories();$pdo=db();$allHistoryCats=xt_history_categories();$topupCats=array_values(array_filter($allHistoryCats,static function($c){return ($c['kind']??'')==='purchase';}));if(empty($_SESSION['tu_admin_csrf']))$_SESSION['tu_admin_csrf']=bin2hex(random_bytes(32));$csrf=$_SESSION['tu_admin_csrf'];$msg='';$err='';
if($_SERVER['REQUEST_METHOD']==='POST'){
 try{
  if(!hash_equals($csrf,(string)($_POST['csrf']??'')))throw new RuntimeException('Security check failed.');
  $act=$_POST['action']??'';
  if($act==='save'){
   $id=(int)($_POST['id']??0);$name=trim((string)($_POST['name']??''));$categoryId=(int)($_POST['category_id']??0);$catRow=null;foreach($topupCats as $candidate){if((int)$candidate['id']===$categoryId){$catRow=$candidate;break;}}if(!$catRow)throw new RuntimeException('Please select a valid active category in Admin > History Categories.');$cat=(string)$catRow['name'];$slug=(string)$catRow['slug'];$amount=trim((string)($_POST['amount_label']??''));$desc=trim((string)($_POST['description']??''));$price=(float)($_POST['price']??0);$min=max(1,(int)($_POST['min_qty']??1));$max=max($min,(int)($_POST['max_qty']??1));$sort=(int)($_POST['sort_order']??0);$status=isset($_POST['status'])?1:0;
   $fieldsRaw=trim((string)($_POST['custom_fields_json']??''));
   $customFields=[];
   if($fieldsRaw!==''){
    $decoded=json_decode($fieldsRaw,true);
    if(!is_array($decoded)||json_last_error()!==JSON_ERROR_NONE)throw new RuntimeException('Custom fields must be valid JSON.');
    if(count($decoded)>12)throw new RuntimeException('Maximum 12 custom fields per product.');
    foreach($decoded as $f){
     if(!is_array($f))throw new RuntimeException('Invalid custom field definition.');
     $label=trim((string)($f['label']??''));$type=(string)($f['type']??'text');$required=!empty($f['required']);if(preg_match('/server/i',$label))$type='select';
     if($label===''||mb_strlen($label)>60||!in_array($type,['text','select'],true))throw new RuntimeException('Each custom field needs a label and type text or select.');
     $clean=['label'=>$label,'type'=>$type,'required'=>$required];
     if($type==='select'){
      $opts=$f['options']??[];if(preg_match('/server/i',$label)&&(!$opts||!is_array($opts)))$opts=['Bangladesh','India','Indonesia','Pakistan','Brazil','Vietnam','MENA','MY / SG'];if(!is_array($opts))throw new RuntimeException('Dropdown options must be an array.');
      $opts=array_values(array_filter(array_map(static fn($v)=>trim((string)$v),$opts),static fn($v)=>$v!==''));
      if(count($opts)<1||count($opts)>50)throw new RuntimeException('Each dropdown needs 1–50 options.');
      $clean['options']=$opts;
     }
     $customFields[]=$clean;
    }
   }
   $fieldsJson=$customFields?json_encode($customFields,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES):null;

   if($name===''||$cat===''||$price<=0)throw new RuntimeException('Product name, category and a price greater than zero are required.');
   $image=null;
   if(!empty($_FILES['image']['name'])&&is_uploaded_file($_FILES['image']['tmp_name'])){
    $mime=(new finfo(FILEINFO_MIME_TYPE))->file($_FILES['image']['tmp_name']);$ext=['image/jpeg'=>'jpg','image/png'=>'png','image/webp'=>'webp','image/gif'=>'gif'][$mime]??'';
    if($ext==='')throw new RuntimeException('Only JPG, PNG, WEBP and GIF images are allowed.');
    if((int)$_FILES['image']['size']>5*1024*1024)throw new RuntimeException('Image must be 5 MB or smaller.');
    $dir=__DIR__.'/../uploads/topup-products';if(!is_dir($dir))mkdir($dir,0755,true);$file='topup_'.bin2hex(random_bytes(8)).'.'.$ext;
    if(!move_uploaded_file($_FILES['image']['tmp_name'],$dir.'/'.$file))throw new RuntimeException('Image upload failed.');$image='uploads/topup-products/'.$file;
   }
   if($id){$sql="UPDATE topup_products SET name=?,category_slug=?,category_name=?,description=?,amount_label=?,price=?,min_qty=?,max_qty=?,sort_order=?,status=?,custom_fields_json=?,updated_at=?";$args=[$name,$slug,$cat,$desc,$amount,$price,$min,$max,$sort,$status,$fieldsJson,utc_sql_now()];if($image){$sql.=",image_path=?";$args[]=$image;}$sql.=" WHERE id=?";$args[]=$id;$st=$pdo->prepare($sql);$st->execute($args);}
   else{$st=$pdo->prepare("INSERT INTO topup_products(name,category_slug,category_name,description,image_path,amount_label,price,min_qty,max_qty,sort_order,status,custom_fields_json) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)");$st->execute([$name,$slug,$cat,$desc,$image,$amount,$price,$min,$max,$sort,$status,$fieldsJson]);}
   if($status===1){
    $event=$id?'topup_product_updated':'topup_product_added';
    $title=$id?'Top-Up product updated':'New Top-Up product available';
    $body=$id?('The '.$name.' package has been updated. Open Gaming Top-Up to see the latest details.'):('A new '.$name.' package has been added in '.$cat.'. Open Gaming Top-Up to view it.');
    xt_user_notify_all($event,$title,$body,'topup.php?category='.rawurlencode($slug));
   }
   $msg='Top-up product saved.';
  }elseif($act==='delete'){
   $deleteId=(int)($_POST['id']??0);$find=$pdo->prepare('SELECT name FROM topup_products WHERE id=?');$find->execute([$deleteId]);$deletedName=(string)($find->fetchColumn()?:'');
   $st=$pdo->prepare('DELETE FROM topup_products WHERE id=?');$st->execute([$deleteId]);
   if($deletedName!=='')xt_user_notify_all('topup_product_removed','Top-Up product removed','The '.$deletedName.' package is no longer available.','topup.php');
   $msg='Product deleted.';
  }
 }catch(Throwable $e){$err=$e->getMessage();}
}
$edit=null;if(isset($_GET['edit'])){$st=$pdo->prepare('SELECT * FROM topup_products WHERE id=?');$st->execute([(int)$_GET['edit']]);$edit=$st->fetch(PDO::FETCH_ASSOC)?:null;}
$items=$pdo->query('SELECT * FROM topup_products ORDER BY sort_order,id DESC')->fetchAll(PDO::FETCH_ASSOC);
function te($v){return htmlspecialchars((string)$v,ENT_QUOTES,'UTF-8');}
?><!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no"><title>Top-Up Products · Admin</title><link rel="stylesheet" href="../theme.php"><link rel="stylesheet" href="../premium-global.css"><style>body{background:#080d1b;color:#eef4ff;font:14px Arial;margin:0;padding:18px}.wrap{max-width:980px;margin:auto}.panel{background:#111a2d;border:1px solid #30415f;border-radius:18px;padding:17px;margin:14px 0}.grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:10px}label{display:block;font-size:12px;color:#aebbd0;margin:9px 0 5px}input,textarea,select{width:100%;padding:11px;border-radius:10px;border:1px solid #344765;background:#080f20;color:white;box-sizing:border-box}button,.btn{display:inline-block;padding:10px 14px;border:0;border-radius:10px;background:linear-gradient(110deg,#09cbb2,#267dff);color:#03111d;font-weight:900;text-decoration:none;cursor:pointer}.muted{color:#93a5c1;font-size:12px}.item{display:flex;gap:12px;align-items:center;border-top:1px solid #263653;padding:12px 0}.item img{width:58px;height:58px;object-fit:contain;border-radius:10px;background:#0b1324}.danger{background:#70283a;color:#fff}.msg{padding:11px;background:#123c32;border-radius:10px}.err{background:#4b1d2a}@media(max-width:600px){.grid{grid-template-columns:1fr}}</style></head><body><main class="wrap"><a class="btn" href="dashboard.php">← Admin Dashboard</a><h1>Top-Up Product Manager</h1><p><a class="btn" href="history-categories.php">Manage Categories</a> <a class="btn" href="topup-orders.php">Top-Up Requests</a></p><p class="muted">Create and manage Diamond, Like, Weekly, Monthly, Guild Glory and future service packages.</p><?php if($msg):?><p class="msg"><?=te($msg)?></p><?php endif;?><?php if($err):?><p class="msg err"><?=te($err)?></p><?php endif;?>
<section class="panel"><h2><?= $edit?'Edit Product':'Add New Product'?></h2><form method="post" enctype="multipart/form-data"><input type="hidden" name="csrf" value="<?=te($csrf)?>"><input type="hidden" name="action" value="save"><input type="hidden" name="id" value="<?= (int)($edit['id']??0)?>"><div class="grid"><div><label>Product Name</label><input name="name" required value="<?=te($edit['name']??'')?>"></div><div><label>Gaming Top-Up Category</label><select name="category_id" required><option value="">Select a category</option><?php foreach($topupCats as $tc):?><option value="<?= (int)$tc['id']?>" <?=((string)($edit['category_slug']??'')===(string)$tc['slug'])?'selected':''?>><?=te($tc['name'])?></option><?php endforeach;?></select><small class="muted">Add or rename options in Admin → History Categories.</small></div><div><label>Amount / Package Label</label><input name="amount_label" placeholder="100 Diamonds / 1,000 Likes" value="<?=te($edit['amount_label']??'')?>"></div><div><label>Price (BDT)</label><input name="price" type="number" min="0.01" step="0.01" required value="<?=te($edit['price']??'')?>"></div><div><label>Product Logo / Image</label><input name="image" type="file" accept="image/png,image/jpeg,image/webp,image/gif"><?php if(!empty($edit['image_path'])):?><small class="muted">Current: <?=te($edit['image_path'])?></small><?php endif;?></div><div><label>Minimum Quantity</label><input name="min_qty" type="number" min="1" value="<?=te($edit['min_qty']??1)?>"></div><div><label>Maximum Quantity</label><input name="max_qty" type="number" min="1" value="<?=te($edit['max_qty']??1)?>"></div><div><label>Sort Order</label><input name="sort_order" type="number" value="<?=te($edit['sort_order']??0)?>"></div><div><label><input style="width:auto" type="checkbox" name="status" <?=(!isset($edit['status'])||(int)$edit['status']===1)?'checked':''?>> Active / Visible</label></div></div><label>Custom Order Fields (JSON)</label>
<textarea name="custom_fields_json" rows="8" placeholder='[{"label":"Server Selection","type":"select","required":true,"options":["Bangladesh","Indonesia","MY / SG","MENA","Pakistan","Vietnam","Brazil"]},{"label":"Guild ID","type":"text","required":true}]'><?=te($edit['custom_fields_json']??'')?></textarea>
<small class="muted">Each product can have different fields. Types: text or select. Example: Server Selection + Guild ID for Basic Bots; Player UID + Server ID for Diamond. Leave empty if no customer details are needed.</small>
<label>Description</label><textarea name="description" rows="3"><?=te($edit['description']??'')?></textarea><p><button type="submit">Save Product</button> <a class="btn" href="topup-products.php">New Product</a></p></form></section>
<section class="panel"><h2>Products (<?=count($items)?>)</h2><?php foreach($items as $it):?><div class="item"><?php if($it['image_path']):?><img src="../<?=te($it['image_path'])?>" alt=""><?php else:?><img src="../assets/brand-placeholder.svg" alt=""><?php endif;?><div style="flex:1"><b><?=te($it['name'])?></b><div class="muted"><?=te($it['category_name'])?> · <?=te($it['amount_label'])?> · ৳<?=number_format((float)$it['price'],2)?> · <?=((int)$it['status']?'Active':'Hidden')?></div></div><a class="btn" href="?edit=<?=(int)$it['id']?>">Edit</a><form method="post" onsubmit="return confirm('Delete this product?')"><input type="hidden" name="csrf" value="<?=te($csrf)?>"><input type="hidden" name="action" value="delete"><input type="hidden" name="id" value="<?=(int)$it['id']?>"><button class="danger">Delete</button></form></div><?php endforeach;?></section></main></body></html>
