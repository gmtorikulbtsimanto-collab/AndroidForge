(function(){
  if (window.__xtAdminProgressBound) return;
  window.__xtAdminProgressBound = true;
  var KEY='xt_admin_action_progress';
  var activeTimer=null;
  var activeNode=null;
  var activeButton=null;
  var activeLabel='Processing…';
  function lang(){try{return localStorage.getItem('xtreme_language')||'en';}catch(e){return 'en';}}
  function words(key){
    var l=lang();
    var d={
      en:{processing:'Processing…',purchase:'Processing purchase…',deleting:'Deleting…',uploading:'Uploading…',sending:'Sending…',updating:'Updating…',saving:'Saving…'},
      bn:{processing:'প্রক্রিয়াকরণ…',purchase:'কেনাকাটা চলছে…',deleting:'মুছে ফেলা হচ্ছে…',uploading:'আপলোড হচ্ছে…',sending:'পাঠানো হচ্ছে…',updating:'আপডেট হচ্ছে…',saving:'সেভ হচ্ছে…'},
      it:{processing:'Elaborazione…',purchase:'Acquisto in corso…',deleting:'Eliminazione…',uploading:'Caricamento…',sending:'Invio…',updating:'Aggiornamento…',saving:'Salvataggio…'},
      hi:{processing:'प्रक्रिया जारी…',purchase:'खरीद जारी…',deleting:'हटाया जा रहा है…',uploading:'अपलोड हो रहा है…',sending:'भेजा जा रहा है…',updating:'अपडेट हो रहा है…',saving:'सेव हो रहा है…'},
      vi:{processing:'Đang xử lý…',purchase:'Đang mua…',deleting:'Đang xóa…',uploading:'Đang tải lên…',sending:'Đang gửi…',updating:'Đang cập nhật…',saving:'Đang lưu…'},
      ne:{processing:'प्रक्रिया हुँदैछ…',purchase:'खरिद हुँदैछ…',deleting:'मेटिँदैछ…',uploading:'अपलोड हुँदैछ…',sending:'पठाइँदैछ…',updating:'अपडेट हुँदैछ…',saving:'सेभ हुँदैछ…'},
      dz:{processing:'ལས་སྦྱོར་བཞིན།…',purchase:'ཉོ་བཞིན།…',deleting:'བཏོན་བཞིན།…',uploading:'ཡར་བཙུགས་བཞིན།…',sending:'གཏང་བཞིན།…',updating:'བསྒྱུར་བཞིན།…',saving:'ཉར་བཞིན།…'}
    };
    return (d[l]||d.en)[key]||d.en[key];
  }
  function stop(){if(activeTimer){clearInterval(activeTimer);activeTimer=null;}}
  function removeNode(){if(activeNode&&activeNode.parentNode)activeNode.parentNode.removeChild(activeNode);activeNode=null;activeButton=null;}
  function makeInline(button){
    var span=document.createElement('span');span.className='xt-action-progress-inline';
    span.setAttribute('role','status');span.setAttribute('aria-live','polite');
    span.style.cssText='display:inline-flex;align-items:center;justify-content:center;margin-inline-start:7px;min-width:32px;font:800 12px/1.2 system-ui,sans-serif;color:#38bdf8;white-space:nowrap;vertical-align:middle;';
    span.textContent='1%';
    if(button&&button.parentNode){button.insertAdjacentElement('afterend',span);}
    else {span.style.margin='6px 0';(document.activeElement&&document.activeElement.parentNode||document.body).appendChild(span);}
    return span;
  }
  function buttonFor(form,ev){
    var b=ev.submitter;
    if(b&&form.contains(b))return b;
    return form.querySelector('button[type="submit"],input[type="submit"],button:not([type])')||null;
  }
  document.addEventListener('submit',function(ev){
    var f=ev.target;
    if(!(f instanceof HTMLFormElement)||ev.defaultPrevented||(f.method||'get').toLowerCase()!=='post')return;
    if(f.dataset.xtProgressBound==='1')return;
    f.dataset.xtProgressBound='1';
    var button=buttonFor(f,ev);
    var hasFile=Array.prototype.some.call(f.querySelectorAll('input[type="file"]'),function(i){return i.files&&i.files.length>0});
    var action=f.querySelector('[name="action"]');
    var isPurchase=!!(f.querySelector('[name="product_id"]')&&f.querySelector('[name="plan_id"]')&&f.querySelector('[name="quantity"]'));
    var actionName=action?String(action.value||'').toLowerCase():'';
    activeLabel=isPurchase?words('purchase'):(actionName.indexOf('delete')!==-1?words('deleting'):(hasFile||actionName.indexOf('upload')!==-1?words('uploading'):(actionName.indexOf('send')!==-1?words('sending'):(actionName.indexOf('edit')!==-1||actionName.indexOf('update')!==-1?words('updating'):words('saving')))));
    stop();removeNode();activeButton=button;activeNode=makeInline(button);
    if(button){button.setAttribute('aria-busy','true');}
    var n=1;activeNode.textContent=n+'%';
    try{sessionStorage.setItem(KEY,'1')}catch(e){}
    /* Inline numeric progress only. It advances while waiting and reaches 100% only after the server responds. */
    activeTimer=setInterval(function(){
      if(!activeNode||!activeNode.isConnected){stop();return;}
      if(n<99)n+=hasFile?(n<75?3:1):(n<70?7:(n<90?3:1));
      n=Math.min(99,n);activeNode.textContent=n+'%';activeNode.title=activeLabel;
    },hasFile?220:70);
  },true);
  window.addEventListener('pageshow',function(){
    try{sessionStorage.removeItem(KEY)}catch(e){}
    stop();
    if(activeNode){activeNode.textContent='100%';activeNode.style.color='#22c55e';}
    if(activeButton)activeButton.removeAttribute('aria-busy');
    setTimeout(removeNode,650);
  });
  // Navigation away is not proof the server action succeeded. Never mark 100% on pagehide.
  window.addEventListener('pagehide',function(){stop();});
})();
