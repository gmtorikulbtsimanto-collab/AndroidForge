<?php
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../vendor/autoload.php';
require_once __DIR__ . '/../admin-push-functions.php';
if (session_status() !== PHP_SESSION_ACTIVE) session_start();
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');
// Match the same Admin session checks used by notifications.php.
$isAdmin = !empty($_SESSION['admin_id']) || !empty($_SESSION['admin_logged_in']);
if (!$isAdmin) { http_response_code(401); echo json_encode(['ok'=>false,'error'=>'Admin login required']); exit; }
$pushAdminId = !empty($_SESSION['admin_id']) ? (int)$_SESSION['admin_id'] : null;
function push_reply(array $d,int $status=200): never { http_response_code($status); echo json_encode($d,JSON_UNESCAPED_UNICODE); exit; }
try {
  $action=(string)($_GET['action']??'');
  if ($action==='public-key' && $_SERVER['REQUEST_METHOD']==='GET') {
    push_reply(['ok'=>true,'publicKey'=>xt_admin_push_public_key()]);
  }
  if ($action==='subscribe' && $_SERVER['REQUEST_METHOD']==='POST') {
    if (empty($_SESSION['admin_push_csrf'])) $_SESSION['admin_push_csrf']=bin2hex(random_bytes(24));
    $csrf=(string)($_SERVER['HTTP_X_PUSH_CSRF']??'');
    if (!hash_equals($_SESSION['admin_push_csrf'],$csrf)) push_reply(['ok'=>false,'error'=>'Security check failed'],403);
    $data=json_decode(file_get_contents('php://input'),true);
    $sub=$data['subscription']??null;
    if (!is_array($sub) || empty($sub['endpoint']) || empty($sub['keys']['p256dh']) || empty($sub['keys']['auth'])) push_reply(['ok'=>false,'error'=>'Invalid subscription'],422);
    xt_admin_push_tables();
    $endpointHash = hash('sha256', (string)$sub['endpoint']);
    $find=db()->prepare("SELECT id FROM admin_push_subscriptions WHERE endpoint_hash=? LIMIT 1");
    $find->execute([$endpointHash]);
    $existing=$find->fetchColumn();
    if ($existing) {
      $st=db()->prepare("UPDATE admin_push_subscriptions SET admin_id=?,endpoint=?,endpoint_hash=?,p256dh=?,auth=?,updated_at=UTC_TIMESTAMP() WHERE id=?");
      $st->execute([$pushAdminId,$sub['endpoint'],$endpointHash,$sub['keys']['p256dh'],$sub['keys']['auth'],(int)$existing]);
    } else {
      $st=db()->prepare("INSERT INTO admin_push_subscriptions(admin_id,endpoint,endpoint_hash,p256dh,auth,created_at,updated_at) VALUES(?,?,?,?,?,UTC_TIMESTAMP(),UTC_TIMESTAMP())");
      $st->execute([$pushAdminId,$sub['endpoint'],$endpointHash,$sub['keys']['p256dh'],$sub['keys']['auth']]);
    }
    $test = xt_admin_send_push('XTREME TITAN Push Test', 'Push subscription saved successfully. Your admin notifications are connected.', 'dashboard.php');
    push_reply(['ok'=>true,'test'=>$test]);
  }
  if ($action==='csrf' && $_SERVER['REQUEST_METHOD']==='GET') {
    if (empty($_SESSION['admin_push_csrf'])) $_SESSION['admin_push_csrf']=bin2hex(random_bytes(24));
    push_reply(['ok'=>true,'csrf'=>$_SESSION['admin_push_csrf']]);
  }
  push_reply(['ok'=>false,'error'=>'Invalid action'],400);
} catch(Throwable $e) { error_log('Admin push endpoint: '.$e->getMessage()); push_reply(['ok'=>false,'error'=>'Push setup failed. Check PHP error log.'],500); }
