<?php
require_once __DIR__ . '/../config.php';
if (session_status() !== PHP_SESSION_ACTIVE) { @session_start(); }
if (empty($_SESSION['admin_id']) && empty($_SESSION['admin_logged_in'])) { header('Location: login.php'); exit; }
$pdo = db();
$rows = [];
$error = '';
try {
    $pdo->exec("CREATE TABLE IF NOT EXISTS admin_stock_alert_state (
        plan_id BIGINT UNSIGNED NOT NULL PRIMARY KEY,
        alerted TINYINT(1) NOT NULL DEFAULT 0,
        last_stock INT NOT NULL DEFAULT 0,
        updated_at DATETIME NOT NULL
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    // Reconcile state on every visit: a plan with stock again is re-armed for the next depletion.
    $pdo->exec("UPDATE admin_stock_alert_state s
        JOIN product_plans pp ON pp.id=s.plan_id
        SET s.alerted=0,s.last_stock=(SELECT COUNT(*) FROM user_keys uk WHERE uk.plan_id=pp.id AND uk.product_id=pp.product_id AND uk.user_id IS NULL),s.updated_at=UTC_TIMESTAMP()
        WHERE (SELECT COUNT(*) FROM user_keys uk WHERE uk.plan_id=pp.id AND uk.product_id=pp.product_id AND uk.user_id IS NULL)>0");
    $rows = $pdo->query("SELECT cp.id product_id, cp.name product_name, pp.id plan_id,
        COALESCE(NULLIF(pp.duration_label,''), CONCAT(ABS(pp.duration_days),' days')) plan_label,
        UPPER(COALESCE(pp.plan_type,'PRO')) plan_type,
        (SELECT COUNT(*) FROM user_keys uk WHERE uk.product_id=pp.product_id AND uk.plan_id=pp.id AND uk.user_id IS NULL) available_stock
        FROM product_plans pp JOIN catalog_products cp ON cp.id=pp.product_id
        WHERE cp.status=1 AND pp.status=1
        HAVING available_stock=0
        ORDER BY cp.name, pp.plan_type, pp.duration_seconds, pp.id")->fetchAll(PDO::FETCH_ASSOC);
} catch (Throwable $e) { $error = $e->getMessage(); }
function stock_h($v){ return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }
?><!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no"><title>Out of Stock — Admin</title>
<link rel="stylesheet" href="../theme.php"><link rel="stylesheet" href="admin-theme.css"><style>
body{margin:0;color:#eaf4ff;background:#07111f;font-family:Arial,sans-serif}.wrap{max-width:1100px;margin:auto;padding:22px 14px 70px}.head{display:flex;justify-content:space-between;align-items:center;gap:12px;flex-wrap:wrap}.back{color:#55dfff;text-decoration:none;font-weight:800}.summary{margin:16px 0;padding:17px;border:1px solid #29435d;border-radius:16px;background:#101f31}.count{font-size:30px;font-weight:900;color:#ff657d}.item{padding:16px;margin:12px 0;border:1px solid rgba(255,90,120,.35);border-radius:15px;background:#101d2d}.item strong{font-size:16px}.meta{display:flex;gap:8px;flex-wrap:wrap;margin-top:9px;color:#aebed0;font-size:13px}.tag{padding:5px 9px;border-radius:20px;background:#401d2a;color:#ff9cad;font-weight:800}.empty{padding:22px;border:1px solid #28533f;border-radius:15px;background:#102a24;color:#8df0bd}.err{padding:12px;background:#401d2a;color:#ffb3c0;border-radius:12px}
</style></head><body><main class="wrap"><header class="head"><div><h1>Out of Stock</h1><p>All active product plans with zero available keys</p></div><a class="back" href="dashboard.php">← Admin Dashboard</a></header>
<section class="summary"><div class="count"><?=count($rows)?></div><b>Plans currently out of stock</b></section>
<?php if($error):?><div class="err"><?=stock_h($error)?></div><?php elseif(!$rows):?><div class="empty">All active plans currently have available stock.</div><?php else: foreach($rows as $r):?><article class="item"><strong><?=stock_h($r['product_name'])?></strong><div class="meta"><span class="tag">OUT OF STOCK</span><span>Plan: <?=stock_h($r['plan_label'])?></span><span>Type: <?=stock_h($r['plan_type'])?></span><span>Product ID: <?= (int)$r['product_id']?></span><span>Plan ID: <?= (int)$r['plan_id']?></span><span>Available keys: 0</span></div></article><?php endforeach; endif;?>
</main></body></html>