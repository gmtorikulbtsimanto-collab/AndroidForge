<?php
require_once __DIR__.'/../config.php';
require_once __DIR__.'/../uddoktapay-lib.php';
if(empty($_SESSION['admin_id'])&&empty($_SESSION['admin_logged_in'])){header('Location: login.php');exit;}
if(empty($_SESSION['admin_uddokta_csrf']))$_SESSION['admin_uddokta_csrf']=bin2hex(random_bytes(32));
$success='';$error='';
if($_SERVER['REQUEST_METHOD']==='POST'){
 try {
  if(!hash_equals($_SESSION['admin_uddokta_csrf'],(string)($_POST['csrf']??''))) throw new RuntimeException('Security verification failed. Refresh and try again.');
  $base=rtrim(trim((string)($_POST['base_url']??'')),'/');
  if(!preg_match('~^https://[a-z0-9.-]+(?::\d+)?$~i',$base)) throw new RuntimeException('Enter the HTTPS base domain only, without /api.');
  $key=trim((string)($_POST['api_key']??''));$enabled=isset($_POST['enabled'])?1:0;
  xt_uddokta_settings_table();$pdo=db();
  if($key!==''){
   $enc=xt_uddokta_encrypt($key);
   $st=$pdo->prepare('UPDATE uddoktapay_settings SET base_url=?,api_key_enc=?,enabled=?,updated_at=UTC_TIMESTAMP() WHERE id=1');
   $st->execute([$base,$enc,$enabled]);
  } else {
   $st=$pdo->prepare('UPDATE uddoktapay_settings SET base_url=?,enabled=?,updated_at=UTC_TIMESTAMP() WHERE id=1');
   $st->execute([$base,$enabled]);
  }
  $success='UddoktaPay settings saved securely.';
 } catch(Throwable $e){$error=$e->getMessage();}
}
$cfg=xt_uddokta_config();
?><!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no"><title>UddoktaPay Settings · XTREME TITAN</title><meta name="viewport" content="width=device-width,initial-scale=1"><link rel="stylesheet" href="../theme.php"><link rel="stylesheet" href="../reference-theme.css"><link rel="stylesheet" href="../premium-global.css"><style>
*{box-sizing:border-box}body{font-family:Inter,system-ui,-apple-system,Arial,sans-serif;color:#eef7ff}.ud-wrap{width:min(760px,calc(100% - 28px));margin:28px auto 50px}.ud-top{display:flex;align-items:center;justify-content:space-between;gap:12px;margin-bottom:18px}.ud-back{color:#7fe5ff;text-decoration:none;font-weight:800}.ud-panel{position:relative;overflow:hidden;padding:clamp(20px,4vw,32px);border-radius:24px;border:1px solid #1d6077;background:linear-gradient(145deg,#0e2035f5,#071321f7);box-shadow:0 22px 60px #0007}.ud-kicker{color:#65dff3;font-size:10px;font-weight:950;letter-spacing:.18em}.ud-panel h1{margin:10px 0;font-size:clamp(25px,6vw,34px);letter-spacing:-.04em}.ud-desc{color:#aebfd2;line-height:1.6}.ud-status{display:flex;align-items:center;gap:9px;margin:20px 0;padding:12px 14px;border-radius:13px;background:#102b36;border:1px solid #1a6470;color:#b8fff0;font-size:12px;font-weight:800}.ud-dot{width:9px;height:9px;border-radius:50%;background:<?=$cfg['enabled']?'#39e69b':'#f5b84b'?>;box-shadow:0 0 14px currentColor}.ud-form label{display:block;margin:18px 0 8px;font-size:13px;font-weight:850}.ud-form input[type=text],.ud-form input[type=password]{width:100%;padding:15px;border:1px solid #294761;border-radius:13px;background:#061321;color:#fff;font-size:14px;outline:none}.ud-form input:focus{border-color:#16cfe6;box-shadow:0 0 0 4px #16cfe61a}.ud-help{display:block;margin-top:7px;color:#8199b2;font-size:11px;line-height:1.5}.ud-toggle{display:flex!important;align-items:center;gap:11px;padding:14px;margin-top:20px!important;border:1px solid #24445c;border-radius:13px;background:#0a1b2d}.ud-toggle input{width:19px;height:19px;accent-color:#00d3ad}.ud-save{width:100%;margin-top:20px;padding:16px;border:0;border-radius:14px;background:linear-gradient(100deg,#00d2a9,#16a8f4);color:#04121d;font-size:15px;font-weight:950}.ud-alert{padding:13px 15px;border-radius:13px;margin:15px 0;line-height:1.5;font-size:13px}.ud-ok{background:#103b32;border:1px solid #217e69;color:#b9ffea}.ud-err{background:#4a1d2b;border:1px solid #a6475e;color:#ffe4eb}.ud-api{margin-top:20px;padding:15px;border-radius:14px;background:#061321;border:1px solid #203a52;color:#b7c9dc;font-size:12px;line-height:1.8;overflow-wrap:anywhere}.ud-api code{color:#72e7ff}@media(max-width:500px){.ud-wrap{margin-top:15px}.ud-panel{border-radius:19px}}
</style></head><body><main class="ud-wrap"><div class="ud-top"><a class="ud-back" href="dashboard.php">← Admin Dashboard</a><span class="ud-kicker">PAYMENT CONTROL</span></div><section class="ud-panel"><div class="ud-kicker">XTREME TITAN · GATEWAY SETTINGS</div><h1>UddoktaPay Integration</h1><p class="ud-desc">Configure the secure API connection for automatic wallet deposits. Your API key is encrypted before it is stored and is never displayed again.</p>
<?php if($success):?><div class="ud-alert ud-ok"><?=h($success)?></div><?php endif;?>
<?php if($error):?><div class="ud-alert ud-err"><?=h($error)?></div><?php endif;?>
<div class="ud-status"><span class="ud-dot"></span><?= $cfg['enabled']?'Gateway enabled':'Gateway disabled' ?> · <?= $cfg['api_key']!==''?'API key saved':'API key not configured' ?></div>
<form class="ud-form" method="post"><input type="hidden" name="csrf" value="<?=h($_SESSION['admin_uddokta_csrf'])?>">
<label for="base_url">API Base URL</label><input id="base_url" type="text" name="base_url" value="<?=h($cfg['base_url']?:'https://xtremetitanofficial.paymently.io')?>" required><small class="ud-help">Use only your Paymently/UddoktaPay domain. Do not add /api or /checkout-v2.</small>
<label for="api_key">API Key</label><input id="api_key" type="password" name="api_key" autocomplete="new-password" placeholder="Paste your active API key"><small class="ud-help"><?= $cfg['api_key']!==''?'An API key is already saved. Leave this field blank to keep it unchanged.':'No API key saved yet.' ?> Required abilities: payment:checkout and payment:verify.</small>
<label class="ud-toggle"><input type="checkbox" name="enabled" value="1" <?= $cfg['enabled']?'checked':'' ?>><span>Enable automatic UddoktaPay deposits</span></label>
<button class="ud-save" type="submit">Save Gateway Settings</button></form>
<div class="ud-api"><b>API endpoints used</b><br><code>/api/checkout-v2</code> — create checkout<br><code>/api/verify-payment</code> — verify completed payment<br><br>Wallet credit is only issued after the server receives a verified <b>COMPLETED</b> payment status.</div></section></main></body></html>
