<?php
require_once __DIR__ . '/../config.php';
if (empty($_SESSION['admin_id']) && empty($_SESSION['admin_logged_in'])) { header('Location: login.php'); exit; }
$pdo=db();
$modules=[
 'reseller-websites'=>'Reseller Websites','ip-api'=>'IP Address & API Price Fix','panel-reset'=>'Panel Reset Management','transactions-audit'=>'Transactions & Audit','key-orders'=>'Key Orders','api-categories'=>'API Categories','api-providers'=>'API & Provider Settings','update-status'=>'Update Status','main-tutorial'=>'Main Tutorial','demo-videos'=>'Product Demo Videos','apk-notifications'=>'APK Notifications','apk-loaders'=>'APK Loaders Hub','google-login'=>'Manage Google Login','slider-banners'=>'Slider Banners'
];
$key=(string)($_GET['module']??'update-status'); if(!isset($modules[$key])){$key='update-status';}
$title=$modules[$key]; $msg='';$err='';
$pdo->exec("CREATE TABLE IF NOT EXISTS admin_module_records (id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,module_key VARCHAR(64) NOT NULL,title VARCHAR(190) NOT NULL,details TEXT NULL,target_url VARCHAR(1000) NULL,meta_value VARCHAR(255) NULL,status TINYINT(1) NOT NULL DEFAULT 1,created_at DATETIME NOT NULL,updated_at DATETIME NOT NULL,INDEX idx_module(module_key),INDEX idx_status(status)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
if(empty($_SESSION['module_center_csrf'])) $_SESSION['module_center_csrf']=bin2hex(random_bytes(32));$csrf=$_SESSION['module_center_csrf'];
if($_SERVER['REQUEST_METHOD']==='POST'){
 if(!hash_equals($csrf,(string)($_POST['csrf']??''))){$err='Security check failed. Refresh and try again.';}
 else try{
  $action=(string)($_POST['action']??'save');
  if($action==='delete'){$id=(int)($_POST['id']??0);$st=$pdo->prepare('DELETE FROM admin_module_records WHERE id=? AND module_key=?');$st->execute([$id,$key]);$msg='Record deleted.';}
  else {$id=(int)($_POST['id']??0);$t=trim((string)($_POST['title']??''));$d=trim((string)($_POST['details']??''));$u=trim((string)($_POST['target_url']??''));$m=trim((string)($_POST['meta_value']??''));$active=isset($_POST['status'])?1:0;
   if($t==='') throw new RuntimeException('Please enter a title.');
   if($u!=='' && !filter_var($u,FILTER_VALIDATE_URL)) throw new RuntimeException('URL must be a valid http/https URL.');
   if($id>0){$st=$pdo->prepare('UPDATE admin_module_records SET title=?,details=?,target_url=?,meta_value=?,status=?,updated_at=UTC_TIMESTAMP() WHERE id=? AND module_key=?');$st->execute([$t,$d,$u,$m,$active,$id,$key]);$msg='Record updated.';}
   else{$st=$pdo->prepare('INSERT INTO admin_module_records(module_key,title,details,target_url,meta_value,status,created_at,updated_at) VALUES(?,?,?,?,?,?,UTC_TIMESTAMP(),UTC_TIMESTAMP())');$st->execute([$key,$t,$d,$u,$m,$active]);$msg='Record added.';}
  }
 }catch(Throwable $e){$err=$e instanceof RuntimeException?$e->getMessage():'Could not save this record. Check database permissions and try again.';}
}
$edit=null;if(isset($_GET['edit'])){$st=$pdo->prepare('SELECT * FROM admin_module_records WHERE id=? AND module_key=?');$st->execute([(int)$_GET['edit'],$key]);$edit=$st->fetch()?:null;}
$st=$pdo->prepare('SELECT * FROM admin_module_records WHERE module_key=? ORDER BY id DESC');$st->execute([$key]);$rows=$st->fetchAll();
function mh($v){return htmlspecialchars((string)$v,ENT_QUOTES,'UTF-8');}
$descriptions=[
 'reseller-websites'=>'Keep reseller website domains, owner references and setup notes. Domain changes do not automatically configure DNS or hosting.',
 'ip-api'=>'Record provider IP whitelist requirements and API pricing rules. This page does not change server IP or call external providers.',
 'panel-reset'=>'Record authorized panel reset operations and related notes. It does not execute destructive server/database resets.',
 'transactions-audit'=>'Maintain audit references and notes. Financial transactions remain in the existing payment and purchase records.',
 'key-orders'=>'Keep order references and operational notes. Actual key sales remain in the existing purchase workflow.',
 'api-categories'=>'Create and maintain API category records for future provider mapping.',
 'api-providers'=>"Store provider setup references and integration notes. Live API calls require the provider's official API documentation and credentials.",
 'update-status'=>'Publish version numbers, release notes and update links.',
 'main-tutorial'=>'Manage tutorial titles, instructions and external video/article links.',
 'demo-videos'=>'Manage product demo video titles and URLs.',
 'apk-notifications'=>'Publish APK version and release notification records.',
 'apk-loaders'=>'Manage APK loader names, descriptions and download links.',
 'google-login'=>"Keep Google OAuth client configuration references. Actual sign-in behavior is controlled by the site's OAuth implementation and Google Console.",
 'slider-banners'=>'Manage banner titles, image URLs and destination links. Upload/media library integration is a separate step.'
];
?>
<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title><?=mh($title)?> — Admin</title><link rel="stylesheet" href="../theme.php"><link rel="stylesheet" href="admin-theme.css"><style>
*{box-sizing:border-box}body{margin:0;background:#050a13!important;color:#eff7ff!important;font-family:system-ui,Arial,sans-serif}.wrap{width:min(1050px,100%);margin:auto;padding:18px 13px 45px}.top,.card{background:linear-gradient(145deg,#0d1c2e,#07111f)!important;border:1px solid #17c9e633!important;border-radius:20px;padding:17px;margin-bottom:13px;box-shadow:0 16px 45px #0005}.top{display:flex;justify-content:space-between;align-items:center;gap:10px}.top h1{font-size:20px;margin:0}.muted{color:#91a4bb;font-size:12px;line-height:1.55}.btn,button{display:inline-block;border:1px solid #17d9ff55;background:linear-gradient(135deg,#12364b,#192747);color:#eafaff;padding:10px 13px;border-radius:11px;text-decoration:none;font-weight:800;font-size:11px;cursor:pointer}.field{display:grid;gap:6px;margin:12px 0}.field label{font-size:11px;color:#a9bfd4;font-weight:800}.field input,.field textarea{width:100%;padding:12px;border:1px solid #34516c;border-radius:11px;background:#06111f!important;color:#fff!important}.field textarea{min-height:90px;resize:vertical}.row{display:grid;grid-template-columns:1fr 1fr;gap:12px}.alert{padding:11px;border-radius:11px;margin:10px 0;font-size:12px;background:#113328;border:1px solid #20e6a055}.error{background:#391c27;border-color:#ff6c8b66}.records{display:grid;gap:9px}.record{padding:13px;border:1px solid #21415b;border-radius:14px;background:#091626}.record h3{font-size:13px;margin:0 0 6px}.record p{font-size:11px;color:#a5b7ca;white-space:pre-wrap;line-height:1.5}.record a{color:#24d7ff;font-size:11px;overflow-wrap:anywhere}.tag{font-size:9px;color:#20e6a0;border:1px solid #20e6a055;border-radius:20px;padding:4px 7px}.tools{display:flex;gap:7px;flex-wrap:wrap;margin-top:10px}.danger{border-color:#ff6c8b66;background:#351a28;color:#ffb3c1}.check{display:flex;align-items:center;gap:8px;color:#a9bfd4;font-size:11px}@media(max-width:650px){.row{grid-template-columns:1fr}.top h1{font-size:16px}.wrap{padding:10px}}
</style></head><body><main class="wrap">
<header class="top"><div><div class="muted">XTREME TITAN / ADMIN MODULE</div><h1><?=mh($title)?></h1><div class="muted">Manage records for this module</div></div><a class="btn" href="dashboard.php">← Dashboard</a></header>
<section class="card"><div class="muted"><?=mh($descriptions[$key]??'Manage module records.')?></div><?php if($msg):?><div class="alert"><?=mh($msg)?></div><?php endif;?><?php if($err):?><div class="alert error"><?=mh($err)?></div><?php endif;?>
<h2 style="font-size:15px;margin:18px 0 8px"><?=$edit?'Edit record':'Add new record'?></h2><form method="post"><input type="hidden" name="csrf" value="<?=mh($csrf)?>"><input type="hidden" name="id" value="<?=mh($edit['id']??0)?>"><input type="hidden" name="action" value="save">
<div class="field"><label>Title *</label><input name="title" maxlength="190" required value="<?=mh($edit['title']??'')?>" placeholder="Enter title"></div>
<div class="field"><label>Description / Details</label><textarea name="details" placeholder="Description, configuration notes or release details"><?=mh($edit['details']??'')?></textarea></div>
<div class="row"><div class="field"><label>Target URL (optional)</label><input type="url" name="target_url" value="<?=mh($edit['target_url']??'')?>" placeholder="https://example.com"></div><div class="field"><label>Version / Reference (optional)</label><input name="meta_value" maxlength="255" value="<?=mh($edit['meta_value']??'')?>" placeholder="Version, domain, provider ID..."></div></div>
<label class="check"><input type="checkbox" name="status" value="1" <?=!isset($edit['status'])||$edit['status']?'checked':''?>> Enabled / Published</label>
<div class="tools"><button type="submit"><?=$edit?'Save changes':'Add record'?></button><?php if($edit):?><a class="btn" href="module-center.php?module=<?=mh($key)?>">Cancel edit</a><?php endif;?></div></form></section>
<section class="card"><h2 style="font-size:15px;margin:0 0 12px">Saved records <span class="muted">(<?=count($rows)?>)</span></h2><?php if(!$rows):?><div class="muted">No records added yet.</div><?php else:?><div class="records"><?php foreach($rows as $r):?><article class="record"><div style="display:flex;justify-content:space-between;gap:8px;align-items:center"><h3><?=mh($r['title'])?></h3><span class="tag"><?=$r['status']?'ENABLED':'DISABLED'?></span></div><?php if($r['meta_value']):?><div class="muted"><?=mh($r['meta_value'])?></div><?php endif;?><?php if($r['details']):?><p><?=mh($r['details'])?></p><?php endif;?><?php if($r['target_url']):?><a href="<?=mh($r['target_url'])?>" target="_blank" rel="noopener noreferrer"><?=mh($r['target_url'])?></a><?php endif;?><div class="tools"><a class="btn" href="module-center.php?module=<?=mh($key)?>&edit=<?=$r['id']?>">Edit</a><form method="post" onsubmit="return confirm('Delete this record?')"><input type="hidden" name="csrf" value="<?=mh($csrf)?>"><input type="hidden" name="id" value="<?=$r['id']?>"><input type="hidden" name="action" value="delete"><button class="danger" type="submit">Delete</button></form></div></article><?php endforeach;?></div><?php endif;?></section>
</main></body></html>
