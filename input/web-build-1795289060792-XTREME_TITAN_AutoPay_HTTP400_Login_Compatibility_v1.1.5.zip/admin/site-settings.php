<?php
require_once __DIR__ . '/../config.php';
if (empty($_SESSION['admin_id']) && empty($_SESSION['admin_logged_in'])) { header('Location: login.php'); exit; }
$pdo = db();
$site = site_settings();
$message=''; $error='';
if (empty($_SESSION['site_settings_csrf'])) $_SESSION['site_settings_csrf']=bin2hex(random_bytes(32));
$csrf=$_SESSION['site_settings_csrf'];

function upload_site_asset(array $file, string $fallback=''): string {
    if (empty($file['name'])) return $fallback;
    if (($file['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK) throw new RuntimeException('Upload failed.');
    if ((int)($file['size'] ?? 0) > 40*1024*1024) throw new RuntimeException('Image/video/ZIP must be 40 MB or smaller.');
    $tmp=(string)($file['tmp_name'] ?? '');
    if ($tmp==='' || !is_uploaded_file($tmp)) throw new RuntimeException('Invalid uploaded file.');
    $orig=strtolower((string)($file['name']??''));
    $dir=dirname(__DIR__).'/uploads/site';
    if(!is_dir($dir) && !mkdir($dir,0755,true) && !is_dir($dir)) throw new RuntimeException('Could not create uploads/site folder.');
    if (str_ends_with($orig,'.zip')) {
        if (!class_exists('ZipArchive')) throw new RuntimeException('ZIP support is not enabled on this server. Upload MP4/WebM directly instead.');
        $zip=new ZipArchive();
        if($zip->open($tmp)!==true) throw new RuntimeException('The background ZIP could not be opened.');
        $allowed=['mp4'=>'mp4','webm'=>'webm','gif'=>'gif','jpg'=>'jpg','jpeg'=>'jpg','png'=>'png','webp'=>'webp'];
        $chosen='';
        for($i=0;$i<$zip->numFiles;$i++){
            $name=$zip->getNameIndex($i); if($name===false || str_ends_with($name,'/')) continue;
            $base=basename($name); $ext=strtolower(pathinfo($base,PATHINFO_EXTENSION));
            if(isset($allowed[$ext])) { $chosen=$name; if(in_array($ext,['mp4','webm'],true)) break; }
        }
        if($chosen===''){ $zip->close(); throw new RuntimeException('No supported background image/video was found inside the ZIP.'); }
        $ext=strtolower(pathinfo($chosen,PATHINFO_EXTENSION));
        $name='background_'.date('Ymd_His').'_'.bin2hex(random_bytes(4)).'.'.$allowed[$ext];
        $stream=$zip->getStream($chosen); if(!$stream){$zip->close();throw new RuntimeException('Could not read the background from the ZIP.');}
        $dest=$dir.'/'.$name; $out=fopen($dest,'wb'); if(!$out){fclose($stream);$zip->close();throw new RuntimeException('Could not create the background file.');}
        stream_copy_to_stream($stream,$out); fclose($stream); fclose($out); $zip->close();
        return 'uploads/site/'.$name;
    }
    $mime=function_exists('finfo_open') ? (function() use($tmp){$f=finfo_open(FILEINFO_MIME_TYPE);$m=$f?finfo_file($f,$tmp):'';if($f)finfo_close($f);return (string)$m;})() : (string)($file['type']??'');
    $allowed=['image/jpeg'=>'jpg','image/png'=>'png','image/webp'=>'webp','image/gif'=>'gif','video/mp4'=>'mp4','video/webm'=>'webm'];
    if(!isset($allowed[$mime])) throw new RuntimeException('Use JPG, PNG, WebP, GIF, MP4, WebM or a ZIP containing one of these.');
    $name='site_'.date('Ymd_His').'_'.bin2hex(random_bytes(4)).'.'.$allowed[$mime];
    $dest=$dir.'/'.$name;
    if(!move_uploaded_file($tmp,$dest)) throw new RuntimeException('Could not save uploaded file.');
    return 'uploads/site/'.$name;
}

function upload_site_music(array $file, string $fallback=''): string {
    if (empty($file['name'])) return $fallback;
    if (($file['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK) throw new RuntimeException('Music upload failed.');
    if ((int)($file['size'] ?? 0) > 20*1024*1024) throw new RuntimeException('Music file must be 20 MB or smaller.');
    $tmp=(string)($file['tmp_name'] ?? '');
    if ($tmp==='' || !is_uploaded_file($tmp)) throw new RuntimeException('Invalid music upload.');
    $mime=function_exists('finfo_open') ? (function() use($tmp){$f=finfo_open(FILEINFO_MIME_TYPE);$m=$f?finfo_file($f,$tmp):'';if($f)finfo_close($f);return (string)$m;})() : (string)($file['type']??'');
    $allowed=['audio/mp4'=>'m4a','audio/x-m4a'=>'m4a','audio/mpeg'=>'mp3','audio/wav'=>'wav','audio/x-wav'=>'wav','audio/ogg'=>'ogg','application/ogg'=>'ogg'];
    $ext=strtolower(pathinfo((string)$file['name'],PATHINFO_EXTENSION));
    if (!isset($allowed[$mime]) && !in_array($ext,['m4a','mp3','wav','ogg'],true)) throw new RuntimeException('Use M4A, MP3, WAV or OGG audio.');
    $ext=$allowed[$mime]??$ext;
    $dir=dirname(__DIR__).'/uploads/music';
    if(!is_dir($dir) && !mkdir($dir,0755,true) && !is_dir($dir)) throw new RuntimeException('Could not create uploads/music folder.');
    $name='site_music_'.date('Ymd_His').'_'.bin2hex(random_bytes(4)).'.'.$ext;
    if(!move_uploaded_file($tmp,$dir.'/'.$name)) throw new RuntimeException('Could not save music file.');
    return 'uploads/music/'.$name;
}

function valid_url_or_blank(string $v): bool { return $v==='' || filter_var($v,FILTER_VALIDATE_URL)!==false; }

if($_SERVER['REQUEST_METHOD']==='POST'){
    if(!isset($_POST['csrf']) || !hash_equals($csrf,(string)$_POST['csrf'])) $error='Security verification failed.';
    else {
        try{
            ensure_site_settings_table();
            $values=[
                'site_title'=>trim((string)($_POST['site_title']??'')),
                'site_subtitle'=>trim((string)($_POST['site_subtitle']??'')),
                'background_music_enabled'=>isset($_POST['background_music_enabled'])?'1':'0',
                'background_music_path'=>$site['background_music_path']??'uploads/music/xtreme-background.m4a',
                'payment_number'=>trim((string)($_POST['payment_number']??'')),
                'bkash_number'=>trim((string)($_POST['bkash_number']??'')),
                'nagad_number'=>trim((string)($_POST['nagad_number']??'')),
                'binance_pay_id'=>trim((string)($_POST['binance_pay_id']??$site['binance_pay_id']??'1224732977')),
                'payment_binance_logo'=>$site['payment_binance_logo']??'assets/binance-pay.svg',
                'payment_binance_qr'=>$site['payment_binance_qr']??'',
                'payment_notice_text'=>trim((string)($_POST['payment_notice_text']??'')),
                'bkash_payment_guide_image'=>$site['bkash_payment_guide_image']??'assets/bkash-payment-option-guide.jpg',
                'nagad_payment_guide_image'=>$site['nagad_payment_guide_image']??'',
                'paypal_me'=>trim((string)($_POST['paypal_me']??'')),
                'telegram_url'=>trim((string)($_POST['telegram_url']??'')),
                'discord_url'=>trim((string)($_POST['discord_url']??'')),
                'support_text'=>trim((string)($_POST['support_text']??'')),
                'footer_text'=>trim((string)($_POST['footer_text']??'')),
                'logo_path'=>$site['logo_path'],'background_path'=>$site['background_path'],'decor1_path'=>$site['decor1_path'],'decor2_path'=>$site['decor2_path'],
                'payment_bkash_logo'=>$site['payment_bkash_logo'],'payment_nagad_logo'=>$site['payment_nagad_logo'],'payment_paypal_logo'=>$site['payment_paypal_logo'],'add_funds_banner_path'=>$site['add_funds_banner_path'],'add_funds_banner_url'=>trim((string)($_POST['add_funds_banner_url']??$site['add_funds_banner_url'])),'header_banner_path'=>$site['header_banner_path'],'header_banner_url'=>trim((string)($_POST['header_banner_url']??$site['header_banner_url'])),'header_banner_text'=>trim((string)($_POST['header_banner_text']??$site['header_banner_text'])),
                'theme_default'=>trim((string)($_POST['theme_default']??'premium')),
                'wallet_title'=>trim((string)($_POST['wallet_title']??'My Wallet')),
                'wallet_text'=>trim((string)($_POST['wallet_text']??'Manage deposits & balance')),
                'theme_section_title'=>trim((string)($_POST['theme_section_title']??'Theme & Appearance')),
                'theme_primary'=>trim((string)($_POST['theme_primary']??'#16d9ff')),
                'theme_secondary'=>trim((string)($_POST['theme_secondary']??'#2685ff')),
                'theme_background'=>trim((string)($_POST['theme_background']??'#050b14')),
                'theme_panel'=>trim((string)($_POST['theme_panel']??'#0d1b2d')),
                'particle_mode'=>trim((string)($_POST['particle_mode']??'dots')),
                'particle_opacity'=>(string)max(0,min(100,(int)($_POST['particle_opacity']??55))),
                'particle_speed'=>(string)max(5,min(60,(int)($_POST['particle_speed']??18))),
                'particle_size'=>(string)max(1,min(8,(int)($_POST['particle_size']??3))),
                'particle_color'=>trim((string)($_POST['particle_color']??'#b8e7ff')),
                'telegram_title'=>trim((string)($_POST['telegram_title']??'Telegram Official Channel')),
                'telegram_text'=>trim((string)($_POST['telegram_text']??'Official announcements & updates')),
                'rules_url'=>trim((string)($_POST['rules_url']??'rules.php')),
                'rules_title'=>trim((string)($_POST['rules_title']??'Rules & Regulation')),
                'rules_text'=>trim((string)($_POST['rules_text']??'Terms of service & platform policies')),
                'rules_body'=>trim((string)($_POST['rules_body']??'')),
                'referral_title'=>trim((string)($_POST['referral_title']??'Referral Hub')),
                'referral_text'=>trim((string)($_POST['referral_text']??'Earn rewards & withdraw bonus')),
                'top_members_title'=>trim((string)($_POST['top_members_title']??'Top Members')),
                'top_members_text'=>trim((string)($_POST['top_members_text']??'Community leaderboard & rankings')),
                'password_title'=>trim((string)($_POST['password_title']??'Change Password')),
                'password_text'=>trim((string)($_POST['password_text']??'Security & credentials')),
                'logout_title'=>trim((string)($_POST['logout_title']??'Logout')),
                'logout_text'=>trim((string)($_POST['logout_text']??'Securely exit session')),
                'referral_rate'=>trim((string)($_POST['referral_rate']??'5'))
            ];
            foreach(['paypal_me','telegram_url','discord_url','add_funds_banner_url','header_banner_url'] as $k){ if(!valid_url_or_blank($values[$k])) throw new RuntimeException(strtoupper($k).' must be a valid URL.'); }
            if(!in_array($values['theme_default'],['black','obsidian','white','premium','luxury'],true)) $values['theme_default']='premium';
            if(!in_array($values['particle_mode'],['off','dots','stars','rain'],true)) $values['particle_mode']='dots';
            if(!preg_match('/^#[0-9a-fA-F]{6}$/',$values['particle_color'])) throw new RuntimeException('Animation color must be a 6-digit hex color.');
            foreach(['theme_primary','theme_secondary','theme_background','theme_panel'] as $k){ if(!preg_match('/^#[0-9a-fA-F]{6}$/',$values[$k])) throw new RuntimeException('Theme colors must be 6-digit hex colors.'); }
            if(!is_numeric($values['referral_rate']) || (float)$values['referral_rate']<0 || (float)$values['referral_rate']>100) throw new RuntimeException('Referral rate must be between 0 and 100.');
            if (!empty($_FILES['header_banner']['name'])) {
                $bannerTmp=(string)($_FILES['header_banner']['tmp_name']??'');
                $bannerMime='';
                if ($bannerTmp!=='' && function_exists('finfo_open')) { $fi=finfo_open(FILEINFO_MIME_TYPE); if($fi){$bannerMime=(string)finfo_file($fi,$bannerTmp);finfo_close($fi);} }
                if (!in_array($bannerMime,['image/jpeg','image/png','image/webp','image/gif'],true)) throw new RuntimeException('Header banner must be a JPG, PNG, WebP or GIF image.');
            }
            foreach(['logo'=>'logo_path','background'=>'background_path','decor1'=>'decor1_path','decor2'=>'decor2_path','payment_bkash_logo'=>'payment_bkash_logo','payment_nagad_logo'=>'payment_nagad_logo','payment_paypal_logo'=>'payment_paypal_logo','payment_binance_logo'=>'payment_binance_logo','payment_binance_qr'=>'payment_binance_qr','bkash_payment_guide_image'=>'bkash_payment_guide_image','nagad_payment_guide_image'=>'nagad_payment_guide_image','add_funds_banner'=>'add_funds_banner_path','header_banner'=>'header_banner_path'] as $field=>$key){
                if(isset($_FILES[$field])) $values[$key]=upload_site_asset($_FILES[$field],$values[$key]);
            }
            if(isset($_FILES['background_music'])) $values['background_music_path']=upload_site_music($_FILES['background_music'],$values['background_music_path']);
            $stmt=$pdo->prepare('INSERT INTO site_settings(setting_key,setting_value) VALUES(?,?) ON DUPLICATE KEY UPDATE setting_value=VALUES(setting_value)');
            foreach($values as $k=>$v) $stmt->execute([$k,$v]);
            $message='Site settings saved successfully. The changes are live on the website.';
            $site=site_settings();
        }catch(Throwable $e){$error=$e->getMessage();}
    }
}
function ah($v){return htmlspecialchars((string)$v,ENT_QUOTES,'UTF-8');}
?>
<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no"><title>Site Settings — XTREME_TITAN_OFFICIAL SHOP</title><link rel="stylesheet" href="../theme.php?v=20260929-27"><link rel="stylesheet" href="admin-theme.css"><style>
.wrap{width:min(920px,100%);margin:auto;padding:16px 12px 50px}.top{display:flex;align-items:center;justify-content:space-between;gap:10px;padding:13px 15px;margin-bottom:12px;border:1px solid rgba(16,216,255,.2);border-radius:18px;background:rgba(3,10,18,.78)}.brand{font-weight:1000}.muted{color:#91a2b8;font-size:12px}.card{padding:18px;border-radius:18px;margin-bottom:12px}.grid{display:grid;grid-template-columns:1fr 1fr;gap:12px}label{display:block;font-size:11px;font-weight:900;color:#b8c6d8;margin:0 0 6px}input,textarea{width:100%;padding:12px;border-radius:11px;border:1px solid #293c53;background:#071220;color:#fff}textarea{min-height:90px;resize:vertical}.field{margin-bottom:12px}.save{width:100%;padding:13px;border:0;border-radius:11px;background:#63ff16;color:#06101c;font-weight:1000;cursor:pointer}.file-note{font-size:10px;color:#71839a;margin-top:5px}.preview{display:flex;align-items:center;gap:10px;margin-top:8px}.preview img{width:58px;height:58px;object-fit:cover;border-radius:12px;background:#081321}.alert{padding:11px;border-radius:11px;margin-bottom:12px;font-size:12px}.success{background:#12331f;color:#a9ffbe;border:1px solid #1f6a36}.error{background:#3b1c24;color:#ff9aaa;border:1px solid #6b2b38}.links{display:flex;gap:8px;flex-wrap:wrap}.links a{color:#10d8ff;font-weight:900;text-decoration:none}@media(max-width:700px){.grid{grid-template-columns:minmax(0,1fr)}.wrap{width:100%;max-width:100%;padding:10px 10px 32px}.top{align-items:flex-start;flex-wrap:wrap;min-width:0}.top>div:first-child{min-width:0;max-width:100%}.links{width:100%;gap:12px}.card{padding:14px;min-width:0}.field{min-width:0;width:100%}}
/* Admin site-settings layout repair: prevent fields/cards from extending beyond mobile viewport. */
*,*::before,*::after{box-sizing:border-box}.wrap,.top,.card,.grid,.field{min-width:0;max-width:100%}.grid{grid-template-columns:repeat(2,minmax(0,1fr));align-items:start}.field input:not([type=range]):not([type=color]),.field select,.field textarea{display:block;width:100%;min-width:0;max-width:100%;box-sizing:border-box}.field input[type=file]{display:block;width:100%;min-width:0;max-width:100%;font-size:13px;overflow:hidden}.file-note{overflow-wrap:anywhere;word-break:break-word;line-height:1.5}.preview{min-width:0;flex-wrap:wrap}.preview span{min-width:0;overflow-wrap:anywhere}.preview img{flex:0 0 58px}.save{min-height:48px;line-height:1.35;white-space:normal}.links a{display:inline-block;padding:7px 0}@media(max-width:700px){.grid{grid-template-columns:minmax(0,1fr)}.wrap{padding-top:10px}.top{gap:12px}.brand{overflow-wrap:anywhere}.card h2{font-size:20px;line-height:1.25}.field input,.field select,.field textarea{font-size:16px!important}.save{font-size:15px!important}}
</style><script src="admin-background.js?v=20260929-27" defer></script><link rel="stylesheet" href="../responsive-lock.css?v=20260929-28">
<script src="admin-action-progress.js?v=20261023-inline-progress25" defer></script>
<link rel="icon" type="image/png" sizes="48x48" href="/assets/pwa-icon-48.png">
<link rel="apple-touch-icon" sizes="180x180" href="/assets/pwa-icon-180.png">
<link rel="manifest" href="/admin/admin-manifest.json">
<meta name="apple-mobile-web-app-title" content="XTREME TITAN">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="mobile-web-app-capable" content="yes">
<meta name="theme-color" content="#080a14">
<script src="admin-action-progress.js?v=20261023-inline-progress25" defer></script>
</head><body><div class="admin-panel-logo"><img src="../assets/xtreme-titan-logo.jpg" alt="XTREME TITAN"></div><main class="wrap">
<header class="top"><div><div class="brand">SITE CONTROL / ADMIN</div><div class="muted">Change branding, decorations, payment/support information from one place.</div></div><div class="links"><a href="dashboard.php">Dashboard</a><a href="products.php">Products</a><a href="logout.php">Logout</a></div></header>
<?php if($message):?><div class="alert success"><?=ah($message)?></div><?php endif;?><?php if($error):?><div class="alert error"><?=ah($error)?></div><?php endif;?>
<form method="post" enctype="multipart/form-data"><input type="hidden" name="csrf" value="<?=ah($csrf)?>">
<section class="card"><h2>Website text</h2><div class="grid"><div class="field"><label>Site title</label><input name="site_title" value="<?=ah($site['site_title'])?>" required></div><div class="field"><label>Homepage subtitle</label><input name="site_subtitle" value="<?=ah($site['site_subtitle'])?>"></div><div class="field"><label>Footer text</label><input name="footer_text" value="<?=ah($site['footer_text'])?>"></div><div class="field"><label>Support text</label><input name="support_text" value="<?=ah($site['support_text'])?>"></div></div></section>
<section class="card"><h2>Background Music</h2><div class="grid">
<div class="field"><label><input type="checkbox" name="background_music_enabled" value="1" <?=(!empty($site['background_music_enabled']) && $site['background_music_enabled']==='1')?'checked':''?>> Enable website background music</label><div class="file-note">Music starts automatically when the browser permits it. iPhone/Safari may require the visitor's first tap.</div></div>
<div class="field"><label>Replace music (M4A / MP3 / WAV / OGG, max 20 MB)</label><input type="file" name="background_music" accept=".m4a,.mp3,.wav,.ogg,audio/*"><div class="file-note">Current: <?=ah($site['background_music_path']??'')?></div></div>
</div></section>
<section class="card"><h2>Logo & decoration</h2><div class="grid">
<div class="field"><label>Main logo</label><input type="file" name="logo" accept="image/jpeg,image/png,image/webp,image/gif"><div class="file-note">Current: <?=ah($site['logo_path'])?></div><div class="preview"><img src="../<?=ah($site['logo_path'])?>" alt=""><span>Upload a new logo to replace it.</span></div></div>
<div class="field"><label>Background</label><input type="file" name="background" accept="image/jpeg,image/png,image/webp,image/gif,video/mp4,video/webm,.zip"><div class="file-note">Current: <?=ah($site['background_path'])?></div></div>
<div class="field"><label>Decoration image 1</label><input type="file" name="decor1" accept="image/jpeg,image/png,image/webp,image/gif"><div class="file-note">Current: <?=ah($site['decor1_path'])?></div><div class="preview"><img src="../<?=ah($site['decor1_path'])?>" alt=""></div></div>
<div class="field"><label>Decoration image 2</label><input type="file" name="decor2" accept="image/jpeg,image/png,image/webp,image/gif"><div class="file-note">Current: <?=ah($site['decor2_path'])?></div><div class="preview"><img src="../<?=ah($site['decor2_path'])?>" alt=""></div></div>
</div></section>
<section class="card"><h2>Global animation controls</h2><p class="muted">Controls the small falling dots/stars on public pages, including login and registration when they load the global theme CSS. Upload a GIF in Main logo if you want an animated logo.</p><div class="grid"><div class="field"><label>Animation type</label><select name="particle_mode"><option value="off" <?=($site['particle_mode']==='off'?'selected':'')?>>Off</option><option value="dots" <?=($site['particle_mode']==='dots'?'selected':'')?>>Small falling dots</option><option value="stars" <?=($site['particle_mode']==='stars'?'selected':'')?>>Falling stars</option><option value="rain" <?=($site['particle_mode']==='rain'?'selected':'')?>>Light particle rain</option></select></div><div class="field"><label>Opacity: <span id="particle-opacity-value"><?=ah($site['particle_opacity'])?>%</span></label><input type="range" min="0" max="100" name="particle_opacity" value="<?=ah($site['particle_opacity'])?>" oninput="document.getElementById('particle-opacity-value').textContent=this.value+'%'" /></div><div class="field"><label>Speed (seconds; lower is faster)</label><input type="number" min="5" max="60" name="particle_speed" value="<?=ah($site['particle_speed'])?>"></div><div class="field"><label>Particle size (1–8 px)</label><input type="number" min="1" max="8" name="particle_size" value="<?=ah($site['particle_size'])?>"></div><div class="field"><label>Particle color</label><input type="color" name="particle_color" value="<?=ah($site['particle_color'])?>"></div></div></section>

<section class="card"><h2>Payments & support</h2><div class="grid"><div class="field"><label>bKash number</label><input name="bkash_number" value="<?=ah($site['bkash_number'])?>"></div><div class="field"><label>Nagad number</label><input name="nagad_number" value="<?=ah($site['nagad_number'])?>"></div><div class="field"><label>Binance Pay UID</label><input name="binance_pay_id" inputmode="numeric" value="<?=ah($site['binance_pay_id']??'1224732977')?>"><div class="file-note">This UID is shown to users for Binance Pay deposits. You can change it here anytime.</div></div><div class="field" style="grid-column:1/-1"><label>Add Funds payment notice (shown above currency for BDT)</label><textarea name="payment_notice_text" rows="4" maxlength="1200" placeholder="Example: bKash/Nagad-এ শুধু Send Money করুন। Cash Out বা Mobile Recharge করবেন না."><?=ah($site['payment_notice_text'])?></textarea><div class="file-note">এই লেখাটি BDT নির্বাচন করলে Add Funds পেজের একেবারে উপরে দেখাবে। ফাঁকা রাখলে নোটিশটি লুকানো থাকবে। চাইলে বাংলা/English দুটোই লিখতে পারবেন।</div></div><div class="field"><label>PayPal.Me URL</label><input type="url" name="paypal_me" value="<?=ah($site['paypal_me'])?>"></div><div class="field"><label>Telegram URL</label><input type="url" name="telegram_url" value="<?=ah($site['telegram_url'])?>"></div><div class="field"><label>Discord URL</label><input type="url" name="discord_url" value="<?=ah($site['discord_url'])?>"></div></div></section>
<section class="card"><h2>Header announcement banner</h2><p class="muted">This banner appears directly below the shop logo and title on the Store dashboard. Upload an image, add an optional notice caption, and enter any destination URL (for example a YouTube channel or video). Tapping the banner opens the link in a new tab.</p><div class="grid"><div class="field"><label>Header banner image</label><input type="file" name="header_banner" accept="image/jpeg,image/png,image/webp,image/gif"><div class="file-note">Current: <?=ah($site['header_banner_path'])?></div><?php if(!empty($site['header_banner_path'])):?><div class="preview"><img src="../<?=ah($site['header_banner_path'])?>" alt="Header banner preview"></div><?php endif;?></div><div class="field"><label>Banner click-through URL</label><input type="url" name="header_banner_url" placeholder="https://youtube.com/@yourchannel" value="<?=ah($site['header_banner_url'])?>"><div class="file-note">Leave blank if the banner should not open a link.</div><label style="margin-top:12px">Notice text (optional)</label><input name="header_banner_text" maxlength="180" placeholder="NOTICE • Official updates and announcements" value="<?=ah($site['header_banner_text'])?>"></div></div></section>
<section class="card"><h2>Add Funds promotional banner</h2><p class="muted">Upload an image to display above the Add Funds button on the user Store page. Enter the destination URL; tapping the image opens that link.</p><div class="grid"><div class="field"><label>Banner image</label><input type="file" name="add_funds_banner" accept="image/jpeg,image/png,image/webp,image/gif"><div class="file-note">Current: <?=ah($site['add_funds_banner_path'])?></div><?php if(!empty($site['add_funds_banner_path'])):?><div class="preview"><img src="../<?=ah($site['add_funds_banner_path'])?>" alt="Add Funds banner"></div><?php endif;?></div><div class="field"><label>Click-through URL</label><input type="url" name="add_funds_banner_url" placeholder="https://example.com/your-link" value="<?=ah($site['add_funds_banner_url'])?>"><div class="file-note">Leave blank to show the image without a link.</div></div></div></section>

<section class="card"><h2>bKash & Nagad payment notice images</h2><p class="muted">এখান থেকে bKash এবং Nagad-এর নির্দেশনা/নোটিশের ছবি আলাদাভাবে আপলোড বা পরিবর্তন করুন। নতুন ছবি না দিলে আগের ছবিই থাকবে।</p><div class="grid"><div class="field"><label>bKash payment instruction image</label><input type="file" name="bkash_payment_guide_image" accept="image/jpeg,image/png,image/webp,image/gif"><div class="file-note">Current: <?=ah($site['bkash_payment_guide_image']??'assets/bkash-payment-option-guide.jpg')?></div><?php $bkGuide=$site['bkash_payment_guide_image']??'assets/bkash-payment-option-guide.jpg'; if($bkGuide): ?><div class="preview"><img src="../<?=ah($bkGuide)?>" alt="bKash notice preview"></div><?php endif;?></div><div class="field"><label>Nagad payment instruction image</label><input type="file" name="nagad_payment_guide_image" accept="image/jpeg,image/png,image/webp,image/gif"><div class="file-note">Current: <?=ah($site['nagad_payment_guide_image']??'')?></div><?php if(!empty($site['nagad_payment_guide_image'])): ?><div class="preview"><img src="../<?=ah($site['nagad_payment_guide_image'])?>" alt="Nagad notice preview"></div><?php else: ?><div class="file-note">এখনো Nagad-এর কোনো ছবি আপলোড করা হয়নি।</div><?php endif;?></div></div></section>
<section class="card"><h2>Payment logos</h2><div class="grid"><div class="field"><label>bKash logo</label><input type="file" name="payment_bkash_logo" accept="image/jpeg,image/png,image/webp,image/gif"><div class="file-note">Current: <?=ah($site['payment_bkash_logo'])?></div><div class="preview"><img src="../<?=ah($site['payment_bkash_logo'])?>" alt="bKash"></div></div><div class="field"><label>Nagad logo</label><input type="file" name="payment_nagad_logo" accept="image/jpeg,image/png,image/webp,image/gif"><div class="file-note">Current: <?=ah($site['payment_nagad_logo'])?></div><div class="preview"><img src="../<?=ah($site['payment_nagad_logo'])?>" alt="Nagad"></div></div><div class="field"><label>PayPal logo</label><input type="file" name="payment_paypal_logo" accept="image/jpeg,image/png,image/webp,image/gif"><div class="file-note">Current: <?=ah($site['payment_paypal_logo'])?></div><div class="preview"><img src="../<?=ah($site['payment_paypal_logo'])?>" alt="PayPal"></div></div><div class="field"><label>Binance Pay logo</label><input type="file" name="payment_binance_logo" accept="image/jpeg,image/png,image/webp,image/gif"><div class="file-note">Change the Binance Pay icon shown on the Deposit page. Current: <?=ah($site['payment_binance_logo'])?></div><div class="preview"><img src="../<?=ah($site['payment_binance_logo'])?>" alt="Binance Pay"></div></div><div class="field"><label>Binance Pay QR code (optional)</label><input type="file" name="payment_binance_qr" accept="image/jpeg,image/png,image/webp,image/gif"><div class="file-note">Upload your Binance Receive QR image. Leave empty to keep the current QR. Current: <?=ah($site['payment_binance_qr'])?></div><?php if(!empty($site['payment_binance_qr'])): ?><div class="preview"><img src="../<?=ah($site['payment_binance_qr'])?>" alt="Binance Pay QR"></div><?php endif; ?></div></div></section>

<section class="card"><h2>Premium theme & profile controls</h2><div class="grid"><div class="field"><label>Wallet card title</label><input name="wallet_title" value="<?=ah($site['wallet_title'])?>"></div><div class="field"><label>Wallet card text</label><input name="wallet_text" value="<?=ah($site['wallet_text'])?>"></div><div class="field"><label>Theme section title</label><input name="theme_section_title" value="<?=ah($site['theme_section_title'])?>"></div><div class="field"><label>Default theme</label><select name="theme_default"><option value="premium" <?=($site['theme_default']==='premium'?'selected':'')?>>Premium</option><option value="black" <?=($site['theme_default']==='black'?'selected':'')?>>Black Smooth</option><option value="obsidian" <?=($site['theme_default']==='obsidian'?'selected':'')?>>Deep Obsidian Dark</option><option value="white" <?=($site['theme_default']==='white'?'selected':'')?>>White</option><option value="luxury" <?=($site['theme_default']==='luxury'?'selected':'')?>>Clean Luxury Light</option></select></div><div class="field"><label>Primary color</label><input type="text" name="theme_primary" value="<?=ah($site['theme_primary'])?>" pattern="#[0-9A-Fa-f]{6}"></div><div class="field"><label>Secondary color</label><input type="text" name="theme_secondary" value="<?=ah($site['theme_secondary'])?>" pattern="#[0-9A-Fa-f]{6}"></div><div class="field"><label>Background color</label><input type="text" name="theme_background" value="<?=ah($site['theme_background'])?>" pattern="#[0-9A-Fa-f]{6}"></div><div class="field"><label>Panel color</label><input type="text" name="theme_panel" value="<?=ah($site['theme_panel'])?>" pattern="#[0-9A-Fa-f]{6}"></div><div class="field"><label>Telegram card title</label><input name="telegram_title" value="<?=ah($site['telegram_title'])?>"></div><div class="field"><label>Telegram card text</label><input name="telegram_text" value="<?=ah($site['telegram_text'])?>"></div><div class="field"><label>Rules URL</label><input name="rules_url" value="<?=ah($site['rules_url'])?>"></div><div class="field"><label>Rules title</label><input name="rules_title" value="<?=ah($site['rules_title'])?>"></div><div class="field"><label>Rules card text</label><input name="rules_text" value="<?=ah($site['rules_text'])?>"></div><div class="field"><label>Rules body</label><textarea name="rules_body"><?=ah($site['rules_body'])?></textarea></div><div class="field"><label>Referral title</label><input name="referral_title" value="<?=ah($site['referral_title'])?>"></div><div class="field"><label>Referral text</label><input name="referral_text" value="<?=ah($site['referral_text'])?>"></div><div class="field"><label>Referral reward rate (%)</label><input name="referral_rate" value="<?=ah($site['referral_rate'])?>"></div><div class="field"><label>Top Members title</label><input name="top_members_title" value="<?=ah($site['top_members_title'])?>"></div><div class="field"><label>Top Members text</label><input name="top_members_text" value="<?=ah($site['top_members_text'])?>"></div><div class="field"><label>Change Password title</label><input name="password_title" value="<?=ah($site['password_title'])?>"></div><div class="field"><label>Change Password text</label><input name="password_text" value="<?=ah($site['password_text'])?>"></div><div class="field"><label>Logout title</label><input name="logout_title" value="<?=ah($site['logout_title'])?>"></div><div class="field"><label>Logout text</label><input name="logout_text" value="<?=ah($site['logout_text'])?>"></div></div></section>
<button class="save" type="submit">SAVE ALL WEBSITE SETTINGS</button></form>
</main></body></html>
