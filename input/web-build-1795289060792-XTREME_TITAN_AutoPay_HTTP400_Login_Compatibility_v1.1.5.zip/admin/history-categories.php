<?php
require_once __DIR__.'/../config.php';
require_once __DIR__.'/../history-category-lib.php';
require_once __DIR__.'/../topup-lib.php';
if(empty($_SESSION['admin_id']) && empty($_SESSION['admin_logged_in'])) {header('Location: login.php');exit;}
if(empty($_SESSION['history_categories_csrf'])) $_SESSION['history_categories_csrf']=bin2hex(random_bytes(32));
$csrf=$_SESSION['history_categories_csrf'];$error='';$success='';
$pdo=db();xt_topup_ensure_tables();xt_history_categories();
if($_SERVER['REQUEST_METHOD']==='POST'){
 try{
  if(!hash_equals($csrf,(string)($_POST['csrf']??''))) throw new RuntimeException('Security verification failed. Refresh and try again.');
  $action=(string)($_POST['action']??'');
  if($action==='save'){
   $id=(int)($_POST['id']??0);$name=trim((string)($_POST['name']??''));$keywords=trim((string)($_POST['keywords']??''));$kind=(string)($_POST['kind']??'purchase');$enabled=isset($_POST['enabled'])?1:0;$sort=(int)($_POST['sort_order']??50);
   if($name===''||mb_strlen($name)>60) throw new RuntimeException('Enter a category name (max 60 characters).');
   if(!in_array($kind,['purchase','deposit','other'],true)) throw new RuntimeException('Invalid category type.');
   $slug=xt_history_slug($name);
   if($id>0){$st=$pdo->prepare('UPDATE history_categories SET name=?,slug=?,keywords=?,kind=?,sort_order=?,enabled=? WHERE id=?');$st->execute([$name,$slug,$keywords,$kind,$sort,$enabled,$id]);}
   else{$st=$pdo->prepare('INSERT INTO history_categories (name,slug,keywords,kind,sort_order,enabled) VALUES (?,?,?,?,?,?)');$st->execute([$name,$slug,$keywords,$kind,$sort,$enabled]);}
   $success='History category saved.';
  }elseif($action==='delete'){
   $id=(int)($_POST['id']??0);$st=$pdo->prepare("DELETE FROM history_categories WHERE id=? AND slug NOT IN ('deposit','other')");$st->execute([$id]);$success=$st->rowCount()?'Category deleted.':'Default Deposit/Other categories cannot be deleted.';
  }else throw new RuntimeException('Unknown action.');
 }catch(Throwable $e){$error=$e->getMessage();}
}
$all=$pdo->query('SELECT * FROM history_categories ORDER BY sort_order,id')->fetchAll(PDO::FETCH_ASSOC);
function he($v){return htmlspecialchars((string)$v,ENT_QUOTES,'UTF-8');}
?><!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no"><title>History Categories · Admin</title><link rel="stylesheet" href="../theme.php"><link rel="stylesheet" href="../reference-theme.css"><link rel="stylesheet" href="../premium-global.css"><style>
*{box-sizing:border-box}body{font-family:Inter,system-ui,Arial,sans-serif;color:#eff6ff}.hc-wrap{max-width:920px;margin:24px auto;padding:0 14px 50px}.hc-panel{padding:22px;border:1px solid #29435f;border-radius:22px;background:linear-gradient(145deg,#101d32,#080f1d);box-shadow:0 20px 55px #0006}.hc-kicker{font-size:10px;color:#5de7ee;font-weight:950;letter-spacing:.17em}.hc-panel h1{font-size:28px;margin:8px 0}.hc-muted{color:#93a8c2;font-size:12px;line-height:1.5}.hc-form{display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-top:18px}.hc-form label{display:block;font-size:11px;font-weight:850;margin-bottom:6px}.hc-form input,.hc-form select{width:100%;padding:12px;border-radius:11px;border:1px solid #2b4562;background:#071321;color:#fff}.hc-form .wide{grid-column:1/-1}.hc-check{display:flex;align-items:center;gap:8px}.hc-btn{border:0;border-radius:11px;padding:12px 16px;background:linear-gradient(90deg,#00cda8,#159dff);color:#061522;font-weight:950}.hc-row{margin-top:13px;padding:14px;border-radius:15px;border:1px solid #263951;background:#0b1525}.hc-row-top{display:flex;justify-content:space-between;gap:12px;align-items:center}.hc-name{font-weight:950}.hc-small{font-size:10px;color:#91a5bf;margin-top:5px}.hc-actions{display:flex;gap:8px;align-items:center}.hc-del{background:#512333;color:#ffdce4;border:1px solid #874157;border-radius:9px;padding:7px 10px}.hc-msg{padding:11px;border-radius:11px;margin:12px 0;font-size:12px}.hc-ok{background:#103b32;color:#c4ffea}.hc-err{background:#4a1d2b;color:#ffe4eb}@media(max-width:600px){.hc-form{grid-template-columns:1fr}.hc-form .wide{grid-column:auto}}
</style></head><body><main class="hc-wrap"><p><a href="topup-products.php" style="color:#72eaff;text-decoration:none;font-weight:800;margin-right:16px">← Gaming Top-Up Products</a><a href="dashboard.php" style="color:#72eaff;text-decoration:none;font-weight:800">← Admin Dashboard</a></p><section class="hc-panel"><div class="hc-kicker">XTREME TITAN · HISTORY CONTROL</div><h1>History Categories</h1><p class="hc-muted">Add, rename, reorder or hide the category filters shown on the customer History page. Purchase categories are matched against product and plan names using comma-separated keywords.</p>
<?php if($success):?><div class="hc-msg hc-ok"><?=he($success)?></div><?php endif;?><?php if($error):?><div class="hc-msg hc-err"><?=he($error)?></div><?php endif;?>
<form class="hc-form" method="post"><input type="hidden" name="csrf" value="<?=he($csrf)?>"><input type="hidden" name="action" value="save">
<div><label>Category name</label><input name="name" maxlength="60" placeholder="e.g. Weekly" required></div>
<div><label>Category type</label><select name="kind"><option value="purchase">Product / purchase</option><option value="deposit">Deposit</option><option value="other">Other</option></select></div>
<div class="wide"><label>Keywords (comma separated)</label><input name="keywords" placeholder="weekly, 7 day, 7-day"></div>
<div><label>Sort order</label><input type="number" name="sort_order" value="50"></div>
<div class="hc-check"><input type="checkbox" name="enabled" checked> <label style="margin:0">Visible on History</label></div>
<div class="wide"><button class="hc-btn" type="submit">＋ Add Category</button></div></form>
<h2 style="font-size:17px;margin:24px 0 8px">Existing Categories</h2>
<?php foreach($all as $c):?><div class="hc-row"><form class="hc-form" method="post" style="margin:0"><input type="hidden" name="csrf" value="<?=he($csrf)?>"><input type="hidden" name="action" value="save"><input type="hidden" name="id" value="<?=he($c['id'])?>">
<div><label>Name</label><input name="name" value="<?=he($c['name'])?>" required></div><div><label>Type</label><select name="kind"><option value="purchase" <?=$c['kind']==='purchase'?'selected':''?>>Product / purchase</option><option value="deposit" <?=$c['kind']==='deposit'?'selected':''?>>Deposit</option><option value="other" <?=$c['kind']==='other'?'selected':''?>>Other</option></select></div>
<div class="wide"><label>Keywords</label><input name="keywords" value="<?=he($c['keywords'])?>"></div><div><label>Sort order</label><input type="number" name="sort_order" value="<?=he($c['sort_order'])?>"></div><div class="hc-check"><input type="checkbox" name="enabled" <?=$c['enabled']?'checked':''?>> <label style="margin:0">Visible</label></div><div class="wide hc-actions"><button class="hc-btn" type="submit">Save Changes</button></form><?php if(!in_array($c['slug'],['deposit','other'],true)):?><form method="post" onsubmit="return confirm('Delete this category?')"><input type="hidden" name="csrf" value="<?=he($csrf)?>"><input type="hidden" name="action" value="delete"><input type="hidden" name="id" value="<?=he($c['id'])?>"><button class="hc-del">Delete</button></form><?php endif;?></div></div><?php endforeach;?>
</section></main></body></html>
