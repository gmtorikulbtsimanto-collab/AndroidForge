<?php
declare(strict_types=1);
require_once __DIR__.'/../config.php';
if (session_status() !== PHP_SESSION_ACTIVE) session_start();
if (empty($_SESSION['admin_id']) && empty($_SESSION['admin_logged_in'])) { header('Location: login.php'); exit; }
ensure_account_role_columns();
$pdo=db(); $message=''; $error='';
if(empty($_SESSION['account_manager_csrf'])) $_SESSION['account_manager_csrf']=bin2hex(random_bytes(32));
$csrf=$_SESSION['account_manager_csrf'];
function amh($v): string { return htmlspecialchars((string)$v,ENT_QUOTES,'UTF-8'); }
function am_columns(PDO $pdo): array { return $pdo->query('SHOW COLUMNS FROM users')->fetchAll(PDO::FETCH_COLUMN); }
$cols=am_columns($pdo);
$pick=function(array $names)use($cols):?string{foreach($names as $n)if(in_array($n,$cols,true))return $n;return null;};
$idCol=$pick(['id','user_id']); $nameCol=$pick(['name','full_name']); $userCol=$pick(['username','user_name']); $emailCol=$pick(['email','email_address']); $phoneCol=$pick(['phone','phone_number','mobile']); $passCol=$pick(['password_hash','password','pwd','pass']); $roleCol=$pick(['role','user_role','account_type','type']);
if(!$idCol || !$nameCol || !$userCol || !$emailCol || !$phoneCol || !$passCol) {
  http_response_code(500); echo 'Account Management setup error: required users table fields are missing. Check the users table columns.'; exit;
}
if($_SERVER['REQUEST_METHOD']==='POST'){
 try{
  if(!hash_equals($csrf,(string)($_POST['csrf']??''))) throw new RuntimeException('Security token expired. Refresh and try again.');
  $action=(string)($_POST['action']??'');
  $id=(int)($_POST['id']??0);
  $name=trim((string)($_POST['name']??'')); $username=strtolower(trim((string)($_POST['username']??'')));
  $email=strtolower(trim((string)($_POST['email']??''))); $phone=trim((string)($_POST['phone']??'')); $pw=(string)($_POST['password']??'');
  if(mb_strlen($name)<2) throw new RuntimeException('Name must contain at least 2 characters.');
  if(!preg_match('/^[a-z0-9][a-z0-9._-]{2,49}$/',$username)) throw new RuntimeException('Username must be 3–50 characters and use letters, numbers, dot, dash or underscore.');
  if(!filter_var($email,FILTER_VALIDATE_EMAIL)) throw new RuntimeException('Enter a valid email address.');
  if($phone===''||strlen($phone)>30) throw new RuntimeException('Enter a valid phone number.');
  $duSql="SELECT `$idCol` FROM users WHERE (`$userCol`=? OR `$emailCol`=? OR `$phoneCol`=?)".($action==='save'?" AND `$idCol`<>?":"")." LIMIT 1";
  $du=$pdo->prepare($duSql); $duArgs=[$username,$email,$phone]; if($action==='save')$duArgs[]=$id; $du->execute($duArgs);
  if($du->fetchColumn()) throw new RuntimeException('Username, email or phone is already used by another account.');
  if($action==='save'){
    if($id<1) throw new RuntimeException('Select an account to edit.');
    $sets=["`$nameCol`=?","`$userCol`=?","`$emailCol`=?","`$phoneCol`=?"]; $vals=[$name,$username,$email,$phone];
    if($pw!==''){if(strlen($pw)<8)throw new RuntimeException('New password must be at least 8 characters.');$sets[]="`$passCol`=?";$vals[]=password_hash($pw,PASSWORD_DEFAULT);}
    if($roleCol){
      $role=strtolower(trim((string)($_POST['role']??'user')));
      if(!in_array($role,['user','reseller','admin'],true))$role='user';
      $currentAdminId=(int)($_SESSION['admin_id']??0);
      if($id===$currentAdminId && $role!=='admin') throw new RuntimeException('You cannot remove administrator access from your own account.');
      if($role!=='admin'){
        $q=$pdo->prepare("SELECT COUNT(*) FROM users WHERE LOWER(`$roleCol`)='admin'");$q->execute();
        if((int)$q->fetchColumn()<=1){
          $old=$pdo->prepare("SELECT LOWER(`$roleCol`) FROM users WHERE `$idCol`=?");$old->execute([$id]);
          if((string)$old->fetchColumn()==='admin') throw new RuntimeException('The last administrator account cannot be changed to a non-admin role.');
        }
      }
      $sets[]="`$roleCol`=?";$vals[]=$role;
    }
    $vals[]=$id;$st=$pdo->prepare("UPDATE users SET ".implode(',',$sets)." WHERE `$idCol`=? LIMIT 1");$st->execute($vals);
    $message='Account updated successfully.'.($pw!==''?' Password changed.':' Password unchanged.');
  }elseif($action==='create'){
    if(strlen($pw)<8)throw new RuntimeException('Password must be at least 8 characters.');
    $role=strtolower(trim((string)($_POST['role']??'user'))); if(!in_array($role,['user','reseller','admin'],true))$role='user';
    $fields=[$nameCol,$userCol,$emailCol,$phoneCol,$passCol];$values=[$name,$username,$email,$phone,password_hash($pw,PASSWORD_DEFAULT)];
    if($roleCol){$fields[]=$roleCol;$values[]=$role;}
    $quoted=array_map(fn($v)=>"`$v`",$fields);$marks=implode(',',array_fill(0,count($fields),'?'));
    $st=$pdo->prepare('INSERT INTO users('.implode(',',$quoted).") VALUES($marks)");$st->execute($values);
    $message='Account created successfully.';
  }else throw new RuntimeException('Unknown action.');
 }catch(Throwable $e){$error=$e instanceof RuntimeException?$e->getMessage():'Could not save account. Check the database columns and try again.';error_log('Admin account manager: '.$e->getMessage());}
}

// The website may keep its primary administrator in a separate `admins` table.
// Manage that table separately from ordinary customer/reseller rows in `users`.
$adminTableAvailable=false; $adminRows=[]; $adminEdit=null; $adminCols=[];
try {
    $adminCols=$pdo->query("SHOW COLUMNS FROM admins")->fetchAll(PDO::FETCH_COLUMN);
    $adminTableAvailable=true;
} catch(Throwable $ignore) {}
if($adminTableAvailable) {
    $aid=$pick(['id']); // users-table picker; resolve admins columns independently below
    $apick=function(array $choices) use ($adminCols): ?string { foreach($choices as $c) if(in_array($c,$adminCols,true)) return $c; return null; };
    $aId=$apick(['id','admin_id']); $aName=$apick(['name','full_name']); $aUser=$apick(['username','user_name']);
    $aEmail=$apick(['email','email_address']); $aPhone=$apick(['phone','phone_number','mobile']); $aPass=$apick(['password_hash','password','pwd','pass']);
    if($aId && $aName && $aUser && $aEmail && $aPass) {
        if($_SERVER['REQUEST_METHOD']==='POST' && in_array((string)($_POST['action']??''),['admin_save','admin_create'],true)) {
            try {
                if(!hash_equals($csrf,(string)($_POST['csrf']??''))) throw new RuntimeException('Security token expired. Refresh and try again.');
                $act=(string)$_POST['action']; $aid=(int)($_POST['admin_id']??0);
                $an=trim((string)($_POST['admin_name']??'')); $au=strtolower(trim((string)($_POST['admin_username']??'')));
                $ae=strtolower(trim((string)($_POST['admin_email']??''))); $aph=trim((string)($_POST['admin_phone']??'')); $apw=(string)($_POST['admin_password']??'');
                if(mb_strlen($an)<2) throw new RuntimeException('Admin name must contain at least 2 characters.');
                if(!preg_match('/^[a-z0-9][a-z0-9._-]{2,49}$/',$au)) throw new RuntimeException('Admin username must be 3–50 valid characters.');
                if(!filter_var($ae,FILTER_VALIDATE_EMAIL)) throw new RuntimeException('Enter a valid admin email address.');
                if($aPhone && ($aph==='' || strlen($aph)>30)) throw new RuntimeException('Enter a valid admin phone number.');
                if($act==='admin_create' && strlen($apw)<8) throw new RuntimeException('New admin password must be at least 8 characters.');
                if($act==='admin_save' && $apw!=='' && strlen($apw)<8) throw new RuntimeException('New admin password must be at least 8 characters.');
                $du=$pdo->prepare("SELECT `$aId` FROM admins WHERE (`$aUser`=? OR `$aEmail`=?)".($act==='admin_save'?" AND `$aId`<>?":"")." LIMIT 1");
                $da=[$au,$ae]; if($act==='admin_save')$da[]=$aid; $du->execute($da);
                if($du->fetchColumn()) throw new RuntimeException('Admin username or email is already used by another admin.');
                if($act==='admin_save') {
                    if($aid<1) throw new RuntimeException('Select an administrator account to edit.');
                    $sets=["`$aName`=?","`$aUser`=?","`$aEmail`=?"]; $vals=[$an,$au,$ae];
                    if($aPhone){$sets[]="`$aPhone`=?";$vals[]=$aph;}
                    if($apw!==''){$sets[]="`$aPass`=?";$vals[]=password_hash($apw,PASSWORD_DEFAULT);}
                    $vals[]=$aid; $st=$pdo->prepare("UPDATE admins SET ".implode(',',$sets)." WHERE `$aId`=? LIMIT 1");$st->execute($vals);
                    $message='Administrator account updated successfully.'.($apw!==''?' Password changed.':' Password unchanged.');
                } else {
                    $fields=[$aName,$aUser,$aEmail,$aPass];$vals=[$an,$au,$ae,password_hash($apw,PASSWORD_DEFAULT)];
                    if($aPhone){$fields[]=$aPhone;$vals[]=$aph;}
                    $st=$pdo->prepare('INSERT INTO admins('.implode(',',array_map(fn($c)=>"`$c`",$fields)).') VALUES('.implode(',',array_fill(0,count($fields),'?')).')');
                    $st->execute($vals);$message='Administrator account created successfully.';
                }
            } catch(Throwable $e) { $error=$e instanceof RuntimeException?$e->getMessage():'Could not save administrator account. Check the admins table columns.'; error_log('Admin table account manager: '.$e->getMessage()); }
        }
        $adminSelect=["`$aId` AS id","`$aName` AS name","`$aUser` AS username","`$aEmail` AS email",$aPhone?"`$aPhone` AS phone":"'' AS phone"];
        $adminRows=$pdo->query('SELECT '.implode(',',$adminSelect)." FROM admins ORDER BY `$aId` DESC LIMIT 100")->fetchAll(PDO::FETCH_ASSOC);
        $adminEditId=(int)($_GET['edit_admin']??0);
        if($adminEditId){$q=$pdo->prepare('SELECT '.implode(',',$adminSelect)." FROM admins WHERE `$aId`=? LIMIT 1");$q->execute([$adminEditId]);$adminEdit=$q->fetch(PDO::FETCH_ASSOC)?:null;}
    } else { $adminTableAvailable=false; }
}

// Always include the actual Admin Panel account from `users` even if its ID
// is older than the latest 250 customer records.
$userAdminRows=[];
if($roleCol) {
    try {
        $adminWhere="LOWER(COALESCE(`$roleCol`,'')) IN ('admin','administrator','1','true','yes')";
        $sql="SELECT `$idCol` AS id,`$nameCol` AS name,`$userCol` AS username,`$emailCol` AS email,`$phoneCol` AS phone,`$roleCol` AS role FROM users WHERE $adminWhere";
        $args=[];
        $sessionAdminId=(int)($_SESSION['admin_id']??0);
        if($sessionAdminId>0){$sql.=" OR `$idCol`=?";$args[]=$sessionAdminId;}
        $sql.=" ORDER BY `$idCol` DESC LIMIT 100";
        $q=$pdo->prepare($sql);$q->execute($args);$userAdminRows=$q->fetchAll(PDO::FETCH_ASSOC);
    } catch(Throwable $e) { error_log('Account manager admin-user listing: '.$e->getMessage()); }
} else {
    $sessionAdminId=(int)($_SESSION['admin_id']??0);
    if($sessionAdminId>0) {
        try {
            $q=$pdo->prepare("SELECT `$idCol` AS id,`$nameCol` AS name,`$userCol` AS username,`$emailCol` AS email,`$phoneCol` AS phone,'admin' AS role FROM users WHERE `$idCol`=? LIMIT 1");
            $q->execute([$sessionAdminId]);$userAdminRows=$q->fetchAll(PDO::FETCH_ASSOC);
        } catch(Throwable $e) { error_log('Account manager current admin listing: '.$e->getMessage()); }
    }
}
$selectCols=["`$idCol` AS id","`$nameCol` AS name","`$userCol` AS username","`$emailCol` AS email","`$phoneCol` AS phone"];
$selectCols[]=$roleCol?"`$roleCol` AS role":"'user' AS role";
$rows=$pdo->query('SELECT '.implode(',',$selectCols)." FROM users ORDER BY `$idCol` DESC LIMIT 250")->fetchAll(PDO::FETCH_ASSOC);
$editId=(int)($_GET['edit']??0);$edit=null;
if($editId){$q=$pdo->prepare('SELECT '.implode(',',$selectCols)." FROM users WHERE `$idCol`=? LIMIT 1");$q->execute([$editId]);$edit=$q->fetch(PDO::FETCH_ASSOC)?:null;}
?><!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Account Management — XTREME TITAN</title><link rel="stylesheet" href="../theme.php?v=20261121"><link rel="stylesheet" href="admin-theme.css"><link rel="stylesheet" href="../responsive-lock.css"><style>
*{box-sizing:border-box}body{background:#050a13;color:#eff7ff;font-family:Inter,Arial,sans-serif}.wrap{width:min(1100px,100%);margin:auto;padding:16px}.panel{background:linear-gradient(145deg,#0d1c2e,#07101d);border:1px solid rgba(20,197,238,.2);border-radius:18px;padding:18px;margin:0 0 15px}.muted{color:#91a4bb;font-size:13px;line-height:1.5}h1{font-size:25px;margin:0 0 7px}h2{font-size:18px;margin:0 0 12px}.notice{padding:11px;border-radius:11px;margin:0 0 12px}.ok{background:#123222;color:#9bf2b5}.err{background:#3a1721;color:#ffb1bd}.grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:12px}.field label{display:block;font-size:11px;font-weight:900;color:#b7c8dc;margin:0 0 6px}.field input,.field select{width:100%;min-width:0;padding:12px;border-radius:10px;border:1px solid #2c4059;background:#050d18;color:#fff;font-size:15px}.field{margin-bottom:12px}.btn{display:inline-flex;align-items:center;justify-content:center;border:0;border-radius:10px;padding:12px 16px;background:#63ff16;color:#07110a;font-weight:900;text-decoration:none;cursor:pointer;min-height:42px}.btn.alt{background:#15263b;color:#d8e9ff;border:1px solid #344a65}.search{width:100%;padding:12px;border-radius:10px;border:1px solid #2c4059;background:#050d18;color:#fff;font-size:15px;margin:0 0 12px}.account-list{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:12px}.account{background:#081321;border:1px solid #263d55;border-radius:14px;padding:14px;min-width:0}.account-head{display:flex;align-items:flex-start;justify-content:space-between;gap:8px}.account-name{font-size:15px;font-weight:900;overflow-wrap:anywhere}.account-meta{color:#a8b9cd;font-size:12px;line-height:1.7;margin:9px 0;overflow-wrap:anywhere}.role{display:inline-block;border-radius:99px;background:#102d22;color:#9df5b9;padding:4px 8px;font-size:10px;font-weight:900}.actions{display:flex;gap:8px;flex-wrap:wrap}.empty{color:#91a4bb;padding:18px;text-align:center}.hint{font-size:11px;color:#91a4bb;margin-top:6px}@media(max-width:650px){.grid,.account-list{grid-template-columns:1fr}.wrap{padding:10px}.panel{padding:14px}.btn{width:100%}.actions .btn{width:auto;flex:1}}
</style></head><body><main class="wrap">
<section class="panel"><h1>Account Management</h1><div class="muted">Create and update website accounts. Change username, email, phone number, full name, role and password. Passwords are saved as secure hashes. Admin account changes also apply to AutoPay admin login.</div><p><a class="btn alt" href="dashboard.php">← Admin Dashboard</a></p><?php if($message):?><div class="notice ok"><?=amh($message)?></div><?php endif;?><?php if($error):?><div class="notice err"><?=amh($error)?></div><?php endif;?></section>
<section class="panel"><h2><?= $edit?'Edit Account #'.(int)$edit['id']:'Create Account' ?></h2><form method="post"><input type="hidden" name="csrf" value="<?=amh($csrf)?>"><input type="hidden" name="action" value="<?=$edit?'save':'create'?>"><?php if($edit):?><input type="hidden" name="id" value="<?=(int)$edit['id']?>"><?php endif;?>
<div class="grid"><div class="field"><label>FULL NAME</label><input name="name" required minlength="2" value="<?=amh($edit['name']??'')?>"></div><div class="field"><label>USERNAME</label><input name="username" required minlength="3" maxlength="50" pattern="[A-Za-z0-9][A-Za-z0-9._-]{2,49}" value="<?=amh($edit['username']??'')?>" placeholder="e.g. lixtorikul"></div><div class="field"><label>EMAIL ADDRESS</label><input type="email" name="email" required value="<?=amh($edit['email']??'')?>"></div><div class="field"><label>PHONE NUMBER</label><input name="phone" required value="<?=amh($edit['phone']??'')?>"></div><div class="field"><label><?=$edit?'NEW PASSWORD (LEAVE EMPTY TO KEEP CURRENT)':'PASSWORD'?></label><input type="password" name="password" <?=$edit?'':'required'?> minlength="8" autocomplete="new-password" placeholder="<?=$edit?'Leave blank to keep unchanged':'At least 8 characters'?>"><div class="hint"><?=$edit?'Leave empty to keep the current password.':'Use at least 8 characters.'?></div></div><?php if($roleCol):?><div class="field"><label>ACCOUNT ROLE</label><select name="role"><?php foreach(['user'=>'User','reseller'=>'Reseller','admin'=>'Admin'] as $v=>$label):?><option value="<?=$v?>" <?=strtolower((string)($edit['role']??'user'))===$v?'selected':''?>><?=$label?></option><?php endforeach;?></select></div><?php endif;?></div><div class="actions"><button class="btn" type="submit"><?=$edit?'Save Account Changes':'Create Account'?></button><?php if($edit):?><a class="btn alt" href="accounts.php">Cancel Edit</a><?php endif;?></div></form></section>
<?php if($adminTableAvailable):?>
<section class="panel"><h2>Administrator Accounts <span class="muted">(separate admins table)</span></h2>
<div class="muted">This section manages the separate administrator login used by Admin Panel. Changes here update the admin login credentials, not customer accounts.</div>
<form method="post" style="margin-top:14px"><input type="hidden" name="csrf" value="<?=amh($csrf)?>"><input type="hidden" name="action" value="<?=$adminEdit?'admin_save':'admin_create'?>"><?php if($adminEdit):?><input type="hidden" name="admin_id" value="<?=(int)$adminEdit['id']?>"><?php endif;?>
<div class="grid"><div class="field"><label>ADMIN FULL NAME</label><input name="admin_name" required minlength="2" value="<?=amh($adminEdit['name']??'')?>"></div><div class="field"><label>ADMIN USERNAME</label><input name="admin_username" required minlength="3" maxlength="50" value="<?=amh($adminEdit['username']??'')?>" placeholder="e.g. lixtorikul"></div><div class="field"><label>ADMIN EMAIL / GMAIL</label><input type="email" name="admin_email" required value="<?=amh($adminEdit['email']??'')?>"></div><?php if(isset($aPhone)&&$aPhone):?><div class="field"><label>ADMIN PHONE</label><input name="admin_phone" value="<?=amh($adminEdit['phone']??'')?>"></div><?php endif;?><div class="field"><label><?=$adminEdit?'NEW PASSWORD (OPTIONAL)':'PASSWORD'?></label><input type="password" name="admin_password" <?=$adminEdit?'':'required'?> minlength="8" autocomplete="new-password" placeholder="<?=$adminEdit?'Leave blank to keep current':'At least 8 characters'?>"><div class="hint"><?=$adminEdit?'Leave blank to keep the current password.':'At least 8 characters.'?></div></div></div>
<div class="actions"><button class="btn" type="submit"><?=$adminEdit?'Save Admin Changes':'Create Admin Account'?></button><?php if($adminEdit):?><a class="btn alt" href="accounts.php">Cancel Edit</a><?php endif;?></div></form>
<div class="account-list" style="margin-top:15px"><?php foreach($adminRows as $ar):?><article class="account"><div class="account-head"><div class="account-name"><?=amh($ar['name'])?><div class="muted">@<?=amh($ar['username'])?> · Admin ID #<?=(int)$ar['id']?></div></div><span class="role">ADMIN</span></div><div class="account-meta"><div><b>Email:</b> <?=amh($ar['email'])?></div><?php if($ar['phone']!==''):?><div><b>Phone:</b> <?=amh($ar['phone'])?></div><?php endif;?></div><div class="actions"><a class="btn alt" href="accounts.php?edit_admin=<?=(int)$ar['id']?>">✎ Edit Admin Account</a></div></article><?php endforeach;?><?php if(!$adminRows):?><div class="empty">No administrator accounts found in admins table.</div><?php endif;?></div>
</section>
<?php endif;?>
<section class="panel"><h2>Admin Accounts <span class="muted">(website Admin Panel login)</span></h2>
<div class="muted">These are administrator accounts stored in the website's <code>users</code> table. This list includes the currently signed-in Admin ID even if it is older than the latest 250 accounts.</div>
<div class="account-list" style="margin-top:14px">
<?php foreach($userAdminRows as $ar):?>
<article class="account">
 <div class="account-head"><div class="account-name"><?=amh($ar['name'])?><div class="muted">@<?=amh($ar['username'])?> · Admin ID #<?=(int)$ar['id']?></div></div><span class="role">ADMIN</span></div>
 <div class="account-meta"><div><b>Email:</b> <?=amh($ar['email'])?></div><div><b>Phone:</b> <?=amh($ar['phone'])?></div></div>
 <div class="actions"><a class="btn alt" href="accounts.php?edit=<?=(int)$ar['id']?>">✎ Edit Admin Account</a></div>
</article>
<?php endforeach;?>
<?php if(!$userAdminRows):?><div class="empty">No admin account was found in the users table. Check that the Admin Panel account has role=admin.</div><?php endif;?>
</div></section>
<section class="panel"><h2>Website Accounts <span class="muted">(latest 250)</span></h2><input id="accountSearch" class="search" type="search" placeholder="Search name, username, email, phone or role..."><div class="account-list" id="accountList"><?php foreach($rows as $r):?><article class="account" data-search="<?=amh(strtolower(implode(' ',[$r['name'],$r['username'],$r['email'],$r['phone'],$r['role']])))?>"><div class="account-head"><div class="account-name"><?=amh($r['name'])?><div class="muted">@<?=amh($r['username'])?> · ID #<?=(int)$r['id']?></div></div><span class="role"><?=amh(strtoupper((string)$r['role']))?></span></div><div class="account-meta"><div><b>Email:</b> <?=amh($r['email'])?></div><div><b>Phone:</b> <?=amh($r['phone'])?></div></div><div class="actions"><a class="btn alt" href="accounts.php?edit=<?=(int)$r['id']?>">✎ Edit Account</a></div></article><?php endforeach;?><?php if(!$rows):?><div class="empty">No accounts found.</div><?php endif;?></div><div id="noResults" class="empty" hidden>No matching accounts.</div></section>
</main><script>
(()=>{const q=document.getElementById('accountSearch'),cards=[...document.querySelectorAll('.account')],empty=document.getElementById('noResults');if(!q)return;q.addEventListener('input',()=>{const v=q.value.trim().toLowerCase();let n=0;cards.forEach(c=>{const ok=c.dataset.search.includes(v);c.hidden=!ok;if(ok)n++;});empty.hidden=n!==0;});})();
</script></body></html>
