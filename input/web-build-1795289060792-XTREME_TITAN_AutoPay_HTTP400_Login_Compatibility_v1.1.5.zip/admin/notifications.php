<?php
require_once __DIR__ . '/../config.php';
if (session_status() !== PHP_SESSION_ACTIVE) { @session_start(); }
if (empty($_SESSION['admin_id']) && empty($_SESSION['admin_logged_in'])) {
    http_response_code(401);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode(['ok'=>false,'error'=>'Admin login required.']);
    exit;
}
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
function notice_json_v2(array $data, int $status=200): never {
    http_response_code($status);
    echo json_encode($data, JSON_UNESCAPED_UNICODE|JSON_INVALID_UTF8_SUBSTITUTE);
    exit;
}
try {
    // Self-contained setup: does not depend on a helper being added to root config.php.
    $pdo = db();
    $pdo->exec("CREATE TABLE IF NOT EXISTS admin_notifications (
        id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
        event_type VARCHAR(40) NOT NULL,
        title VARCHAR(160) NOT NULL,
        body VARCHAR(500) NOT NULL,
        target_url VARCHAR(255) NOT NULL DEFAULT 'dashboard.php',
        created_at DATETIME NOT NULL,
        read_at DATETIME NULL,
        INDEX idx_admin_notice_unread (read_at, id),
        INDEX idx_admin_notice_type (event_type, id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

    $action=(string)($_GET['action']??'poll');
    if ($action==='poll') {
        $after=max(0,(int)($_GET['after']??0));
        if ($after===0) {
            $q=$pdo->query('SELECT id,event_type,title,body,target_url,created_at,read_at FROM admin_notifications ORDER BY id DESC LIMIT 25');
        } else {
            $q=$pdo->prepare('SELECT id,event_type,title,body,target_url,created_at,read_at FROM admin_notifications WHERE id>? ORDER BY id DESC LIMIT 40');
            $q->execute([$after]);
        }
        $rows=$q->fetchAll(PDO::FETCH_ASSOC);
        $unread=(int)$pdo->query('SELECT COUNT(*) FROM admin_notifications WHERE read_at IS NULL')->fetchColumn();
        $latest=(int)$pdo->query('SELECT COALESCE(MAX(id),0) FROM admin_notifications')->fetchColumn();
        notice_json_v2(['ok'=>true,'items'=>$rows,'unread'=>$unread,'latest_id'=>$latest]);
    }
    if ($action==='csrf') {
        if (empty($_SESSION['admin_notice_csrf'])) $_SESSION['admin_notice_csrf']=bin2hex(random_bytes(24));
        notice_json_v2(['ok'=>true,'csrf'=>$_SESSION['admin_notice_csrf']]);
    }
    if ($action==='read' && $_SERVER['REQUEST_METHOD']==='POST') {
        if (empty($_SESSION['admin_notice_csrf'])) $_SESSION['admin_notice_csrf']=bin2hex(random_bytes(24));
        $csrf=(string)($_SERVER['HTTP_X_NOTICE_CSRF']??($_POST['csrf']??''));
        if (!hash_equals($_SESSION['admin_notice_csrf'],$csrf)) notice_json_v2(['ok'=>false,'error'=>'Security check failed.'],403);
        $id=max(0,(int)($_POST['id']??0));
        if ($id) { $q=$pdo->prepare('UPDATE admin_notifications SET read_at=UTC_TIMESTAMP() WHERE id=?'); $q->execute([$id]); }
        else $pdo->exec('UPDATE admin_notifications SET read_at=UTC_TIMESTAMP() WHERE read_at IS NULL');
        notice_json_v2(['ok'=>true]);
    }
    notice_json_v2(['ok'=>false,'error'=>'Invalid action.'],400);
} catch (Throwable $e) {
    error_log('Admin notification endpoint: '.$e->getMessage());
    notice_json_v2(['ok'=>false,'error'=>'Database/table error. Check that the admin database user can CREATE and read tables.'],500);
}
