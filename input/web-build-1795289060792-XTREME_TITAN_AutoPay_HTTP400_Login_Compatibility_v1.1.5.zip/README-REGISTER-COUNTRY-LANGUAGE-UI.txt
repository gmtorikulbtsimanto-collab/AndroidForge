XTREME TITAN - Registration country/language UI patch

Changes in this patch:
- Replaced the plain country/currency select presentation with responsive selectable country cards.
- Kept the selected country synchronized with the registration POST field (region), currency/language preferences, and phone dialing code.
- Added registration-page translations for Bangla, Hindi, Nepali, Dzongkha, Vietnamese, and English, including labels and placeholders.
- Selected region now posts with the registration form; previously the selector was outside the form and its value was not reliably submitted.

Country-to-primary-language mapping:
BD -> Bangla, IN -> Hindi, NP -> Nepali, BT -> Dzongkha, VN -> Vietnamese, OT -> English.
A country can have multiple languages; this mapping selects one primary UI language. This does not automatically translate every page or all languages spoken in each country.

Install:
1. Back up your current site and database.
2. Replace register.php in the same location as the existing register.php.
3. Keep all other files in the archive unchanged unless they are already part of your current update workflow.
4. Test each country choice and submit a test registration to confirm region, currency, language and phone code are saved correctly.

Google's hosted sign-in button can use its own language based on Google's/browser locale and may not change immediately with the country selector.
Live hosting/database tests have not been performed.
