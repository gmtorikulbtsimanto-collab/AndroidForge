TMPanel Ultimate UI V5
======================

এই প্যাকেজটি Original project ZIP-এর উপর তৈরি।

পরিবর্তন:
- Store, My Keys, Add Funds, History ও Profile-এ একক responsive content width/card design system।
- Profile theme selector-এ শুধু Dark ও White। পুরোনো local theme values Dark/White-এ normalize হয়।
- Login/Register এবং Admin PHP screens-এ shared premium UI stylesheet।
- পাঁচটি bottom navigation link/label/route markup পরিবর্তন করা হয়নি; তাদের বিদ্যমান stylesheet-কে override না করার জন্য আলাদা রাখা হয়েছে।
- Payment, wallet, authentication, key issuance ও database PHP logic ইচ্ছাকৃতভাবে rewrite করা হয়নি।

গুরুত্বপূর্ণ:
- লাইভ সার্ভারে দেওয়ার আগে সম্পূর্ণ ফাইল ও MySQL database backup নিন।
- staging/subdomain-এ login, registration, Google auth, deposit/payment webhook, key purchase, history, theme switching এবং admin actions পরীক্ষা করুন।
- এই প্যাকেজে Android APK build করা হয়নি; PWA/website assets আগের মতো রাখা হয়েছে।
