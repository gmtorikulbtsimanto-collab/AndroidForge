/* XTREME TITAN: animated falling star particles, Safari-safe and click-through. */
(function () {
  'use strict';
  var CANVAS_ID = 'xtreme-starfall-canvas';
  function cssVar(name, fallback) {
    try { return getComputedStyle(document.documentElement).getPropertyValue(name).trim() || fallback; }
    catch (_) { return fallback; }
  }
  function startStarfall() {
    if (!document.documentElement || document.getElementById(CANVAS_ID)) return;
    var canvas = document.createElement('canvas');
    canvas.id = CANVAS_ID;
    canvas.setAttribute('aria-hidden', 'true');
    canvas.style.cssText = 'position:fixed!important;top:0!important;left:0!important;right:0!important;bottom:0!important;width:100vw!important;height:100vh!important;display:block!important;pointer-events:none!important;z-index:2147483647!important;opacity:1!important;visibility:visible!important;mix-blend-mode:screen!important;contain:strict!important;';
    /* Put the overlay on the root element so body stacking contexts cannot hide it. */
    document.documentElement.appendChild(canvas);
    var ctx;
    try { ctx = canvas.getContext('2d', { alpha: true, desynchronized: true }); } catch (_) { ctx = null; }
    if (!ctx) { canvas.remove(); return; }

    var width = 1, height = 1, dpr = 1, particles = [], last = 0, raf = 0;
    var reduceMotion = !!(window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches);
    function readSettings() {
      var mode = cssVar('--xt-particle-mode', 'dots').toLowerCase();
      var opacity = parseFloat(cssVar('--xt-particle-opacity', '0.55'));
      var size = parseFloat(cssVar('--xt-particle-size', '3')) || 3;
      var speed = parseFloat(cssVar('--xt-particle-speed', '18')) || 18;
      var color = cssVar('--xt-particle-color', '#b8e7ff');
      if (!isFinite(opacity)) opacity = 0.55;
      /* If the saved mode is not off, keep a faint visible minimum in case a bad value was saved. */
      if (mode !== 'off' && opacity <= 0) opacity = 0.35;
      return { mode: mode, opacity: Math.max(0, Math.min(1, opacity)), size: Math.max(1, Math.min(8, size)), speed: Math.max(5, Math.min(60, speed)), color: /^#[0-9a-f]{6}$/i.test(color) ? color : '#b8e7ff' };
    }
    function resize() {
      dpr = Math.min(window.devicePixelRatio || 1, 2);
      width = Math.max(1, window.innerWidth || document.documentElement.clientWidth || 1);
      height = Math.max(1, window.innerHeight || document.documentElement.clientHeight || 1);
      canvas.width = Math.round(width * dpr);
      canvas.height = Math.round(height * dpr);
      canvas.style.width = width + 'px'; canvas.style.height = height + 'px';
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      var count = Math.max(42, Math.min(110, Math.round(width / 4.2)));
      particles = Array.from({ length: count }, function () { return makeParticle(true); });
    }
    function makeParticle(randomY) {
      var s = readSettings();
      var scale = s.size / 3;
      return { x: Math.random() * width, y: randomY ? Math.random() * height : -5 - Math.random() * 45,
        r: (0.65 + Math.random() * 1.35) * Math.min(2.1, scale),
        vy: (0.65 + Math.random() * 1.8) * (18 / s.speed) * (reduceMotion ? 0.65 : 1),
        vx: (Math.random() - 0.5) * 0.32, phase: Math.random() * Math.PI * 2,
        twinkle: 0.8 + Math.random() * 2.4, bright: Math.random() > 0.72 };
    }
    function frame(now) {
      raf = window.requestAnimationFrame(frame);
      if (now - last < 20) return;
      var dt = last ? Math.min(0.06, (now - last) / 1000) : 0.016;
      last = now;
      var s = readSettings();
      ctx.clearRect(0, 0, width, height);
      if (s.mode === 'off' || s.opacity <= 0) return;
      for (var i = 0; i < particles.length; i++) {
        var p = particles[i];
        p.y += p.vy * 60 * dt; p.x += p.vx * 60 * dt; p.phase += dt * p.twinkle;
        if (p.y > height + 12 || p.x < -12 || p.x > width + 12) particles[i] = p = makeParticle(false);
        var pulse = 0.42 + 0.58 * ((Math.sin(p.phase) + 1) / 2);
        var alpha = Math.min(1, s.opacity * pulse * (p.bright ? 1 : 0.82));
        ctx.globalAlpha = alpha;
        ctx.shadowBlur = 4 + p.r * 4;
        ctx.shadowColor = p.bright ? '#ffffff' : s.color;
        ctx.fillStyle = p.bright ? '#ffffff' : s.color;
        ctx.beginPath(); ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2); ctx.fill();
        if (p.bright && pulse > 0.76) {
          ctx.globalAlpha = alpha * 0.55;
          ctx.fillRect(p.x - p.r * 2.8, p.y - 0.45, p.r * 5.6, 0.9);
          ctx.fillRect(p.x - 0.45, p.y - p.r * 2.8, 0.9, p.r * 5.6);
        }
      }
      ctx.globalAlpha = 1; ctx.shadowBlur = 0;
    }
    window.addEventListener('resize', resize, { passive: true });
    resize();
    raf = window.requestAnimationFrame(frame);
  }
  function addBackgroundVideo() {
    /* Keep the existing background video effect behind content; do not rewrite content stacking. */
    if (!document.body || document.querySelector('.xtreme-bg-video')) return;
    var v = document.createElement('video');
    v.className = 'xtreme-bg-video'; v.autoplay = true; v.muted = true; v.loop = true; v.playsInline = true;
    v.setAttribute('aria-hidden', 'true'); v.src = 'assets/tanofficial_neon_background.mp4';
    v.style.cssText = 'position:fixed;inset:0;width:100%;height:100%;object-fit:cover;z-index:-2;pointer-events:none;opacity:.18;filter:saturate(1.05) brightness(.55)';
    document.body.prepend(v);
  }
  function init() { addBackgroundVideo(); startStarfall(); }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init, { once: true });
  else init();
})();
