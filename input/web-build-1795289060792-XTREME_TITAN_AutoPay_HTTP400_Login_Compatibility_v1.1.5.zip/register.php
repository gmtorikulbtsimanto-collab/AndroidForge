<?php

ini_set('display_errors', 0);
ini_set('display_startup_errors', 0);
error_reporting(E_ALL);

require_once __DIR__ . '/config.php';
if (session_status() !== PHP_SESSION_ACTIVE) session_start();
if (empty($_SESSION['google_login_nonce'])) $_SESSION['google_login_nonce']=bin2hex(random_bytes(24));

if (!empty($_SESSION['user_id'])) {
    header('Location: dashboard.php');
    exit;
}

$error = '';

$name = trim($_POST['name'] ?? '');
$email = trim($_POST['email'] ?? '');
$countryCode = $_POST['country_code'] ?? '+880';
$phoneNumber = trim($_POST['phone'] ?? '');
$region = strtoupper(trim((string)($_POST['region'] ?? 'BD')));
$regionSettings = ['BD'=>['currency'=>'BDT','language'=>'bn','phone'=>'+880','country'=>'BD'],'IN'=>['currency'=>'INR','language'=>'hi','phone'=>'+91','country'=>'IN'],'NP'=>['currency'=>'NPR','language'=>'ne','phone'=>'+977','country'=>'NP'],'BT'=>['currency'=>'BTN','language'=>'dz','phone'=>'+975','country'=>'BT'],'VN'=>['currency'=>'VND','language'=>'vi','phone'=>'+84','country'=>'VN'],'OT'=>['currency'=>'USD','language'=>'en','phone'=>'','country'=>'OT']];
if (!isset($regionSettings[$region])) $region='BD';
$currency = $regionSettings[$region]['currency'];
$countryMap = ['+880'=>'BD','+91'=>'IN','+977'=>'NP','+975'=>'BT','+84'=>'VN'];
$currencyCountry = ['USD'=>'US','EUR'=>'IT','BDT'=>'BD','AED'=>'AE','INR'=>'IN','NPR'=>'NP','BTN'=>'BT','VND'=>'VN','GBP'=>'GB'];
$countryCode = $regionSettings[$region]['phone'] ?: ($countryCode ?: '+1');

$allowedCodes = [
    '+880',
    '+91',
    '+977',
    '+975',
    '+84',
    '+1'
];

if (!in_array($countryCode, $allowedCodes, true)) {
    $countryCode = '+880';
}

if (!isset($_SESSION['ref_code']) && !empty($_GET['ref'])) $_SESSION['ref_code'] = trim((string)$_GET['ref']);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $password = $_POST['password'] ?? '';
    $confirmPassword = $_POST['confirm_password'] ?? '';

    if (mb_strlen($name) < 2) {

        $error = 'Enter your name.';

    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {

        $error = 'Enter a valid email address.';

    } elseif ($phoneNumber === '') {

        $error = 'Enter your phone number.';

    } elseif (strlen($password) < 6) {

        $error = 'Password must be at least 6 characters.';

    } elseif ($password !== $confirmPassword) {

        $error = 'Passwords do not match.';

    } else {

        // Remove spaces, brackets, hyphens etc.
        $phoneNumber = preg_replace('/\D+/', '', $phoneNumber);

        if ($phoneNumber === '') {

            $error = 'Enter a valid phone number.';

        } elseif (strlen($phoneNumber) < 6 || strlen($phoneNumber) > 15) {

            $error = 'Enter a valid phone number.';

        } else {

            $fullPhone = $countryCode . $phoneNumber;

            try {

                $pdo = db();

                /*
                 * Check email or phone already exists
                 */
                $check = $pdo->prepare(
                    'SELECT id, email, phone
                     FROM users
                     WHERE email = ? OR phone = ?
                     LIMIT 1'
                );

                $check->execute([
                    $email,
                    $fullPhone
                ]);

                $existing = $check->fetch();

                if ($existing) {

                    if (
                        isset($existing['email']) &&
                        strtolower($existing['email']) === strtolower($email)
                    ) {

                        $error =
                            'An account with this email already exists.';

                    } else {

                        $error =
                            'An account with this phone number already exists.';
                    }

                } else {

                    /*
                     * Create account immediately after the user confirms
                     * the registration form. Email OTP is intentionally skipped.
                     * Keep legacy OTP columns populated for compatibility with
                     * existing database schemas, but do not send or require OTP.
                     */
                    $passwordHash = password_hash($password, PASSWORD_DEFAULT);
                    $unusedOtp = (string) random_int(100000, 999999);
                    $otpHash = password_hash($unusedOtp, PASSWORD_DEFAULT);
                    $otpExpiresAt = date('Y-m-d H:i:s', time() + 600);

                    $insert = $pdo->prepare(
                        'INSERT INTO users
                        (
                            name,
                            email,
                            phone,
                            password_hash,
                            otp_hash,
                            otp_expires_at,
                            otp_attempts
                        )
                        VALUES (?, ?, ?, ?, ?, ?, ?)'
                    );

                    $insert->execute([
                        $name,
                        $email,
                        $fullPhone,
                        $passwordHash,
                        $otpHash,
                        $otpExpiresAt,
                        0
                    ]);

                    $userId = (int) $pdo->lastInsertId();

                    try {
                        $cols = $pdo->query('SHOW COLUMNS FROM users')->fetchAll(PDO::FETCH_ASSOC);
                        $hasCurrency = false;
                        foreach ($cols as $cc) {
                            if (($cc['Field'] ?? '') === 'currency') {
                                $hasCurrency = true;
                                break;
                            }
                        }
                        if ($hasCurrency) {
                            $up = $pdo->prepare('UPDATE users SET currency=? WHERE id=?');
                            $up->execute([$currency, $userId]);
                        }
                        try {
                            ensure_user_preference_columns();
                            $up2 = $pdo->prepare('UPDATE users SET country_code=?, language=? WHERE id=?');
                            $up2->execute([$regionSettings[$region]['country'], $regionSettings[$region]['language'], $userId]);
                        } catch (Throwable $ignoreCountry) {}
                    } catch (Throwable $currencyIgnore) {}

                    // Preserve referral attribution if a valid referral code exists.
                    try {
                        ensure_referral_tables();
                        $refCode = trim((string)($_SESSION['ref_code'] ?? ''));
                        if (preg_match('/^XT(\d+)$/i', $refCode, $m)) {
                            $referrerId = (int)$m[1];
                            if ($referrerId > 0 && $referrerId !== $userId) {
                                $chk = $pdo->prepare('SELECT id FROM users WHERE id=? LIMIT 1');
                                $chk->execute([$referrerId]);
                                if ($chk->fetch()) {
                                    $ir = $pdo->prepare('INSERT IGNORE INTO user_referrals (referrer_id,referred_user_id,created_at) VALUES (?,?,?)');
                                    $ir->execute([$referrerId, $userId, utc_sql_now()]);
                                }
                            }
                        }
                    } catch (Throwable $ignoreReferral) {}

                    session_regenerate_id(true);
                    $_SESSION['user_id'] = $userId;
                    $_SESSION['user_name'] = $name;
                    unset(
                        $_SESSION['pending_registration'],
                        $_SESSION['pending_otp_user_id'],
                        $_SESSION['pending_otp_email'],
                        $_SESSION['pending_otp_name'],
                        $_SESSION['pending_otp_phone']
                    );

                    header('Location: dashboard.php');
                    exit;
                }

            } catch (PDOException $e) {

                /*
                 * Duplicate email/phone
                 */
                if ((int)($e->errorInfo[1] ?? 0) === 1062) {

                    $error =
                        'This email or phone number is already registered.';

                } else {

                    /*
                     * Temporary debugging message
                     */
                    $error =
                        'DATABASE ERROR: ' .
                        $e->getMessage();
                }

            } catch (Throwable $e) {

                /*
                 * Temporary debugging message
                 */
                $error =
                    'ERROR: ' .
                    $e->getMessage();
            }
        }
    }
}
?>

<!doctype html>
<html lang="en">

<head>
<link rel="stylesheet" href="theme.php?v=20261022-lightfix3">

    <meta charset="utf-8">

    <meta
        name="viewport"
        content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no"
    >

    <title>XTREME TITAN</title>

    <link
        rel="stylesheet"
        href="style.css"
    >

    <style>

        .phone-group {
            display: flex;
            gap: 8px;
            width: 100%;
        }

        .phone-group select {
            height: 47px;
            min-width: 155px;
            border: 1px solid #d1d5db;
            border-radius: 11px;
            padding: 0 10px;
            background: #fff;
            color: #111827;
            font-size: 13px;
            outline: none;
        }

        .phone-group input {
            flex: 1;
            min-width: 0;
        }

        .phone-group select:focus {
            border-color: #6366f1;
            box-shadow: 0 0 0 3px rgba(99,102,241,.12);
        }

        @media (max-width: 500px) {

            .phone-group {
                gap: 6px;
            }

            .phone-group select {
                min-width: 140px;
                padding: 0 6px;
                font-size: 12px;
            }

        }

    </style>

<link rel="stylesheet" href="reference-auth.css">
<style>
.phone-group{display:flex!important;align-items:stretch!important;gap:8px!important}.phone-group select{flex:0 0 152px!important;width:152px!important;min-width:152px!important;height:58px!important;min-height:58px!important;padding:0 9px!important;font-size:12px!important;border-radius:14px!important;background:#070d17!important;color:#fff!important;border:1px solid rgba(130,153,190,.22)!important}.phone-group input{flex:1 1 auto!important;width:auto!important;min-width:0!important;height:58px!important;min-height:58px!important;font-size:15px!important}@media(max-width:380px){.phone-group{gap:6px!important}.phone-group select{flex-basis:142px!important;width:142px!important;min-width:142px!important;font-size:11px!important;padding:0 7px!important}}
</style>
<style>
/* Registration mobile sizing */
.auth-card{width:min(430px,calc(100% - 20px))!important;max-width:430px!important;padding:22px 16px!important;border-radius:23px!important;margin:16px auto!important}
.phone-group{display:flex!important;gap:8px!important;width:100%!important;align-items:stretch!important}
.phone-group select{flex:0 0 112px!important;width:112px!important;min-width:112px!important;font-size:14px!important;padding:12px 8px!important}
.phone-group input{flex:1 1 auto!important;min-width:0!important;font-size:15px!important}
.brand-logo-img{display:none!important}.brand-clean{text-align:center}.brand-clean .brand-name{font-size:24px;font-weight:1000}.brand-clean .brand-name span{color:#10d8ff}.brand-clean .brand-subtitle{color:#91a0b5;font-size:10px;margin-top:5px}
@media(max-width:380px){.auth-card{width:calc(100% - 14px)!important;padding:18px 12px!important}.phone-group{gap:6px!important}.phone-group select{flex-basis:104px!important;width:104px!important;min-width:104px!important;font-size:13px!important}.phone-group input{font-size:14px!important}}
.register-premium{position:relative}.register-premium:before{content:"";position:absolute;inset:-25px;border-radius:36px;background:radial-gradient(circle at 50% 0,rgba(16,216,255,.10),transparent 55%);pointer-events:none}.register-premium .auth-card{position:relative;background:linear-gradient(145deg,rgba(10,22,38,.96),rgba(5,11,21,.94))!important;border:1px solid rgba(16,216,255,.20)!important;box-shadow:0 28px 90px rgba(0,0,0,.52),0 0 40px rgba(16,216,255,.06)!important}.register-premium .eyebrow{color:#10d8ff!important}.register-premium .auth-card h1{background:linear-gradient(90deg,#fff,#10d8ff);-webkit-background-clip:text;background-clip:text;color:transparent}.register-premium .btn{background:linear-gradient(135deg,#10d8ff,#287cff 55%,#8b5cf6)!important}.register-premium .brand-name{font-size:25px!important;text-shadow:0 0 22px rgba(16,216,255,.16)}</style><style>.page{display:flex!important;flex-direction:column!important;align-items:center!important;min-height:100vh!important}.page .auth-card{flex:0 0 auto!important}.page footer{width:min(430px,calc(100% - 20px))!important;display:block!important;text-align:center!important;align-self:center!important;margin:8px auto 22px!important;padding:8px 10px!important;color:#7d8da5!important;font-size:10px!important;line-height:1.4!important;position:static!important;float:none!important;clear:both!important}.register-google{display:flex!important;justify-content:center!important;min-height:40px!important}.register-divider{width:100%!important;text-align:center!important}.page .brand{width:100%!important;text-align:center!important;float:none!important;align-self:center!important}</style><link rel="stylesheet" href="site-polish.css?v=20261022-lightfix3">
<script>
function handleGoogleCredential(response){if(!response||!response.credential){alert('Google did not return a login credential. Please try again.');return;}const body=new URLSearchParams();body.set('credential',response.credential);try{body.set('region',localStorage.getItem('xtreme_country')||document.getElementById('region')?.value||'BD')}catch(e){body.set('region',document.getElementById('region')?.value||'BD')}fetch('google-auth.php',{method:'POST',body:body.toString(),credentials:'same-origin',headers:{'Accept':'application/json','Content-Type':'application/x-www-form-urlencoded; charset=UTF-8'}}).then(async r=>{const raw=await r.text();let j;try{j=JSON.parse(raw);}catch(e){console.error('google-auth.php non-JSON response:',r.status,raw.slice(0,1000));throw new Error('Google Login server error (HTTP '+r.status+'). Response: '+raw.replace(/<[^>]*>/g,' ').replace(/\s+/g,' ').trim().slice(0,220));}if(j.ok){location.href='dashboard.php';return;}throw new Error(j.error||'Google Login failed.');}).catch(e=>alert(e.message||'Google Login failed. Please try again.'));}
</script><script>
</script>
<script src="theme-client.js?v=20261022-country" defer></script><link rel="stylesheet" href="premium-global.css?v=20261022-lightfix3"><script src="currency-client.js?v=20261022-country3" defer></script><script src="language-client.js?v=20261023-full-language-v50" defer></script><link rel="stylesheet" href="responsive-lock.css?v=20260929-28">
<link rel="stylesheet" href="auth-premium.css?v=20261022-1">
<link rel="icon" type="image/png" sizes="48x48" href="favicon.png"><link rel="apple-touch-icon" sizes="180x180" href="assets/pwa-icon-180.png"><link rel="manifest" href="pwa-manifest.json"><meta name="apple-mobile-web-app-title" content="XTREME TITAN"><meta name="apple-mobile-web-app-capable" content="yes"><meta name="theme-color" content="#080a14"><script src="/admin/admin-action-progress.js?v=20261023-inline-progress25" defer></script>

<link rel="stylesheet" href="pwa-install-prompt.css?v=1">
</head>

<body>

<div class="page register-premium">

    <div class="brand brand-clean">
        <img class="site-logo" src="assets/xtreme-titan-logo.jpg" alt="XTREME TITAN">
        <div class="brand-name">XTREME <span>TITAN</span> OFFICIAL</div>
        <div class="brand-subtitle">XTREME TITAN OFFICIAL — SECURE REGISTER</div>
    </div>


    <div class="auth-card">

        <div class="eyebrow">
            CREATE ACCOUNT
        </div>

        <h1>
            Register
        </h1>

        <p class="intro">
            Create your account and confirm to continue. No email code is required.
        </p>

        <label for="region" data-i18n="Select Country / Currency">Select Country / Currency</label>
        <div class="country-choice-grid" role="group" aria-label="Select country and currency">
          <button type="button" class="country-choice" data-region="BD" aria-pressed="false"><span class="country-flag">🇧🇩</span><span class="country-copy"><strong data-i18n="Bangladesh">Bangladesh</strong><small>BDT · বাংলা</small></span><span class="country-check">✓</span></button>
          <button type="button" class="country-choice" data-region="IN" aria-pressed="false"><span class="country-flag">🇮🇳</span><span class="country-copy"><strong data-i18n="India">India</strong><small>INR · हिन्दी</small></span><span class="country-check">✓</span></button>
          <button type="button" class="country-choice" data-region="NP" aria-pressed="false"><span class="country-flag">🇳🇵</span><span class="country-copy"><strong data-i18n="Nepal">Nepal</strong><small>NPR · नेपाली</small></span><span class="country-check">✓</span></button>
          <button type="button" class="country-choice" data-region="BT" aria-pressed="false"><span class="country-flag">🇧🇹</span><span class="country-copy"><strong data-i18n="Bhutan">Bhutan</strong><small>BTN · རྫོང་ཁ</small></span><span class="country-check">✓</span></button>
          <button type="button" class="country-choice" data-region="VN" aria-pressed="false"><span class="country-flag">🇻🇳</span><span class="country-copy"><strong data-i18n="Vietnam">Vietnam</strong><small>VND · Tiếng Việt</small></span><span class="country-check">✓</span></button>
          <button type="button" class="country-choice" data-region="OT" aria-pressed="false"><span class="country-flag">🌐</span><span class="country-copy"><strong data-i18n="Other">Other</strong><small>USD · English</small></span><span class="country-check">✓</span></button>
        </div>
        <select id="region" required aria-hidden="true" tabindex="-1" class="region-native-select" style="position:absolute!important;width:1px!important;height:1px!important;overflow:hidden!important;clip:rect(0,0,0,0)!important;white-space:nowrap!important;opacity:0!important;pointer-events:none!important">
          <option value="BD" <?= $region==='BD'?'selected':'' ?>>Bangladesh — BDT</option>
          <option value="IN" <?= $region==='IN'?'selected':'' ?>>India — INR</option>
          <option value="NP" <?= $region==='NP'?'selected':'' ?>>Nepal — NPR</option>
          <option value="BT" <?= $region==='BT'?'selected':'' ?>>Bhutan — BTN</option>
          <option value="VN" <?= $region==='VN'?'selected':'' ?>>Vietnam — VND</option>
          <option value="OT" <?= $region==='OT'?'selected':'' ?>>Other — USD</option>
        </select>


        <?php if ($error): ?>

            <div class="alert error">
                <?= e($error) ?>
            </div>

        <?php endif; ?>


        <form
            method="post"
            autocomplete="on"
            id="register-form"
        >
            <input type="hidden" name="region" id="region_post" value="<?= e($region) ?>">

            <label for="name">
                Name
            </label>

            <input
                id="name"
                type="text"
                name="name"
                value="<?= e($name) ?>"
                placeholder="Your name"
                required
                autocomplete="name"
            >


            <label for="email">
                Email address
            </label>

            <input
                id="email"
                type="email"
                name="email"
                value="<?= e($email) ?>"
                placeholder="you@example.com"
                required
                autocomplete="email"
            >


            <label for="phone">
                Phone Number
            </label>

            <div class="phone-group">

                <select
                    name="country_code"
                    id="country_code"
                    required
                >

                    <option
                        value="+880"
                        <?= $countryCode === '+880' ? 'selected' : '' ?>
                    >
                        🇧🇩 Bangladesh (+880)
                    </option>

                    <option
                        value="+91"
                        <?= $countryCode === '+91' ? 'selected' : '' ?>
                    >
                        🇮🇳 India (+91)
                    </option>

                    <option
                        value="+977"
                        <?= $countryCode === '+977' ? 'selected' : '' ?>
                    >
                        🇳🇵 Nepal (+977)
                    </option>

                    <option value="+975" <?= $countryCode === '+975' ? 'selected' : '' ?>>🇧🇹 Bhutan (+975)</option>
                    <option
                        value="+84"
                        <?= $countryCode === '+84' ? 'selected' : '' ?>
                    >
                        🇻🇳 Vietnam (+84)
                    </option>
                    <option value="+1" <?= $countryCode === '+1' ? 'selected' : '' ?>>🌐 Other (+1)</option>

                </select>


                <input
                    id="phone"
                    type="tel"
                    name="phone"
                    value="<?= e($phoneNumber) ?>"
                    placeholder="Phone number"
                    required
                    autocomplete="tel"
                    inputmode="numeric"
                >

            </div>

            <label for="password">
                Password
            </label>

            <input
                id="password"
                type="password"
                name="password"
                placeholder="Create a password"
                minlength="6"
                required
                autocomplete="new-password"
            >


            <label for="confirm_password">
                Confirm password
            </label>

            <input
                id="confirm_password"
                type="password"
                name="confirm_password"
                placeholder="Repeat your password"
                minlength="6"
                required
                autocomplete="new-password"
            >


            <button
                class="btn"
                type="submit"
            >
                Create account
            </button>

        </form>
        <div class="register-divider"><span>OR</span></div>
        <div id="g_id_onload" data-client_id="865419675972-n8g84i701iu6ngui7c9auvoqv889v17n.apps.googleusercontent.com" data-callback="handleGoogleCredential" data-auto_prompt="false" data-auto_select="false" data-nonce="<?=h((string)($_SESSION['google_login_nonce']??''))?>"></div>
        <div class="google-button-shell"><button type="button" class="google-region-proxy" id="google-region-proxy"><svg class="google-g-mark" aria-hidden="true" viewBox="0 0 48 48"><path fill="#EA4335" d="M24 9.5c3.54 0 6.71 1.22 9.21 3.6l6.85-6.85C35.9 2.38 30.47 0 24 0 14.62 0 6.51 5.38 2.56 13.22l7.98 6.19C12.43 13.72 17.74 9.5 24 9.5z"/><path fill="#4285F4" d="M46.98 24.55c0-1.57-.15-3.09-.38-4.55H24v9.02h12.94c-.58 2.96-2.26 5.48-4.74 7.18l7.65 5.93c4.47-4.13 7.13-10.2 7.13-17.58z"/><path fill="#FBBC05" d="M10.53 28.59A14.4 14.4 0 0 1 9.75 24c0-1.59.27-3.13.76-4.59l-7.98-6.19A23.9 23.9 0 0 0 0 24c0 3.87.93 7.52 2.56 10.78l7.97-6.19z"/><path fill="#34A853" d="M24 48c6.48 0 11.93-2.13 15.9-5.87l-7.65-5.93c-2.12 1.42-4.84 2.26-8.25 2.26-6.26 0-11.57-4.22-13.47-9.91l-7.98 6.19C6.51 42.62 14.62 48 24 48z"/></svg><span>Continue with Google</span></button><div class="g_id_signin register-google" data-type="standard" data-shape="rectangular" data-theme="outline" data-text="continue_with" data-size="large" data-width="320"></div></div>



        <div class="links">

            Already have an account?

            <a href="login.php">
                Sign in
            </a>

        </div>

    </div>


    <div style="text-align:center;margin:8px auto 0;font-size:10px"><a href="reseller-login.php" style="color:#c084fc;text-decoration:none;font-weight:900">Reseller Login</a> · <a href="reseller-register.php" style="color:#c084fc;text-decoration:none;font-weight:900">Reseller Register</a></div><footer>
        © <?= date('Y') ?> XTREME_TITAN_OFFICIAL SHOP
    </footer>

</div>

<style>
.country-choice-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:10px;margin:10px 0 22px}
.country-choice{display:flex;align-items:center;gap:10px;position:relative;min-width:0;min-height:72px;padding:12px;border:1px solid rgba(135,153,185,.30);border-radius:16px;background:linear-gradient(145deg,rgba(8,15,29,.96),rgba(13,23,41,.96));color:#eaf2ff;text-align:left;cursor:pointer;transition:border-color .18s,background .18s,box-shadow .18s,transform .18s}
.country-choice:active{transform:scale(.985)}.country-choice[aria-pressed="true"]{border:2px solid #10d8ff;background:linear-gradient(145deg,rgba(5,87,111,.65),rgba(14,39,65,.98));box-shadow:0 0 0 3px rgba(16,216,255,.10),0 8px 24px rgba(16,216,255,.12)}
.country-flag{font-size:26px;flex:0 0 auto}.country-copy{display:flex;flex-direction:column;gap:4px;min-width:0}.country-copy strong{font-size:14px;font-weight:850;line-height:1.2}.country-copy small{font-size:11px;color:#9eafc8;font-weight:750}.country-check{margin-left:auto;display:grid;place-items:center;width:21px;height:21px;flex:0 0 21px;border:1px solid #58667c;border-radius:50%;font-size:12px;color:transparent}.country-choice[aria-pressed="true"] .country-check{background:#10d8ff;border-color:#10d8ff;color:#061321}
@media(max-width:360px){.country-choice-grid{gap:7px}.country-choice{padding:9px;gap:7px;min-height:66px}.country-copy strong{font-size:12px}.country-copy small{font-size:10px}.country-flag{font-size:22px}}
</style>
<script>
(function(){
 'use strict';
 const sel=document.getElementById('region'),phone=document.getElementById('country_code'),post=document.getElementById('region_post');
 if(!sel)return;
 const meta={BD:{currency:'BDT',language:'bn',country:'BD',phone:'+880'},IN:{currency:'INR',language:'hi',country:'IN',phone:'+91'},NP:{currency:'NPR',language:'ne',country:'NP',phone:'+977'},BT:{currency:'BTN',language:'dz',country:'BT',phone:'+975'},VN:{currency:'VND',language:'vi',country:'VN',phone:'+84'},OT:{currency:'USD',language:'en',country:'OT',phone:'+1'}};
 const dictionaries={
  en:{'Create Account':'Create Account','Create account':'Create account','Register':'Register','Create your account. We\'ll send a 6-digit code to verify your email.':'Create your account. We\'ll send a 6-digit code to verify your email.','Select Country / Currency':'Select Country / Currency','Name':'Name','Email address':'Email address','Phone Number':'Phone Number','Password':'Password','Confirm password':'Confirm password','Your name':'Your name','you@example.com':'you@example.com','Phone number':'Phone number','Create a password':'Create a password','Repeat your password':'Repeat your password','Already have an account?':'Already have an account?','Sign in':'Sign in','Reseller Login':'Reseller Login','Reseller Register':'Reseller Register','OR':'OR','Bangladesh':'Bangladesh','India':'India','Nepal':'Nepal','Bhutan':'Bhutan','Vietnam':'Vietnam','Other':'Other','CREATE ACCOUNT':'CREATE ACCOUNT','XTREME TITAN OFFICIAL — SECURE REGISTER':'XTREME TITAN OFFICIAL — SECURE REGISTER'},
  bn:{'Create Account':'অ্যাকাউন্ট তৈরি করুন','Create account':'অ্যাকাউন্ট তৈরি করুন','Register':'রেজিস্ট্রেশন','Create your account. We\'ll send a 6-digit code to verify your email.':'আপনার অ্যাকাউন্ট তৈরি করুন। ইমেইল যাচাই করতে ৬ সংখ্যার কোড পাঠানো হবে।','Select Country / Currency':'দেশ / মুদ্রা নির্বাচন করুন','Name':'নাম','Email address':'ইমেইল ঠিকানা','Phone Number':'ফোন নম্বর','Password':'পাসওয়ার্ড','Confirm password':'পাসওয়ার্ড নিশ্চিত করুন','Your name':'আপনার নাম','you@example.com':'আপনার ইমেইল','Phone number':'ফোন নম্বর','Create a password':'পাসওয়ার্ড তৈরি করুন','Repeat your password':'পাসওয়ার্ড আবার লিখুন','Already have an account?':'আগে থেকেই অ্যাকাউন্ট আছে?','Sign in':'লগইন','Reseller Login':'রিসেলার লগইন','Reseller Register':'রিসেলার রেজিস্ট্রেশন','OR':'অথবা','Bangladesh':'বাংলাদেশ','India':'ভারত','Nepal':'নেপাল','Bhutan':'ভুটান','Vietnam':'ভিয়েতনাম','Other':'অন্যান্য','CREATE ACCOUNT':'অ্যাকাউন্ট তৈরি করুন','XTREME TITAN OFFICIAL — SECURE REGISTER':'XTREME TITAN OFFICIAL — নিরাপদ রেজিস্ট্রেশন'},
  hi:{'Create Account':'खाता बनाएं','Create account':'खाता बनाएं','Register':'रजिस्टर करें','Create your account. We\'ll send a 6-digit code to verify your email.':'अपना खाता बनाएं। ईमेल सत्यापित करने के लिए 6 अंकों का कोड भेजा जाएगा।','Select Country / Currency':'देश / मुद्रा चुनें','Name':'नाम','Email address':'ईमेल पता','Phone Number':'फ़ोन नंबर','Password':'पासवर्ड','Confirm password':'पासवर्ड की पुष्टि करें','Your name':'अपना नाम','you@example.com':'आपका ईमेल','Phone number':'फ़ोन नंबर','Create a password':'पासवर्ड बनाएं','Repeat your password':'पासवर्ड दोबारा लिखें','Already have an account?':'पहले से खाता है?','Sign in':'साइन इन','Reseller Login':'रीसेलर लॉगिन','Reseller Register':'रीसेलर रजिस्ट्रेशन','OR':'या','Bangladesh':'बांग्लादेश','India':'भारत','Nepal':'नेपाल','Bhutan':'भूटान','Vietnam':'वियतनाम','Other':'अन्य','CREATE ACCOUNT':'खाता बनाएं','XTREME TITAN OFFICIAL — SECURE REGISTER':'XTREME TITAN OFFICIAL — सुरक्षित पंजीकरण'},
  ne:{'Create Account':'खाता बनाउनुहोस्','Create account':'खाता बनाउनुहोस्','Register':'दर्ता गर्नुहोस्','Create your account. We\'ll send a 6-digit code to verify your email.':'आफ्नो खाता बनाउनुहोस्। इमेल प्रमाणित गर्न ६ अङ्कको कोड पठाइनेछ।','Select Country / Currency':'देश / मुद्रा छान्नुहोस्','Name':'नाम','Email address':'इमेल ठेगाना','Phone Number':'फोन नम्बर','Password':'पासवर्ड','Confirm password':'पासवर्ड पुष्टि गर्नुहोस्','Your name':'आफ्नो नाम','you@example.com':'तपाईंको इमेल','Phone number':'फोन नम्बर','Create a password':'पासवर्ड बनाउनुहोस्','Repeat your password':'पासवर्ड फेरि लेख्नुहोस्','Already have an account?':'पहिले नै खाता छ?','Sign in':'साइन इन','Reseller Login':'रिसेलर लगइन','Reseller Register':'रिसेलर दर्ता','OR':'वा','Bangladesh':'बंगलादेश','India':'भारत','Nepal':'नेपाल','Bhutan':'भुटान','Vietnam':'भियतनाम','Other':'अन्य','CREATE ACCOUNT':'खाता बनाउनुहोस्'},
  dz:{'Create Account':'རྩིས་ཐོ་བཟོ།','Create account':'རྩིས་ཐོ་བཟོ།','Register':'ཐོ་འགོད།','Create your account. We\'ll send a 6-digit code to verify your email.':'ཁྱེད་ཀྱི་རྩིས་ཐོ་བཟོ། གློག་འཕྲིན་བདེན་དཔང་བྱེད་ནིའི་ཨང་དྲུག་གི་ཨང་རྟགས་བསྐུར་འོང་།','Select Country / Currency':'རྒྱལ་ཁབ་ / དངུལ་ལོར་འདེམས།','Name':'མིང་།','Email address':'གློག་འཕྲིན་ཁ་བྱང་།','Phone Number':'ཁ་པར་ཨང་།','Password':'གསང་ཚིག','Confirm password':'གསང་ཚིག་ངོས་འཛིན།','Your name':'ཁྱེད་ཀྱི་མིང་།','you@example.com':'ཁྱེད་ཀྱི་གློག་འཕྲིན།','Phone number':'ཁ་པར་ཨང་།','Create a password':'གསང་ཚིག་བཟོ།','Repeat your password':'གསང་ཚིག་སླར་འབྲི།','Already have an account?':'རྩིས་ཐོ་ཡོད་དམ།','Sign in':'ནང་འཛུལ།','Reseller Login':'བསྐྱར་ཚོང་ནང་འཛུལ།','Reseller Register':'བསྐྱར་ཚོང་ཐོ་འགོད།','OR':'ཡང་ན།','Bangladesh':'བང་ལ་དེཤ','India':'རྒྱ་གར།','Nepal':'བལ་ཡུལ།','Bhutan':'འབྲུག','Vietnam':'ཝིཏ་ནམ།','Other':'གཞན།','CREATE ACCOUNT':'རྩིས་ཐོ་བཟོ།','XTREME TITAN OFFICIAL — SECURE REGISTER':'XTREME TITAN OFFICIAL — ཉེན་མེད་ཐོ་འགོད།'},
  vi:{'Create Account':'Tạo tài khoản','Create account':'Tạo tài khoản','Register':'Đăng ký','Create your account. We\'ll send a 6-digit code to verify your email.':'Tạo tài khoản của bạn. Chúng tôi sẽ gửi mã 6 chữ số để xác minh email.','Select Country / Currency':'Chọn quốc gia / tiền tệ','Name':'Họ tên','Email address':'Địa chỉ email','Phone Number':'Số điện thoại','Password':'Mật khẩu','Confirm password':'Xác nhận mật khẩu','Your name':'Tên của bạn','you@example.com':'email@vidu.com','Phone number':'Số điện thoại','Create a password':'Tạo mật khẩu','Repeat your password':'Nhập lại mật khẩu','Already have an account?':'Bạn đã có tài khoản?','Sign in':'Đăng nhập','Reseller Login':'Đăng nhập đại lý','Reseller Register':'Đăng ký đại lý','OR':'HOẶC','Bangladesh':'Bangladesh','India':'Ấn Độ','Nepal':'Nepal','Bhutan':'Bhutan','Vietnam':'Việt Nam','Other':'Khác','CREATE ACCOUNT':'TẠO TÀI KHOẢN','XTREME TITAN OFFICIAL — SECURE REGISTER':'XTREME TITAN OFFICIAL — ĐĂNG KÝ AN TOÀN'}
 };
 const originals=new WeakMap();
 function translate(){const l=(meta[sel.value]||meta.BD).language,d=dictionaries[l]||dictionaries.en;document.documentElement.lang=l;document.documentElement.dir='ltr';
  const walker=document.createTreeWalker(document.body,NodeFilter.SHOW_TEXT);const nodes=[];while(walker.nextNode())nodes.push(walker.currentNode);nodes.forEach(n=>{if(!originals.has(n))originals.set(n,n.nodeValue);const orig=originals.get(n),trim=orig.trim();if(d[trim])n.nodeValue=orig.replace(trim,d[trim]);});
  document.querySelectorAll('[placeholder]').forEach(el=>{if(!el.dataset.originalPlaceholder)el.dataset.originalPlaceholder=el.getAttribute('placeholder');const v=el.dataset.originalPlaceholder;if(d[v])el.setAttribute('placeholder',d[v]);});
  document.querySelectorAll('[data-i18n]').forEach(el=>{const k=el.dataset.i18n;if(d[k])el.textContent=d[k];});
 }
 function apply(){const m=meta[sel.value]||meta.BD;try{localStorage.setItem('xtreme_currency',m.currency);localStorage.setItem('xtreme_country',m.country);localStorage.setItem('xtreme_language',m.language);}catch(e){}if(post)post.value=sel.value;if(phone&&m.phone){phone.value=m.phone;}document.documentElement.lang=m.language;document.querySelectorAll('.country-choice').forEach(b=>b.setAttribute('aria-pressed',b.dataset.region===sel.value?'true':'false'));translate();window.dispatchEvent(new Event('xtreme-currency-change'));window.dispatchEvent(new Event('xtreme-language-change'));}
 document.querySelectorAll('.country-choice').forEach(b=>b.addEventListener('click',()=>{sel.value=b.dataset.region;apply();}));sel.addEventListener('change',apply);window.addEventListener('xtreme-language-change',translate);apply();
})();
</script>
<link rel="stylesheet" href="auth-region-picker.css?v=20261022-official-google-button-fix2"><script src="auth-region-picker.js?v=20261022-official-google-button-fix2" defer></script>

<script src="pwa-install-prompt.js?v=1" defer></script>

<style>
/* XTREME TITAN premium registration confirmation */
.xt-confirm-backdrop{position:fixed;inset:0;z-index:99999;display:none;align-items:center;justify-content:center;padding:22px;background:rgba(2,5,14,.78);backdrop-filter:blur(12px);-webkit-backdrop-filter:blur(12px)}
.xt-confirm-backdrop.is-open{display:flex;animation:xtFadeIn .18s ease-out}
.xt-confirm-dialog{width:min(100%,420px);position:relative;overflow:hidden;border:1px solid rgba(28,220,255,.42);border-radius:25px;padding:27px 23px 22px;background:radial-gradient(ellipse at top,rgba(23,106,151,.22),transparent 55%),linear-gradient(150deg,#10182b 0%,#080d19 62%,#130d27 100%);box-shadow:0 0 0 1px rgba(155,95,255,.13),0 24px 80px rgba(0,0,0,.62),0 0 34px rgba(0,198,255,.13);color:#f3f7ff;font-family:inherit;text-align:center}
.xt-confirm-dialog:before{content:"";position:absolute;top:0;left:14%;right:14%;height:2px;background:linear-gradient(90deg,transparent,#16dfff,#a66cff,transparent)}
.xt-confirm-icon{width:62px;height:62px;margin:0 auto 15px;border-radius:19px;display:grid;place-items:center;font-size:29px;color:#20e4ff;background:linear-gradient(145deg,rgba(14,208,255,.16),rgba(143,74,255,.18));border:1px solid rgba(36,219,255,.36);box-shadow:0 0 24px rgba(16,205,255,.12)}
.xt-confirm-title{font-size:21px;line-height:1.25;font-weight:950;letter-spacing:.045em;margin:0 0 10px;color:#fff}
.xt-confirm-copy{font-size:14px;line-height:1.65;color:#b9c8df;margin:0 auto 23px;max-width:320px}
.xt-confirm-copy strong{color:#50e8ff}
.xt-confirm-actions{display:grid;grid-template-columns:1fr 1fr;gap:11px}
.xt-confirm-btn{appearance:none;border-radius:13px;min-height:48px;padding:12px 10px;font:900 13px/1.2 inherit;letter-spacing:.06em;cursor:pointer;transition:transform .15s,filter .15s}
.xt-confirm-btn:active{transform:scale(.975)}
.xt-confirm-yes{color:#04121d;border:1px solid #43eaff;background:linear-gradient(110deg,#20dfff,#4b9dff);box-shadow:0 7px 22px rgba(24,196,255,.22)}
.xt-confirm-no{color:#d7e2f4;border:1px solid rgba(153,174,207,.34);background:linear-gradient(145deg,rgba(34,46,67,.9),rgba(18,25,42,.95))}
.xt-confirm-note{margin:15px 0 0;color:#7386a4;font-size:10px;line-height:1.45}
@keyframes xtFadeIn{from{opacity:0}to{opacity:1}}
@media(prefers-reduced-motion:reduce){.xt-confirm-backdrop.is-open{animation:none}.xt-confirm-btn{transition:none}}
</style>
<div class="xt-confirm-backdrop" id="xt-confirm-backdrop" aria-hidden="true">
  <section class="xt-confirm-dialog" role="dialog" aria-modal="true" aria-labelledby="xt-confirm-title" aria-describedby="xt-confirm-copy">
    <div class="xt-confirm-icon" aria-hidden="true">✦</div>
    <h2 class="xt-confirm-title" id="xt-confirm-title">CONFIRM YOUR REGISTRATION</h2>
    <p class="xt-confirm-copy" id="xt-confirm-copy">Are you ready to create your <strong>XTREME TITAN</strong> account? Confirm to continue, or cancel to review your details.</p>
    <div class="xt-confirm-actions">
      <button type="button" class="xt-confirm-btn xt-confirm-no" id="xt-confirm-cancel">CANCEL</button>
      <button type="button" class="xt-confirm-btn xt-confirm-yes" id="xt-confirm-ok">CONFIRM</button>
    </div>
    <p class="xt-confirm-note">Please make sure your registration details are correct.</p>
  </section>
</div>
<script>
(function(){
  'use strict';
  const form=document.getElementById('register-form');
  const modal=document.getElementById('xt-confirm-backdrop');
  const yes=document.getElementById('xt-confirm-ok');
  const no=document.getElementById('xt-confirm-cancel');
  if(!form||!modal||!yes||!no)return;
  let confirmed=false, previousFocus=null;
  function closeModal(){modal.classList.remove('is-open');modal.setAttribute('aria-hidden','true');document.body.style.overflow='';if(previousFocus&&previousFocus.focus)previousFocus.focus();}
  form.addEventListener('submit',function(event){
    if(confirmed){confirmed=false;return;}
    event.preventDefault();previousFocus=document.activeElement;modal.classList.add('is-open');modal.setAttribute('aria-hidden','false');document.body.style.overflow='hidden';yes.focus();
  });
  yes.addEventListener('click',function(){confirmed=true;closeModal();if(typeof form.requestSubmit==='function')form.requestSubmit();else form.submit();});
  no.addEventListener('click',closeModal);
  modal.addEventListener('click',function(event){if(event.target===modal)closeModal();});
  document.addEventListener('keydown',function(event){if(event.key==='Escape'&&modal.classList.contains('is-open'))closeModal();});
})();
</script>

</body>

</html>