<?php
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/topup-lib.php';
require_login();
try { xt_user_notification_tables(); } catch (Throwable $ignore) {}

if (empty($_SESSION['deposit_csrf'])) {
    $_SESSION['deposit_csrf'] = bin2hex(random_bytes(32));
}
$depositCsrf = $_SESSION['deposit_csrf'];

$error = '';
$success = '';

if (isset($_GET['success']) && $_GET['success'] === '1') {
    $success = 'Add Funds request submitted successfully. It is now waiting for approval.';
}

$name = $_SESSION['user_name'] ?? 'User';
$initial = strtoupper(mb_substr($name, 0, 1));

$amount = '';
$prefs = current_user_preferences();
$currencyCode = $prefs['currency'];
$countryCode = $prefs['country'];
$isBangladesh = ($countryCode === 'BD' || $currencyCode === 'BDT');
$paymentMethod = $isBangladesh ? 'bKash' : 'PayPal';
$transactionId = '';

$site = site_settings();
$paymentNumber = site_setting('payment_number', '');
$bkashNumber = site_setting('bkash_number', $paymentNumber);
$rocketNumber = site_setting('rocket_number', '');
$nagadNumber = site_setting('nagad_number', $paymentNumber);
$paypalMe = site_setting('paypal_me', 'https://www.paypal.me/xtremetitanofficial');
$paymentNotice = trim((string)site_setting('payment_notice_text', ''));
$bkashPaymentNotice = 'For bKash deposits, select Send Money only. Do not select Mobile Recharge, Cash Out, or Payment. Then follow the secure Paymently checkout instructions.';
$nagadPaymentNotice = 'For Nagad deposits, select Send Money only. Do not select Mobile Recharge, Cash Out, or Payment. Then follow the secure Paymently checkout instructions.';
$bkashGuideImage = trim((string)site_setting('bkash_payment_guide_image', 'assets/bkash-payment-option-guide.jpg'));
$nagadGuideImage = trim((string)site_setting('nagad_payment_guide_image', ''));
if ($paypalMe === '') { $paypalMe = 'https://www.paypal.me/xtremetitanofficial'; }
$bkashLogo = site_setting('payment_bkash_logo', 'assets/payment-bkash-premium.png');
$rocketLogo = site_setting('payment_rocket_logo', '');
$nagadLogo = site_setting('payment_nagad_logo', 'assets/payment-nagad-premium.png');
$paypalLogo = site_setting('payment_paypal_logo', 'assets/payment-paypal-premium.svg');
$binancePayId = site_setting('binance_pay_id', '1224732977');
$binanceLogo = site_setting('payment_binance_logo', 'assets/binance-pay.svg');
$binanceQr = site_setting('payment_binance_qr', '');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $postedCsrf = (string)($_POST['csrf'] ?? '');
    $paymentMethod = trim((string)($_POST['payment_method'] ?? ''));
    $amount = trim((string)($_POST['amount'] ?? ''));
    $postedCurrency = strtoupper(trim((string)($_POST['currency_code'] ?? $prefs['currency'])));
    $allowedDepositCurrencies = ['USD','EUR','BDT','AED','INR','NPR','BTN','VND','GBP'];
    if (!in_array($postedCurrency, $allowedDepositCurrencies, true)) $postedCurrency = $prefs['currency'];
    $currencyCode = $postedCurrency;
    $isBangladesh = ($currencyCode === 'BDT');
    $transactionId = trim((string)($_POST['transaction_id'] ?? ''));

    try {
        if (!hash_equals($depositCsrf, $postedCsrf)) {
            throw new RuntimeException('Your form session expired. Please refresh the page and try again.');
        }
        $allowedMethods = ($currencyCode === 'BDT') ? ['bKash','Nagad','Binance Pay'] : ['PayPal','Binance Pay'];
        if (!in_array($paymentMethod, $allowedMethods, true)) {
            throw new RuntimeException('Please select a payment method.');
        }
        if ($amount === '' || !is_numeric($amount) || (float)$amount <= 0) {
            throw new RuntimeException('Please enter a valid deposit amount.');
        }
        if ((float)$amount > 1000000) {
            throw new RuntimeException('Deposit amount is too large.');
        }
        // bKash and Nagad use the secure Paymently checkout. Show a separate
        // confirmation/instructions screen first; never request a manual TXN ID.
        if (in_array($paymentMethod, ['bKash','Nagad'], true)) {
            if ($currencyCode !== 'BDT') throw new RuntimeException('bKash and Nagad are available for BDT only.');
            $_SESSION['xt_paymently_pending'] = [
                'method' => $paymentMethod,
                'amount' => number_format((float)$amount, 2, '.', ''),
                'created' => time()
            ];
            header('Location: deposit.php?payment_notice=1');
            exit;
        }
        if (!in_array($paymentMethod, ['Binance Pay','PayPal'], true)) {
            throw new RuntimeException('Please select a supported payment method.');
        }
        if ($transactionId === '' || strlen($transactionId) > 150) {
            throw new RuntimeException('Please enter a valid transaction ID/reference.');
        }
        $receiptRelative = null;
        if (!isset($_FILES['receipt_file']) || (int)($_FILES['receipt_file']['error'] ?? UPLOAD_ERR_NO_FILE) === UPLOAD_ERR_NO_FILE) throw new RuntimeException('Please upload your payment screenshot.');
        if (isset($_FILES['receipt_file']) && (int)($_FILES['receipt_file']['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_NO_FILE) {
            $file = $_FILES['receipt_file'];
            if ((int)$file['error'] !== UPLOAD_ERR_OK) throw new RuntimeException('The payment screenshot could not be uploaded. Please try again.');
            if ((int)$file['size'] < 1 || (int)$file['size'] > 5 * 1024 * 1024) throw new RuntimeException('Payment screenshot must be 5 MB or smaller.');
            $finfo = new finfo(FILEINFO_MIME_TYPE); $mime = $finfo->file($file['tmp_name']);
            $extensions = ['image/jpeg'=>'jpg','image/png'=>'png','image/webp'=>'webp'];
            if (!isset($extensions[$mime])) throw new RuntimeException('Upload a JPG, PNG or WebP payment screenshot.');
            $uploadDir = __DIR__ . '/uploads/deposits';
            if (!is_dir($uploadDir) && !mkdir($uploadDir, 0755, true) && !is_dir($uploadDir)) throw new RuntimeException('Screenshot storage is unavailable. Please contact support.');
            if (!is_file($uploadDir . '/.htaccess')) @file_put_contents($uploadDir . '/.htaccess', "Options -Indexes\n<FilesMatch \"\\.(php|phtml|phar)$\">\nDeny from all\n</FilesMatch>\n");
            $safeName = 'deposit_' . (int)($_SESSION['user_id'] ?? 0) . '_' . bin2hex(random_bytes(12)) . '.' . $extensions[$mime];
            if (!move_uploaded_file($file['tmp_name'], $uploadDir . '/' . $safeName)) throw new RuntimeException('Could not save the payment screenshot. Please try again.');
            $receiptRelative = 'uploads/deposits/' . $safeName;
        }

        $pdo = db();
        try { $pdo->exec("SET time_zone = '+00:00'"); } catch (Throwable $ignore) {}

        // Make the existing deposits table tolerant of the optional receipt field.
        try {
            $cols = $pdo->query('SHOW COLUMNS FROM deposits')->fetchAll(PDO::FETCH_COLUMN);
        } catch (Throwable $e) {
            throw new RuntimeException('The deposits table could not be read. Please contact the administrator.');
        }
        if (!in_array('receipt_path', $cols, true)) {
            try { $pdo->exec("ALTER TABLE deposits ADD COLUMN receipt_path VARCHAR(255) NULL"); } catch (Throwable $ignore) {}
            $cols = $pdo->query('SHOW COLUMNS FROM deposits')->fetchAll(PDO::FETCH_COLUMN);
        }
        if (!in_array('receipt_path', $cols, true)) throw new RuntimeException('Screenshot storage is not available in the deposits table. Please contact the administrator.');
        $metadataColumns = [
            'currency_code' => "ALTER TABLE deposits ADD COLUMN currency_code VARCHAR(10) NULL",
            'amount_bdt' => "ALTER TABLE deposits ADD COLUMN amount_bdt DECIMAL(14,2) NULL",
            'source_role' => "ALTER TABLE deposits ADD COLUMN source_role VARCHAR(20) NULL",
            'deposit_country' => "ALTER TABLE deposits ADD COLUMN deposit_country VARCHAR(8) NULL"
        ];
        foreach ($metadataColumns as $column => $ddl) { if (!in_array($column, $cols, true)) { try { $pdo->exec($ddl); } catch (Throwable $ignore) {} } }
        $cols = $pdo->query('SHOW COLUMNS FROM deposits')->fetchAll(PDO::FETCH_COLUMN);

        if (!in_array($paymentMethod, $allowedMethods, true)) {
            throw new RuntimeException('This payment method is not available for your selected country/currency.');
        }

        $amountDb = number_format((float)$amount, 2, '.', '');
        // Wallet and product prices use BDT as the internal base currency. Preserve the submitted amount/currency for admin review, and store a BDT equivalent for wallet credit and the reseller $50 threshold.
        $bdtPerUnit = ['BDT'=>1.0,'USD'=>122.0,'EUR'=>133.33,'AED'=>33.22,'INR'=>1.77,'NPR'=>0.88,'BTN'=>1.77,'VND'=>0.0049,'GBP'=>154.0];
        $amountBdt = round((float)$amount * ($bdtPerUnit[$currencyCode] ?? 1.0), 2);
        $hasCreatedAt = in_array('created_at', $cols, true);
        $hasCurrency = in_array('currency_code', $cols, true);
        $hasAmountBdt = in_array('amount_bdt', $cols, true);
        $hasSourceRole = in_array('source_role', $cols, true);
        $hasDepositCountry = in_array('deposit_country', $cols, true);
        $now = utc_sql_now();
        $userId = (int)($_SESSION['user_id'] ?? 0);
        if ($userId <= 0) throw new RuntimeException('Your login session is no longer valid. Please sign in again.');
        $role = current_user_role();
        $columns = ['user_id','amount','status','payment_method','transaction_id'];
        $values = ['?','?',"'pending'",'?','?'];
        $params = [$userId,$amountDb,$paymentMethod,$transactionId];
        if ($receiptRelative !== null && in_array('receipt_path', $cols, true)) { $columns[]='receipt_path'; $values[]='?'; $params[]=$receiptRelative; }
        if ($hasCurrency) { $columns[]='currency_code'; $values[]='?'; $params[]=$currencyCode; }
        if ($hasAmountBdt) { $columns[]='amount_bdt'; $values[]='?'; $params[]=number_format($amountBdt,2,'.',''); }
        if ($hasSourceRole) { $columns[]='source_role'; $values[]='?'; $params[]=$role; }
        if ($hasDepositCountry) { $columns[]='deposit_country'; $values[]='?'; $params[]=$prefs['country'] ?? 'OT'; }
        if ($hasCreatedAt) { $columns[]='created_at'; $values[]='?'; $params[]=$now; }
        $sql = 'INSERT INTO deposits (' . implode(',', $columns) . ') VALUES (' . implode(',', $values) . ')';
        $stmt = $pdo->prepare($sql); $stmt->execute($params);
        notify_admin('new_deposit', 'New Deposit Request', 'A customer submitted a deposit request of ' . $amountDb . ' ' . $currencyCode . ' via ' . $paymentMethod . '.', 'deposits.php');
        xt_user_notify($userId,'deposit_pending','Deposit request received','Your deposit request for '.number_format((float)$amountDb,2).' '.$currencyCode.' is waiting for admin approval.','history.php?tab=deposit');

        header('Location: deposit.php?success=1');
        exit;
    } catch (Throwable $e) {
        // Show a useful user-facing message but never expose credentials/SQL details.
        $error = $e->getMessage() ?: 'Unable to submit the deposit request. Please try again.';
    }
}
?>
<?php if (!empty($_GET['payment_notice']) && !empty($_SESSION['xt_paymently_pending'])):
    $pending = $_SESSION['xt_paymently_pending'];
    if (time() - (int)($pending['created'] ?? 0) > 900) { unset($_SESSION['xt_paymently_pending']); header('Location: deposit.php'); exit; }
    if (empty($_SESSION['uddokta_csrf'])) $_SESSION['uddokta_csrf'] = bin2hex(random_bytes(32));
    $noticeMethod = (string)$pending['method'];
    $noticeAmount = (string)$pending['amount'];
    $noticeCreated = (int)($pending['created'] ?? time());
    $noticeUserId = (int)($_SESSION['user_id'] ?? 0);
    $noticeSignature = hash_hmac('sha256', $noticeUserId.'|'.(string)$pending['method'].'|'.$noticeAmount.'|'.$noticeCreated, DB_PASS);
    $isBkashNotice = ($noticeMethod === 'bKash');
    $noticeHeading = $isBkashNotice ? 'bKash payment instructions' : 'Nagad payment instructions';
    $noticeIntro = $isBkashNotice
        ? 'Follow these instructions when sending money with bKash.'
        : 'Follow these instructions when sending money with Nagad.';
    $noticeWarningTitle = $isBkashNotice ? 'Important: use Send Money only. Do not use Mobile Recharge, Cash Out, or Payment.' : 'Important: use Send Money only. Do not use Mobile Recharge, Cash Out, or Payment.';
    $noticeText = $isBkashNotice
        ? 'bKash app খুলে “Send Money” নির্বাচন করুন। Mobile Recharge, Cash Out অথবা Payment নির্বাচন করবেন না। সঠিক Send Money অপশন ব্যবহার করে টাকা পাঠান।'
        : 'Nagad app খুলে “Send Money” নির্বাচন করুন। Mobile Recharge, Cash Out অথবা Payment নির্বাচন করবেন না। সঠিক Send Money অপশন ব্যবহার করে টাকা পাঠান।';
?>
<!doctype html>
<html lang="bn">
<head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no,viewport-fit=cover">
<title><?=h($noticeHeading)?> · XTREME TITAN</title>
<link rel="stylesheet" href="theme.php"><link rel="stylesheet" href="reference-theme.css"><link rel="stylesheet" href="site-polish.css"><link rel="stylesheet" href="premium-global.css">
<script src="language-client.js?v=20261119-deposit-notice-v2" defer></script>
<script>document.addEventListener('DOMContentLoaded',function(){document.querySelectorAll('[data-localize-copy]').forEach(function(el){var t=(el.textContent||'').trim();if(t){el.setAttribute('data-auto-button-label','1');el.setAttribute('data-original-button-label',t);}});if(window.XtremeLanguage&&window.XtremeLanguage.apply)window.XtremeLanguage.apply();});</script>
<style>
:root{color-scheme:dark}*{box-sizing:border-box}body{margin:0;min-height:100vh;background:#080610;color:#fff;font-family:inherit;padding:22px 0 34px}
.xt-bkash-notice-wrap{width:min(660px,calc(100% - 30px));margin:20px auto 34px}
.xt-bkash-notice{padding:clamp(22px,5vw,34px);border:1px solid #a51b60;border-radius:27px;background:radial-gradient(ellipse at 50% 0%,#42102e55,transparent 48%),linear-gradient(155deg,#1a0e1b 0%,#100b17 100%);box-shadow:0 0 35px #e0006b18,inset 0 1px #ff8cc51a}
.xt-notice-pill{display:inline-flex;align-items:center;gap:9px;padding:9px 16px;border:1px solid #d51c70;border-radius:30px;background:#4a0b2d;color:#ff9ac5;font-size:clamp(13px,3.5vw,17px);font-weight:900;margin-bottom:15px}
.xt-notice-title{display:flex;align-items:center;gap:12px;font-size:clamp(25px,6vw,37px);line-height:1.2;font-weight:1000;margin:0 0 22px;color:#fff}.xt-notice-title .warn-icon{color:#ff1684;font-size:30px}
.xt-notice-alert{padding:20px 22px;border:2px solid #87303f;border-radius:19px;background:linear-gradient(145deg,#35151f,#28121d);margin-bottom:24px}
.xt-notice-alert strong{display:block;color:#ff9eae;font-size:clamp(17px,4.2vw,22px);line-height:1.4;margin-bottom:12px}
.xt-notice-alert p{margin:0;color:#ffe0e7;font-size:clamp(15px,3.8vw,19px);line-height:1.75;font-weight:650}
.xt-notice-guide{padding:12px;border:2px solid #9c145a;border-radius:23px;background:#110b18;margin:22px 0 20px;box-shadow:0 0 22px #ed16801c}
.xt-notice-guide img{display:block;width:100%;height:auto;border-radius:15px;object-fit:contain}
.xt-guide-caption{display:flex;align-items:flex-start;gap:10px;justify-content:center;text-align:center;color:#ff82bd;font-size:clamp(13px,3.5vw,18px);font-weight:900;line-height:1.45;padding:12px 4px 3px;max-width:100%;min-width:0;overflow-wrap:anywhere;word-break:normal}.xt-guide-caption>span:last-child{display:block;min-width:0;max-width:100%;overflow-wrap:anywhere;white-space:normal}.xt-guide-caption span:first-child{color:#35d79a;flex:0 0 auto}
.xt-notice-steps{display:grid;grid-template-columns:1fr 1fr;gap:12px;margin:20px 0}.xt-notice-step{padding:15px 12px;border:1px solid #7b1b50;border-radius:15px;background:#211020;color:#ffd9e9;text-align:center;font-size:14px;font-weight:850;line-height:1.5}.xt-notice-step.active{border:2px solid #ec2387;box-shadow:0 0 18px #ec238733;color:#fff}
.xt-notice-step small{display:block;color:#b9a5b8;font-size:12px;font-weight:650;margin-top:5px}
.xt-notice-amount{border:1px solid #75314e;border-radius:15px;padding:15px 18px;margin:20px 0;background:#130d19}.xt-notice-amount small{display:block;color:#cbb6c8;font-size:14px}.xt-notice-amount strong{display:block;color:#ff83bd;font-size:28px;margin-top:5px;font-weight:1000}
.xt-notice-pay{width:100%;border:0;border-radius:16px;padding:18px 16px;margin-top:8px;background:linear-gradient(100deg,#ed37ad,#9254ff);color:white;font-size:clamp(16px,4vw,20px);font-weight:1000;box-shadow:0 8px 24px #b62ca544;cursor:pointer}
.xt-notice-back{display:block;text-align:center;color:#f3a2d1;text-decoration:none;font-size:16px;font-weight:850;padding:17px 8px 0}
@media(max-width:420px){.xt-notice-steps{grid-template-columns:1fr}.xt-bkash-notice{padding:20px 17px}.xt-notice-alert{padding:16px}}
</style>
</head>
<body>
<main class="xt-bkash-notice-wrap"><section class="xt-bkash-notice">
<div class="xt-notice-pill" data-auto-button-label="1" data-original-button-label="<?=h($isBkashNotice ? 'Important for bKash users' : 'Important for Nagad users')?>">❗ <?= $isBkashNotice ? 'বিকাশ ব্যবহারকারীদের জন্য জরুরি' : 'নগদ ব্যবহারকারীদের জন্য জরুরি' ?></div>
<h1 class="xt-notice-title"><span class="warn-icon">⚠</span><span data-auto-button-label="1" data-original-button-label="<?=h($noticeHeading)?>"><?= $isBkashNotice ? 'বিকাশ পেমেন্ট করার সঠিক নিয়ম' : 'নগদ পেমেন্ট করার সঠিক নিয়ম' ?></span></h1>
<div class="xt-notice-alert"><strong data-auto-button-label="1" data-original-button-label="<?=h($noticeWarningTitle)?>">✋ <?= $isBkashNotice ? 'বিশেষ সতর্কবার্তা: শুধু সেন্ড মানি ব্যবহার করুন!' : 'বিশেষ সতর্কবার্তা: শুধু সেন্ড মানি ব্যবহার করুন!' ?></strong><p data-auto-button-label="1" data-original-button-label="<?=h($noticeText)?>"><?= $isBkashNotice ? 'বিকাশ অ্যাপ খুলে “সেন্ড মানি (Send Money)” নির্বাচন করুন। মোবাইল রিচার্জ, ক্যাশ আউট অথবা পেমেন্ট নির্বাচন করবেন না।' : 'নগদ অ্যাপ খুলে “সেন্ড মানি (Send Money)” নির্বাচন করুন। মোবাইল রিচার্জ, ক্যাশ আউট অথবা পেমেন্ট নির্বাচন করবেন না।' ?></p></div>
<?php $guideImage = $isBkashNotice ? $bkashGuideImage : $nagadGuideImage; if ($guideImage !== ''): ?>
<div class="xt-notice-guide"><img src="<?=h($guideImage)?>" alt="<?= $isBkashNotice ? 'bKash' : 'Nagad' ?> payment instruction"><div class="xt-guide-caption"><span>✓</span><span data-auto-button-label="1" data-original-button-label="As shown above, select Send Money and send your payment."><?= $isBkashNotice ? 'উপরের ছবির মতো অবশ্যই “সেন্ড মানি (Send Money)” সিলেক্ট করে টাকা পাঠান' : 'উপরের ছবির মতো অবশ্যই “সেন্ড মানি (Send Money)” সিলেক্ট করে টাকা পাঠান' ?></span></div></div>
<?php else: ?>
<div class="xt-notice-steps"><div class="xt-notice-step active" data-localize-copy>১. নগদ অ্যাপে Send Money<small>Nagad অ্যাপ খুলে Send Money নির্বাচন করুন</small></div><div class="xt-notice-step" data-localize-copy>২. নিরাপদ চেকআউট<small>Paymently-তে দেখানো নির্দেশনা অনুসরণ করুন</small></div></div>
<?php endif; ?>
<div class="xt-notice-amount"><small data-auto-button-label="1" data-original-button-label="Your selected deposit amount">আপনার নির্বাচিত জমার পরিমাণ</small><strong>৳<?=h(number_format((float)$noticeAmount,2))?></strong></div>
<form method="post" action="uddoktapay-start.php"><input type="hidden" name="csrf" value="<?=h($_SESSION['uddokta_csrf'])?>"><input type="hidden" name="amount" value="<?=h($noticeAmount)?>"><input type="hidden" name="payment_method" value="<?=h($noticeMethod)?>"><input type="hidden" name="pending_created" value="<?=h((string)$noticeCreated)?>"><input type="hidden" name="pending_signature" value="<?=h($noticeSignature)?>"><button class="xt-notice-pay" type="submit" data-localize-copy>স্বয়ংক্রিয়ভাবে পেমেন্ট করুন →</button></form>
<a class="xt-notice-back" href="deposit.php" data-auto-button-label="1" data-original-button-label="← Go back">← ফিরে যান</a>
</section></main>
</body></html>
<?php exit; endif; ?>
<!doctype html>
<html lang="en">
<head>
<link rel="stylesheet" href="theme.php?v=20261022-lightfix3">
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no,viewport-fit=cover">
<title><?=h($site['site_title'])?> — Add Funds</title>
<link rel="stylesheet" href="reference-theme.css">
<link rel="stylesheet" href="site-polish.css?v=20261022-lightfix3">
<script src="theme-client.js?v=20260928-19" defer></script><link rel="stylesheet" href="premium-global.css?v=20261022-lightfix3"><script src="currency-client.js?v=20261022-country3" defer></script><script src="language-client.js?v=20261118-deposit-sendmoney-v3" defer></script><script src="preference-sync.js?v=20260928-19" defer></script>

<link rel="stylesheet" href="responsive-lock.css?v=20260929-31">

<link rel="icon" type="image/png" sizes="48x48" href="/assets/pwa-icon-48.png">
<link rel="apple-touch-icon" sizes="180x180" href="/assets/pwa-icon-180.png">
<link rel="manifest" href="/pwa-manifest.json">
<meta name="apple-mobile-web-app-title" content="XTREME TITAN">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="mobile-web-app-capable" content="yes">
<meta name="theme-color" content="#080a14">
<script src="/admin/admin-action-progress.js?v=20261023-inline-progress25" defer></script>

<style id="xt-global-header-logo-unified-v29">
/* One consistent site-header logo and title scale on every customer page */
header.top, header.topbar {
  box-sizing:border-box!important;
  width:100%!important;
  min-height:0!important;
  height:auto!important;
  padding:14px 14px 16px!important;
  margin:0 auto!important;
  display:flex!important;
  align-items:center!important;
  justify-content:center!important;
  text-align:center!important;
}
header.top .brand-with-logo, header.topbar .brand-with-logo {
  box-sizing:border-box!important;
  width:100%!important;
  max-width:100%!important;
  display:flex!important;
  flex-direction:column!important;
  align-items:center!important;
  justify-content:center!important;
  gap:7px!important;
  margin:0 auto!important;
  text-align:center!important;
}
header.top .header-logo, header.topbar .header-logo {
  display:block!important;
  box-sizing:border-box!important;
  width:46px!important;height:46px!important;
  min-width:46px!important;min-height:46px!important;
  max-width:46px!important;max-height:46px!important;
  flex:0 0 46px!important;
  object-fit:contain!important;object-position:center!important;
  background:transparent!important;
  border:0!important;padding:0!important;margin:0 auto!important;
  border-radius:10px!important;
}
header.top .brand-text, header.topbar .top-title {
  display:block!important;
  max-width:100%!important;
  margin:0 auto!important;padding:0!important;
  text-align:center!important;
  font-size:clamp(17px,4.6vw,25px)!important;
  line-height:1.2!important;
  font-weight:900!important;
  letter-spacing:0!important;
  overflow-wrap:anywhere!important;
}
header.topbar .xt-dashboard-tagline {
  margin:0 auto!important;
  text-align:center!important;
  line-height:1.2!important;
}
@media(max-width:420px) {
  header.top,header.topbar{padding:12px 10px 14px!important}
  header.top .header-logo,header.topbar .header-logo {
    width:46px!important;height:46px!important;min-width:46px!important;min-height:46px!important;
    max-width:46px!important;max-height:46px!important;flex-basis:46px!important;
  }
}
</style>
<link rel="stylesheet" href="assets/xtreme-music.css?v=3">
<style id="binance-pay-premium-style">
.binance-method{margin-top:10px!important;border-color:rgba(240,185,11,.48)!important;background:linear-gradient(135deg,rgba(240,185,11,.16),rgba(16,25,42,.98) 48%,rgba(8,15,28,.98))!important;box-shadow:0 10px 28px rgba(240,185,11,.09),inset 0 1px 0 rgba(255,255,255,.07)!important}
.binance-method .method-name{color:#f5d98b!important;font-weight:1000!important}.binance-method .method-note{color:#c6b58a!important}
.binance-method.selected{border-color:#f0b90b!important;box-shadow:0 0 0 1px rgba(240,185,11,.3),0 12px 32px rgba(240,185,11,.13)!important}
.binance-pay-panel{padding:14px;border:1px solid rgba(240,185,11,.22);border-radius:16px;background:linear-gradient(145deg,rgba(240,185,11,.09),rgba(8,16,29,.94));margin-top:8px}
.binance-qr{display:block;width:min(210px,70%);max-height:230px;object-fit:contain;background:#fff;padding:9px;border-radius:14px;margin:5px auto 14px}
.binance-hint{margin-top:10px;color:#d7c79f!important}
</style>

<link rel="stylesheet" href="assets/xtreme-bottom-nav.css?v=20261117-border-v11">

<style id="xt-deposit-premium-redesign-v2">
.premium-deposit-page{--dep-cyan:#25d9ff;--dep-pink:#f02d91;--dep-green:#13d6a0}
.premium-deposit-page .deposit-wrap{width:min(100% - 24px,760px)!important;max-width:760px!important;margin:14px auto 110px!important;padding:0!important}
.premium-deposit-page .deposit-hero{
  padding:18px 18px 17px!important;margin:0 0 15px!important;border-radius:22px!important;
  border:1px solid rgba(50,190,235,.34)!important;
  background:radial-gradient(circle at 0 0,rgba(18,196,225,.17),transparent 46%),linear-gradient(145deg,#101d35,#090f20 72%)!important;
  box-shadow:0 14px 34px rgba(0,0,0,.25),inset 0 1px 0 rgba(255,255,255,.07)!important;
}
.premium-deposit-page .deposit-eyebrow{color:#42d9ee!important;font-size:10px!important;font-weight:1000!important;letter-spacing:.14em!important}
.premium-deposit-page .deposit-hero h1{margin:5px 0!important;font-size:clamp(24px,6vw,32px)!important;font-weight:1000!important;color:#fff!important}
.premium-deposit-page .deposit-hero p{margin:0!important;color:#9fb0c7!important;font-size:12px!important;line-height:1.5!important}
.premium-deposit-page .deposit-shell{
  padding:16px!important;margin:0 0 16px!important;border-radius:24px!important;
  border:1px solid rgba(44,180,225,.34)!important;
  background:radial-gradient(ellipse at 100% 0,rgba(22,131,208,.12),transparent 42%),linear-gradient(155deg,#0d1b30 0%,#080f1e 72%)!important;
  box-shadow:0 16px 38px rgba(0,0,0,.24),inset 0 1px 0 rgba(255,255,255,.06)!important;
}
.premium-deposit-page .deposit-shell>div[style*="padding:18px"]{
  padding:14px!important;border-radius:17px!important;border:1px solid rgba(31,205,190,.34)!important;
  background:linear-gradient(120deg,rgba(9,177,143,.14),rgba(16,126,222,.14))!important;
}
.premium-deposit-page .deposit-step{
  display:flex!important;align-items:center!important;gap:11px!important;margin:8px 0 13px!important;
  color:#f5f8ff!important
}
.premium-deposit-page .deposit-step>span{
  width:34px!important;height:34px!important;flex:0 0 34px!important;display:grid!important;place-items:center!important;
  border-radius:11px!important;background:linear-gradient(145deg,#0abfce,#276ce9)!important;color:white!important;
  font-weight:1000!important;box-shadow:0 6px 18px rgba(25,150,220,.22)!important
}
.premium-deposit-page .deposit-step strong{display:block!important;font-size:15px!important;font-weight:950!important}
.premium-deposit-page .deposit-step small{display:block!important;margin-top:2px!important;color:#91a4bd!important;font-size:11px!important}
.premium-deposit-page .deposit-preferences,.premium-deposit-page .amount-box,.premium-deposit-page .verify-box{
  padding:10px!important;margin:8px 0 12px!important;border-radius:15px!important;
  border:1px solid rgba(113,145,186,.24)!important;background:rgba(8,16,31,.72)!important
}
.premium-deposit-page .pref-title,.premium-deposit-page .amount-box label,.premium-deposit-page .field label{
  color:#edf5ff!important;font-weight:900!important
}
.premium-deposit-page .pref-text,.premium-deposit-page .secure-note{color:#93a6c0!important}
.premium-deposit-page .pref-select,.premium-deposit-page .field input,.premium-deposit-page .amount-input{
  border:1px solid rgba(116,153,196,.34)!important;border-radius:13px!important;background:#0b1425!important;color:#f4f8ff!important
}
.premium-deposit-page .premium-methods{
  display:grid!important;grid-template-columns:repeat(2,minmax(0,1fr))!important;gap:9px!important;margin:14px 0!important
}
.premium-deposit-page .premium-methods .premium-method{
  position:relative!important;box-sizing:border-box!important;min-width:0!important;min-height:76px!important;
  display:grid!important;grid-template-columns:43px minmax(0,1fr)!important;grid-template-rows:auto auto!important;
  align-items:center!important;gap:3px 9px!important;padding:11px!important;border-radius:16px!important;
  border:1px solid rgba(112,147,191,.3)!important;background:linear-gradient(145deg,#17233a,#0d1629)!important;
  color:#eaf4ff!important;box-shadow:inset 0 1px 0 rgba(255,255,255,.06),0 7px 17px rgba(0,0,0,.18)!important
}
.premium-deposit-page .premium-methods .payment-logo{grid-row:1/3!important;width:40px!important;height:38px!important;object-fit:contain!important}
.premium-deposit-page .premium-methods .method-name{font-size:14px!important;font-weight:1000!important;line-height:1.2!important}
.premium-deposit-page .premium-methods .method-note{font-size:9px!important;color:#93a8c2!important;line-height:1.25!important}
.premium-deposit-page .premium-methods .premium-method.selected{
  border-color:#22d8ed!important;background:linear-gradient(135deg,rgba(0,190,205,.2),rgba(31,83,176,.24),rgba(22,24,57,.96))!important;
  box-shadow:0 0 0 1px rgba(35,220,235,.24),0 8px 24px rgba(12,173,219,.16),inset 0 1px 0 rgba(255,255,255,.12)!important
}
.premium-deposit-page .premium-methods .premium-method.selected:after{
  content:"✓"!important;position:absolute!important;top:7px!important;right:8px!important;width:20px!important;height:20px!important;
  display:grid!important;place-items:center!important;border-radius:50%!important;background:#13c98d!important;color:#06251c!important;font-size:13px!important;font-weight:1000!important
}
.premium-deposit-page .payment-details{
  display:none!important;padding:14px!important;margin:12px 0 17px!important;border-radius:17px!important;
  border:1px solid rgba(42,194,218,.28)!important;background:linear-gradient(145deg,rgba(15,39,62,.9),rgba(8,16,30,.96))!important
}
.premium-deposit-page .payment-details.show{display:block!important}
.premium-deposit-page .detail-title{font-size:15px!important;font-weight:1000!important;color:#f5f8ff!important}
.premium-deposit-page .detail-text{color:#aebdd0!important;font-size:12px!important;line-height:1.55!important}
.premium-deposit-page .number-row{display:flex!important;align-items:center!important;justify-content:space-between!important;gap:8px!important;margin:10px 0!important;padding:10px!important;border-radius:12px!important;background:rgba(4,11,23,.7)!important;color:#5ce5d1!important}
.premium-deposit-page .copy{border:0!important;border-radius:9px!important;padding:8px 11px!important;background:linear-gradient(110deg,#09bfa2,#168de9)!important;color:#fff!important;font-weight:900!important}
.premium-deposit-page .amount-input{display:flex!important;align-items:center!important;padding:7px 10px!important;min-height:48px!important}
.premium-deposit-page .amount-input input{min-width:0!important;background:transparent!important;color:#fff!important;border:0!important;font-size:20px!important;font-weight:950!important}
.premium-deposit-page .amount-chips{display:grid!important;grid-template-columns:repeat(3,minmax(0,1fr))!important;gap:6px!important;margin-top:9px!important}
.premium-deposit-page .amount-chips button{
  min-height:34px!important;padding:6px 4px!important;border-radius:10px!important;border:1px solid rgba(122,144,180,.25)!important;
  background:linear-gradient(145deg,#172136,#101827)!important;color:#f4f7ff!important;font-size:13px!important;font-weight:950!important
}
.premium-deposit-page .amount-chips button:active{transform:scale(.97)!important}
.premium-deposit-page .verify-box{display:grid!important;gap:12px!important}
.premium-deposit-page .verify-box[hidden],.premium-deposit-page .step-3[hidden]{display:none!important}
.premium-deposit-page .field input{width:100%!important;box-sizing:border-box!important;padding:12px!important}
.premium-deposit-page .premium-submit{
  width:100%!important;min-height:58px!important;border:0!important;border-radius:16px!important;
  background:linear-gradient(105deg,#08b987,#079fca 72%,#168be8)!important;color:#fff!important;
  font-size:17px!important;font-weight:1000!important;box-shadow:0 12px 28px rgba(0,174,171,.22)!important
}
.premium-deposit-page .secure-note{text-align:center!important;font-size:11px!important;line-height:1.5!important;margin:11px 0 0!important}
.payment-instruction-notice{
  display:flex!important;align-items:flex-start!important;gap:11px!important;padding:13px!important;margin:0 0 15px!important;
  border-radius:16px!important;border:1px solid rgba(239,54,120,.42)!important;
  background:linear-gradient(145deg,rgba(74,17,48,.58),rgba(30,15,33,.9))!important;color:#ffd6e5!important
}
.payment-instruction-icon{flex:0 0 30px!important;width:30px!important;height:30px!important;display:grid!important;place-items:center!important;border-radius:50%!important;background:#df2476!important;color:white!important;font-weight:1000!important}
.payment-instruction-copy strong{display:block!important;color:#ff8bb9!important;font-size:14px!important;margin-bottom:5px!important}
.payment-instruction-copy div{font-size:12px!important;line-height:1.6!important;color:#f0c8d7!important}
.sendmoney-guide{margin-top:14px!important;padding:13px!important;border:1px solid rgba(238,57,132,.36)!important;border-radius:16px!important;background:linear-gradient(145deg,rgba(65,15,48,.58),rgba(16,19,38,.96))!important}
.sendmoney-guide-head{text-align:center!important;margin-bottom:12px!important}
.sendmoney-guide-badge{display:inline-flex!important;padding:5px 10px!important;border-radius:999px!important;background:rgba(229,35,119,.16)!important;border:1px solid rgba(255,65,145,.4)!important;color:#ff79b2!important;font-size:10px!important;font-weight:1000!important}
.sendmoney-guide-head strong{display:block!important;margin:8px 0 3px!important;color:#fff!important;font-size:15px!important}
.sendmoney-guide-head small{color:#f4a4c4!important;font-size:11px!important}
.sendmoney-guide-head small b{color:#ff5c9f!important}
.sendmoney-actions{display:grid!important;grid-template-columns:repeat(4,minmax(0,1fr))!important;gap:6px!important}
.sendmoney-action{position:relative!important;min-width:0!important;display:flex!important;flex-direction:column!important;align-items:center!important;justify-content:center!important;gap:6px!important;padding:10px 3px!important;border-radius:13px!important;background:#151b2a!important;border:1px solid rgba(142,156,181,.2)!important;text-align:center!important}
.sendmoney-action-icon{width:37px!important;height:37px!important;display:grid!important;place-items:center!important;border-radius:50%!important;background:#242d42!important;color:#c2d4e8!important;font-size:19px!important;font-weight:1000!important}
.sendmoney-action b{font-size:9px!important;line-height:1.25!important;color:#bdc8d8!important;overflow-wrap:anywhere!important}
.sendmoney-action i{position:absolute!important;top:3px!important;right:3px!important;width:18px!important;height:18px!important;display:grid!important;place-items:center!important;border-radius:50%!important;font-style:normal!important;font-weight:1000!important;font-size:12px!important}
.sendmoney-action.is-correct{border-color:rgba(23,216,151,.65)!important;background:linear-gradient(145deg,rgba(8,106,87,.42),rgba(20,30,48,.95))!important;box-shadow:0 0 18px rgba(13,211,153,.12)!important}
.sendmoney-action.is-correct .sendmoney-action-icon{background:linear-gradient(145deg,#0abf8b,#10a6c7)!important;color:#fff!important}
.sendmoney-action.is-correct b{color:#53e7b5!important}
.sendmoney-action.is-correct i{background:#13c98d!important;color:#05281d!important}
.sendmoney-action.is-wrong i{background:#e53b57!important;color:#fff!important}
.sendmoney-guide-foot{margin:10px 0 0!important;text-align:center!important;color:#c0ccdc!important;font-size:10px!important}
@media(max-width:560px){
 .premium-deposit-page .deposit-wrap{width:calc(100% - 20px)!important;margin-top:10px!important}
 .premium-deposit-page .deposit-shell{padding:12px!important;border-radius:20px!important}
 .premium-deposit-page .premium-methods{grid-template-columns:repeat(2,minmax(0,1fr))!important}
 .premium-deposit-page .premium-methods .premium-method{grid-template-columns:36px minmax(0,1fr)!important;min-height:70px!important;padding:9px!important;gap:3px 7px!important}
 .premium-deposit-page .premium-methods .payment-logo{width:34px!important;height:34px!important}
 .premium-deposit-page .premium-methods .method-name{font-size:12px!important}
 .premium-deposit-page .premium-methods .method-note{font-size:8px!important}
 .sendmoney-actions{gap:4px!important}
 .sendmoney-action{padding:9px 2px!important}
 .sendmoney-action-icon{width:32px!important;height:32px!important;font-size:17px!important}
 .sendmoney-action b{font-size:8px!important}
}
.premium-deposit-page.auto-payment-mode .verify-box,.premium-deposit-page.auto-payment-mode .step-3{display:none!important}
</style>
</head>
<body class="premium-deposit-page">
<?php $xtHeaderSite = $site; require __DIR__ . '/customer-wallet-header.php'; ?>

<main class="wrap deposit-wrap">
  <div class="deposit-hero">
    <div class="deposit-eyebrow">WALLET • ADD FUNDS</div>
    <h1>Add Funds</h1>
    <p>Choose a payment method, enter your amount and send the payment.</p>
  </div>

  <?php if ($error): ?><div class="alert error deposit-alert"><?=h($error)?></div><?php endif; ?>
  <?php if ($success): ?><div class="alert success deposit-alert"><?=h($success)?></div><?php endif; ?>

  <section class="deposit-shell" style="margin-bottom:16px;display:none">
    <div style="padding:18px;border:1px solid rgba(22,217,255,.28);border-radius:18px;background:linear-gradient(135deg,rgba(0,195,160,.10),rgba(22,120,255,.10))">
      <div style="display:flex;align-items:center;gap:12px;flex-wrap:wrap;justify-content:space-between">
        <div><strong style="font-size:16px" data-auto-button-label="1" data-original-button-label="Automatic Deposit">Automatic Deposit</strong><div style="font-size:13px;opacity:.8;margin-top:5px"><span data-auto-button-label="1" data-original-button-label="Pay online and get your wallet credited automatically after server-side verification. BDT deposits.">Pay online and get your wallet credited automatically after server-side verification. BDT deposits.</span></div></div>
        <a href="uddoktapay-start.php" style="display:inline-block;padding:12px 18px;border-radius:12px;background:linear-gradient(90deg,#00cfa8,#16a5ff);color:#04131d;font-weight:900;text-decoration:none" data-auto-button-label="1" data-original-button-label="Pay Automatically →">Pay Automatically →</a>
      </div>
    </div>
  </section>

  <section class="deposit-shell">
    <div class="deposit-step"><span>01</span><div><strong>পেমেন্ট পদ্ধতি নির্বাচন করুন</strong><small>আপনার পছন্দের পেমেন্ট পদ্ধতি বেছে নিন।</small></div></div>
    <form method="post" id="depositForm" autocomplete="off" enctype="multipart/form-data"><input type="hidden" name="currency_code" id="currencyCodeField" value="<?=h($currencyCode)?>">
      <input type="hidden" name="csrf" value="<?=h($depositCsrf)?>">
      <input type="hidden" name="payment_method" id="payment_method" value="<?=h($paymentMethod)?>">

      <section class="preference-box deposit-preferences">
        <div class="pref-row"><div><div class="pref-title" data-auto-button-label="1" data-original-button-label="Currency">Currency</div><div class="pref-text"><span data-auto-button-label="1" data-original-button-label="Bangladesh: bKash + Nagad + Binance Pay. Other countries: PayPal + Binance Pay.">BDT = bKash + Nagad + Binance Pay. Other currencies = PayPal + Binance Pay.</span></div></div><select id="depositCurrency" class="pref-select"><option value="USD">🇺🇸 USD — US Dollar</option><option value="EUR">🇮🇹 EUR — Euro</option><option value="BDT">🇧🇩 BDT — Bangladeshi Taka</option><option value="AED">🇦🇪 AED — UAE Dirham</option><option value="INR">🇮🇳 INR — Indian Rupee</option><option value="NPR">🇳🇵 NPR — Nepalese Rupee</option><option value="BTN">🇧🇹 BTN — Bhutanese Ngultrum</option><option value="VND">🇻🇳 VND — Vietnamese Dong</option><option value="GBP">🇬🇧 GBP — Pound Sterling</option></select></div>
        <div id="depositPrefStatus" class="pref-status" aria-live="polite"></div>
      </section>

      <div class="methods premium-methods" id="paymentMethods">
        <button type="button" class="method premium-method" data-method="bKash" style="display:<?= $isBangladesh ? 'grid' : 'none' ?>"><img class="payment-logo" src="<?=h($bkashLogo)?>" alt="bKash"><span class="method-name">bKash</span><span class="method-note">Bangladesh only</span></button>
        <button type="button" class="method premium-method" data-method="Nagad" style="display:<?= $isBangladesh ? 'grid' : 'none' ?>"><img class="payment-logo" src="<?=h($nagadLogo)?>" alt="Nagad"><span class="method-name">Nagad</span><span class="method-note">Bangladesh only</span></button>
        <button type="button" class="method premium-method" data-method="PayPal" style="display:<?= $isBangladesh ? 'none' : 'grid' ?>"><img class="payment-logo" src="<?=h($paypalLogo)?>" alt="PayPal"><span class="method-name">PayPal</span><span class="method-note">Other countries</span></button>
        <button type="button" class="method premium-method binance-method" data-method="Binance Pay"><img class="payment-logo" src="<?=h($binanceLogo)?>" alt="Binance Pay"><span class="method-name">Binance Pay</span><span class="method-note">Available worldwide · USDT</span></button>
      </div>

      <div class="payment-details" id="paymentDetails"></div>

      <div class="deposit-step step-2"><span>02</span><div><strong>Amount</strong><small>How much did you send?</small></div></div>
      <div class="amount-box">
        <label for="amount">Amount to add</label>
        <div class="amount-input"><span class="currency-symbol"><?=h($prefs['symbol'])?></span><input id="amount" name="amount" type="number" inputmode="decimal" step="0.01" min="0.01" placeholder="0.00" value="<?=h($amount)?>" required></div>
        <div class="amount-chips"><button type="button" data-amount="100">+100</button><button type="button" data-amount="200">+200</button><button type="button" data-amount="500">+500</button><button type="button" data-amount="1000">+1000</button><button type="button" data-amount="2000">+2000</button><button type="button" data-amount="5000">+5000</button></div>
      </div>

      <div class="deposit-step step-3" <?= in_array($paymentMethod, ['bKash','Nagad'], true) ? 'hidden' : '' ?>><span>03</span><div><strong>Enter payment details</strong><small>For Binance Pay or PayPal, enter the transaction ID/reference you received after sending the payment.</small></div></div>
      <div class="verify-box" <?= in_array($paymentMethod, ['bKash','Nagad'], true) ? 'hidden' : '' ?>>
        <div class="field"><label for="transaction_id">Transaction ID / Reference</label><input id="transaction_id" name="transaction_id" type="text" maxlength="150" placeholder="e.g. 9A7B6C5D4E" value="<?=h($transactionId)?>" <?= in_array($paymentMethod, ['bKash','Nagad'], true) ? '' : 'required' ?>></div>
        <div class="field" id="receiptUploadField"><label for="receipt_file">Payment screenshot</label><input id="receipt_file" name="receipt_file" type="file" accept="image/jpeg,image/png,image/webp"></div>
      </div>

      <button class="submit premium-submit" id="submitDeposit" type="submit"><?= in_array($paymentMethod, ['bKash','Nagad'], true) ? 'স্বয়ংক্রিয়ভাবে পেমেন্ট করুন →' : '✓ Submit Deposit Request' ?></button>
      <p class="secure-note">Your request is sent to the admin for approval. Your balance changes only after approval.</p>
    </form>
  </section>
</main>

<nav class="xt-bottom-navigation-card" aria-label="Main navigation">
<a href="store.php" data-nav="store" aria-label="Store"><span class="xt-nav-icon"><img src="assets/nav-icons/store.png" alt="" aria-hidden="true"></span><span class="xt-nav-label">Store</span></a>
<a href="my-keys.php" data-nav="keys" aria-label="My Keys"><span class="xt-nav-icon"><img src="assets/nav-icons/keys.png" alt="" aria-hidden="true"></span><span class="xt-nav-label">My Keys</span></a>
<a href="deposit.php" class="is-active" data-nav="funds" aria-label="Add Funds"><span class="xt-nav-icon"><img src="assets/nav-icons/funds.png" alt="" aria-hidden="true"></span><span class="xt-nav-label">Add Funds</span></a>
<a href="history.php" data-nav="history" aria-label="History"><span class="xt-nav-icon"><img src="assets/nav-icons/history.png" alt="" aria-hidden="true"></span><span class="xt-nav-label">History</span></a>
<a href="profile.php" data-nav="profile" aria-label="Profile"><span class="xt-nav-icon"><img src="assets/nav-icons/profile.png" alt="" aria-hidden="true"></span><span class="xt-nav-label">Profile</span></a>
</nav>

<script>
function markDepositTranslations(root=document){
  const scope=root.querySelectorAll?root:document;
  scope.querySelectorAll('.deposit-hero h1,.deposit-hero p,.deposit-eyebrow,.deposit-step strong,.deposit-step small,.amount-box label,.verify-box label,.secure-note,.payment-details .detail-title,.payment-details .detail-text,.payment-details .binance-hint,.premium-submit,.payment-instruction-copy strong,.payment-instruction-copy div,.xt-notice-amount small,.xt-notice-back').forEach(el=>{
    if(el.children.length===0){const raw=(el.textContent||'').trim();if(raw && !el.hasAttribute('data-original-button-label')){el.setAttribute('data-auto-button-label','1');el.setAttribute('data-original-button-label',raw);}}
  });
  if(window.XtremeLanguage && typeof window.XtremeLanguage.apply==='function') window.XtremeLanguage.apply();
}
const methods = [...document.querySelectorAll('.premium-method')];
const hidden = document.getElementById('payment_method');
const details = document.getElementById('paymentDetails');
const amountInput = document.getElementById('amount');
const currencySel = document.getElementById('depositCurrency');
const prefStatus = document.getElementById('depositPrefStatus');
const bkashNumber = <?=json_encode($bkashNumber)?>;
const nagadNumber = <?=json_encode($nagadNumber)?>;
const paypal = <?=json_encode($paypalMe)?>;
const binancePayId = <?=json_encode($binancePayId)?>;
const binanceQr = <?=json_encode($binanceQr)?>;
const bkashNotice = <?=json_encode($bkashPaymentNotice, JSON_UNESCAPED_UNICODE)?>;
const nagadNotice = <?=json_encode($nagadPaymentNotice, JSON_UNESCAPED_UNICODE)?>;
const currencyMeta = {USD:{country:'US',symbol:'$'},EUR:{country:'IT',symbol:'€'},BDT:{country:'BD',symbol:'৳'},AED:{country:'AE',symbol:'د.إ'},INR:{country:'IN',symbol:'₹'},NPR:{country:'NP',symbol:'रू'},BTN:{country:'BT',symbol:'Nu.'},VND:{country:'VN',symbol:'₫'},GBP:{country:'GB',symbol:'£'}};
function esc(s){return String(s ?? '').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[c]));}
function isBD(){return currencySel.value==='BDT';}
function renderMethods(){
  const bd=isBD();
  methods.forEach(b=>{
    const m=b.dataset.method;
    const visible = m==='Binance Pay' || (bd ? ['bKash','Nagad'].includes(m) : m==='PayPal');
    b.style.setProperty('display', visible?'grid':'none', 'important');
  });
  const allowedNow = bd ? ['bKash','Nagad','Binance Pay'] : ['PayPal','Binance Pay'];
  if(!allowedNow.includes(hidden.value)) hidden.value=bd?'bKash':'PayPal';
  const active=methods.find(b=>b.dataset.method===hidden.value && b.style.display!=='none');
  if(active) showMethod(active.dataset.method);
  document.querySelector('.currency-symbol').textContent=(currencyMeta[currencySel.value]||currencyMeta.USD).symbol;
}
function showMethod(method){
  const bd=isBD();
  const allowedNow = bd ? ['bKash','Nagad','Binance Pay'] : ['PayPal','Binance Pay'];
  if(!allowedNow.includes(method)) method=bd?'bKash':'PayPal';
  hidden.value=method;
  const verifyBox=document.querySelector('.verify-box'); const receiptField=document.getElementById('receiptUploadField'); const verifyStep=document.querySelector('.step-3'); const submitButton=document.getElementById('submitDeposit'); const secureNote=document.querySelector('.secure-note');
  const autoMethod=['bKash','Nagad'].includes(method);
  if(verifyBox){verifyBox.hidden=autoMethod;verifyBox.style.display=autoMethod?'none':'grid';} if(receiptField) receiptField.style.display=autoMethod?'none':''; const receiptInput=document.getElementById('receipt_file'); if(receiptInput) receiptInput.required=!autoMethod; if(verifyStep){verifyStep.hidden=autoMethod;verifyStep.style.display=autoMethod?'none':'flex';} const txInput=document.getElementById('transaction_id'); if(txInput) txInput.required=!autoMethod; document.body.classList.toggle('auto-payment-mode',autoMethod);
  if(submitButton){
    const buttonLabel=autoMethod?'এখনই পেমেন্ট করুন':'✓ Submit Deposit Request';
    submitButton.innerHTML=autoMethod?'এখনই পেমেন্ট করুন':'✓ Submit Deposit Request';
    submitButton.setAttribute('data-auto-button-label','1');
    submitButton.setAttribute('data-original-button-label',buttonLabel);
  }
  if(secureNote) secureNote.textContent=autoMethod?'You will review the payment instructions before opening secure checkout.':'Your request is sent to the admin for approval. Your balance changes only after approval.';
  methods.forEach(b=>b.classList.toggle('selected', b.dataset.method===method && b.style.display!=='none'));
  if(method==='PayPal'){
    details.innerHTML='<div class="detail-title">PayPal</div><div class="detail-text">Pay using the PayPal link below. After payment, return here and enter the PayPal transaction ID / reference.</div>'+(paypal?'<a class="paypal-link" href="'+esc(paypal)+'" target="_blank" rel="noopener">Open PayPal.Me →</a>':'<div class="detail-warning">PayPal link is not configured yet.</div>');
  }else if(method==='Binance Pay'){
    details.innerHTML='<div class="detail-title">Binance Pay · USDT</div><div class="binance-pay-panel">'+(binanceQr?'<img class="binance-qr" src="'+esc(binanceQr)+'" alt="Binance Pay QR code">':'')+'<div class="detail-text">Send your payment using Binance Pay. Use the UID below, then enter your Binance transaction ID/reference.</div><div class="number-row"><strong>'+esc(binancePayId||'Not configured')+'</strong>'+(binancePayId?'<button type="button" class="copy" id="copyNumber">Copy UID</button>':'')+'</div><div class="detail-text binance-hint">Binance Pay is available for all countries. Confirm the amount and USDT currency in Binance before sending.</div></div>';
    const copy=document.getElementById('copyNumber');
    if(copy) copy.onclick=async()=>{try{await navigator.clipboard.writeText(binancePayId);copy.textContent='Copied ✓';setTimeout(()=>copy.textContent='Copy UID',1400);}catch(e){}};
  }else if(method==='bKash' || method==='Nagad'){
    const methodNotice=method==='bKash'?bkashNotice:nagadNotice; const providerIntro=method==='bKash'?'bKash selected. Choose your amount, then tap “Pay Now”. The next page shows only bKash instructions.':'Nagad selected. Choose your amount, then tap “Pay Now”. The next page shows only Nagad instructions.';
    const providerRule=method==='bKash'?'Use Send Money only in the bKash app. Do not choose Mobile Recharge, Cash Out, or Payment.':'Use Send Money only in the Nagad app. Do not choose Mobile Recharge, Cash Out, or Payment.';
    details.innerHTML='<div class="detail-title" data-auto-button-label="1" data-original-button-label="'+esc(method+' · Secure automatic payment')+'">'+esc(method)+' · Secure automatic payment</div><div class="detail-text" data-auto-button-label="1" data-original-button-label="'+esc(providerIntro)+'">'+esc(providerIntro)+'</div><div class="detail-text" data-auto-button-label="1" data-original-button-label="'+esc(providerRule)+'">'+esc(providerRule)+'</div>';
  }else{
    const num=method==='bKash'?bkashNumber:nagadNumber;
    details.innerHTML='<div class="detail-title">'+esc(method)+' number</div><div class="number-row"><strong>'+esc(num||'Not configured')+'</strong>'+(num?'<button type="button" class="copy" id="copyNumber">Copy</button>':'')+'</div>'+
      '<div class="sendmoney-guide" role="note" aria-label="Correct payment option">'+
        '<div class="sendmoney-guide-head"><span class="sendmoney-guide-badge">✓ সঠিক অপশন</span><strong>কোন অপশন দিয়ে টাকা পাঠাবেন?</strong><small>অবশ্যই <b>Send Money</b> নির্বাচন করুন</small></div>'+
        '<div class="sendmoney-actions">'+
          '<div class="sendmoney-action is-correct"><span class="sendmoney-action-icon">৳</span><b>Send Money</b><i>✓</i></div>'+
          '<div class="sendmoney-action is-wrong"><span class="sendmoney-action-icon">▣</span><b>Mobile Recharge</b><i>×</i></div>'+
          '<div class="sendmoney-action is-wrong"><span class="sendmoney-action-icon">⇢</span><b>Cash Out</b><i>×</i></div>'+
          '<div class="sendmoney-action is-wrong"><span class="sendmoney-action-icon">▧</span><b>Payment</b><i>×</i></div>'+
        '</div>'+
        '<p class="sendmoney-guide-foot">পেমেন্ট সম্পন্ন হলে Transaction ID নিচে লিখুন।</p>'+
      '</div>';
    const copy=document.getElementById('copyNumber');
    if(copy) copy.onclick=async()=>{try{await navigator.clipboard.writeText(num);copy.textContent='Copied ✓';setTimeout(()=>copy.textContent='Copy',1400);}catch(e){}};
  }
  details.classList.add('show');
  markDepositTranslations(details);
}
async function saveDepositPrefs(){
  document.getElementById('currencyCodeField').value=currencySel.value;const fd=new FormData();fd.append('currency',currencySel.value);fd.append('country', (currencyMeta[currencySel.value]||currencyMeta.USD).country);
  try{localStorage.setItem('xtreme_currency',currencySel.value);localStorage.setItem('xtreme_country',(currencyMeta[currencySel.value]||currencyMeta.USD).country);window.dispatchEvent(new Event('xtreme-currency-change'));await fetch('preferences.php',{method:'POST',body:fd,credentials:'same-origin'});prefStatus.textContent='Saved';}catch(e){prefStatus.textContent='Saved on this device';}
  setTimeout(()=>prefStatus.textContent='',1200);renderMethods();
}
currencySel.value=<?=json_encode($currencyCode)?>;
try{currencySel.value=localStorage.getItem('xtreme_currency')||currencySel.value;}catch(e){}
document.getElementById('currencyCodeField').value=currencySel.value;
// Currency controls payment mode. BDT is the Bangladesh payment mode.
currencySel.addEventListener('change',saveDepositPrefs);
methods.forEach(b=>b.addEventListener('click',()=>showMethod(b.dataset.method)));
renderMethods();
markDepositTranslations(document);
showMethod(hidden.value || (isBD()?'bKash':'PayPal'));

document.querySelectorAll('.amount-chips button').forEach(btn=>btn.addEventListener('click',()=>{
  const current = Number(amountInput.value || 0);
  const increment = Number(btn.dataset.amount || 0);
  if(Number.isFinite(current) && Number.isFinite(increment) && increment > 0){
    amountInput.value = (current + increment).toFixed(2);
    amountInput.dispatchEvent(new Event('input', {bubbles:true}));
  }
  amountInput.focus();
}));

document.getElementById('depositForm').addEventListener('submit', function(e){
  if(!hidden.value){e.preventDefault();alert('Please select a payment method.');return;}
  const amount=Number(amountInput.value);
  if(!Number.isFinite(amount)||amount<=0){e.preventDefault();alert('Please enter a valid amount.');return;}
  const method=hidden.value;
  if(['bKash','Nagad'].includes(method)){
    // Server stores the selected amount and opens the separate Paymently notice page.
  }else{const tx=document.getElementById('transaction_id').value.trim();if(!tx){e.preventDefault();alert('Please enter your transaction ID / reference.');return;}}
  const btn=document.getElementById('submitDeposit');
  btn.disabled=true;btn.innerHTML='<span class="spinner"></span> Submitting…';
});
</script>
<script src="background-video.js?v=20261018-starfall2"></script>





































<script src="assets/xtreme-music.js?v=3" data-enabled="<?=e(site_setting('background_music_enabled','1'))?>" data-src="<?=e(site_setting('background_music_path','uploads/music/xtreme-background.m4a'))?>" defer></script>

<style id="xt-deposit-compact-full-screen-v3">
@media(max-width:560px){
  .xt-bkash-notice-wrap{width:calc(100% - 24px)!important;margin:8px auto 14px!important}
  .xt-bkash-notice{padding:13px 12px!important;border-radius:19px!important}
  .xt-notice-pill{font-size:12px!important;padding:6px 10px!important;margin-bottom:8px!important}
  .xt-notice-title{font-size:clamp(20px,5.3vw,27px)!important;line-height:1.12!important;margin:0 0 10px!important}
  .xt-notice-title .warn-icon{font-size:22px!important}
  .xt-notice-alert{padding:11px 12px!important;margin-bottom:10px!important;border-radius:14px!important}
  .xt-notice-alert strong{font-size:14px!important;line-height:1.25!important;margin-bottom:5px!important}
  .xt-notice-alert p{font-size:12px!important;line-height:1.42!important}
  .xt-notice-guide{padding:7px!important;margin:9px 0!important;border-radius:16px!important}
  .xt-notice-guide img{border-radius:10px!important}
  .xt-guide-caption{font-size:11px!important;line-height:1.25!important;padding:6px 2px 1px!important}
  .xt-notice-amount{padding:8px 10px!important;margin:9px 0!important;border-radius:12px!important}
  .xt-notice-amount small{font-size:11px!important}
  .xt-notice-amount strong{font-size:21px!important;margin-top:2px!important}
  .xt-notice-back{padding:9px 6px 0!important;font-size:13px!important}
  .premium-deposit-page .deposit-wrap{margin:6px auto calc(124px + env(safe-area-inset-bottom))!important}
  .premium-deposit-page .deposit-hero{padding:11px 12px!important;margin-bottom:8px!important;border-radius:16px!important}
  .premium-deposit-page .deposit-hero h1{font-size:21px!important}
  .premium-deposit-page .deposit-hero p{font-size:11px!important;line-height:1.35!important}
  .premium-deposit-page .deposit-shell{padding:9px!important;margin-bottom:9px!important;border-radius:17px!important}
  .premium-deposit-page .payment-instruction-notice{padding:8px!important;margin-bottom:8px!important;gap:7px!important;border-radius:12px!important}
  .premium-deposit-page .payment-instruction-icon{width:23px!important;height:23px!important;flex-basis:23px!important}
  .premium-deposit-page .payment-instruction-copy strong{font-size:12px!important;margin-bottom:2px!important}
  .premium-deposit-page .payment-instruction-copy div{font-size:10px!important;line-height:1.35!important}
  .premium-deposit-page .deposit-step{gap:7px!important;margin:5px 0 7px!important}
  .premium-deposit-page .deposit-step>span{width:28px!important;height:28px!important;flex-basis:28px!important;border-radius:8px!important}
  .premium-deposit-page .deposit-step strong{font-size:13px!important}
  .premium-deposit-page .deposit-step small{font-size:10px!important}
  .premium-deposit-page .payment-details{padding:9px!important;margin:7px 0 9px!important;border-radius:13px!important}
  .premium-deposit-page .detail-title{font-size:13px!important}
  .premium-deposit-page .detail-text{font-size:10px!important;line-height:1.35!important;margin-top:3px!important}
  .premium-deposit-page .amount-box,.premium-deposit-page .deposit-preferences{padding:8px!important;margin:6px 0 8px!important;border-radius:12px!important}
  .premium-deposit-page .amount-chips{gap:5px!important;margin-top:6px!important}
  .premium-deposit-page .amount-chips button{min-height:31px!important;font-size:12px!important}
  .premium-deposit-page .secure-note{font-size:10px!important;margin-top:6px!important}
}
</style>
</body>
</html>

<style id="xt-payment-mobile-overflow-fix">@media(max-width:560px){.premium-methods{display:grid!important;grid-template-columns:minmax(0,1fr)!important;width:100%!important;min-width:0!important}.premium-methods .premium-method{display:grid;grid-template-columns:48px minmax(0,1fr)!important;width:100%!important;min-width:0!important;padding:10px 12px!important;gap:4px 9px!important}.premium-methods .premium-method .payment-logo{width:44px!important;height:38px!important}.premium-methods .premium-method .method-name{font-size:14px!important;white-space:normal!important}.premium-methods .premium-method .method-note{white-space:normal!important;overflow-wrap:anywhere!important}}</style>

<style id="xt-deposit-final-instruction-layout-v4">
.xt-guide-caption{display:flex!important;align-items:flex-start!important;justify-content:center!important;width:100%!important;max-width:100%!important;min-width:0!important;box-sizing:border-box!important;white-space:normal!important;overflow-wrap:anywhere!important;word-break:normal!important}
.xt-guide-caption>span:last-child{flex:1 1 auto!important;min-width:0!important;max-width:100%!important;text-align:center!important;white-space:normal!important;overflow-wrap:anywhere!important}
.xt-notice-guide,.xt-notice-guide img{max-width:100%!important;box-sizing:border-box!important}
.payment-details .detail-text{overflow-wrap:anywhere!important;white-space:normal!important}
@media(max-width:560px){.xt-guide-caption{font-size:clamp(11px,3vw,14px)!important;line-height:1.35!important;padding:7px 2px 2px!important;gap:6px!important}.premium-deposit-page .deposit-wrap{margin-bottom:calc(124px + env(safe-area-inset-bottom))!important}}
</style>
