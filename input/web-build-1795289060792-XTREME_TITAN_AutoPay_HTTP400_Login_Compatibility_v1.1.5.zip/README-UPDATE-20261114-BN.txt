XTREME TITAN — PAYMENT TRANSLATION + HISTORY TOP-UP + STORE CATEGORY UPDATE

এই ZIP একটি targeted update patch; এটি সম্পূর্ণ website backup নয়।

যা ঠিক করা হয়েছে:
1) Add Funds-এর Automatic Deposit card এবং UddoktaPay Automatic Add Funds checkout page-এ language-client translation যুক্ত/হালনাগাদ।
2) History-তে All, Key Purchases, Top-Up এবং Deposits — চারটি filter। Diamond/Like/Weekly/Monthly/Guild War-সহ সব Gaming Top-Up order একই Top-Up filter-এ থাকবে।
3) History-তে Cancelled status দেখানোর translation dictionary এবং Paymently/UddoktaPay pending deposit cancel handling।
4) নতুন UddoktaPay checkout request-এ random cancel token তৈরি হয়; Paymently cancel redirect-এ token যাচাই করে pending deposit-কে cancelled করা হয়। ইতিমধ্যে verified/approved payment-কে cancelled দিয়ে overwrite করা হয় না।
5) Store-এর Gaming Top-Up category tiles এখন Admin-এর enabled purchase categories থেকে তৈরি হবে। Link-এর মতো blue underline style সরিয়ে premium card-button style দেওয়া হয়েছে।
6) Admin > Gaming Top-Up Products-এ Category Name/Slug free-text নয়; Admin > History Categories থেকে category dropdown select করতে হবে।
7) Store, History, Deposit, Top-Up এবং Automatic Checkout পেজে নতুন translation dictionary cache-bust করা হয়েছে।

UPLOAD:
- আগে website files ও MySQL database backup নিন।
- ZIP extract করে folder structure একই রেখে htdocs-এ upload করুন এবং matching files replace করুন।
- config.php বা কোনো credential এই ZIP-এ নেই; আপনার existing config.php replace করবেন না।
- Admin > History Categories-এ নতুন Product/Purchase category তৈরি করুন (Visible চালু রাখুন)।
- Admin > Gaming Top-Up Products-এ dropdown থেকে category বেছে Product Name, Amount/Package Label, Price ও Image দিয়ে Save করুন।
- Store-এ enabled purchase categories tile হিসেবে দেখাবে।

TEST:
- প্রথমে একটি test user দিয়ে অল্প টাকার deposit ও top-up request পরীক্ষা করুন।
- Automatic payment cancel redirect পরীক্ষা করুন; History-তে Cancelled দেখা উচিত।
- Already completed payment cancel করা যাবে না।
- Translation browser-এর selected xtreme_language preference অনুযায়ী হয়। নতুন free-form product names-এর জন্য existing MyMemory fallback ব্যবহার হতে পারে; network unavailable হলে original text থাকতে পারে।

LIMITATIONS:
- Paymently/UddoktaPay live server callback এবং database-এ পরীক্ষা করার সুযোগ ছিল না। তাই production-এ দেওয়ার আগে staging/test account-এ পরীক্ষা করুন।
- Gaming Top-Up fulfillment এখনও Admin manual Processing/Completed/Rejected workflow; game publisher delivery API এতে যুক্ত নয়।
