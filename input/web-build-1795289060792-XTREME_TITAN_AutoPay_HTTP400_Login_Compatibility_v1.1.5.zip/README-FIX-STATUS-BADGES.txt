XTREME TITAN - targeted patch

- Explicitly posts product media forms back to admin/products.php.
- Keeps the original Save/Add button text during chunked video upload and removes the temporary Uploading video / Saving product labels.
- Adds admin-controlled SAFE, RISK, UPDATING and TESTING badges per product.
- Renders selected badges in the top-left corner of the product photo/video.
- Preserves ONLINE / MAINTENANCE in the top-right corner.

Upload the ZIP contents to htdocs, preserving the existing folder structure. Back up your current files first. No SQL migration is required.
