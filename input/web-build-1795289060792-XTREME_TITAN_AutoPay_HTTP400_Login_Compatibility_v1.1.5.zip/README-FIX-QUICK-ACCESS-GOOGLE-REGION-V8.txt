XTREME TITAN — QUICK ACCESS TRANSLATION + GOOGLE REGION FLOW PATCH (V8)

Changes:
- Fixes Quick Access links where emoji and label were in the same text node, so My Keys, Add Funds, History and Profile can use the selected language dictionary.
- Preloads Google Identity Services before country selection; after a country is selected it requests Google's account prompt using the chosen country context.
- Keeps the existing Google credential callback and country/currency/language persistence path.
- Bumps client-side cache versions for language and region-picker scripts.

Important browser limitation:
Google controls its own account chooser. One Tap/prompt availability depends on the browser and Google session. If Google does not display the prompt, the standard Google sign-in button remains the supported fallback; a website cannot force-click Google's protected sign-in button.

Deploy by backing up the current site and uploading the patched files from this ZIP, preserving the existing folder structure. Test login and registration on the live host after upload.
