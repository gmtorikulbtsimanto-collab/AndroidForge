<?php
declare(strict_types=1);

/**
 * XTREME TITAN admin Web Push sender.
 * Requires minishlink/web-push from the project's vendor/autoload.php.
 */
if (!function_exists('xt_admin_push_tables')) {
    function xt_admin_push_tables(): void {
        $pdo = db();
        $pdo->exec("CREATE TABLE IF NOT EXISTS admin_push_subscriptions (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
            admin_id BIGINT NULL,
            endpoint TEXT NOT NULL,
            endpoint_hash CHAR(64) NULL,
            p256dh VARCHAR(255) NOT NULL,
            auth VARCHAR(255) NOT NULL,
            created_at DATETIME NOT NULL,
            updated_at DATETIME NOT NULL,
            UNIQUE KEY uq_admin_push_endpoint_hash (endpoint_hash),
            INDEX idx_admin_push_admin (admin_id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

        // Migrate installations where an earlier version created the table without endpoint_hash.
        $columns = $pdo->query("SHOW COLUMNS FROM admin_push_subscriptions")->fetchAll(PDO::FETCH_COLUMN);
        if (!in_array('endpoint_hash', $columns, true)) {
            $pdo->exec("ALTER TABLE admin_push_subscriptions ADD COLUMN endpoint_hash CHAR(64) NULL");
        }
        if (!in_array('admin_id', $columns, true)) {
            $pdo->exec("ALTER TABLE admin_push_subscriptions ADD COLUMN admin_id BIGINT NULL");
        }
        $rows = $pdo->query("SELECT id, endpoint FROM admin_push_subscriptions WHERE endpoint_hash IS NULL OR endpoint_hash=''")->fetchAll(PDO::FETCH_ASSOC);
        $update = $pdo->prepare("UPDATE admin_push_subscriptions SET endpoint_hash=? WHERE id=?");
        foreach ($rows as $row) {
            $update->execute([hash('sha256', (string)$row['endpoint']), (int)$row['id']]);
        }
        $indexes = $pdo->query("SHOW INDEX FROM admin_push_subscriptions")->fetchAll(PDO::FETCH_ASSOC);
        $hasUniqueHash = false;
        foreach ($indexes as $index) {
            if (($index['Key_name'] ?? '') === 'uq_admin_push_endpoint_hash') { $hasUniqueHash = true; break; }
        }
        if (!$hasUniqueHash) {
            $pdo->exec("ALTER TABLE admin_push_subscriptions ADD UNIQUE KEY uq_admin_push_endpoint_hash (endpoint_hash)");
        }
    }
}

if (!function_exists('xt_admin_push_public_key')) {
    function xt_admin_push_public_key(): string {
        if (!defined('XT_ADMIN_VAPID_PUBLIC_KEY') || !XT_ADMIN_VAPID_PUBLIC_KEY) {
            throw new RuntimeException('VAPID public key is not configured.');
        }
        return XT_ADMIN_VAPID_PUBLIC_KEY;
    }
}

if (!function_exists('xt_admin_send_push')) {
    /**
     * Send a notification to all active admin subscriptions.
     * Returns counts for diagnostics; never throws into the customer transaction.
     */
    function xt_admin_send_push(string $title, string $body, string $targetUrl = 'dashboard.php'): array {
        try {
            if (!class_exists(\Minishlink\WebPush\WebPush::class)) {
                $autoload = __DIR__ . '/vendor/autoload.php';
                if (is_file($autoload)) require_once $autoload;
            }
            if (!class_exists(\Minishlink\WebPush\WebPush::class)) {
                throw new RuntimeException('Minishlink Web Push library is missing.');
            }
            if (!defined('XT_ADMIN_VAPID_PUBLIC_KEY') || !defined('XT_ADMIN_VAPID_PRIVATE_KEY')) {
                throw new RuntimeException('VAPID credentials are missing.');
            }

            xt_admin_push_tables();
            $rows = db()->query('SELECT id, endpoint, p256dh, auth FROM admin_push_subscriptions ORDER BY id ASC')->fetchAll(PDO::FETCH_ASSOC);
            if (!$rows) return ['sent'=>0, 'failed'=>0, 'subscriptions'=>0];

            $webPush = new \Minishlink\WebPush\WebPush([
                'VAPID' => [
                    'subject' => XT_ADMIN_VAPID_SUBJECT,
                    'publicKey' => XT_ADMIN_VAPID_PUBLIC_KEY,
                    'privateKey' => XT_ADMIN_VAPID_PRIVATE_KEY,
                ],
            ], ['TTL' => 300, 'urgency' => 'high'], 15);

            $sent = 0;
            $failed = 0;
            $delete = [];
            $targetUrl = ltrim($targetUrl, '/');
            if ($targetUrl === '' || strpos($targetUrl, '..') !== false || preg_match('~^[a-z]+:~i', $targetUrl)) {
                $targetUrl = 'admin/dashboard.php';
            } elseif (strpos($targetUrl, 'admin/') !== 0) {
                $targetUrl = 'admin/' . $targetUrl;
            }
            $payload = json_encode([
                'title' => mb_substr($title, 0, 120),
                'body' => mb_substr($body, 0, 240),
                'url' => '/' . $targetUrl,
                'tag' => 'xtreme-admin-' . substr(hash('sha256', $title . '|' . $body . '|' . microtime(true)), 0, 16),
            ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);

            foreach ($rows as $row) {
                try {
                    // Current browsers use aes128gcm. The subscription endpoint and keys
                    // are the browser-issued values saved by admin/push.php.
                    $subscription = \Minishlink\WebPush\Subscription::create([
                        'endpoint' => $row['endpoint'],
                        'publicKey' => $row['p256dh'],
                        'authToken' => $row['auth'],
                        'contentEncoding' => 'aes128gcm',
                    ]);
                    $report = $webPush->sendOneNotification($subscription, $payload, ['TTL'=>300, 'urgency'=>'high']);
                    if ($report->isSuccess()) {
                        $sent++;
                    } else {
                        $failed++;
                        $status = $report->getResponse() ? $report->getResponse()->getStatusCode() : 0;
                        if (in_array($status, [404, 410], true)) $delete[] = (int)$row['id'];
                        error_log('Admin Web Push failed for subscription '.$row['id'].': '.$report->getReason());
                    }
                } catch (Throwable $e) {
                    $failed++;
                    error_log('Admin Web Push error for subscription '.$row['id'].': '.$e->getMessage());
                }
            }
            if ($delete) {
                $in = implode(',', array_fill(0, count($delete), '?'));
                $st = db()->prepare("DELETE FROM admin_push_subscriptions WHERE id IN ($in)");
                $st->execute($delete);
            }
            return ['sent'=>$sent, 'failed'=>$failed, 'subscriptions'=>count($rows)];
        } catch (Throwable $e) {
            error_log('XT Admin Push sender: '.$e->getMessage());
            return ['sent'=>0, 'failed'=>0, 'subscriptions'=>0, 'error'=>$e->getMessage()];
        }
    }
}
