<?php
require_once __DIR__ . '/config.php';

if (
    empty($_SESSION['reset_user_id']) ||
    empty($_SESSION['reset_email'])
) {
    header('Location: forgot-password.php');
    exit;
}

$error = '';
$email = $_SESSION['reset_email'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $code = preg_replace('/\D/', '', $_POST['otp'] ?? '');
    $password = $_POST['password'] ?? '';
    $confirm = $_POST['confirm_password'] ?? '';

    if (strlen($code) !== 6) {

        $error = 'Enter the 6-digit verification code.';

    } elseif (strlen($password) < 6) {

        $error = 'Password must be at least 6 characters.';

    } elseif ($password !== $confirm) {

        $error = 'Passwords do not match.';

    } else {

        try {

            $s = db()->prepare(
                'SELECT id, reset_otp_hash,
                        reset_otp_expires_at,
                        reset_otp_attempts
                 FROM users
                 WHERE id = ?
                 LIMIT 1'
            );

            $s->execute([
                (int) $_SESSION['reset_user_id']
            ]);

            $u = $s->fetch();

            if (!$u || empty($u['reset_otp_hash'])) {

                $error = 'No active reset code. Please request a new code.';

            } elseif ((int) $u['reset_otp_attempts'] >= 5) {

                $error = 'Too many incorrect attempts. Please request a new code.';

            } elseif (
                empty($u['reset_otp_expires_at']) ||
                strtotime($u['reset_otp_expires_at']) < time()
            ) {

                $error = 'This reset code has expired. Please request a new code.';

            } elseif (!password_verify($code, $u['reset_otp_hash'])) {

                $s = db()->prepare(
                    'UPDATE users
                     SET reset_otp_attempts = reset_otp_attempts + 1
                     WHERE id = ?'
                );

                $s->execute([
                    $u['id']
                ]);

                $error = 'Incorrect verification code.';

            } else {

                $newPasswordHash = password_hash(
                    $password,
                    PASSWORD_DEFAULT
                );

                $s = db()->prepare(
                    'UPDATE users
                     SET password_hash = ?,
                         reset_otp_hash = NULL,
                         reset_otp_expires_at = NULL,
                         reset_otp_attempts = 0
                     WHERE id = ?'
                );

                $s->execute([
                    $newPasswordHash,
                    $u['id']
                ]);

                unset(
                    $_SESSION['reset_user_id'],
                    $_SESSION['reset_email'],
                    $_SESSION['reset_name']
                );

                header('Location: login.php');
                exit;
            }

        } catch (Throwable $e) {

            $error = 'Password reset failed. Please try again.';
        }
    }
}
?>

<!doctype html>
<html lang="en">

<head>
<link rel="stylesheet" href="theme.php?v=20261022-lightfix3">

    <meta charset="utf-8">

    <meta
        name="viewport"
        content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no"
    >

    <title>Reset Password — XTREME_TITAN_OFFICIAL SHOP</title>

    <link rel="stylesheet" href="style.css">
<style>.auth-brand{text-align:center;color:#fff;font-weight:1000;font-size:22px;letter-spacing:.7px;margin:8px auto 12px}.auth-brand span{color:#10d8ff}.auth-brand small{display:block;color:#91a0b5;font-size:9px;font-weight:700;letter-spacing:.5px;margin-top:5px}.page{width:min(430px,calc(100% - 24px));margin:auto;padding:18px 0 30px}.auth-card{background:rgba(5,14,25,.92)!important;border:1px solid rgba(16,216,255,.22)!important;border-radius:20px!important;padding:20px!important;box-shadow:0 20px 60px rgba(0,0,0,.42)}.auth-card h1{font-size:27px!important}.auth-card .btn{width:100%;border:0;border-radius:12px;padding:13px;background:linear-gradient(135deg,#10d8ff,#1681ff);color:#fff;font-weight:900}.auth-card input{border-radius:12px!important}.links a{color:#10d8ff!important}</style>

<link rel="stylesheet" href="reference-theme.css">
<link rel="stylesheet" href="site-polish.css?v=20261022-lightfix3">
<script src="theme-client.js?v=20260928-19" defer></script><link rel="stylesheet" href="premium-global.css?v=20261022-lightfix3"><script src="currency-client.js?v=20261018-fx1" defer></script><link rel="stylesheet" href="responsive-lock.css?v=20260929-28">

<link rel="icon" type="image/png" sizes="48x48" href="/assets/pwa-icon-48.png">
<link rel="apple-touch-icon" sizes="180x180" href="/assets/pwa-icon-180.png">
<link rel="manifest" href="/pwa-manifest.json">
<meta name="apple-mobile-web-app-title" content="XTREME TITAN">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="mobile-web-app-capable" content="yes">
<meta name="theme-color" content="#080a14">
<script src="/admin/admin-action-progress.js?v=20261023-inline-progress25" defer></script>
</head>

<body>

<div class="page">

    <div class="auth-brand"><img class="site-logo" src="assets/xtreme-titan-logo.jpg" alt="XTREME TITAN">XTREME <span>TITAN</span><small>XTREME_TITAN_OFFICIAL SHOP</small></div>

    <div class="auth-card">

        <div class="eyebrow">
            VERIFY &amp; RESET
        </div>

        <h1>
            Reset password
        </h1>

        <p class="intro">
            Enter the 6-digit code sent to
            <strong><?= e($email) ?></strong>
            and choose a new password.
        </p>

        <?php if ($error): ?>

            <div class="alert error">
                <?= e($error) ?>
            </div>

        <?php endif; ?>

        <form method="post" autocomplete="off">

            <label for="otp">
                6-digit verification code
            </label>

            <input
                id="otp"
                type="text"
                name="otp"
                inputmode="numeric"
                pattern="[0-9]{6}"
                maxlength="6"
                minlength="6"
                placeholder="000000"
                autocomplete="one-time-code"
                required
            >

            <label for="password">
                New password
            </label>

            <input
                id="password"
                type="password"
                name="password"
                minlength="6"
                placeholder="Create a new password"
                autocomplete="new-password"
                required
            >

            <label for="confirm_password">
                Confirm new password
            </label>

            <input
                id="confirm_password"
                type="password"
                name="confirm_password"
                minlength="6"
                placeholder="Repeat your new password"
                autocomplete="new-password"
                required
            >

            <button
                class="btn"
                type="submit"
            >
                Reset password
            </button>

        </form>

        <div class="links">

            <a href="login.php">
                Back to sign in
            </a>

        </div>

    </div>

    <footer>
        © <?= date('Y') ?> XTREME_TITAN_OFFICIAL SHOP
    </footer>

</div>

</body>

</html>