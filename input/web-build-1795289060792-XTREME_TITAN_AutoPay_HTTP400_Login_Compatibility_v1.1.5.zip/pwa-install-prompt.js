(function(){
  'use strict';
  var deferredPrompt = null;
  var banner = null;
  var installBtn = null;
  var cancelBtn = null;
  var dismissedKey = 'xt_pwa_install_prompt_dismissed_session';
  function isStandalone(){
    return (window.matchMedia && window.matchMedia('(display-mode: standalone)').matches) || window.navigator.standalone === true;
  }
  function makeBanner(){
    if (banner) return;
    banner = document.createElement('div');
    banner.id = 'xt-pwa-install-banner';
    banner.setAttribute('role','region');
    banner.setAttribute('aria-label','Install XTREME TITAN app');
    banner.innerHTML = '<div class="xt-pwa-copy"><div class="xt-pwa-title">Install XTREME TITAN</div><div class="xt-pwa-sub">Add our website to your Home Screen</div></div><button type="button" id="xt-pwa-install-btn">Install</button><button type="button" id="xt-pwa-cancel-btn">Cancel</button>';
    document.body.insertBefore(banner, document.body.firstChild);
    document.body.classList.add('xt-pwa-banner-visible');
    installBtn = document.getElementById('xt-pwa-install-btn');
    cancelBtn = document.getElementById('xt-pwa-cancel-btn');
    installBtn.addEventListener('click', function(){
      if (deferredPrompt) {
        deferredPrompt.prompt();
        deferredPrompt.userChoice.then(function(choice){
          deferredPrompt = null;
          if (choice && choice.outcome === 'accepted') hideBanner(false);
        }).catch(function(){});
      } else {
        var isIOS = /iphone|ipad|ipod/i.test(navigator.userAgent) && !window.MSStream;
        alert(isIOS ? 'To install: tap Share in Safari, then choose “Add to Home Screen”.' : 'If the install prompt is not available yet, open your browser menu and choose “Install app” or “Add to Home screen”.');
      }
    });
    cancelBtn.addEventListener('click', function(){
      try { sessionStorage.setItem(dismissedKey,'1'); } catch(e) {}
      hideBanner(false);
    });
  }
  function hideBanner(keepPadding){
    if (banner) banner.hidden = true;
    if (!keepPadding) document.body.classList.remove('xt-pwa-banner-visible');
  }
  window.addEventListener('beforeinstallprompt', function(event){
    event.preventDefault();
    deferredPrompt = event;
  });
  window.addEventListener('appinstalled', function(){
    deferredPrompt = null;
    hideBanner(false);
  });
  function init(){
    if (isStandalone()) return;
    try { if (sessionStorage.getItem(dismissedKey) === '1') return; } catch(e) {}
    makeBanner();
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded',init); else init();
})();
