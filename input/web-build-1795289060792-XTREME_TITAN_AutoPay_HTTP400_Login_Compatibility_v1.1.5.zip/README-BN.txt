এই ZIP-এ শুধু admin/push.php আছে।
Upload destination: htdocs/
Extract destination: htdocs/
এতে ফাইলটি htdocs/admin/push.php-তে বসবে।
পুরোনো ফাইলের Backup আগে রাখুন। এরপর Admin Panel থেকে Logout করে আবার Login করুন।
তারপর Dashboard-এর Enable Push ব্যবহার করুন; URL আলাদা করে নতুন tab-এ খুলে পরীক্ষা করবেন না।
