XTREME TITAN OFFICIAL SHOP — Google Region / Sign-in Flow Fix

Expected flow:
1. Login and registration pages show a Google-coloured G mark and Continue with Google.
2. First click opens country/region selection.
3. Selecting a country saves country, currency and language, then automatically opens a separate compact Google sign-in panel.
4. The compact panel contains Google's official Google Identity Services rendered button. One click opens Google's account chooser.
5. After the user chooses an account and Google returns a credential, the existing google-auth.php callback completes sign-in.

Files changed:
- auth-region-picker.js
- auth-region-picker.css
- login.php (cache-busting and Google logo)
- register.php (cache-busting and Google logo)

Important: this ZIP has not been tested on the live hosting account. Google OAuth still requires the configured client ID, authorized origin, and callback/server settings to be correct.
