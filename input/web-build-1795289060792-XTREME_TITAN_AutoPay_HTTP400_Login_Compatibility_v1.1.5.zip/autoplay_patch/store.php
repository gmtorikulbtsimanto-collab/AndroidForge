<?php
require_once __DIR__.'/config.php';
$s=site_settings();
$mode=(string)($s['theme_default']??'premium');
$primary=(string)($s['theme_primary']??'#16d9ff');
$secondary=(string)($s['theme_secondary']??'#2685ff');
$bg=(string)($s['theme_background']??'#050b14');
$panel=(string)($s['theme_panel']??'#0d1b2d');
$particleMode=(string)($s['particle_mode']??'dots');
$particleOpacity=max(0,min(100,(int)($s['particle_opacity']??55)))/100;
$particleSpeed=max(5,min(60,(int)($s['particle_speed']??18)));
$particleSize=max(1,min(8,(int)($s['particle_size']??3)));
$particleColor=(string)($s['particle_color']??'#b8e7ff');
if(!preg_match('/^#[0-9a-fA-F]{6}$/',$particleColor)) $particleColor='#b8e7ff';
$themes=[
'black'=>['#18d9ff','#3478ff','#02050a','#0a111b'],
'obsidian'=>['#16d9ff','#6d5cff','#03060c','#101827'],
'white'=>['#1677ff','#5b45ff','#f5f7fb','#ffffff'],
'premium'=>[$primary,$secondary,$bg,$panel],
'luxury'=>['#111827','#8b5cf6','#f7f7f5','#ffffff']
];
if(isset($themes[$mode]) && $mode!=='premium'){[$primary,$secondary,$bg,$panel]=$themes[$mode];}
header('Content-Type: text/css; charset=UTF-8');
?>
:root{--xt-site-background:url('<?=htmlspecialchars((string)($s['background_path']??'assets/tanofficial_neon_background.gif'),ENT_QUOTES,'UTF-8')?>');--v6-cyan:<?=htmlspecialchars($primary,ENT_QUOTES,'UTF-8')?>!important;--v6-blue:<?=htmlspecialchars($secondary,ENT_QUOTES,'UTF-8')?>!important;--v6-bg:<?=htmlspecialchars($bg,ENT_QUOTES,'UTF-8')?>!important;--v6-panel:<?=htmlspecialchars($panel,ENT_QUOTES,'UTF-8')?>!important;--premium-cyan:<?=htmlspecialchars($primary,ENT_QUOTES,'UTF-8')?>!important;--premium-blue:<?=htmlspecialchars($secondary,ENT_QUOTES,'UTF-8')?>!important}
html,body{background-color:<?=htmlspecialchars($bg,ENT_QUOTES,'UTF-8')?>!important}body{--theme-primary:<?=htmlspecialchars($primary,ENT_QUOTES,'UTF-8')?>;--theme-secondary:<?=htmlspecialchars($secondary,ENT_QUOTES,'UTF-8')?>}.card,.panel,.key-card,.item,.product,.dashboard-balance,.dashboard-stat,.dashboard-quick{background:linear-gradient(145deg,<?=htmlspecialchars($panel,ENT_QUOTES,'UTF-8')?>ee,<?=htmlspecialchars($bg,ENT_QUOTES,'UTF-8')?>e8)!important}.submit,.copy-btn,.product-action,.tab.active,.range.active,.add{background:linear-gradient(135deg,<?=htmlspecialchars($primary,ENT_QUOTES,'UTF-8')?>,<?=htmlspecialchars($secondary,ENT_QUOTES,'UTF-8')?>)!important}.nav>a.active,.bottom-nav>a.active{color:<?=htmlspecialchars($primary,ENT_QUOTES,'UTF-8')?>!important;border-color:<?=htmlspecialchars($primary,ENT_QUOTES,'UTF-8')?>!important}.profile-action:hover{border-color:<?=htmlspecialchars($primary,ENT_QUOTES,'UTF-8')?>!important}
html[data-theme="white"],html[data-theme="luxury"] body{color:#111827!important}html[data-theme="white"] .panel,html[data-theme="luxury"] .panel,html[data-theme="white"] .card,html[data-theme="luxury"] .card{color:#111827!important;background:#fff!important}html[data-theme="white"] .subtitle,html[data-theme="luxury"] .subtitle,html[data-theme="white"] .muted,html[data-theme="luxury"] .muted{color:#64748b!important}html[data-theme="white"] input,html[data-theme="luxury"] input,html[data-theme="white"] textarea,html[data-theme="luxury"] textarea{background:#f8fafc!important;color:#111827!important}

/* Global theme engine: the selected profile theme follows the user across every page. */
html[data-theme="black"]{--ui-bg:#03060b;--ui-panel:#0b111b;--ui-panel2:#101927;--ui-text:#f6f8ff;--ui-muted:#94a3b8;--ui-accent:#35e8c5;--ui-accent2:#18a0ff;--ui-money:#55e6a5;--ui-ref:#c084fc;--ui-deposit:#ffb454;--ui-topup:#ff5c8a}
html[data-theme="obsidian"]{--ui-bg:#05050b;--ui-panel:#111322;--ui-panel2:#171a2b;--ui-text:#fafaff;--ui-muted:#9da4bb;--ui-accent:#8b7cff;--ui-accent2:#38bdf8;--ui-money:#4ade80;--ui-ref:#f472b6;--ui-deposit:#fbbf24;--ui-topup:#22d3ee}
html[data-theme="premium"]{--ui-bg:#080a12;--ui-panel:#121625;--ui-panel2:#191f31;--ui-text:#f8fafc;--ui-muted:#9aa6bc;--ui-accent:#e879f9;--ui-accent2:#8b5cf6;--ui-money:#34d399;--ui-ref:#f59e0b;--ui-deposit:#fb7185;--ui-topup:#22d3ee}
html[data-theme="white"]{--ui-bg:#f3f5f9;--ui-panel:#ffffff;--ui-panel2:#f8fafc;--ui-text:#172033;--ui-muted:#64748b;--ui-accent:#7c3aed;--ui-accent2:#ec4899;--ui-money:#059669;--ui-ref:#d97706;--ui-deposit:#e11d48;--ui-topup:#0891b2}
html[data-theme="luxury"]{--ui-bg:#f7f5ef;--ui-panel:#fffdf8;--ui-panel2:#f5efe3;--ui-text:#211b16;--ui-muted:#756a60;--ui-accent:#a16207;--ui-accent2:#b45309;--ui-money:#15803d;--ui-ref:#9333ea;--ui-deposit:#be123c;--ui-topup:#0f766e}

html[data-theme]{background:var(--ui-bg)!important}
html[data-theme] body{background:var(--ui-bg)!important;color:var(--ui-text)!important}
html[data-theme] body::before{content:none!important;display:none!important;animation:none!important;background-image:none!important}
html[data-theme] body::after{background:linear-gradient(180deg,rgba(0,0,0,.04),rgba(0,0,0,.18))!important}
html[data-theme="white"] body::before,html[data-theme="luxury"] body::before{background-color:transparent!important}
html[data-theme="white"] body::after,html[data-theme="luxury"] body::after{background:rgba(255,255,255,.05)!important}

html[data-theme] .top,html[data-theme] .topbar{background:color-mix(in srgb,var(--ui-panel) 94%,transparent)!important;border-color:color-mix(in srgb,var(--ui-accent) 24%,transparent)!important;color:var(--ui-text)!important}
html[data-theme] .brand,html[data-theme] .top-title,html[data-theme] h1,html[data-theme] h2,html[data-theme] h3,html[data-theme] .title,html[data-theme] .item-title{color:var(--ui-text)!important}
html[data-theme] .subtitle,html[data-theme] .sub,html[data-theme] .muted,html[data-theme] .desc,html[data-theme] .small{color:var(--ui-muted)!important}
html[data-theme] .panel,html[data-theme] .profile,html[data-theme] .quick,html[data-theme] .balance,html[data-theme] .summary-card,html[data-theme] .card,html[data-theme] .item,html[data-theme] .product,html[data-theme] .key-card,html[data-theme] .dashboard-balance,html[data-theme] .dashboard-stat,html[data-theme] .dashboard-quick,.theme-box,.profile-action{background:linear-gradient(145deg,var(--ui-panel),var(--ui-panel2))!important;color:var(--ui-text)!important;border-color:color-mix(in srgb,var(--ui-accent) 18%,#64748b)!important;box-shadow:0 20px 60px rgba(0,0,0,.12),inset 0 1px 0 rgba(255,255,255,.04)!important}
html[data-theme="white"] .panel,html[data-theme="white"] .card,html[data-theme="white"] .item,html[data-theme="white"] .product,html[data-theme="white"] .key-card,html[data-theme="white"] .profile-action,html[data-theme="luxury"] .panel,html[data-theme="luxury"] .card,html[data-theme="luxury"] .item,html[data-theme="luxury"] .product,html[data-theme="luxury"] .key-card,html[data-theme="luxury"] .profile-action{box-shadow:0 18px 45px rgba(15,23,42,.08),inset 0 1px 0 rgba(255,255,255,.9)!important}
html[data-theme] input,html[data-theme] select,html[data-theme] textarea{background:color-mix(in srgb,var(--ui-bg) 78%,var(--ui-panel))!important;color:var(--ui-text)!important;border-color:color-mix(in srgb,var(--ui-accent) 20%,#94a3b8)!important}
html[data-theme] input::placeholder,html[data-theme] textarea::placeholder{color:var(--ui-muted)!important}
html[data-theme] .submit,html[data-theme] .add,html[data-theme] .buy-btn,html[data-theme] .product-action,html[data-theme] .copy-btn,html[data-theme] .topup{background:linear-gradient(135deg,var(--ui-accent),var(--ui-accent2))!important;color:#fff!important;border:0!important;box-shadow:0 14px 32px color-mix(in srgb,var(--ui-accent2) 28%,transparent)!important}
html[data-theme] .nav,html[data-theme] .bottom-nav{background:color-mix(in srgb,var(--ui-panel) 96%,transparent)!important;border-color:color-mix(in srgb,var(--ui-accent) 25%,transparent)!important}
html[data-theme] .nav>a.active,html[data-theme] .bottom-nav>a.active{color:var(--ui-accent)!important;background:color-mix(in srgb,var(--ui-accent) 11%,transparent)!important;border-color:color-mix(in srgb,var(--ui-accent) 35%,transparent)!important}

/* Stable controls: every page keeps the same touch target and typography. */
html[data-theme] button,html[data-theme] .btn,html[data-theme] a.btn,html[data-theme] .submit,html[data-theme] .add,html[data-theme] .buy-btn,html[data-theme] .product-action{min-height:48px!important;min-width:0!important;border-radius:14px!important;font-size:14px!important;font-weight:900!important;line-height:1.15!important;display:inline-flex!important;align-items:center!important;justify-content:center!important;box-sizing:border-box!important;padding:12px 16px!important;text-decoration:none!important;cursor:pointer!important}
html[data-theme] .nav>a,html[data-theme] .bottom-nav>a{min-height:60px!important;height:60px!important;padding:7px 4px!important;display:flex!important;flex-direction:column!important;align-items:center!important;justify-content:center!important;gap:3px!important;font-size:10px!important}
html[data-theme] .theme-btn{min-height:58px!important;height:auto!important;padding:9px 6px!important;border-radius:14px!important;background:var(--ui-panel2)!important;color:var(--ui-muted)!important;border-color:color-mix(in srgb,var(--ui-accent) 20%,#64748b)!important}
html[data-theme] .theme-btn.active{background:linear-gradient(135deg,var(--ui-accent),var(--ui-accent2))!important;color:#fff!important;border-color:transparent!important}

/* Semantic dashboard colours: money, referrals, deposits and top-ups stay visually distinct. */
html[data-theme] .balance-value,html[data-theme] .money,html[data-theme] .wallet-value,.wallet-balance,.amount.money{color:var(--ui-money)!important}
html[data-theme] .ref-value,.referral-value,.referrals-value{color:var(--ui-ref)!important}
html[data-theme] .deposit-value,.deposit-amount,.deposit-accent{color:var(--ui-deposit)!important}
html[data-theme] .topup-value,.topup-accent,.add-funds-accent{color:var(--ui-topup)!important}
html[data-theme] .amount{color:var(--ui-money)!important}
html[data-theme] .status{border-radius:999px!important}
html[data-theme] .premium-method.selected,html[data-theme] .method.selected{border-color:var(--ui-deposit)!important;box-shadow:0 0 0 2px color-mix(in srgb,var(--ui-deposit) 13%,transparent),0 14px 35px rgba(0,0,0,.14)!important}

@media(max-width:600px){html[data-theme] .wrap,html[data-theme] .container,html[data-theme] .page{padding-left:13px!important;padding-right:13px!important}html[data-theme] .panel,html[data-theme] .card,html[data-theme] .item{border-radius:20px!important}html[data-theme] button,html[data-theme] .btn,html[data-theme] .submit,html[data-theme] .add,html[data-theme] .buy-btn,html[data-theme] .product-action{min-height:50px!important}}

/* Admin-controlled particle variables; the shared JS canvas renders genuinely moving foreground particles. */
html{--xt-particle-mode:<?=htmlspecialchars($particleMode,ENT_QUOTES,'UTF-8')?>;--xt-particle-opacity:<?=number_format($particleOpacity,2,'.','')?>;--xt-particle-speed:<?=$particleSpeed?>s;--xt-particle-size:<?=$particleSize?>px;--xt-particle-color:<?=htmlspecialchars($particleColor,ENT_QUOTES,'UTF-8')?>}


/* Light themes: explicit contrast fixes for every shared page, including profile and My Keys. */
html[data-theme="white"],html[data-theme="luxury"]{color-scheme:light!important}
html[data-theme="white"] body,html[data-theme="luxury"] body{background:var(--ui-bg)!important;color:var(--ui-text)!important}
html[data-theme="white"] .top,html[data-theme="white"] .topbar,html[data-theme="white"] header,html[data-theme="luxury"] .top,html[data-theme="luxury"] .topbar,html[data-theme="luxury"] header{background:var(--ui-panel)!important;color:var(--ui-text)!important;border-color:color-mix(in srgb,var(--ui-accent) 24%,#cbd5e1)!important}
html[data-theme="white"] .profile-hero,html[data-theme="luxury"] .profile-hero{background:linear-gradient(145deg,#ffffff,#f1f5f9)!important;color:var(--ui-text)!important;border-color:#cbd5e1!important}
html[data-theme="white"] .theme-box,html[data-theme="luxury"] .theme-box,html[data-theme="white"] .preference-box,html[data-theme="luxury"] .preference-box{background:var(--ui-panel)!important;color:var(--ui-text)!important;border-color:#cbd5e1!important}
html[data-theme="white"] .profile-action,html[data-theme="luxury"] .profile-action,html[data-theme="white"] .key-card,html[data-theme="luxury"] .key-card,html[data-theme="white"] .empty,html[data-theme="luxury"] .empty{background:linear-gradient(145deg,var(--ui-panel),var(--ui-panel2))!important;color:var(--ui-text)!important;border-color:color-mix(in srgb,var(--ui-accent) 22%,#cbd5e1)!important}
html[data-theme="white"] .product,html[data-theme="luxury"] .product,html[data-theme="white"] .pa-title,html[data-theme="luxury"] .pa-title,html[data-theme="white"] .pref-title,html[data-theme="luxury"] .pref-title,html[data-theme="white"] .section-title,html[data-theme="luxury"] .section-title,html[data-theme="white"] .eyebrow,html[data-theme="luxury"] .eyebrow{color:var(--ui-text)!important}
html[data-theme="white"] .meta,html[data-theme="luxury"] .meta,html[data-theme="white"] .pa-text,html[data-theme="luxury"] .pa-text,html[data-theme="white"] .pref-text,html[data-theme="luxury"] .pref-text,html[data-theme="white"] .muted,html[data-theme="luxury"] .muted{color:var(--ui-muted)!important}
html[data-theme="white"] .key,html[data-theme="luxury"] .key{background:#eef2f7!important;color:#1e293b!important;border-color:color-mix(in srgb,var(--ui-accent) 35%,#cbd5e1)!important}
html[data-theme="white"] .nav,html[data-theme="luxury"] .nav,html[data-theme="white"] .bottom-nav,html[data-theme="luxury"] .bottom-nav{background:var(--ui-panel)!important;color:var(--ui-text)!important;border-color:#cbd5e1!important}
html[data-theme="white"] .nav>a,html[data-theme="luxury"] .nav>a,html[data-theme="white"] .bottom-nav>a,html[data-theme="luxury"] .bottom-nav>a{color:var(--ui-muted)!important}
html[data-theme="white"] .theme-btn:not(.active),html[data-theme="luxury"] .theme-btn:not(.active){background:var(--ui-panel2)!important;color:var(--ui-text)!important;border-color:#cbd5e1!important}
html[data-theme="white"] body::after,html[data-theme="luxury"] body::after{background:transparent!important;opacity:0!important}
#xtreme-starfall-canvas{pointer-events:none!important}


<style id="xtreme-wallet-single-icon-fix-v42">
/* One wallet icon only: keep the card's icon and remove the older value-level icon. */
.store-dashboard .dashboard-balance-value:before,
.store-dashboard .dashboard-balance-value:after {
  content:none!important;
  display:none!important;
  background:none!important;
}
.store-dashboard .dashboard-balance:after {
  content:none!important;
  display:none!important;
}
</style>
