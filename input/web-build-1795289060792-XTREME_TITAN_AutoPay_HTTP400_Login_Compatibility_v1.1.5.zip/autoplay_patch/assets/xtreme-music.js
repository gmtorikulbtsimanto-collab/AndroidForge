(function(){
'use strict';
var cfg=document.currentScript;
var enabled=!!(cfg && cfg.dataset.enabled==='1');
var src=(cfg && cfg.dataset.src)||'uploads/music/xtreme-background.m4a';
if(!enabled || !src) return;
var audio=new Audio(src); audio.preload='auto'; audio.loop=true; audio.volume=.42;
var muteKey='xt_music_muted_v1',posKey='xt_music_pos_v1',muted=false;
try{muted=localStorage.getItem(muteKey)==='1';}catch(e){}
audio.muted=muted;
var player=document.createElement('button');
player.type='button';player.className='xt-music-toggle';
player.setAttribute('aria-label',muted?'Unmute background music':'Mute background music');
player.title='Background music — tap to mute or unmute';
player.innerHTML='<span class="xt-music-icon" aria-hidden="true"><svg viewBox="0 0 24 24" focusable="false"><path d="M9 18V5l12-2v13M9 10l12-2M5.5 21a3.5 2.5 0 1 0 0-5 3.5 2.5 0 0 0 0 5Zm12-2a3.5 2.5 0 1 0 0-5 3.5 2.5 0 0 0 0 5Z"/></svg></span><span class="xt-music-state">'+(muted?'MUTED':'MUSIC')+'</span>';
function update(){
 player.classList.toggle('is-muted',audio.muted);
 player.querySelector('.xt-music-state').textContent=audio.muted?'MUTED':'MUSIC';
 player.setAttribute('aria-label',audio.muted?'Unmute background music':'Mute background music');
}
document.addEventListener('DOMContentLoaded',function(){if(!player.isConnected)document.body.appendChild(player);});
if(document.body)document.body.appendChild(player);
function savePos(){try{if(Number.isFinite(audio.currentTime)&&audio.currentTime>0)sessionStorage.setItem(posKey,String(audio.currentTime));}catch(e){}}
try{var saved=parseFloat(sessionStorage.getItem(posKey)||'0');if(saved>0)audio.addEventListener('loadedmetadata',function(){try{audio.currentTime=saved;}catch(e){}},{once:true});}catch(e){}
function play(){var p=audio.play();if(p&&p.then)p.then(function(){player.classList.remove('needs-tap');update();}).catch(function(){player.classList.add('needs-tap');});}
play();
player.addEventListener('click',function(e){
 e.preventDefault();e.stopPropagation();
 if(audio.paused){audio.muted=false;try{localStorage.setItem(muteKey,'0');}catch(x){}play();}
 else{audio.muted=!audio.muted;try{localStorage.setItem(muteKey,audio.muted?'1':'0');}catch(x){}if(!audio.muted)play();update();}
});
/* Browsers may block audible autoplay. Keep retrying until a real user gesture successfully starts playback. */
var unlocked=false, retryEvents=['pointerdown','touchend','keydown','click'];
function removeUnlockListeners(){retryEvents.forEach(function(ev){document.removeEventListener(ev,unlock,true);});}
function unlock(){
 if(unlocked || !audio.paused) { unlocked=true; removeUnlockListeners(); return; }
 var p;
 try { p=audio.play(); } catch(err) { return; }
 if(p && typeof p.then==='function'){
  p.then(function(){unlocked=true;player.classList.remove('needs-tap');removeUnlockListeners();update();})
   .catch(function(){player.classList.add('needs-tap');});
 } else { unlocked=true;removeUnlockListeners();update(); }
}
retryEvents.forEach(function(ev){document.addEventListener(ev,unlock,true);});

document.addEventListener('visibilitychange',function(){if(!document.hidden && audio.paused){play();}});
window.addEventListener('pagehide',savePos);window.addEventListener('beforeunload',savePos);document.addEventListener('visibilitychange',function(){if(document.hidden)savePos();});
setInterval(savePos,500);
update();
/* Button click tones are scoped to the requested customer pages only. */
var AudioCtx=window.AudioContext||window.webkitAudioContext,ctx=null,seq=0;
function sectionFor(){
 var p=(location.pathname||'').toLowerCase();
 if(/(?:store|dashboard)\.php$/.test(p))return 0;
 if(/my-?keys\.php$/.test(p))return 1;
 if(/deposit\.php$/.test(p))return 2;
 if(/history\.php$/.test(p))return 3;
 if(/profile\.php$/.test(p))return 4;
 return -1;
}
function clickTone(el){
 var section=sectionFor();if(!AudioCtx||section<0||el===player||el.closest('.xt-music-toggle'))return;
 try{
  if(!ctx)ctx=new AudioCtx();if(ctx.state==='suspended')ctx.resume();
  var label=(el.getAttribute('aria-label')||el.getAttribute('title')||el.innerText||el.value||el.id||'button').trim().toLowerCase();
  var hash=0;for(var i=0;i<label.length;i++)hash=(hash*31+label.charCodeAt(i))>>>0;
  var base=[520,610,700,790,880][section],freq=base+(hash%9)*23+(seq++%2)*7;
  var osc=ctx.createOscillator(),gain=ctx.createGain();osc.type='sine';
  osc.frequency.setValueAtTime(freq,ctx.currentTime);osc.frequency.exponentialRampToValueAtTime(freq*.78,ctx.currentTime+.075);
  gain.gain.setValueAtTime(.0001,ctx.currentTime);gain.gain.exponentialRampToValueAtTime(.045,ctx.currentTime+.008);gain.gain.exponentialRampToValueAtTime(.0001,ctx.currentTime+.095);
  osc.connect(gain);gain.connect(ctx.destination);osc.start();osc.stop(ctx.currentTime+.1);
 }catch(e){}
}
document.addEventListener('pointerdown',function(e){var el=e.target.closest('a,button,[role="button"],[onclick],input[type="submit"],input[type="button"],summary');if(el)clickTone(el);},{capture:true,passive:true});
})();