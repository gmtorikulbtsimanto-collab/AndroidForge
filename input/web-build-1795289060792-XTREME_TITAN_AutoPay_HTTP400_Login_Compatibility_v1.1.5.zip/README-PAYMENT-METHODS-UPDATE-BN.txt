XTREME TITAN OFFICIAL — পেমেন্ট মেথড আপডেট

এই ZIP-এ website Deposit page আপডেট করা হয়েছে:
- Website-এ শুধু bKash এবং Nagad দেখাবে।
- Website deposit currency BDT-তে সীমাবদ্ধ।
- POST/backend validation-এও শুধু bKash/Nagad গ্রহণ করা হবে; PayPal/Binance Pay জমা অনুরোধ প্রত্যাখ্যান হবে।
- bKash/Nagad-এর বিদ্যমান UddoktaPay secure checkout flow রাখা হয়েছে।

অ্যাপের ZIP আলাদা দেওয়া হয়েছে। অ্যাপে bKash, Nagad, Rocket এবং Upay চারটি source দেখানো হয়েছে। SMS permission/listener বা auto-match এখনো এই starter build-এ চালু নয়।

ইনস্টল: website root-এ এই ZIP-এর ফাইলগুলো upload করে পুরোনো deposit.php replace করুন। আগে backup নিন। config.php ও অন্যান্য existing settings অপরিবর্তিত রাখা হয়েছে।
