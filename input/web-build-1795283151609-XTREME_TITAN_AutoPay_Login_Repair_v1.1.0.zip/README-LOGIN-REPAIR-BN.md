# XTREME TITAN AutoPay — Login repair v1.1.0

## এই আপডেটে যা ঠিক করা হয়েছে
- APK এখন Login-এর আগে `website-mobile-api/health.php` দিয়ে API response পরীক্ষা করে।
- Shared hosting-এর browser security/challenge শেষ হওয়ার জন্য সর্বোচ্চ 8 বার retry করে।
- Health endpoint JSON না দিলে পাসওয়ার্ড পাঠায় না; কোন ধাপে সমস্যা হচ্ছে তা দেখায়।
- Login response-এ HTTP status, content-type, response URL এবং সংক্ষিপ্ত response preview দেখায়—আগের অস্পষ্ট HTTP 0 বার্তার বদলে।
- সফল Login-এর পর hidden WebView সঠিকভাবে সরিয়ে destroy করে।
- App version 1.1.0 / versionCode 110 করা হয়েছে।

## ইনস্টল
1. Website ZIP-এর `website-mobile-api` ফোল্ডারটি ওয়েবসাইটের `config.php`-এর একই directory-তে আপলোড করুন।
2. APK ZIP AndroidForge-এ import করে নতুন APK build করুন।
3. App-এ Website root URL অথবা `/website-mobile-api`-সহ URL দিন; app নিজে API path ঠিক করবে।
4. প্রথমে API health check সফল হতে হবে, তারপর Admin Login হবে।

## সীমাবদ্ধতা
এই ZIP source-level repair। এই পরিবেশে Android SDK/AndroidForge এবং আপনার live hosting/database-এ প্রবেশাধিকার নেই, তাই APK compile বা live login সফল হয়েছে বলে দাবি করা হচ্ছে না। যদি Health Check-এ HTML/403/503 আসে, সেটি hosting security/routing/config.php placement-এর সমস্যা; শুধু APK rebuild করলে সমাধান হবে না।
