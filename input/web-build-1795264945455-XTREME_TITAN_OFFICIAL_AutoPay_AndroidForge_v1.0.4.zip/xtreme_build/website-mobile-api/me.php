<?php
require __DIR__.'/_bootstrap.php'; xt_api_method('GET');
try{$pdo=db();$u=xt_api_user($pdo);xt_api_out(200,['ok'=>true,'user'=>$u,'wallet_balance'=>xt_api_balance($pdo,(int)$u['id']),'currency'=>'BDT']);}catch(Throwable $e){error_log('XT mobile me: '.$e->getMessage());xt_api_out(500,['ok'=>false,'message'=>'Could not load account']);}
