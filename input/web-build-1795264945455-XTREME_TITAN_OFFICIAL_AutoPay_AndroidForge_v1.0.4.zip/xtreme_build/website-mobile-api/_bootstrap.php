<?php
declare(strict_types=1);
require_once dirname(__DIR__) . '/config.php';
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');
header('X-Content-Type-Options: nosniff');
function xt_api_out(int $code, array $data): never { http_response_code($code); echo json_encode($data, JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE); exit; }
function xt_api_method(string $method): void { if (($_SERVER['REQUEST_METHOD'] ?? '') !== $method) xt_api_out(405,['ok'=>false,'message'=>'Method not allowed']); }
function xt_api_body(): array { $v=json_decode((string)file_get_contents('php://input'),true); return is_array($v)?$v:[]; }
function xt_api_columns(PDO $pdo,string $table): array { $s=$pdo->query("SHOW COLUMNS FROM `".str_replace('`','',$table)."`"); return array_column($s->fetchAll(PDO::FETCH_ASSOC),'Field'); }
function xt_api_pick(array $cols,array $choices): ?string { foreach($choices as $c) if(in_array($c,$cols,true)) return $c; return null; }
function xt_api_schema(PDO $pdo): void {
 $pdo->exec("CREATE TABLE IF NOT EXISTS mobile_api_tokens (id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,user_id INT NOT NULL,token_hash CHAR(64) NOT NULL UNIQUE,device_name VARCHAR(100) NULL,created_at DATETIME NOT NULL,expires_at DATETIME NOT NULL,last_used_at DATETIME NULL,revoked_at DATETIME NULL,INDEX idx_mobile_user(user_id),INDEX idx_mobile_expiry(expires_at)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
}
function xt_api_user(PDO $pdo): array {
 xt_api_schema($pdo); $h=[]; foreach(function_exists('getallheaders')?(getallheaders()?:[]):[] as $k=>$v)$h[strtolower($k)]=$v;
 $auth=(string)($h['authorization']??$_SERVER['HTTP_AUTHORIZATION']??''); if(!preg_match('/^Bearer\s+([A-Za-z0-9._-]{40,120})$/i',$auth,$m)) xt_api_out(401,['ok'=>false,'message'=>'Sign in to continue']);
 $hash=hash('sha256',$m[1]); $s=$pdo->prepare('SELECT id,user_id FROM mobile_api_tokens WHERE token_hash=? AND revoked_at IS NULL AND expires_at>UTC_TIMESTAMP() LIMIT 1');$s->execute([$hash]);$t=$s->fetch(PDO::FETCH_ASSOC); if(!$t)xt_api_out(401,['ok'=>false,'message'=>'Mobile session expired. Please sign in again.']);
 $pdo->prepare('UPDATE mobile_api_tokens SET last_used_at=UTC_TIMESTAMP() WHERE id=?')->execute([(int)$t['id']]);
 $cols=xt_api_columns($pdo,'users');$id=xt_api_pick($cols,['id']);$name=xt_api_pick($cols,['name','username']);$email=xt_api_pick($cols,['email']);$role=xt_api_pick($cols,['role']);
 $sql='SELECT `'.$id.'` AS id'.($name?',`'.$name.'` AS name':",'' AS name").($email?',`'.$email.'` AS email':",'' AS email").($role?',`'.$role.'` AS role':",'user' AS role").' FROM users WHERE `'.$id.'`=? LIMIT 1';$u=$pdo->prepare($sql);$u->execute([(int)$t['user_id']]);$user=$u->fetch(PDO::FETCH_ASSOC);if(!$user)xt_api_out(401,['ok'=>false,'message'=>'Account not found']);return $user;
}
function xt_api_balance(PDO $pdo,int $uid): string { $s=$pdo->prepare("SELECT COALESCE(SUM(COALESCE(amount_bdt,amount)),0) FROM deposits WHERE user_id=? AND LOWER(status)='approved'");$s->execute([$uid]);$credited=(float)$s->fetchColumn();$p=$pdo->prepare('SELECT COALESCE(SUM(total_amount),0) FROM user_purchases WHERE user_id=?');$p->execute([$uid]);$spent=(float)$p->fetchColumn();return number_format($credited-$spent,2,'.',''); }
