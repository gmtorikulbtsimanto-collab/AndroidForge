<?php
require __DIR__.'/_bootstrap.php'; xt_api_method('GET');
try{$pdo=db();$u=xt_api_user($pdo);$s=$pdo->prepare('SELECT id,amount,status,payment_method,transaction_id,created_at FROM deposits WHERE user_id=? ORDER BY id DESC LIMIT 50');$s->execute([(int)$u['id']]);xt_api_out(200,['ok'=>true,'deposits'=>$s->fetchAll(PDO::FETCH_ASSOC)]);}catch(Throwable $e){error_log('XT mobile history: '.$e->getMessage());xt_api_out(500,['ok'=>false,'message'=>'Could not load payment history']);}
