package com.xtremetitan.official.autopay;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.*;
import org.json.JSONObject;
import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

public class MainActivity extends Activity {
    private static final int BG=Color.rgb(6,17,31), PANEL=Color.rgb(12,29,48), LINE=Color.rgb(29,64,90), CYAN=Color.rgb(57,217,242), MUTED=Color.rgb(154,176,196), WHITE=Color.rgb(243,248,255), GREEN=Color.rgb(60,224,164);
    private String api="https://xtremetitanofficial.gamer.free/website-mobile-api", token="", method="bKash";
    private EditText identifier,password,amount,trx,apiInput;
    private LinearLayout accountBox, methodsBox;
    private TextView accountStatus;
    private Button loginButton, submitButton;
    private boolean busy=false;

    @Override public void onCreate(Bundle state){ super.onCreate(state); getWindow().setStatusBarColor(BG); getWindow().setNavigationBarColor(BG); buildUi(); }
    private GradientDrawable shape(int color,int stroke,int radius){ GradientDrawable d=new GradientDrawable(); d.setColor(color); d.setCornerRadius(dp(radius)); if(stroke!=0)d.setStroke(dp(1),stroke); return d; }
    private int dp(float v){return (int)(v*getResources().getDisplayMetrics().density+0.5f);}
    private TextView text(String value,int size,int color,boolean bold){ TextView t=new TextView(this); t.setText(value); t.setTextSize(size); t.setTextColor(color); if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD); return t; }
    private LinearLayout vertical(){ LinearLayout l=new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL); return l; }
    private void pad(View v,int a){v.setPadding(dp(a),dp(a),dp(a),dp(a));}
    private EditText field(String hint, boolean secret){ EditText e=new EditText(this); e.setSingleLine(true); e.setTextColor(WHITE); e.setHintTextColor(0xff60788d); e.setTextSize(14); e.setHint(hint); e.setPadding(dp(14),dp(11),dp(14),dp(11)); e.setBackground(shape(0xff071625,LINE,12)); if(secret)e.setInputType(129); return e; }
    private Button button(String label){ Button b=new Button(this); b.setText(label); b.setTextSize(12); b.setTypeface(Typeface.DEFAULT,Typeface.BOLD); b.setTextColor(0xff04111d); b.setAllCaps(false); b.setBackground(shape(CYAN,0,13)); return b; }
    private void label(LinearLayout parent,String s){ TextView t=text(s,10,MUTED,true); t.setLetterSpacing(.09f); LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2); p.topMargin=dp(14);p.bottomMargin=dp(7);parent.addView(t,p); }
    private void card(LinearLayout parent,View child){ child.setBackground(shape(PANEL,LINE,22)); pad(child,18); LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.bottomMargin=dp(16);parent.addView(child,p); }
    private void buildUi(){
        ScrollView scroll=new ScrollView(this); scroll.setFillViewport(true); scroll.setBackgroundColor(BG); LinearLayout root=vertical(); root.setPadding(dp(20),dp(20),dp(20),dp(38)); scroll.addView(root); setContentView(scroll);
        TextView kicker=text("XTREME TITAN OFFICIAL · SECURE PAYMENTS",10,CYAN,true); kicker.setLetterSpacing(.12f); root.addView(kicker);
        TextView title=text("AutoPay",30,WHITE,true); LinearLayout.LayoutParams tp=new LinearLayout.LayoutParams(-1,-2);tp.topMargin=dp(7);root.addView(title,tp);
        TextView subtitle=text("OFFICIAL PAYMENT COMPANION · ANDROID",12,MUTED,false); LinearLayout.LayoutParams sp=new LinearLayout.LayoutParams(-1,-2);sp.topMargin=dp(4);sp.bottomMargin=dp(20);root.addView(subtitle,sp);
        LinearLayout hero=vertical(); hero.setBackground(shape(0xff0b263b,0xff21627b,22));pad(hero,22); TextView h1=text("PAYMENT VERIFICATION",10,CYAN,true);hero.addView(h1);TextView h2=text("Your payments. One secure place.",23,WHITE,true);LinearLayout.LayoutParams h2p=new LinearLayout.LayoutParams(-1,-2);h2p.topMargin=dp(10);hero.addView(h2,h2p);TextView h3=text("bKash · Nagad · Rocket · Upay",12,MUTED,false);LinearLayout.LayoutParams h3p=new LinearLayout.LayoutParams(-1,-2);h3p.topMargin=dp(7);hero.addView(h3,h3p);LinearLayout.LayoutParams hp=new LinearLayout.LayoutParams(-1,-2);hp.bottomMargin=dp(16);root.addView(hero,hp);
        LinearLayout account=vertical();card(root,account);account.addView(text("Website account",19,WHITE,true));accountStatus=text("Connect your XTREME TITAN account to submit a deposit request.",12,MUTED,false);LinearLayout.LayoutParams asp=new LinearLayout.LayoutParams(-1,-2);asp.topMargin=dp(8);account.addView(accountStatus,asp);
        identifier=field("Website email or phone",false);password=field("Website password",true);label(account,"EMAIL OR PHONE");account.addView(identifier);label(account,"PASSWORD");account.addView(password);loginButton=button("CONNECT WEBSITE ACCOUNT");LinearLayout.LayoutParams lbp=new LinearLayout.LayoutParams(-1,-2);lbp.topMargin=dp(18);account.addView(loginButton,lbp);loginButton.setOnClickListener(v->signIn());
        LinearLayout deposit=vertical();card(root,deposit);deposit.addView(text("New deposit request",19,WHITE,true));label(deposit,"SELECT PAYMENT METHOD");methodsBox=new LinearLayout(this);methodsBox.setOrientation(LinearLayout.HORIZONTAL);methodsBox.setGravity(Gravity.CENTER_VERTICAL);deposit.addView(methodsBox); for(String m:new String[]{"bKash","Nagad","Rocket","Upay"}){ final String value=m; TextView chip=text(m,12,WHITE,true);chip.setGravity(Gravity.CENTER);chip.setPadding(dp(10),dp(12),dp(10),dp(12));chip.setBackground(shape(0xff071625,LINE,12));LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(0,-2,1);cp.setMargins(dp(2),0,dp(2),0);methodsBox.addView(chip,cp);chip.setOnClickListener(v->{method=value;refreshMethods();}); }
        label(deposit,"AMOUNT (BDT)");amount=field("0.00",false);amount.setInputType(8194);deposit.addView(amount);label(deposit,"TRANSACTION ID / REFERENCE");trx=field("Enter payment reference",false);trx.setInputType(0x00002001);deposit.addView(trx);submitButton=button("SUBMIT FOR VERIFICATION");LinearLayout.LayoutParams sbp=new LinearLayout.LayoutParams(-1,-2);sbp.topMargin=dp(18);deposit.addView(submitButton,sbp);submitButton.setOnClickListener(v->submit());TextView note=text("A request is not a payment confirmation. The XTREME TITAN OFFICIAL server must verify the transaction before crediting any wallet.",11,MUTED,false);note.setLineSpacing(dp(3),1f);LinearLayout.LayoutParams np=new LinearLayout.LayoutParams(-1,-2);np.topMargin=dp(12);deposit.addView(note,np);refreshMethods();
        LinearLayout server=vertical();card(root,server);server.addView(text("Server connection",19,WHITE,true));label(server,"XTREME TITAN MOBILE API URL");apiInput=field("API base URL",false);apiInput.setText(api);apiInput.setInputType( UriInputType());server.addView(apiInput);TextView sn=text("Use the HTTPS URL of your website's /website-mobile-api folder.",11,MUTED,false);LinearLayout.LayoutParams snp=new LinearLayout.LayoutParams(-1,-2);snp.topMargin=dp(10);server.addView(sn,snp);
        TextView foot=text("Deposit requests remain pending until verified by the website admin/provider. This app does not automatically verify MFS transactions.",11,MUTED,false);foot.setGravity(Gravity.CENTER);foot.setLineSpacing(dp(3),1f);root.addView(foot);
    }
    private int UriInputType(){return 0x00000001;}
    private void refreshMethods(){ if(methodsBox==null)return; for(int i=0;i<methodsBox.getChildCount();i++){View v=methodsBox.getChildAt(i);String s=((TextView)v).getText().toString();v.setBackground(shape(s.equals(method)?0xff103348:0xff071625,s.equals(method)?CYAN:LINE,12));((TextView)v).setTextColor(s.equals(method)?CYAN:WHITE);} }
    private interface Result {void done(JSONObject data,String error);}
    private void request(String path,String verb,JSONObject body,boolean auth,Result cb){ new Thread(()->{HttpURLConnection c=null;try{String base=apiInput!=null?apiInput.getText().toString().trim():api;if(base.endsWith("/"))base=base.substring(0,base.length()-1);c=(HttpURLConnection)new URL(base+path).openConnection();c.setRequestMethod(verb);c.setConnectTimeout(20000);c.setReadTimeout(20000);c.setRequestProperty("Accept","application/json");if(body!=null){c.setDoOutput(true);c.setRequestProperty("Content-Type","application/json; charset=UTF-8");try(OutputStream o=c.getOutputStream()){o.write(body.toString().getBytes(StandardCharsets.UTF_8));}}if(auth)c.setRequestProperty("Authorization","Bearer "+token);int code=c.getResponseCode();InputStream in=code>=200&&code<300?c.getInputStream():c.getErrorStream();ByteArrayOutputStream out=new ByteArrayOutputStream();byte[] buf=new byte[4096];int n;while((n=in.read(buf))!=-1)out.write(buf,0,n);JSONObject data=new JSONObject(out.toString("UTF-8"));if(code<200||code>=300)throw new Exception(data.optString("message","Request failed (HTTP "+code+")"));runOnUiThread(()->cb.done(data,null));}catch(Exception e){String msg=e.getMessage()==null?"Network error":e.getMessage();runOnUiThread(()->cb.done(null,msg));}finally{if(c!=null)c.disconnect();}}).start(); }
    private void signIn(){if(busy)return;String id=identifier.getText().toString().trim(),pw=password.getText().toString();if(id.isEmpty()||pw.isEmpty()){toast("Enter your website email/phone and password.");return;}api=apiInput.getText().toString().trim();JSONObject b=new JSONObject();try{b.put("identifier",id);b.put("password",pw);b.put("device_name","XTREME TITAN OFFICIAL Android");}catch(Exception ignored){}setBusy(true);request("/login.php","POST",b,false,(d,e)->{setBusy(false);if(e!=null){toast("Sign in failed: "+e);return;}token=d.optString("token","");JSONObject user=d.optJSONObject("user");accountStatus.setText("Connected as "+(user==null?"XTREME TITAN account":user.optString("name",user.optString("id","account"))));password.setText("");loginButton.setText("CONNECTED");toast("Your XTREME TITAN account is connected.");});}
    private void submit(){if(busy)return;if(token.isEmpty()){toast("Connect your XTREME TITAN account first.");return;}String a=amount.getText().toString().trim(),t=trx.getText().toString().trim();try{double v=Double.parseDouble(a);if(v<=0||t.isEmpty())throw new Exception();}catch(Exception ex){toast("Enter a valid amount and transaction reference.");return;}JSONObject b=new JSONObject();try{b.put("method",method);b.put("amount",Double.parseDouble(a));b.put("transaction_reference",t);}catch(Exception ignored){}setBusy(true);request("/deposit-submit.php","POST",b,true,(d,e)->{setBusy(false);if(e!=null){toast("Could not submit: "+e);return;}amount.setText("");trx.setText("");toast(d.optString("message","Request received. Pending verification."));});}
    private void setBusy(boolean v){busy=v;if(loginButton!=null)loginButton.setEnabled(!v);if(submitButton!=null)submitButton.setEnabled(!v);if(loginButton!=null)loginButton.setAlpha(v?.6f:1f);if(submitButton!=null)submitButton.setAlpha(v?.6f:1f);}
    private void toast(String s){Toast.makeText(this,s,Toast.LENGTH_LONG).show();}
}
