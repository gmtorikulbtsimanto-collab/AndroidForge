# XTREME TITAN OFFICIAL Mobile API (Phase 1)

Upload this entire `website-mobile-api` folder into the same directory as the live website's `config.php`. The API bootstrap loads that existing `config.php` and uses the site's current MySQL connection.

## Endpoints
- `POST /website-mobile-api/login.php` JSON `{ "identifier": "email-or-phone", "password": "...", "device_name": "iPhone" }` → returns a 30-day bearer token.
- `GET /website-mobile-api/me.php` with `Authorization: Bearer TOKEN` → account and wallet ledger balance.
- `GET /website-mobile-api/history.php` with bearer token → latest 50 deposit records.
- `POST /website-mobile-api/deposit-submit.php` with bearer token and JSON `{ "method":"bKash|Nagad|Rocket|Upay", "amount":100, "transaction_reference":"ABC123" }` → creates a **pending** deposit, rejects reused references.
- `POST /website-mobile-api/logout.php` with bearer token → revokes the current token.

## Safety and limitations
- This API never credits the wallet. A submitted reference is not proof of payment. Deposits remain pending until the existing admin/provider verification process approves them.
- The current website's existing UddoktaPay checkout integration is separate and currently exposes bKash/Nagad selection in its checkout entry page. Rocket/Upay automatic verification is **not implemented** by this mobile API; provider API credentials and documentation are required.
- No SMS inbox permission is requested. iOS cannot read another app's SMS inbox.
- HTTPS is mandatory. Keep `config.php` private and rotate any credentials that were ever included in a shared ZIP.
- The API creates `mobile_api_tokens` automatically on first login. Revoke tokens by signing out; they also expire after 30 days.
- This is a first backend bridge, not a production security audit. Add rate limiting/WAF controls at the host and test against a staging database before live use.

## Configure the app
Set the app's API URL to `https://xtremetitanofficial.gamer.free/website-mobile-api`. Do not include the trailing slash if possible. The domain must be the exact HTTPS domain serving the website's `config.php`.
