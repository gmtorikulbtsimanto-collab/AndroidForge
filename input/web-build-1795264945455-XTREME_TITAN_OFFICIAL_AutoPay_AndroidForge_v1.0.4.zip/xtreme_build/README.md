# XTREME TITAN OFFICIAL AutoPay — AndroidForge build package

This ZIP has been adapted from the supplied v1.0.4 Expo/React Native source into a native Android Gradle application so AndroidForge can detect and build it.

## Android project
- Android application module: `app`
- Namespace / application ID: `com.xtremetitan.official.autopay`
- Display name: `XTREME TITAN OFFICIAL AutoPay`
- Version: `1.0.4` (versionCode 104)
- Language: Java (native Android)
- Gradle: 8.7; Android Gradle Plugin: 8.6.1
- Minimum Android: 6.0 (API 23); compile/target SDK: 35

## Build with AndroidForge
1. Open https://professional-x.github.io/AndroidForge/.
2. Connect your own fork/repository using the GitHub token flow described by AndroidForge.
3. Upload this ZIP and select Android + `auto` or `debug` build variant.
4. Start the build. When the GitHub Actions run completes, download the APK artifact from that run.

AndroidForge is a GitHub Actions build service; this ZIP does not itself contain a compiled APK. A successful build depends on AndroidForge's current runner/toolchain and network dependency access. The Gradle wrapper JAR is intentionally not bundled; AndroidForge documents wrapper regeneration when it is absent. The included `gradlew` also attempts regeneration when a system Gradle is available.

## App functionality
- XTREME TITAN OFFICIAL dark/cyan payment companion UI
- Website account login through `POST /login.php`
- bKash, Nagad, Rocket, and Upay method selection
- Deposit request submission through `POST /deposit-submit.php`
- Editable HTTPS API base URL, prefilled with `https://xtremetitanofficial.gamer.free/website-mobile-api`
- Network requests run off the UI thread; INTERNET permission only

## Backend setup and payment safety
The `website-mobile-api/` folder is included unchanged from the supplied source. Upload that folder beside the website's `config.php` as described in `website-mobile-api/README.md`.

A submitted transaction reference is not proof of payment. This app only submits a pending deposit request; it does not automatically verify a transaction or credit a wallet. Keep payment-provider secrets on the server, use HTTPS, and test with a staging database before production. The supplied API documentation notes that Rocket/Upay auto-verification is not implemented in this bridge.

## Source preservation
The original Expo files (`App.js`, `app.json`, `eas.json`, and `package.json`) are preserved in `original-expo-source/` for reference. The AndroidForge build root is the native Gradle project at the ZIP root.

## Important verification note
This environment could not complete an online Gradle/Android SDK build, so the APK has not been compiled or device-tested here. Run AndroidForge and share its build log if it reports an error; the exact failing log is needed for a reliable fix.
