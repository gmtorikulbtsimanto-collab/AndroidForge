package com.xtremetitan.official.autopay;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import android.net.Uri;
import androidx.work.*;
import java.util.concurrent.TimeUnit;
import org.json.JSONObject;
import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;

public class MainActivity extends Activity {
 private static final int BG=0xff050b08,PANEL=0xff101a12,LINE=0xff31552a,GREEN=0xff8cff28,WHITE=0xfff3ffe9,MUTED=0xffa6b99b,REQ=501;
 private String api="",token="";
 private EditText identifier,password,apiInput; private TextView status,summary,queueStatus,historyText; private Button loginButton,smsButton; private boolean busy=false;
 private SharedPreferences prefs;
 @Override public void onCreate(Bundle b){super.onCreate(b);getWindow().setStatusBarColor(BG);getWindow().setNavigationBarColor(BG);prefs=getSharedPreferences("autopay_universal",MODE_PRIVATE);token=prefs.getString("token","");api=prefs.getString("api","");if(!token.isEmpty()){scheduleBackgroundSync();showDashboard();}else showLogin();}
 private int dp(float v){return (int)(v*getResources().getDisplayMetrics().density+.5f);}
 private GradientDrawable bg(int c,int s,int r){GradientDrawable d=new GradientDrawable();d.setColor(c);d.setCornerRadius(dp(r));if(s!=0)d.setStroke(dp(1),s);return d;}
 private TextView txt(String s,int z,int c,boolean b){TextView t=new TextView(this);t.setText(s);t.setTextSize(z);t.setTextColor(c);if(b)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);return t;}
 private LinearLayout col(){LinearLayout l=new LinearLayout(this);l.setOrientation(1);return l;}
 private void pad(View v,int n){v.setPadding(dp(n),dp(n),dp(n),dp(n));}
 private EditText field(String h,boolean secret){EditText e=new EditText(this);e.setSingleLine(true);e.setHint(h);e.setTextColor(WHITE);e.setHintTextColor(MUTED);e.setPadding(dp(13),dp(10),dp(13),dp(10));e.setBackground(bg(0xff09110b,LINE,12));if(secret)e.setInputType(129);return e;}
 private Button btn(String s){Button b=new Button(this);b.setText(s);b.setTextColor(0xff102006);b.setTypeface(null,Typeface.BOLD);b.setAllCaps(false);b.setBackground(bg(GREEN,0,13));return b;}
 private void label(LinearLayout p,String s){TextView t=txt(s,10,MUTED,true);LinearLayout.LayoutParams x=new LinearLayout.LayoutParams(-1,-2);x.topMargin=dp(13);x.bottomMargin=dp(6);p.addView(t,x);}
 private void card(LinearLayout p,View v){v.setBackground(bg(PANEL,LINE,18));pad(v,16);LinearLayout.LayoutParams x=new LinearLayout.LayoutParams(-1,-2);x.bottomMargin=dp(14);p.addView(v,x);}
 private void shell(LinearLayout root){ScrollView sc=new ScrollView(this);sc.setBackgroundColor(BG);sc.setFillViewport(true);sc.addView(root);setContentView(sc);}
 private void header(LinearLayout root){ImageView logo=new ImageView(this);logo.setImageResource(com.xtremetitan.official.autopay.R.drawable.autopay_logo);logo.setScaleType(ImageView.ScaleType.FIT_CENTER);LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(dp(116),dp(116));lp.gravity=Gravity.CENTER_HORIZONTAL;lp.bottomMargin=dp(12);root.addView(logo,lp);TextView t=txt("XTREME TITAN OFFICIAL",11,GREEN,true);root.addView(t);TextView h=txt("AutoPay",31,WHITE,true);LinearLayout.LayoutParams x=new LinearLayout.LayoutParams(-1,-2);x.topMargin=dp(4);root.addView(h,x);TextView sub=txt("CENTRAL PAYMENT SMS VERIFICATION PLATFORM",11,MUTED,true);root.addView(sub);}
 private boolean registerMode=false;
 private EditText nameInput;
 private Button modeButton;
 private void showLogin(){
  LinearLayout root=col();root.setPadding(dp(20),dp(24),dp(20),dp(30));shell(root);header(root);
  LinearLayout box=col();card(root,box);
  box.addView(txt(registerMode?"Create your AutoPay account":"Sign in to AutoPay",19,WHITE,true));
  TextView info=txt("Connect to the central XTREME TITAN OFFICIAL platform. One app works with your merchant account and linked websites.",12,MUTED,false);info.setLineSpacing(dp(3),1);LinearLayout.LayoutParams ip=new LinearLayout.LayoutParams(-1,-2);ip.topMargin=dp(8);box.addView(info,ip);
  label(box,"PLATFORM API URL");apiInput=field("https://your-domain.com/autopay/api",false);apiInput.setText(api);box.addView(apiInput);
  if(registerMode){label(box,"YOUR NAME");nameInput=field("Name",false);box.addView(nameInput);}
  label(box,"EMAIL ADDRESS");identifier=field("you@example.com",false);identifier.setInputType(33);box.addView(identifier);
  label(box,"PASSWORD");password=field("At least 12 characters",true);box.addView(password);
  loginButton=btn(registerMode?"CREATE ACCOUNT & CONNECT":"LOGIN");LinearLayout.LayoutParams bp=new LinearLayout.LayoutParams(-1,-2);bp.topMargin=dp(18);box.addView(loginButton,bp);
  loginButton.setOnClickListener(v->{if(registerMode)createAccount();else login();});
  modeButton=btn(registerMode?"I ALREADY HAVE AN ACCOUNT — LOGIN":"NEW HERE? CREATE ACCOUNT");
  modeButton.setBackground(bg(0xff18251a,LINE,13));modeButton.setTextColor(WHITE);
  LinearLayout.LayoutParams mp=new LinearLayout.LayoutParams(-1,-2);mp.topMargin=dp(8);box.addView(modeButton,mp);
  modeButton.setOnClickListener(v->{registerMode=!registerMode;showLogin();});
  TextView note=txt("SMS access is requested only after sign-in. Only supported payment notification fields are sent to your connected website. No wallet is credited automatically.",11,MUTED,false);note.setLineSpacing(dp(3),1);root.addView(note);
 }
 private void createAccount(){
  if(busy)return;
  String email=identifier.getText().toString().trim(),pw=password.getText().toString(),name=nameInput==null?"":nameInput.getText().toString().trim();
  api=normalizeApiBase(apiInput.getText().toString());if(api.isEmpty()){toast("Enter the central platform API URL ending in /api (HTTPS required).");return;}apiInput.setText(api);
  if(name.length()<2||email.isEmpty()||pw.length()<12){toast("Enter your name, valid email and a password of at least 12 characters.");return;}
  JSONObject b=new JSONObject();try{b.put("name",name);b.put("email",email);b.put("password",pw);b.put("device_name","Universal AutoPay Android device");}catch(Exception ignored){}
  busy=true;loginButton.setEnabled(false);
  req("/register.php","POST",b,false,(j,e)->{
   if(e!=null){busy=false;loginButton.setEnabled(true);toast(e);return;}
   // Registration creates the account; obtain a bearer session through the same central login API.
   JSONObject loginBody=new JSONObject();try{loginBody.put("email",email);loginBody.put("password",pw);}catch(Exception ignored){}
   req("/login.php","POST",loginBody,false,(lj,le)->{
    busy=false;loginButton.setEnabled(true);if(le!=null){toast("Account created. Please sign in: "+le);registerMode=false;showLogin();return;}
    token=lj.optString("token","");prefs.edit().putString("token",token).putString("api",api).apply();password.setText("");scheduleBackgroundSync();showDashboard();
   });
  });
 }
 private interface Done{void call(JSONObject j,String err);}
 private void req(String path,String method,JSONObject body,boolean auth,Done done){
  new Thread(()->{
   HttpURLConnection c=null;
   try{
    String base=normalizeApiBase(apiInput!=null?apiInput.getText().toString():api);
    URL target=new URL(base+path);
    c=(HttpURLConnection)target.openConnection();
    c.setRequestMethod(method);
    c.setConnectTimeout(25000);
    c.setReadTimeout(25000);
    c.setUseCaches(false);
    c.setInstanceFollowRedirects(true);
    c.setRequestProperty("Accept","application/json");
    c.setRequestProperty("User-Agent","XTREME-TITAN-AutoPay/0.2.0 Android");
    if(body!=null){
     c.setDoOutput(true);
     // Shared/free PHP hosts and WAF rules sometimes reject JSON POST bodies
     // with HTTP 400. The login endpoint already supports standard form POST.
     // Use form encoding for login; keep JSON for the other API endpoints.
     {
      c.setRequestProperty("Content-Type","application/x-www-form-urlencoded; charset=UTF-8");
      StringBuilder form=new StringBuilder();
      java.util.Iterator<String> keys=body.keys();
      while(keys.hasNext()){
       String key=keys.next();
       if(form.length()>0)form.append('&');
       form.append(URLEncoder.encode(key,"UTF-8"));
       form.append('=');
       form.append(URLEncoder.encode(body.optString(key,""),"UTF-8"));
      }
      try(OutputStream o=c.getOutputStream()){
       o.write(form.toString().getBytes(StandardCharsets.UTF_8));
       o.flush();
      }
     }
    }
    if(auth)c.setRequestProperty("Authorization","Bearer "+token);
    int code=c.getResponseCode();
    InputStream in=(code>=200&&code<400)?c.getInputStream():c.getErrorStream();
    String response="";
    if(in!=null){
     try(InputStream stream=in;ByteArrayOutputStream out=new ByteArrayOutputStream()){
      byte[] buf=new byte[4096];int n;
      while((n=stream.read(buf))!=-1)out.write(buf,0,n);
      response=out.toString("UTF-8").trim();
     }
    }
    JSONObject j;
    try{j=new JSONObject(response);}
    catch(Exception parse){
     String snippet=response.replaceAll("\\s+"," ");
     if(snippet.length()>180)snippet=snippet.substring(0,180);
     String ct=c.getContentType();
     throw new Exception("API response is not JSON (HTTP "+code+", "+(ct==null?"unknown content type":ct)+"). URL: "+target+". "+(snippet.isEmpty()?"Empty response.":snippet));
    }
    if(code<200||code>=300)throw new Exception(j.optString("message","API request failed (HTTP "+code+")"));
    runOnUiThread(()->done.call(j,null));
   }catch(Exception e){
    String m=e.getMessage();
    if(e instanceof java.net.UnknownHostException)m="Cannot find the website domain. Check the full Website API URL and internet connection.";
    else if(e instanceof javax.net.ssl.SSLException)m="Secure HTTPS connection failed: "+(m==null?"SSL error":m);
    else if(e instanceof java.net.SocketTimeoutException)m="Website did not respond within 25 seconds. Check hosting/server availability.";
    else if(e instanceof java.net.ConnectException)m="Could not connect to the website server: "+(m==null?"connection refused":m);
    if(m==null||m.trim().isEmpty())m=e.getClass().getSimpleName()+" while contacting website API.";
    final String message=m;
    runOnUiThread(()->done.call(null,message));
   }finally{if(c!=null)c.disconnect();}
  }).start();
 }

 private String normalizeApiBase(String value){
  String v=value==null?"":value.trim();
  while(v.endsWith("/"))v=v.substring(0,v.length()-1);
  if(v.endsWith("/api/login.php"))v=v.substring(0,v.length()-10);
  if(v.endsWith("/login.php"))v=v.substring(0,v.length()-10);
  if(v.endsWith("/api"))return v;
  if(!v.startsWith("https://"))return "";
  return v+"/api";
 }
 private void login(){
  if(busy)return;
  String email=identifier.getText().toString().trim(),pw=password.getText().toString();
  if(email.isEmpty()||pw.isEmpty()){toast("Enter your email and password.");return;}
  api=normalizeApiBase(apiInput.getText().toString());if(api.isEmpty()){toast("Enter the central platform API URL ending in /api (HTTPS required).");return;}apiInput.setText(api);
  JSONObject b=new JSONObject();try{b.put("email",email);b.put("password",pw);b.put("device_name","Universal AutoPay Android device");}catch(Exception ignored){}
  busy=true;loginButton.setEnabled(false);
  req("/login.php","POST",b,false,(j,e)->{
   busy=false;loginButton.setEnabled(true);
   if(e!=null){toast(e);return;}
   token=j.optString("token","");prefs.edit().putString("token",token).putString("api",api).apply();
   password.setText("");scheduleBackgroundSync();showDashboard();
  });
 }
 private void showDashboard(){
  LinearLayout root=col();root.setPadding(dp(20),dp(24),dp(20),dp(30));shell(root);header(root);
  LinearLayout top=col();card(root,top);top.addView(txt("XTREME TITAN OFFICIAL connected",18,GREEN,true));top.addView(txt("This one app reads supported payment notification fields only after you grant SMS permission, then securely sends parsed details to your central merchant account.",12,MUTED,false));
  LinearLayout methods=col();card(root,methods);methods.addView(txt("SUPPORTED PAYMENT SOURCES",11,GREEN,true));methods.addView(txt("bKash   ·   Nagad   ·   Rocket   ·   Upay",17,WHITE,true));
  LinearLayout sms=col();card(root,sms);sms.addView(txt("SMS capture",19,WHITE,true));status=txt("SMS permission is required to detect incoming payment alerts.",12,MUTED,false);LinearLayout.LayoutParams st=new LinearLayout.LayoutParams(-1,-2);st.topMargin=dp(8);sms.addView(status,st);
  smsButton=btn("ENABLE PAYMENT SMS ACCESS");LinearLayout.LayoutParams sb=new LinearLayout.LayoutParams(-1,-2);sb.topMargin=dp(16);sms.addView(smsButton,sb);smsButton.setOnClickListener(v->requestSmsPermission());
  LinearLayout recent=col();card(root,recent);recent.addView(txt("Last captured notification",17,WHITE,true));summary=txt(prefs.getString("last_sms","No payment SMS captured yet."),12,MUTED,false);summary.setLineSpacing(dp(3),1);LinearLayout.LayoutParams rp=new LinearLayout.LayoutParams(-1,-2);rp.topMargin=dp(8);recent.addView(summary,rp);
  LinearLayout sync=col();card(root,sync);sync.addView(txt("SYNC STATUS",16,GREEN,true));queueStatus=txt("Checking queued notifications…",12,MUTED,false);sync.addView(queueStatus);Button syncNow=btn("SYNC NOW");LinearLayout.LayoutParams snp=new LinearLayout.LayoutParams(-1,-2);snp.topMargin=dp(10);sync.addView(syncNow,snp);syncNow.setOnClickListener(v->{PaymentSmsSyncWorker.enqueue(this);updateQueueStatus();toast("Sync queued. It will run when internet is available.");});
  LinearLayout hist=col();card(root,hist);hist.addView(txt("TRANSACTION HISTORY",17,WHITE,true));historyText=txt("Loading recent payment notifications…",12,MUTED,false);historyText.setLineSpacing(dp(3),1);LinearLayout.LayoutParams hp=new LinearLayout.LayoutParams(-1,-2);hp.topMargin=dp(8);hist.addView(historyText,hp);Button refresh=btn("REFRESH HISTORY");LinearLayout.LayoutParams rhp=new LinearLayout.LayoutParams(-1,-2);rhp.topMargin=dp(10);hist.addView(refresh,rhp);refresh.setOnClickListener(v->loadHistory());
  Button logout=btn("LOG OUT");root.addView(logout);logout.setOnClickListener(v->{reqLogout();token="";prefs.edit().remove("token").apply();WorkManager.getInstance(this).cancelUniqueWork("xt-autopay-sms-periodic");showLogin();});
  updateQueueStatus(); loadHistory();
  if(hasSmsPermission()){status.setText("SMS permission enabled. Waiting for supported payment alerts.");smsButton.setText("SMS ACCESS ENABLED");}
 }
 private void updateQueueStatus(){ if(queueStatus==null)return; new Thread(()->{PaymentSmsQueue q=new PaymentSmsQueue(this);int n=q.countPending();q.close();runOnUiThread(()->{if(queueStatus!=null)queueStatus.setText(n==0?"All captured notifications are synced.":n+" notification(s) waiting to sync. Check internet and tap SYNC NOW.");});}).start(); }
 private void loadHistory(){ if(historyText==null)return; historyText.setText("Loading transaction history…"); req("/mobile-history.php?limit=30","GET",null,true,(j,e)->{if(historyText==null)return;if(e!=null){historyText.setText("Could not load history: "+e);return;}org.json.JSONArray a=j.optJSONArray("events");if(a==null||a.length()==0){historyText.setText("No payment notifications found yet.");return;}StringBuilder out=new StringBuilder();for(int i=0;i<a.length();i++){JSONObject x=a.optJSONObject(i);if(x==null)continue;out.append(x.optString("provider").toUpperCase()).append(" · ").append(x.optString("amount")).append(" ").append(x.optString("currency")).append("\nTX: ").append(x.optString("transaction_id")).append("\nStatus: ").append(x.optString("status")).append("\n\n");}historyText.setText(out.toString().trim());}); }
 private void reqLogout(){String oldToken=token;String base=prefs.getString("api",api);new Thread(()->{try{HttpURLConnection c=(HttpURLConnection)new URL(base+"/logout.php").openConnection();c.setRequestMethod("POST");c.setRequestProperty("Authorization","Bearer "+oldToken);c.getResponseCode();c.disconnect();}catch(Exception e){}}).start();}
 private void scheduleBackgroundSync(){Constraints constraints=new Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build();PeriodicWorkRequest periodic=new PeriodicWorkRequest.Builder(PaymentSmsSyncWorker.class,15,TimeUnit.MINUTES).setConstraints(constraints).build();WorkManager.getInstance(this).enqueueUniquePeriodicWork("xt-autopay-sms-periodic",ExistingPeriodicWorkPolicy.KEEP,periodic);PaymentSmsSyncWorker.enqueue(this);}
 private boolean hasSmsPermission(){return Build.VERSION.SDK_INT<23||(checkSelfPermission(Manifest.permission.RECEIVE_SMS)==PackageManager.PERMISSION_GRANTED);}
 private void requestSmsPermission(){if(Build.VERSION.SDK_INT>=23)requestPermissions(new String[]{Manifest.permission.RECEIVE_SMS},REQ);}
 @Override public void onRequestPermissionsResult(int r,String[] p,int[] g){super.onRequestPermissionsResult(r,p,g);if(r==REQ){if(hasSmsPermission()){status.setText("SMS permission enabled. Waiting for supported payment alerts.");smsButton.setText("SMS ACCESS ENABLED");}else status.setText("Permission not granted. SMS capture is disabled.");}}
 public void showCaptured(String s){runOnUiThread(()->{if(summary!=null)summary.setText(s);if(status!=null)status.setText("Payment notification captured and sent to your central account for review.");});}
 private void toast(String s){Toast.makeText(this,s,Toast.LENGTH_LONG).show();}
}
