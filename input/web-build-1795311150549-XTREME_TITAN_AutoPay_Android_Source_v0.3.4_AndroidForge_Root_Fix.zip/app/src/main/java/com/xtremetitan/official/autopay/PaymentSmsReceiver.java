package com.xtremetitan.official.autopay;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.telephony.SmsMessage;
import org.json.JSONObject;
import java.util.regex.*;

/** Receives payment alerts on the explicitly enrolled admin phone and queues parsed fields for reliable sync. */
public class PaymentSmsReceiver extends BroadcastReceiver {
 @Override public void onReceive(Context context,Intent intent){
  if(!"android.provider.Telephony.SMS_RECEIVED".equals(intent.getAction()))return;
  SharedPreferences p=context.getSharedPreferences("autopay_universal",Context.MODE_PRIVATE);
  if(p.getString("token","").isEmpty())return;
  Object[] pdus=(Object[])intent.getExtras().get("pdus"); if(pdus==null)return;
  String format=intent.getStringExtra("format"); StringBuilder body=new StringBuilder();String sender="";
  for(Object obj:pdus){SmsMessage m=BuildSms.from(obj,format);if(m!=null){body.append(m.getMessageBody()).append(' ');sender=m.getOriginatingAddress();}}
  String msg=body.toString();String low=(sender+" "+msg).toLowerCase();
  String method=low.contains("bkash")||low.contains("b-kash")?"bKash":low.contains("nagad")?"Nagad":low.contains("rocket")||low.contains("dbbl")?"Rocket":low.contains("upay")?"Upay":"";
  if(method.isEmpty())return;
  String trx=first(msg,"(?i)(?:trx\\s*id|txnid|transaction\\s*id|txn\\s*id|ref(?:erence)?\\s*no)\\s*[:#-]?\\s*([A-Z0-9-]{6,40})");
  String amount=first(msg,"(?i)(?:amount|received|payment|cash\\s*in)\\s*(?:of|is|:)?\\s*(?:tk|bdt|৳)?\\s*([0-9][0-9,]*(?:\\.[0-9]{1,2})?)");
  if(trx.isEmpty()||amount.isEmpty())return;
  try{double a=Double.parseDouble(amount.replace(",",""));if(a<=0)return;
   JSONObject j=new JSONObject();j.put("provider",method);j.put("amount",a);j.put("transaction_id",trx);j.put("sender",sender==null?"":sender);j.put("received_at",System.currentTimeMillis()/1000);
   PaymentSmsQueue queue=new PaymentSmsQueue(context);queue.add(j);queue.close();
   PaymentSmsSyncWorker.enqueue(context);
   p.edit().putString("last_sms",method+" · BDT "+amount+" · TXN "+trx+" · queued for secure sync").apply();
  }catch(Exception ignored){}
 }
 private String first(String s,String regex){Matcher m=Pattern.compile(regex).matcher(s);return m.find()?m.group(1):"";}
 static class BuildSms {static SmsMessage from(Object p,String f){try{if(android.os.Build.VERSION.SDK_INT>=23)return SmsMessage.createFromPdu((byte[])p,f);return SmsMessage.createFromPdu((byte[])p);}catch(Exception e){return null;}}}
}
