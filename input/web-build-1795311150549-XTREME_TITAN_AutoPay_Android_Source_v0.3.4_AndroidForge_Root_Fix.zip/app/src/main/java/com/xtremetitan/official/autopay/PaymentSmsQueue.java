package com.xtremetitan.official.autopay;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.content.ContentValues;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.List;

/** Local durable queue. Only parsed payment-notification fields are retained; full SMS text is never uploaded. */
final class PaymentSmsQueue extends SQLiteOpenHelper {
    private static final String DB = "xt_autopay_queue.db";
    PaymentSmsQueue(Context c) { super(c, DB, null, 1); }
    @Override public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE payment_queue (id INTEGER PRIMARY KEY AUTOINCREMENT, transaction_id TEXT NOT NULL UNIQUE, payload TEXT NOT NULL, created_at INTEGER NOT NULL, attempts INTEGER NOT NULL DEFAULT 0)");
    }
    @Override public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {}
    synchronized void add(JSONObject payload) {
        SQLiteDatabase db=getWritableDatabase(); ContentValues v=new ContentValues();
        v.put("transaction_id",payload.optString("transaction_id")); v.put("payload",payload.toString()); v.put("created_at",System.currentTimeMillis()/1000);
        db.insertWithOnConflict("payment_queue",null,v,SQLiteDatabase.CONFLICT_IGNORE);
    }
    synchronized List<JSONObject> pending(int limit) {
        List<JSONObject> out=new ArrayList<>(); Cursor c=getReadableDatabase().rawQuery("SELECT id,payload FROM payment_queue ORDER BY id ASC LIMIT ?",new String[]{String.valueOf(limit)});
        try { while(c.moveToNext()){ JSONObject j=new JSONObject(c.getString(1)); j.put("_queue_id",c.getLong(0)); out.add(j); } } catch(Exception ignored) {} finally { c.close(); } return out;
    }
    synchronized int countPending() { Cursor c=getReadableDatabase().rawQuery("SELECT COUNT(*) FROM payment_queue",null); try { return c.moveToFirst()?c.getInt(0):0; } finally { c.close(); } }
    synchronized void remove(long id) { getWritableDatabase().delete("payment_queue","id=?",new String[]{String.valueOf(id)}); }
    synchronized void failed(long id) { getWritableDatabase().execSQL("UPDATE payment_queue SET attempts=attempts+1 WHERE id=?",new Object[]{id}); }
}
