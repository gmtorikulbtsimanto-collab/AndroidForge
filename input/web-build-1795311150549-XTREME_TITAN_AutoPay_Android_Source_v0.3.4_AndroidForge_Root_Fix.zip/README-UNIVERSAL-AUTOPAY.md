# Universal AutoPay Android Source 2.0.0

Import this folder as an Android Gradle project in AndroidForge.

## Setup
1. Build the `android-project` ZIP with AndroidForge (or open it as a Gradle project).
2. Install the Universal AutoPay Connector ZIP on a PHP 8+ / MySQL website first.
3. In the app, enter the URL of the folder containing the connector's `install.php` (HTTPS), e.g. `https://example.com/autopay-connector`.
4. Choose Create Account or Login. Accounts are separate for each connector URL.
5. Grant SMS permission only if you want this phone to capture supported payment notification messages.

## Privacy and safety
- The app parses supported bKash, Nagad, Rocket and Upay notifications locally.
- It uploads only provider, amount, transaction ID, sender and received timestamp; it does not upload the complete SMS text.
- SMS capture requires the device owner's explicit Android permission.
- Payment SMS is stored as unmatched. It is not proof of settlement and does not automatically credit a wallet.
- Use only on devices and websites you own or are authorized to administer.

## Requirements
Android SDK 35, Java 17-compatible Android Gradle Plugin, Gradle 8.7. The provided wrapper script may require AndroidForge's installed Gradle because this source bundle does not include the Gradle wrapper JAR.
