# Android app — XTREME TITAN OFFICIAL AutoPay v0.2.0

Android Studio-তে এই `android/` project খুলুন। App-এ একবার central API URL দিতে হবে: `https://YOUR-DOMAIN/PATH/api`। প্রতিটি Merchant নিজের account তৈরি/login করবে; একই APK সবাই ব্যবহার করবে।

Account registration-এর পর app central login করে bearer token সংরক্ষণ করে। SMS receiver supported bKash/Nagad/Rocket/Upay message থেকে provider, amount, transaction ID, sender এবং timestamp বের করে local queue-তে রাখে। WorkManager `POST /api/mobile-sms.php`-তে bearer token দিয়ে sync করে। Full SMS body upload করা হয় না।

প্রয়োজনীয়: Android SDK, JDK 17+, Android Gradle Plugin/Gradle dependencies, এবং নিজস্ব release signing key। এই source archive-এ compiled APK নেই।

**SMS policy:** SMS permission কেবল user consent-এর পর চাওয়া হয়। Google Play-এর SMS permission policy অনুযায়ী publication সীমিত হতে পারে; Play Store review-এর আগে policy eligibility নিশ্চিত করুন।
