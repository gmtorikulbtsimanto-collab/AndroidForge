@echo off
setlocal
set "GRADLE_VERSION=8.7"
where gradle >nul 2>nul
if %ERRORLEVEL%==0 (
  gradle %*
  exit /b %ERRORLEVEL%
)
set "CACHE=%USERPROFILE%\.gradle\xtreme-titan-bootstrap"
set "DIST=%CACHE%\gradle-%GRADLE_VERSION%"
if not exist "%DIST%\bin\gradle.bat" (
  if not exist "%CACHE%" mkdir "%CACHE%"
  powershell -NoProfile -ExecutionPolicy Bypass -Command "$ProgressPreference='SilentlyContinue'; Invoke-WebRequest 'https://services.gradle.org/distributions/gradle-%GRADLE_VERSION%-bin.zip' -OutFile '%CACHE%\gradle-%GRADLE_VERSION%-bin.zip'; Expand-Archive -Force '%CACHE%\gradle-%GRADLE_VERSION%-bin.zip' '%CACHE%'"
  if errorlevel 1 exit /b 1
)
call "%DIST%\bin\gradle.bat" %*
exit /b %ERRORLEVEL%
