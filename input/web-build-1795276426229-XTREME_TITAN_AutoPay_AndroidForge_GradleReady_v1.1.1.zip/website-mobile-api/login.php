<?php
require __DIR__.'/_bootstrap.php'; xt_api_method('POST');
try {
 $pdo=db(); ensure_account_role_columns(); xt_api_schema($pdo); $b=xt_api_body();
 $identifier=trim((string)($b['identifier']??'')); $password=(string)($b['password']??'');
 if($identifier===''||$password===''||strlen($identifier)>190||strlen($password)>200) xt_api_out(422,['ok'=>false,'message'=>'Enter admin username, email or phone and password']);
 $account=null; $accountTable='users';
 // Admin Panel's separate admins table is the primary AutoPay administrator source.
 try {
  $ac=xt_api_columns($pdo,'admins');$aid=xt_api_pick($ac,['id','admin_id']);$apass=xt_api_pick($ac,['password_hash','password','pwd','pass']);
  $auser=xt_api_pick($ac,['username','user_name']);$aemail=xt_api_pick($ac,['email','email_address']);$aphone=xt_api_pick($ac,['phone','phone_number','mobile']);$aname=xt_api_pick($ac,['name','full_name']);
  $where=[];$params=[];foreach([$auser,$aemail,$aphone] as $c){if($c){$where[]="`$c`=?";$params[]=$identifier;}}
  if($aid&&$apass&&$where){$q=$pdo->prepare('SELECT `'.$aid.'` AS uid,`'.$apass.'` AS pwd'.($aname?',`'.$aname.'` AS uname':",'' AS uname").' FROM admins WHERE ('.implode(' OR ',$where).') LIMIT 1');$q->execute($params);$a=$q->fetch(PDO::FETCH_ASSOC);if($a&&password_verify($password,(string)$a['pwd'])){$account=$a;$accountTable='admins';}}
 } catch(Throwable $ignore) {}
 // Fallback: a users-table account explicitly assigned admin role.
 if(!$account){
  $cols=xt_api_columns($pdo,'users');$id=xt_api_pick($cols,['id']);$pass=xt_api_pick($cols,['password_hash','password','pwd','pass']);$username=xt_api_pick($cols,['username','user_name']);$email=xt_api_pick($cols,['email','email_address']);$phone=xt_api_pick($cols,['phone','phone_number','mobile']);$name=xt_api_pick($cols,['name','full_name']);$role=xt_api_pick($cols,['role','user_role','account_type','type','is_admin']);
  $where=[];$params=[];foreach([$username,$email,$phone] as $c){if($c){$where[]="`$c`=?";$params[]=$identifier;}}
  if(!$id||!$pass||!$role||!$where)xt_api_out(500,['ok'=>false,'message'=>'Admin login fields are not configured']);
  $q=$pdo->prepare('SELECT `'.$id.'` AS uid,`'.$pass.'` AS pwd,`'.$role.'` AS role'.($name?',`'.$name.'` AS uname':",'' AS uname").' FROM users WHERE ('.implode(' OR ',$where).') LIMIT 1');$q->execute($params);$u=$q->fetch(PDO::FETCH_ASSOC);
  if($u&&password_verify($password,(string)$u['pwd'])&&in_array(strtolower(trim((string)$u['role'])),['admin','administrator','1','true','yes'],true)){$account=$u;$accountTable='users';}
 }
 if(!$account)xt_api_out(401,['ok'=>false,'message'=>'Invalid administrator username, email/phone or password']);
 $raw=bin2hex(random_bytes(32));$device=substr(trim((string)($b['device_name']??'AutoPay Admin Phone')),0,100);
 $ins=$pdo->prepare('INSERT INTO mobile_api_tokens(user_id,account_table,token_hash,device_name,created_at,expires_at) VALUES(?,?,?,?,UTC_TIMESTAMP(),DATE_ADD(UTC_TIMESTAMP(),INTERVAL 30 DAY))');
 $ins->execute([(int)$account['uid'],$accountTable,hash('sha256',$raw),$device]);
 xt_api_out(200,['ok'=>true,'token'=>$raw,'expires_in'=>2592000,'user'=>['id'=>(int)$account['uid'],'name'=>(string)$account['uname'],'role'=>'admin']]);
} catch(Throwable $e){error_log('XT AutoPay admin login: '.$e->getMessage());xt_api_out(500,['ok'=>false,'message'=>'Server could not process admin login. Check website API setup.']);}
