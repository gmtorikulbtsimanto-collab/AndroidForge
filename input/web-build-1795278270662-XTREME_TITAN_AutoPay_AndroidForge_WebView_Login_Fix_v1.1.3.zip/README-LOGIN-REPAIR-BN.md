# XTREME TITAN AutoPay — Login repair v1.1.3

## What changed
- The Android administrator login no longer sends its first login POST through native HttpURLConnection.
- It opens the site's own HTTPS origin in an attached, hidden WebView, allows the host's browser-side JavaScript/cookie challenge to run, then sends the login POST with same-origin browser fetch and credentials.
- The login response is parsed as JSON and reports a short response preview if hosting returns HTML.
- The bundled `website-mobile-api/login.php` is synchronized with the hardened login endpoint from the matching Website package.

## Install together
1. Upload the matching Website ZIP contents to the same website document root, preserving `website-mobile-api/`.
2. Confirm `https://YOUR-DOMAIN/website-mobile-api/login.php` returns JSON `Method not allowed` for a normal browser GET. That is expected.
3. In AndroidForge, import this Android ZIP and build.
4. Enter the website root or API URL; the app normalizes it to `/website-mobile-api`.

## Important verification limits
This source ZIP was edited and ZIP integrity is checked. It has not been compiled in AndroidForge or tested against the live InfinityFree account in this environment. If InfinityFree blocks the WebView POST too, the app will display the HTTP status and a short response preview; that would require changing the hosting/API approach rather than another blind APK rebuild.

No payment is automatically credited by SMS alone. Verify payments with the payment provider or admin before crediting wallets.
