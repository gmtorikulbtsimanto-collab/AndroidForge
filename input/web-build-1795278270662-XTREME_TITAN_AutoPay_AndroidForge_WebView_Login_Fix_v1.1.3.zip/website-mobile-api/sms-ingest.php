<?php
require __DIR__.'/_bootstrap.php'; xt_api_method('POST');
try {
 $pdo=db(); $u=xt_api_user($pdo);
 if(strtolower((string)($u['role']??''))!=='admin') xt_api_out(403,['ok'=>false,'message'=>'Admin access required']);
 $b=xt_api_body(); $method=trim((string)($b['method']??'')); $amount=$b['amount']??null;
 $trx=strtoupper(trim((string)($b['transaction_id']??''))); $sender=substr(trim((string)($b['sender']??'')),0,80);
 $received=(int)($b['received_at']??time());
 if(!in_array($method,['bKash','Nagad','Rocket','Upay'],true)) xt_api_out(422,['ok'=>false,'message'=>'Unsupported payment source']);
 if(!is_numeric($amount)||(float)$amount<=0||(float)$amount>10000000) xt_api_out(422,['ok'=>false,'message'=>'Invalid amount']);
 if($trx===''||strlen($trx)>100||!preg_match('/^[A-Z0-9-]+$/',$trx)) xt_api_out(422,['ok'=>false,'message'=>'Transaction ID could not be parsed']);
 $pdo->exec("CREATE TABLE IF NOT EXISTS mobile_payment_sms (id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,method VARCHAR(20) NOT NULL,amount DECIMAL(14,2) NOT NULL,transaction_id VARCHAR(100) NOT NULL UNIQUE,sender VARCHAR(80) NULL,received_at BIGINT NOT NULL,admin_user_id INT NOT NULL,review_status VARCHAR(20) NOT NULL DEFAULT 'unmatched',created_at DATETIME NOT NULL,INDEX idx_mps_status(review_status),INDEX idx_mps_received(received_at)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
 $q=$pdo->prepare("INSERT INTO mobile_payment_sms(method,amount,transaction_id,sender,received_at,admin_user_id,review_status,created_at) VALUES(?,?,?,?,?,?,'unmatched',UTC_TIMESTAMP())");
 try{$q->execute([$method,number_format((float)$amount,2,'.',''),$trx,$sender,$received,(int)$u['id']]);}
 catch(PDOException $e){if((string)$e->getCode()==='23000')xt_api_out(409,['ok'=>false,'duplicate'=>true,'message'=>'This transaction ID was already received']);throw $e;}
 xt_api_out(201,['ok'=>true,'status'=>'unmatched','message'=>'Payment SMS captured for admin review. No wallet has been credited.']);
} catch(Throwable $e){error_log('XT AutoPay SMS ingest: '.$e->getMessage());xt_api_out(500,['ok'=>false,'message'=>'Could not save payment notification']);}
