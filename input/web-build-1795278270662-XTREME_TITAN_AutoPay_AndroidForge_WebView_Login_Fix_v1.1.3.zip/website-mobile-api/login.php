<?php
declare(strict_types=1);

/*
 * XTREME TITAN AutoPay administrator login endpoint.
 * Keep this endpoint JSON-only, including PHP fatal errors and database failures.
 */
ini_set('display_errors','0');
ini_set('html_errors','0');
ini_set('log_errors','1');
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
header('Pragma: no-cache');
header('X-Content-Type-Options: nosniff');
header('X-Frame-Options: DENY');
ob_start();

function xt_login_json(int $status, array $data): void {
    while (ob_get_level() > 0) { @ob_end_clean(); }
    http_response_code($status);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($data, JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE);
    exit;
}
register_shutdown_function(function (): void {
    $e=error_get_last();
    if($e && in_array($e['type'],[E_ERROR,E_PARSE,E_CORE_ERROR,E_COMPILE_ERROR],true)) {
        while(ob_get_level()>0){@ob_end_clean();}
        if(!headers_sent()) {
            http_response_code(500);
            header('Content-Type: application/json; charset=utf-8');
            header('Cache-Control: no-store');
        }
        echo json_encode(['ok'=>false,'message'=>'AutoPay login endpoint encountered a server error. Check PHP error log.'],JSON_UNESCAPED_SLASHES);
    }
});

try {
    require_once __DIR__.'/_bootstrap.php';
    if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') {
        xt_login_json(405,['ok'=>false,'message'=>'Method not allowed. Send a POST request.']);
    }

    $raw=(string)file_get_contents('php://input');
    $body=json_decode($raw,true);
    if(!is_array($body)) {
        $body=$_POST;
        if(!$body && $raw!=='') { parse_str($raw,$body); }
    }
    $identifier=trim((string)($body['identifier']??$body['username']??$body['email']??''));
    $password=(string)($body['password']??'');
    if($identifier===''||$password===''||strlen($identifier)>190||strlen($password)>200) {
        xt_login_json(422,['ok'=>false,'message'=>'Enter administrator username, email or phone and password.']);
    }

    $pdo=db();
    ensure_account_role_columns();
    xt_api_schema($pdo);

    $account=null;
    $accountTable='users';

    // 1) Separate website admins table, matching the website Admin Panel login.
    try {
        $cols=xt_api_columns($pdo,'admins');
        $id=xt_api_pick($cols,['id','admin_id']);
        $pass=xt_api_pick($cols,['password_hash','password','pwd','pass']);
        $username=xt_api_pick($cols,['username','user_name']);
        $email=xt_api_pick($cols,['email','email_address']);
        $phone=xt_api_pick($cols,['phone','phone_number','mobile']);
        $name=xt_api_pick($cols,['name','full_name']);
        $where=[];$params=[];
        foreach([$username,$email,$phone] as $col) {
            if($col!==null) {$where[]="`$col`=?";$params[]=$identifier;}
        }
        if($id && $pass && $where) {
            $sql='SELECT `'.$id.'` AS account_id,`'.$pass.'` AS pass_hash'.
                 ($name?',`'.$name.'` AS account_name':",'' AS account_name").
                 ' FROM admins WHERE ('.implode(' OR ',$where).') LIMIT 1';
            $q=$pdo->prepare($sql);
            $q->execute($params);
            $row=$q->fetch(PDO::FETCH_ASSOC);
            if($row && password_verify($password,(string)$row['pass_hash'])) {
                $account=['id'=>(int)$row['account_id'],'name'=>(string)$row['account_name']];
                $accountTable='admins';
            }
        }
    } catch(Throwable $e) {
        // Some installations do not use a separate admins table. Continue to users.role.
        error_log('XT AutoPay admins-table lookup: '.$e->getMessage());
    }

    // 2) Admin account stored in users table with role=admin.
    if($account===null) {
        $cols=xt_api_columns($pdo,'users');
        $id=xt_api_pick($cols,['id','user_id']);
        $pass=xt_api_pick($cols,['password_hash','password','pwd','pass']);
        $username=xt_api_pick($cols,['username','user_name']);
        $email=xt_api_pick($cols,['email','email_address']);
        $phone=xt_api_pick($cols,['phone','phone_number','mobile']);
        $name=xt_api_pick($cols,['name','full_name']);
        $role=xt_api_pick($cols,['role','user_role','account_type','type','is_admin']);
        $where=[];$params=[];
        foreach([$username,$email,$phone] as $col) {
            if($col!==null) {$where[]="`$col`=?";$params[]=$identifier;}
        }
        if(!$id||!$pass||!$role||!$where) {
            xt_login_json(500,['ok'=>false,'message'=>'Admin login database fields are not configured.']);
        }
        $sql='SELECT `'.$id.'` AS account_id,`'.$pass.'` AS pass_hash,`'.$role.'` AS account_role'.
             ($name?',`'.$name.'` AS account_name':",'' AS account_name").
             ' FROM users WHERE ('.implode(' OR ',$where).') LIMIT 1';
        $q=$pdo->prepare($sql);
        $q->execute($params);
        $row=$q->fetch(PDO::FETCH_ASSOC);
        $roleValue=strtolower(trim((string)($row['account_role']??'')));
        if($row && password_verify($password,(string)$row['pass_hash']) &&
           in_array($roleValue,['admin','administrator','1','true','yes'],true)) {
            $account=['id'=>(int)$row['account_id'],'name'=>(string)$row['account_name']];
            $accountTable='users';
        }
    }

    if($account===null) {
        xt_login_json(401,['ok'=>false,'message'=>'Invalid administrator username, email/phone or password.']);
    }

    $rawToken=bin2hex(random_bytes(32));
    $device=substr(trim((string)($body['device_name']??'XTREME TITAN AutoPay Admin Phone')),0,100);
    $ins=$pdo->prepare(
        'INSERT INTO mobile_api_tokens(user_id,account_table,token_hash,device_name,created_at,expires_at)
         VALUES(?,?,?,?,UTC_TIMESTAMP(),DATE_ADD(UTC_TIMESTAMP(),INTERVAL 30 DAY))'
    );
    $ins->execute([
        (int)$account['id'],
        $accountTable,
        hash('sha256',$rawToken),
        $device
    ]);

    xt_login_json(200,[
        'ok'=>true,
        'token'=>$rawToken,
        'expires_in'=>2592000,
        'user'=>[
            'id'=>(int)$account['id'],
            'name'=>(string)$account['name'],
            'role'=>'admin'
        ]
    ]);
} catch(Throwable $e) {
    error_log('XT AutoPay login endpoint: '.$e->getMessage());
    xt_login_json(500,['ok'=>false,'message'=>'AutoPay could not complete administrator sign-in. Check the website API database setup.']);
}
