<?php
require __DIR__.'/_bootstrap.php'; xt_api_method('POST');
try {
 $pdo=db(); xt_api_schema($pdo); $b=xt_api_body();
 $identifier=trim((string)($b['identifier']??'')); $password=(string)($b['password']??'');
 if($identifier===''||$password===''||strlen($identifier)>190||strlen($password)>200) xt_api_out(422,['ok'=>false,'message'=>'Enter admin email/phone and password']);
 $cols=xt_api_columns($pdo,'users'); $id=xt_api_pick($cols,['id']); $pass=xt_api_pick($cols,['pwd','password','password_hash','pass']);
 $email=xt_api_pick($cols,['email']); $phone=xt_api_pick($cols,['phone','mobile','phone_number']); $name=xt_api_pick($cols,['name','username']); $role=xt_api_pick($cols,['role']);
 if(!$id||!$pass||!$role||(!$email&&!$phone)) xt_api_out(500,['ok'=>false,'message'=>'Admin login is not configured; users.role must exist']);
 $where=[]; $params=[]; if($email){$where[]="`$email`=?";$params[]=$identifier;} if($phone){$where[]="`$phone`=?";$params[]=$identifier;}
 $sql='SELECT `'.$id.'` AS uid,`'.$pass.'` AS pwd,`'.$role.'` AS role'.($name?',`'.$name.'` AS uname':",'' AS uname").' FROM users WHERE ('.implode(' OR ',$where).') LIMIT 1';
 $s=$pdo->prepare($sql);$s->execute($params);$u=$s->fetch(PDO::FETCH_ASSOC);
 if(!$u||!password_verify($password,(string)$u['pwd'])) xt_api_out(401,['ok'=>false,'message'=>'Invalid admin email/phone or password']);
 if(strtolower((string)$u['role'])!=='admin') xt_api_out(403,['ok'=>false,'message'=>'Only the website administrator can use AutoPay']);
 $raw=bin2hex(random_bytes(32)); $device=substr(trim((string)($b['device_name']??'AutoPay Admin Phone')),0,100);
 $ins=$pdo->prepare('INSERT INTO mobile_api_tokens(user_id,token_hash,device_name,created_at,expires_at) VALUES(?,?,?,UTC_TIMESTAMP(),DATE_ADD(UTC_TIMESTAMP(),INTERVAL 30 DAY))');
 $ins->execute([(int)$u['uid'],hash('sha256',$raw),$device]);
 xt_api_out(200,['ok'=>true,'token'=>$raw,'expires_in'=>2592000,'user'=>['id'=>(int)$u['uid'],'name'=>(string)$u['uname'],'role'=>'admin']]);
} catch(Throwable $e) { error_log('XT AutoPay admin login: '.$e->getMessage()); xt_api_out(500,['ok'=>false,'message'=>'Could not sign in right now']); }
