# XTREME TITAN OFFICIAL AutoPay — v1.0.4 source

Cross-platform Expo / React Native starter for Android and iOS. Branded for XTREME TITAN OFFICIAL. Supports payment-method selection for bKash, Nagad, Rocket and Upay and a secure mobile API connection form.

## Current status
- Branded app source and Android/iOS project identifiers are configured.
- Payment request UI is implemented.
- Website account login is wired to the included PHP mobile API bridge.
- The PHP bridge creates pending deposit requests and returns account/history data; it never credits a wallet by itself.
- This is source code, **not a built APK or IPA**. No payment is automatically approved by this app.

## Critical payment security
A transaction reference entered by a user is not proof of payment. The server must verify the payment with the provider/aggregator API or a trusted signed webhook, check amount/currency/reference, prevent duplicate use, and credit the wallet atomically. Never embed provider API secrets in this mobile app.

This project intentionally requests no SMS-reading permissions. iOS apps cannot read another app's SMS inbox; Android SMS permissions are restricted by Google Play policy.

## Run
1. Install Node.js LTS.
2. `npm install`
3. `npx expo start`

## Build
Install EAS CLI and configure an Expo account: `npm install -g eas-cli`, then `eas build:configure`. Android preview APK: `eas build -p android --profile preview`. iOS distribution requires a matching Apple signing certificate **and provisioning profile** for the exact Bundle ID `com.xtremetitan.official.autopay`. For eSign sideloading, export/sign the IPA using a profile that permits the target device (or the distribution method supported by your signer). A `.p12` alone is not sufficient; do not send certificate private keys/passwords in chat.

## Website API installation
Upload the included `website-mobile-api` folder into the same directory as your website `config.php`. Read `website-mobile-api/README.md`. Set the app API URL to `https://xtremetitanofficial.gamer.free/website-mobile-api`. The mobile API uses your existing user login hashes and creates revocable 30-day mobile tokens.

## Required before production
- App API base URL is preconfigured to the domain supplied by the owner: https://xtremetitanofficial.gamer.free/website-mobile-api. Confirm that this domain serves the website and deploy the included mobile API over HTTPS.
- Add rate limiting and test the API on a staging database before production.
- Add account login and server-issued revocable mobile tokens.
- Implement pending deposit creation, provider verification, idempotency, rate limits and audit logs.
- Confirm provider/aggregator support for bKash, Nagad, Rocket and Upay. The existing website UddoktaPay flow currently offers bKash/Nagad; Rocket/Upay auto-verification is not implemented.
- Test end-to-end in sandbox before any live wallet credit.

## Branding
Display name: XTREME TITAN OFFICIAL AutoPay
Bundle ID: `com.xtremetitan.official.autopay`
Android package: `com.xtremetitan.official.autopay`
