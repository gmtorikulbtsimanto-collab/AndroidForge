XTREME TITAN AutoPay — Complete Native Login Fix v1.1.2

IMPORTANT
- This is the complete Android Studio / AndroidForge source project.
- It uses Android HttpURLConnection for login. It does NOT use WebView fetch for login.
- The API URL field remains editable. Default domain was updated to the gamer.fr domain visible in the latest user screenshot.
- The complete SMS queue and worker source files are included.

BUILD
1. Import this ZIP into AndroidForge as an Android/Gradle project.
2. Let Gradle sync finish, then build a fresh APK.
3. Install the newly built APK (uninstall the old one first if AndroidForge keeps the old app data/build).
4. In Website API URL, use the exact full HTTPS website API base, ending in /website-mobile-api.
5. Sign in. If the server cannot be reached, the app now reports DNS, TLS, timeout, or HTTP/JSON errors separately.

WEBSITE
The website API files are in website-mobile-api/. Upload/merge that folder into the website document root. Do not overwrite config.php or unrelated website files.

NOTES
- No APK binary is included; this ZIP is source code for AndroidForge/Gradle to build.
- A successful live login cannot be guaranteed without testing against the user's live hosting and database.
