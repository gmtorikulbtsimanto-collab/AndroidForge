# Universal AutoPay Connector 2.0

A self-hosted connector for **PHP 8+ and MySQL/MariaDB** websites. Each website installs its own connector and database tables. The Android app's website URL is the URL of the folder containing `install.php`.

## What it does

- Creates a separate AutoPay account per connected website (name, email, password).
- Provides register, login, session, logout, and payment-SMS ingestion APIs.
- Accepts only parsed payment notification fields from the Android app: provider, amount, transaction ID, sender and received timestamp. It does **not** upload the full SMS body.
- Stores each account's records separately in `autopay_payment_sms`.
- Provides `review.php` for the account owner to review their incoming records.
- Stores incoming records as `unmatched`. It does **not** credit wallets or mark payments as settled.

## Install

1. Create a MySQL/MariaDB database and a database user with permission to create tables.
2. Upload the contents of this ZIP into a folder on your HTTPS website, e.g. `public_html/autopay-connector/`. Keep `install.php`, `api/`, and `private/` together.
3. Open `https://your-domain.example/autopay-connector/install.php`.
4. Enter the database host, database name, username and password. The installer creates the required tables and writes `config.php`.
5. **Immediately delete `install.php` from hosting** after successful installation. Do not share `config.php` or database credentials.
6. In Universal AutoPay, enter the connector folder URL, e.g. `https://your-domain.example/autopay-connector` (do not add `/api`).
7. Choose **Create Account**, enter a name, email and password (minimum 10 characters). Later use Login with the same website URL and account.
8. Grant Android SMS permission only if you want this device to read supported incoming payment notifications.

## API

- `GET /api/health.php`
- `POST /api/register.php` JSON `{ "name":"Site Owner", "email":"owner@example.com", "password":"at-least-10-chars" }`
- `POST /api/login.php` JSON or form `{ "email":"...", "password":"..." }`
- `GET /api/me.php` with `Authorization: Bearer <token>`
- `POST /api/sms-ingest.php` with Bearer token and `{ "method":"bKash|Nagad|Rocket|Upay", "amount":123.45, "transaction_id":"...", "sender":"...", "received_at":1730000000 }`
- `POST /api/logout.php` with Bearer token
- Browser review page: `/review.php`

## Compatibility and limitations

- This package is a **generic PHP + MySQL connector**, not a universal plugin for every website platform. A WordPress, Laravel, Node, Python, or other site needs an adapter/plugin that calls the same API or a separately developed integration.
- Each website owner must install the connector on their own website and create an account there. The app does not bypass website access controls.
- SMS parsing is pattern-based and may need adjustments for the exact payment notification wording and sender IDs used by a provider.
- Android SMS permissions are sensitive. The app asks for permission on the user's device; it must be used only with the phone owner's informed consent and for payment alerts they are authorized to process. It is not an SMS spy or remote inbox viewer.
- SMS text is not authoritative proof of payment. Verify each transaction with the provider's official merchant dashboard/API before crediting a wallet. This connector never auto-credits.
- Use HTTPS only. Configure backups, database access controls, and server-side monitoring. Add email verification and stronger anti-abuse controls before a public production rollout.
- Android background delivery is subject to Android battery management and network availability. The local queue retries failed uploads.

## Database tables

`autopay_accounts`, `autopay_tokens`, `autopay_payment_sms`, and `autopay_rate_limits`.

The connector uses a dedicated table namespace and does not modify your existing `users`, `admins`, `deposits`, or wallet tables.
