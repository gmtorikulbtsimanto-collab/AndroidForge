<?php
declare(strict_types=1);
$lock=__DIR__.'/installed.lock';
$config=__DIR__.'/config.php';
if(file_exists($lock)||file_exists($config)){http_response_code(403);exit('AutoPay Connector is already installed. Delete install.php now.');}
$msg='';$err='';
if($_SERVER['REQUEST_METHOD']==='POST'){
 $host=trim((string)($_POST['db_host']??'localhost'));
 $name=trim((string)($_POST['db_name']??''));$user=trim((string)($_POST['db_user']??''));$pass=(string)($_POST['db_pass']??'');
 if($name===''||$user==='')$err='Database name and username are required.';
 else{
  try{
   $pdo=new PDO("mysql:host={$host};dbname={$name};charset=utf8mb4",$user,$pass,[PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION,PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC]);
   $sqls=[
    "CREATE TABLE IF NOT EXISTS autopay_accounts (id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,name VARCHAR(100) NOT NULL,email VARCHAR(190) NOT NULL UNIQUE,password_hash VARCHAR(255) NOT NULL,created_at DATETIME NOT NULL,updated_at DATETIME NULL,INDEX idx_autopay_email(email)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",
    "CREATE TABLE IF NOT EXISTS autopay_tokens (id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,user_id BIGINT UNSIGNED NOT NULL,token_hash CHAR(64) NOT NULL UNIQUE,device_name VARCHAR(100) NULL,created_at DATETIME NOT NULL,expires_at DATETIME NOT NULL,last_used_at DATETIME NULL,revoked_at DATETIME NULL,INDEX idx_autopay_user(user_id),INDEX idx_autopay_expiry(expires_at)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",
    "CREATE TABLE IF NOT EXISTS autopay_payment_sms (id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,user_id BIGINT UNSIGNED NOT NULL,method VARCHAR(20) NOT NULL,amount DECIMAL(14,2) NOT NULL,currency VARCHAR(8) NOT NULL DEFAULT 'BDT',transaction_id VARCHAR(100) NOT NULL,sender VARCHAR(80) NULL,received_at BIGINT NOT NULL,review_status VARCHAR(20) NOT NULL DEFAULT 'unmatched',created_at DATETIME NOT NULL,UNIQUE KEY uq_autopay_user_txn(user_id,transaction_id),INDEX idx_autopay_sms_user(user_id,created_at),INDEX idx_autopay_sms_status(review_status)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",
    "CREATE TABLE IF NOT EXISTS autopay_rate_limits (id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,scope_key CHAR(64) NOT NULL,action_name VARCHAR(24) NOT NULL,created_at DATETIME NOT NULL,INDEX idx_autopay_rate(scope_key,action_name,created_at)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4"
   ];
   foreach($sqls as $sql)$pdo->exec($sql);
   $cfg="<?php\ndeclare(strict_types=1);\nreturn ".var_export(['db_host'=>$host,'db_name'=>$name,'db_user'=>$user,'db_pass'=>$pass,'db_charset'=>'utf8mb4'],true).";\n";
   if(file_put_contents($config,$cfg,LOCK_EX)===false)throw new RuntimeException('Could not write config.php. Check folder permissions.');
   @chmod($config,0600);
   file_put_contents($lock,"installed ".gmdate('c'));
   $msg='Installation complete. Delete install.php from your hosting now, then open the app and create your account.';
  }catch(Throwable $e){$err='Installation failed: '.$e->getMessage();}
 }
}
function h($v){return htmlspecialchars((string)$v,ENT_QUOTES,'UTF-8');}
?><!doctype html><html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Universal AutoPay Connector Setup</title>
<style>body{margin:0;background:#07100a;color:#efffe9;font:16px Arial;padding:24px}.box{max-width:520px;margin:5vh auto;background:#101d13;border:1px solid #35572d;border-radius:18px;padding:24px}h1{font-size:25px}label{display:block;margin:14px 0 6px;color:#b8cbaa}input{box-sizing:border-box;width:100%;padding:13px;border-radius:10px;border:1px solid #47623c;background:#07110a;color:white}button{margin-top:20px;width:100%;padding:14px;border:0;border-radius:10px;background:#8cff28;font-weight:bold}.msg{padding:12px;background:#15351a;border-radius:10px}.err{padding:12px;background:#431c1c;border-radius:10px}</style><div class="box"><h1>Universal AutoPay Connector</h1><p>Connect this PHP + MySQL website to the Universal AutoPay Android app.</p><?php if($msg):?><div class="msg"><?=h($msg)?></div><?php else:?><?php if($err):?><div class="err"><?=h($err)?></div><?php endif;?><form method="post"><label>MySQL Host</label><input name="db_host" value="<?=h($_POST['db_host']??'localhost')?>" required><label>Database Name</label><input name="db_name" value="<?=h($_POST['db_name']??'')?>" required><label>Database Username</label><input name="db_user" value="<?=h($_POST['db_user']??'')?>" required><label>Database Password</label><input name="db_pass" type="password"><button>INSTALL CONNECTOR</button></form><?php endif;?></div></html>
