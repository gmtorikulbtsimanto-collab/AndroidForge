<?php
// Copy to config.php using install.php. Never publish database credentials.
return [
  'db_host' => 'localhost',
  'db_name' => 'YOUR_DATABASE',
  'db_user' => 'YOUR_DATABASE_USER',
  'db_pass' => 'CHANGE_THIS',
  'db_charset' => 'utf8mb4',
];
