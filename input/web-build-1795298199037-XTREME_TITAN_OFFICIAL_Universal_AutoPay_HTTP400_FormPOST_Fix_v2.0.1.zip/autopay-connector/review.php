<?php
declare(strict_types=1);
session_start();
$configFile=__DIR__.'/config.php';
if(!is_file($configFile)){http_response_code(503);exit('Install the connector first.');}
$cfg=require $configFile;
try{$pdo=new PDO('mysql:host='.$cfg['db_host'].';dbname='.$cfg['db_name'].';charset=utf8mb4',$cfg['db_user'],$cfg['db_pass'],[PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION,PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC]);}
catch(Throwable $e){http_response_code(500);exit('Database connection failed.');}
if(empty($_SESSION['ap_csrf']))$_SESSION['ap_csrf']=bin2hex(random_bytes(32));
function h($v){return htmlspecialchars((string)$v,ENT_QUOTES,'UTF-8');}
$error='';
if(isset($_GET['logout'])){$_SESSION=[];session_destroy();header('Location: review.php');exit;}
if($_SERVER['REQUEST_METHOD']==='POST'&&isset($_POST['email'])){
 if(!hash_equals($_SESSION['ap_csrf'],(string)($_POST['csrf']??''))){$error='Session expired. Refresh and try again.';}
 else{
  $email=strtolower(trim((string)$_POST['email']));$pw=(string)($_POST['password']??'');
  $q=$pdo->prepare('SELECT id,name,email,password_hash FROM autopay_accounts WHERE email=? LIMIT 1');$q->execute([$email]);$u=$q->fetch();
  if($u&&password_verify($pw,(string)$u['password_hash'])){session_regenerate_id(true);$_SESSION['ap_user_id']=(int)$u['id'];$_SESSION['ap_user_name']=$u['name'];header('Location: review.php');exit;}
  $error='Email or password is incorrect.';
 }
}
?><!doctype html><html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>AutoPay Payment SMS Review</title>
<style>body{margin:0;background:#07100a;color:#efffe9;font:15px Arial;padding:20px}.wrap{max-width:900px;margin:4vh auto;background:#101d13;border:1px solid #35572d;border-radius:18px;padding:22px;overflow:auto}h1{margin-top:0}input{box-sizing:border-box;width:100%;padding:12px;margin:7px 0 14px;border-radius:9px;border:1px solid #47623c;background:#07110a;color:white}button,.btn{display:inline-block;padding:11px 16px;border:0;border-radius:9px;background:#8cff28;color:#07100a;font-weight:bold;text-decoration:none}table{border-collapse:collapse;width:100%;min-width:650px}th,td{text-align:left;padding:11px;border-bottom:1px solid #30452d}small,.muted{color:#afc0a7}.err{background:#461d1d;padding:10px;border-radius:8px}.pill{padding:4px 8px;border-radius:99px;background:#394126}</style><div class="wrap"><h1>Universal AutoPay</h1><p class="muted">Payment notification review · SMS is not proof of settlement</p>
<?php if(empty($_SESSION['ap_user_id'])):?>
<h2>Website account sign in</h2><?php if($error):?><p class="err"><?=h($error)?></p><?php endif;?>
<form method="post"><input type="hidden" name="csrf" value="<?=h($_SESSION['ap_csrf'])?>"><label>Email</label><input name="email" type="email" required><label>Password</label><input name="password" type="password" required><button>Sign in</button></form>
<?php else:
$q=$pdo->prepare('SELECT method,amount,currency,transaction_id,sender,received_at,review_status,created_at FROM autopay_payment_sms WHERE user_id=? ORDER BY id DESC LIMIT 200');$q->execute([(int)$_SESSION['ap_user_id']]);$rows=$q->fetchAll();?>
<p>Signed in as <b><?=h($_SESSION['ap_user_name'])?></b> · <a class="btn" href="?logout=1">Log out</a></p><h2>Recent payment SMS records</h2><p class="muted">These records are unmatched and are not automatically credited to a wallet. Verify transactions with the payment provider before changing any balance.</p>
<table><thead><tr><th>Received</th><th>Method</th><th>Amount</th><th>Transaction ID</th><th>Sender</th><th>Status</th></tr></thead><tbody>
<?php foreach($rows as $r):?><tr><td><?=h(gmdate('Y-m-d H:i:s',(int)$r['received_at']))?> UTC</td><td><?=h($r['method'])?></td><td><?=h($r['currency'].' '.$r['amount'])?></td><td><?=h($r['transaction_id'])?></td><td><?=h($r['sender'])?></td><td><span class="pill"><?=h($r['review_status'])?></span></td></tr><?php endforeach;?>
<?php if(!$rows):?><tr><td colspan="6">No payment notifications received yet.</td></tr><?php endif;?></tbody></table>
<?php endif;?></div></html>
