<?php
declare(strict_types=1);
ini_set('display_errors','0');
ini_set('html_errors','0');
ini_set('log_errors','1');
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
header('X-Content-Type-Options: nosniff');
ob_start();
function xt_health_out(int $status, array $data): never {
    while (ob_get_level() > 0) { @ob_end_clean(); }
    http_response_code($status);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($data, JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE);
    exit;
}
register_shutdown_function(function (): void {
    $e = error_get_last();
    if ($e && in_array($e['type'], [E_ERROR,E_PARSE,E_CORE_ERROR,E_COMPILE_ERROR], true)) {
        while (ob_get_level() > 0) { @ob_end_clean(); }
        if (!headers_sent()) {
            http_response_code(500);
            header('Content-Type: application/json; charset=utf-8');
            header('Cache-Control: no-store');
        }
        echo json_encode(['ok'=>false,'message'=>'API health endpoint encountered a PHP server error. Check the hosting PHP error log.'], JSON_UNESCAPED_SLASHES);
    }
});
try {
    require_once __DIR__.'/_bootstrap.php';
    $pdo = db();
    ensure_account_role_columns();
    xt_api_schema($pdo);
    $users = xt_api_columns($pdo, 'users');
    $role = xt_api_pick($users, ['role','user_role','account_type','type','is_admin']);
    $adminTable = false;
    try { xt_api_columns($pdo, 'admins'); $adminTable = true; } catch (Throwable $ignore) {}
    xt_api_out(200, [
        'ok'=>true,
        'service'=>'XTREME TITAN AutoPay API',
        'version'=>'1.1.1',
        'admin_login'=>[
            'users_table_role_supported'=>(bool)$role,
            'separate_admins_table_detected'=>$adminTable
        ],
        'endpoints'=>['login'=>'POST login.php','sms_ingest'=>'POST sms-ingest.php']
    ]);
} catch (Throwable $e) {
    error_log('XT AutoPay health: '.$e->getMessage());
    xt_health_out(500, ['ok'=>false,'message'=>'API database setup failed. Check config.php, the website database connection, and mobile_api_tokens table permissions.']);
}
