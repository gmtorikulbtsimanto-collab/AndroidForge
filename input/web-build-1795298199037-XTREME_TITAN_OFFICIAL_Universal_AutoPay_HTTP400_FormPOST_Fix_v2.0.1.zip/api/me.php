<?php
require __DIR__.'/_bootstrap.php';ap_method('GET');
try{$u=ap_token(ap_pdo());ap_out(200,['ok'=>true,'user'=>$u]);}catch(Throwable $e){error_log('AutoPay me: '.$e->getMessage());ap_out(500,['ok'=>false,'message'=>'Could not load account']);}
