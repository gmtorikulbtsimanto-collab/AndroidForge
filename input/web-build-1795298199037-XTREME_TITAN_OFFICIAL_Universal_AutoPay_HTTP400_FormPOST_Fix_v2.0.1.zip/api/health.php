<?php
require __DIR__.'/_bootstrap.php';
try{$pdo=ap_pdo();$q=$pdo->query('SELECT 1');$q->fetchColumn();ap_out(200,['ok'=>true,'service'=>'Universal AutoPay Connector','version'=>'2.0.0','features'=>['account_registration'=>true,'login'=>true,'sms_ingest'=>true],'sms_policy'=>'Parsed payment fields only; no automatic wallet credit']);}
catch(Throwable $e){error_log('AutoPay health: '.$e->getMessage());ap_out(500,['ok'=>false,'message'=>'Connector database check failed']);}
