# XTREME TITAN OFFICIAL AutoPay — AndroidForge Ready v1.0.5

## AndroidForge upload
This archive is a native Android Gradle project. The Android project files are at the ZIP root:
- `settings.gradle`
- `build.gradle`
- `gradle.properties`
- `app/build.gradle`
- `app/src/main/AndroidManifest.xml`

Upload this ZIP to AndroidForge and choose Android / automatic project detection (or the Android Gradle build option if shown). Do not upload the parent folder containing this ZIP; upload this archive itself.

## App details
- App: XTREME TITAN OFFICIAL AutoPay
- Application ID: `com.xtremetitan.official.autopay`
- Version: `1.0.5` (versionCode 105)
- Native Android Java / Gradle project
- Minimum Android: API 23
- Compile / target SDK: 35
- Payment methods shown in the app: bKash, Nagad, Rocket, Upay
- Website API default: `https://xtremetitanofficial.gamer.free/website-mobile-api`

## Backend setup
Upload the complete `website-mobile-api` folder beside the website's `config.php`.
The app login uses the website account API. Deposit submissions are stored as pending requests; the app does not itself verify MFS payments or credit wallets.

## Important limitations
- SMS reading, notification capture, SMS parsing, automatic transaction matching, and automatic wallet credit are not implemented in this build.
- The included mobile API accepts the four method labels and creates pending deposit requests. This does not prove that a payment was received.
- Keep provider secrets on the server. Use HTTPS and test with a staging database before production.
- The Gradle wrapper scripts and wrapper properties are included. The wrapper JAR is not bundled; AndroidForge's build environment must provide/regenerate the wrapper or use its configured Gradle fallback.

## Build verification
This package has been structurally checked for a root-level Android Gradle project and valid ZIP contents. It has not been compiled into an APK in this environment. If AndroidForge reports a failure, share the full Live log / build log so the exact issue can be fixed.
